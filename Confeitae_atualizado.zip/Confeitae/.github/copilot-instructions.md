# Instruções para GitHub Copilot

Siga `AGENTS.md`. Leia `.agents/skills/ksw-security/SKILL.md` antes de modificar arquivos. Após toda modificação do projeto, atualize a skill canônica `.agents/skills/ksw-security/SKILL.md`, incluindo uma entrada datada em seu histórico mesmo quando a mudança não alterar a postura de segurança. Sincronize com `npm run security:skill:sync` e valide com `npm run security:skill:check`. A verificação usa uma impressão digital SHA-256 e funciona mesmo sem Git. Consulte `AGENTS.md` para todos os requisitos e restrições.
