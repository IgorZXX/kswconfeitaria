'use strict';

const express = require('express');
const crypto = require('crypto');
const Stripe = require('stripe');
const { slugify } = require('../lib/tenant-schema');
const jwt = require('jsonwebtoken');
const db = require('../database');
const rateLimit = require('../middleware/rateLimit');
const { ADMIN_SECRET_KEY, JWT_SECRET, isProd } = require('../lib/config');
const { normalizePlanFeatures, parsePlanFeatures, allPlanFeatures } = require('../lib/plan-features');
const {
  validateSubscriptionChange,
  subscriptionExpiration,
  parsePagination,
  normalizeSearch,
  normalizeTenantStatus,
  subscriptionAccessStatus
} = require('../lib/platform-admin');

const router = express.Router();
const COOKIE_NAME = 'ksw_platform_admin';
const SESSION_SECONDS = 30 * 60;
const ADMIN_ISSUER = 'ksw-platform-admin';
const ADMIN_AUDIENCE = 'ksw-admin-panel';

router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store, private');
  res.set('Pragma', 'no-cache');
  next();
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  key: (req) => `platform-admin-login:${req.ip}`,
  message: 'Muitas tentativas de acesso administrativo. Aguarde 15 minutos.'
});

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null)));
}
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || [])));
}
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function onRun(err) {
    if (err) return reject(err);
    return resolve({ changes: this.changes, lastID: this.lastID });
  }));
}
function decorateSubscription(row) {
  return { ...row, subscription_access_status: subscriptionAccessStatus(row) };
}
function getStripeClient() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key || !key.startsWith('sk_') || /sua_chave|coloque|example/i.test(key)) return null;
  return new Stripe(key);
}
function timingSafeKey(received, expected) {
  if (typeof received !== 'string' || typeof expected !== 'string' || !received || !expected) return false;
  const receivedHash = crypto.createHash('sha256').update(received).digest();
  const expectedHash = crypto.createHash('sha256').update(expected).digest();
  return crypto.timingSafeEqual(receivedHash, expectedHash);
}
function getCookie(req, name) {
  const header = String(req.headers.cookie || '');
  for (const part of header.split(';')) {
    const separator = part.indexOf('=');
    if (separator < 0) continue;
    if (part.slice(0, separator).trim() === name) return part.slice(separator + 1).trim();
  }
  return '';
}
function setSessionCookie(res, token) {
  const pieces = [
    `${COOKIE_NAME}=${token}`,
    'Path=/api/admin',
    `Max-Age=${SESSION_SECONDS}`,
    'HttpOnly',
    'SameSite=Strict'
  ];
  if (isProd) pieces.push('Secure');
  res.set('Set-Cookie', pieces.join('; '));
}
function clearSessionCookie(res) {
  const pieces = [`${COOKIE_NAME}=`, 'Path=/api/admin', 'Max-Age=0', 'HttpOnly', 'SameSite=Strict'];
  if (isProd) pieces.push('Secure');
  res.set('Set-Cookie', pieces.join('; '));
}
function verifySameOrigin(req, res, next) {
  const origin = req.get('origin');
  if (!origin) {
    return res.status(403).json({ error: 'A origem é obrigatória para operações administrativas.' });
  }
  try {
    const normalizedOrigin = String(origin).trim();
    const parsed = new URL(normalizedOrigin);
    const requestHost = String(req.get('host') || '').toLowerCase();
    if (normalizedOrigin !== parsed.origin || parsed.username || parsed.password ||
        !requestHost || parsed.host.toLowerCase() !== requestHost ||
        (isProd && parsed.protocol !== 'https:')) {
      return res.status(403).json({ error: 'Origem da solicitação administrativa não autorizada.' });
    }
    return next();
  } catch (_) {
    return res.status(403).json({ error: 'Origem da solicitação administrativa inválida.' });
  }
}

async function writeAudit(action, targetType, targetId = null, metadata = {}) {
  const safeMetadata = JSON.stringify(metadata);
  await dbRun(
    `INSERT INTO platform_audit_logs (actor, action, target_type, target_id, metadata_json)
     VALUES ('super_admin', ?, ?, ?, ?)`,
    [action, targetType, targetId == null ? null : String(targetId), safeMetadata]
  );
}

async function requireAdminSession(req, res, next) {
  const token = getCookie(req, COOKIE_NAME);
  if (!token) return res.status(401).json({ error: 'Sessão administrativa necessária.' });

  let claims;
  try {
    claims = jwt.verify(token, JWT_SECRET, {
      algorithms: ['HS256'],
      issuer: ADMIN_ISSUER,
      audience: ADMIN_AUDIENCE
    });
  } catch (_) {
    clearSessionCookie(res);
    return res.status(401).json({ error: 'Sessão administrativa inválida ou expirada.' });
  }

  if (!claims || claims.type !== 'ksw_super_admin' || !/^[a-f0-9]{48}$/i.test(String(claims.jti || ''))) {
    clearSessionCookie(res);
    return res.status(401).json({ error: 'Sessão administrativa inválida.' });
  }

  try {
    const session = await dbGet(
      `SELECT id, expires_at FROM platform_admin_sessions
        WHERE id = ? AND revoked_at IS NULL AND datetime(expires_at) > CURRENT_TIMESTAMP`,
      [claims.jti]
    );
    if (!session) {
      clearSessionCookie(res);
      return res.status(401).json({ error: 'Sessão administrativa encerrada ou expirada.' });
    }
    req.adminSession = { id: session.id, expires_at: session.expires_at };
    return next();
  } catch (error) {
    console.error('Falha ao validar sessão administrativa:', error);
    return res.status(500).json({ error: 'Não foi possível validar a sessão administrativa.' });
  }
}

// A chave mestra é usada somente para iniciar uma sessão curta. As demais rotas
// aceitam apenas cookie HttpOnly, SameSite=Strict, com JTI revogável no SQLite.
router.post('/session', verifySameOrigin, loginLimiter, async (req, res) => {
  const suppliedKey = req.get('x-admin-key');
  if (!timingSafeKey(suppliedKey, ADMIN_SECRET_KEY)) {
    return res.status(403).json({ error: 'Acesso administrativo negado.' });
  }

  const sessionId = crypto.randomBytes(24).toString('hex');
  const expiration = new Date(Date.now() + SESSION_SECONDS * 1000).toISOString();
  try {
    const token = jwt.sign(
      { type: 'ksw_super_admin', role: 'super_admin' },
      JWT_SECRET,
      { algorithm: 'HS256', expiresIn: SESSION_SECONDS, issuer: ADMIN_ISSUER, audience: ADMIN_AUDIENCE, jwtid: sessionId }
    );
    await db.withTransaction(async (tx) => {
      await tx.run(
        `INSERT INTO platform_admin_sessions (id, expires_at) VALUES (?, ?)`,
        [sessionId, expiration]
      );
      await tx.run(
        `DELETE FROM platform_admin_sessions
          WHERE datetime(expires_at) <= CURRENT_TIMESTAMP
             OR (revoked_at IS NOT NULL AND datetime(revoked_at) < datetime('now', '-2 days'))`
      );
      await tx.run(
        `INSERT INTO platform_audit_logs (actor, action, target_type, target_id, metadata_json)
         VALUES ('super_admin', 'admin.session_created', 'session', ?, '{}')`,
        [sessionId]
      );
    });
    setSessionCookie(res, token);
    return res.status(200).json({ authenticated: true, role: 'super_admin', expires_at: expiration });
  } catch (error) {
    console.error('Falha ao criar sessão administrativa:', error);
    return res.status(500).json({ error: 'Não foi possível iniciar o painel administrativo.' });
  }
});

router.use(requireAdminSession);
router.use((req, res, next) => {
  if (['POST', 'PATCH', 'PUT', 'DELETE'].includes(req.method)) return verifySameOrigin(req, res, next);
  return next();
});

router.get('/session', (req, res) => {
  res.json({ authenticated: true, role: 'super_admin', expires_at: req.adminSession.expires_at });
});

router.delete('/session', async (req, res) => {
  try {
    await dbRun('UPDATE platform_admin_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE id = ? AND revoked_at IS NULL', [req.adminSession.id]);
    await writeAudit('admin.session_revoked', 'session', req.adminSession.id);
    clearSessionCookie(res);
    return res.json({ ok: true, message: 'Sessão administrativa encerrada.' });
  } catch (error) {
    console.error('Falha ao encerrar sessão administrativa:', error);
    return res.status(500).json({ error: 'Não foi possível encerrar a sessão administrativa.' });
  }
});

router.get('/overview', async (req, res) => {
  try {
    const [tenantStats, userStats, subscriptionRows, orderStats, recentTenants] = await Promise.all([
      dbGet(`SELECT COUNT(*) AS total,
                    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active,
                    SUM(CASE WHEN status = 'suspended' THEN 1 ELSE 0 END) AS suspended
               FROM tenants`),
      dbGet('SELECT COUNT(*) AS total FROM users'),
      dbAll(`SELECT DISTINCT owner.plano_tipo, owner.status_assinatura, owner.data_vencimento,
                    billing.billing_interval, billing.price_cents
               FROM tenants t JOIN users owner ON owner.id = t.owner_user_id
               LEFT JOIN platform_plans billing ON billing.plan_key = owner.plano_tipo`),
      dbGet(`SELECT COUNT(*) AS total_orders,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS approved_orders,
                    COALESCE(SUM(CASE WHEN status = 'approved' THEN valor ELSE 0 END), 0) AS approved_revenue,
                    SUM(CASE WHEN status IN ('pending', 'in_process') THEN 1 ELSE 0 END) AS pending_orders
               FROM orders`),
      dbAll(`SELECT t.id, t.nome, t.status, t.created_at, u.nome AS owner_name, u.email AS owner_email,
                    owner.plano_tipo, owner.status_assinatura, owner.data_vencimento,
                    billing.billing_interval, billing.billing_interval_count, billing.name AS plan_name,
                    (SELECT COUNT(*) FROM tenant_memberships tm WHERE tm.tenant_id = t.id AND tm.status = 'active') AS members_count
               FROM tenants t JOIN users u ON u.id = t.owner_user_id
               JOIN users owner ON owner.id = t.owner_user_id
               LEFT JOIN platform_plans billing ON billing.plan_key = owner.plano_tipo
              ORDER BY t.created_at DESC, t.id DESC LIMIT 6`)
    ]);
    const decoratedRecent = recentTenants.map(decorateSubscription);
    const activeSubscriptions = subscriptionRows.filter((row) => subscriptionAccessStatus(row) === 'ativa');
    const monthlyActive = activeSubscriptions.filter((row) => (row.billing_interval || (['mensal', 'anual', 'teste', 'teste_gratis'].includes(row.plano_tipo) ? 'month' : null)) === 'month');
    const lifetimeActive = activeSubscriptions.filter((row) => (row.billing_interval || (row.plano_tipo === 'vitalicio' ? 'once' : null)) === 'once');
    const mrrCents = monthlyActive.reduce((total, row) => total + Math.round((Number(row.price_cents) || 0) / Math.max(1, Number(row.billing_interval_count) || 1)), 0);
    return res.json({
      metrics: {
        companies_total: Number(tenantStats && tenantStats.total) || 0,
        companies_active: Number(tenantStats && tenantStats.active) || 0,
        companies_suspended: Number(tenantStats && tenantStats.suspended) || 0,
        users_total: Number(userStats && userStats.total) || 0,
        subscriptions_active: activeSubscriptions.length,
        monthly_active: monthlyActive.length,
        lifetime_active: lifetimeActive.length,
        estimated_mrr_cents: mrrCents,
        approved_orders: Number(orderStats && orderStats.approved_orders) || 0,
        approved_revenue_cents: Math.round((Number(orderStats && orderStats.approved_revenue) || 0) * 100),
        pending_orders: Number(orderStats && orderStats.pending_orders) || 0
      },
      recent_companies: decoratedRecent
    });
  } catch (error) {
    console.error('Falha ao carregar visão geral da plataforma:', error);
    return res.status(500).json({ error: 'Não foi possível carregar os indicadores da plataforma.' });
  }
});

router.get('/tenants', async (req, res) => {
  const { limit, offset } = parsePagination(req.query);
  const search = normalizeSearch(req.query.search);
  const status = normalizeTenantStatus(req.query.status);
  const conditions = [];
  const params = [];
  if (search) {
    conditions.push('(t.nome LIKE ? OR t.slug LIKE ? OR owner.nome LIKE ? OR owner.email LIKE ?)');
    const value = `%${search}%`;
    params.push(value, value, value, value);
  }
  if (status) { conditions.push('t.status = ?'); params.push(status); }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  try {
    const rows = await dbAll(
      `SELECT t.id, t.nome, t.slug, t.status, t.suspended_at, t.suspended_reason, t.created_at,
              owner.id AS owner_user_id, owner.nome AS owner_name, owner.email AS owner_email,
              owner.plano_tipo, owner.status_assinatura, owner.data_vencimento,
              billing.billing_interval, billing.billing_interval_count, billing.name AS plan_name,
              (SELECT COUNT(*) FROM tenant_memberships tm WHERE tm.tenant_id = t.id AND tm.status = 'active') AS members_count
         FROM tenants t JOIN users owner ON owner.id = t.owner_user_id
         LEFT JOIN platform_plans billing ON billing.plan_key = owner.plano_tipo
         ${where}
        ORDER BY t.created_at DESC, t.id DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    const totalRow = await dbGet(
      `SELECT COUNT(*) AS total FROM tenants t JOIN users owner ON owner.id = t.owner_user_id ${where}`,
      params
    );
    return res.json({ tenants: rows.map(decorateSubscription), pagination: { limit, offset, total: Number(totalRow && totalRow.total) || 0 } });
  } catch (error) {
    console.error('Falha ao listar empresas:', error);
    return res.status(500).json({ error: 'Não foi possível listar as empresas.' });
  }
});

router.get('/tenants/:id', async (req, res) => {
  const tenantId = Number(req.params.id);
  if (!Number.isSafeInteger(tenantId) || tenantId <= 0) return res.status(400).json({ error: 'Identificador de empresa inválido.' });
  try {
    const tenant = await dbGet(
      `SELECT t.id, t.nome, t.slug, t.status, t.suspended_at, t.suspended_reason, t.created_at,
              owner.id AS owner_user_id, owner.nome AS owner_name, owner.email AS owner_email,
              owner.plano_tipo, owner.status_assinatura, owner.data_vencimento,
              billing.billing_interval, billing.billing_interval_count, billing.name AS plan_name
         FROM tenants t JOIN users owner ON owner.id = t.owner_user_id
         LEFT JOIN platform_plans billing ON billing.plan_key = owner.plano_tipo WHERE t.id = ?`,
      [tenantId]
    );
    if (!tenant) return res.status(404).json({ error: 'Empresa não encontrada.' });
    const members = await dbAll(
      `SELECT u.id AS user_id, u.nome, u.email, tm.role, tm.status, tm.created_at
         FROM tenant_memberships tm JOIN users u ON u.id = tm.user_id
        WHERE tm.tenant_id = ? ORDER BY CASE tm.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, u.nome COLLATE NOCASE`,
      [tenantId]
    );
    return res.json({ tenant: decorateSubscription(tenant), members });
  } catch (error) {
    console.error('Falha ao consultar empresa:', error);
    return res.status(500).json({ error: 'Não foi possível consultar a empresa.' });
  }
});

router.patch('/tenants/:id/status', async (req, res) => {
  const tenantId = Number(req.params.id);
  const status = normalizeTenantStatus(req.body && req.body.status);
  const reason = normalizeSearch(req.body && req.body.reason, 300);
  if (!Number.isSafeInteger(tenantId) || tenantId <= 0) return res.status(400).json({ error: 'Identificador de empresa inválido.' });
  if (!status) return res.status(400).json({ error: 'Status deve ser active ou suspended.' });
  if (status === 'suspended' && reason.length < 4) return res.status(400).json({ error: 'Informe um motivo com pelo menos 4 caracteres para suspender a empresa.' });

  try {
    await db.withTransaction(async (tx) => {
      const tenant = await tx.get('SELECT id, status FROM tenants WHERE id = ?', [tenantId]);
      if (!tenant) {
        const error = new Error('Empresa não encontrada.'); error.status = 404; throw error;
      }
      await tx.run(
        `UPDATE tenants SET status = ?, suspended_at = ?, suspended_reason = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [status, status === 'suspended' ? new Date().toISOString() : null, status === 'suspended' ? reason : null, tenantId]
      );
      await tx.run(
        `INSERT INTO platform_audit_logs (actor, action, target_type, target_id, metadata_json)
         VALUES ('super_admin', ?, 'tenant', ?, ?)`,
        [status === 'suspended' ? 'tenant.suspended' : 'tenant.reactivated', String(tenantId), JSON.stringify({ previous_status: tenant.status, status, reason: status === 'suspended' ? reason : null })]
      );
    });
    return res.json({ ok: true, tenant_id: tenantId, status });
  } catch (error) {
    const statusCode = error.status || 500;
    if (statusCode >= 500) console.error('Falha ao alterar status da empresa:', error);
    return res.status(statusCode).json({ error: statusCode === 404 ? error.message : 'Não foi possível alterar o status da empresa.' });
  }
});

router.get('/users', async (req, res) => {
  const { limit, offset } = parsePagination(req.query);
  const search = normalizeSearch(req.query.search);
  const where = search ? 'WHERE u.nome LIKE ? OR u.username LIKE ? OR u.email LIKE ?' : '';
  const params = search ? [`%${search}%`, `%${search}%`, `%${search}%`] : [];
  try {
    const users = await dbAll(
      `SELECT u.id, u.nome, u.username, u.email, u.whatsapp, u.role, u.plano_tipo, u.status_assinatura, u.data_vencimento, u.created_at,
              COUNT(DISTINCT tm.tenant_id) AS companies_count,
              GROUP_CONCAT(DISTINCT t.nome) AS company_names
         FROM users u
         LEFT JOIN tenant_memberships tm ON tm.user_id = u.id AND tm.status = 'active'
         LEFT JOIN tenants t ON t.id = tm.tenant_id
         ${where}
        GROUP BY u.id ORDER BY u.created_at DESC, u.id DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    const total = await dbGet(`SELECT COUNT(*) AS total FROM users u ${where}`, params);
    return res.json({ users, pagination: { limit, offset, total: Number(total && total.total) || 0 } });
  } catch (error) {
    console.error('Falha ao listar contas:', error);
    return res.status(500).json({ error: 'Não foi possível listar as contas.' });
  }
});

router.get('/subscriptions', async (req, res) => {
  const { limit, offset } = parsePagination(req.query);
  const status = normalizeSearch(req.query.status, 20);
  const where = status ? 'WHERE owner.status_assinatura = ?' : '';
  const params = status ? [status] : [];
  try {
    const subscriptions = await dbAll(
      `SELECT t.id AS tenant_id, t.nome AS tenant_name, t.status AS tenant_status,
              owner.id AS owner_user_id, owner.nome AS owner_name, owner.email AS owner_email,
              owner.plano_tipo, owner.status_assinatura, owner.data_vencimento, owner.subscription_id_gateway,
              billing.billing_interval, billing.billing_interval_count, billing.name AS plan_name, billing.price_cents,
              (SELECT o.gateway FROM orders o WHERE o.user_id = owner.id ORDER BY o.created_at DESC, o.id DESC LIMIT 1) AS last_gateway,
              (SELECT o.status FROM orders o WHERE o.user_id = owner.id ORDER BY o.created_at DESC, o.id DESC LIMIT 1) AS last_order_status,
              (SELECT o.valor FROM orders o WHERE o.user_id = owner.id ORDER BY o.created_at DESC, o.id DESC LIMIT 1) AS last_order_value
         FROM tenants t JOIN users owner ON owner.id = t.owner_user_id
         LEFT JOIN platform_plans billing ON billing.plan_key = owner.plano_tipo
         ${where}
        ORDER BY owner.created_at DESC, t.id DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    const total = await dbGet(
      `SELECT COUNT(*) AS total FROM tenants t JOIN users owner ON owner.id = t.owner_user_id ${where}`,
      params
    );
    return res.json({ subscriptions: subscriptions.map(decorateSubscription), pagination: { limit, offset, total: Number(total && total.total) || 0 } });
  } catch (error) {
    console.error('Falha ao listar assinaturas:', error);
    return res.status(500).json({ error: 'Não foi possível listar as assinaturas.' });
  }
});

async function applySubscriptionChange(userId, input, auditTargetType, auditTargetId) {
  const planKey = String(input && input.plano_tipo || '').trim();
  const planRow = planKey === 'free' ? null : await dbGet(
    'SELECT plan_key, billing_interval, billing_interval_count FROM platform_plans WHERE plan_key = ?', [planKey]
  );
  const allowedPlans = new Set(['free', ...((await dbAll('SELECT plan_key FROM platform_plans')).map((row) => row.plan_key))]);
  const recurringPlans = new Set(['mensal', 'anual', 'teste', 'teste_gratis']);
  if (planRow && planRow.billing_interval === 'month') recurringPlans.add(planKey);
  const validation = validateSubscriptionChange(input, allowedPlans, recurringPlans);
  if (!validation.ok) { const error = new Error(validation.error); error.status = 400; throw error; }
  const { plan, status, days } = validation.value;
  const interval = planRow ? planRow.billing_interval : (plan === 'vitalicio' ? 'once' : null);
  const expiration = subscriptionExpiration(plan, status, days, Date.now(), interval);
  await db.withTransaction(async (tx) => {
    const user = await tx.get('SELECT id, plano_tipo, status_assinatura FROM users WHERE id = ?', [userId]);
    if (!user) { const error = new Error('Conta não encontrada.'); error.status = 404; throw error; }
    await tx.run(
      `UPDATE users SET plano_tipo = ?, status_assinatura = ?, data_vencimento = ? WHERE id = ?`,
      [plan, status, expiration, userId]
    );
    await tx.run(
      `INSERT INTO platform_audit_logs (actor, action, target_type, target_id, metadata_json)
       VALUES ('super_admin', 'subscription.manually_updated', ?, ?, ?)`,
      [auditTargetType, String(auditTargetId), JSON.stringify({ user_id: userId, previous_plan: user.plano_tipo, previous_status: user.status_assinatura, plan, status, days, billing_interval: interval })]
    );
  });
}

router.patch('/tenants/:id/subscription', async (req, res) => {
  const tenantId = Number(req.params.id);
  if (!Number.isSafeInteger(tenantId) || tenantId <= 0) return res.status(400).json({ error: 'Identificador de empresa inválido.' });
  try {
    const tenant = await dbGet('SELECT owner_user_id FROM tenants WHERE id = ?', [tenantId]);
    if (!tenant) return res.status(404).json({ error: 'Empresa não encontrada.' });
    await applySubscriptionChange(Number(tenant.owner_user_id), req.body || {}, 'tenant', tenantId);
    return res.json({ ok: true, message: 'Acesso da empresa atualizado. A alteração manual não modifica a cobrança no gateway.' });
  } catch (error) {
    const statusCode = error.status || 500;
    if (statusCode >= 500) console.error('Falha ao atualizar assinatura da empresa:', error);
    return res.status(statusCode).json({ error: statusCode >= 500 ? 'Não foi possível atualizar a assinatura.' : error.message });
  }
});

// Compatibilidade para a tela de administração anterior, agora protegida pela sessão curta.
router.post('/users/:id/update-subscription', async (req, res) => {
  const userId = Number(req.params.id);
  if (!Number.isSafeInteger(userId) || userId <= 0) return res.status(400).json({ error: 'Identificador de conta inválido.' });
  try {
    await applySubscriptionChange(userId, req.body || {}, 'user', userId);
    return res.json({ ok: true, message: 'Assinatura atualizada no KSW. A cobrança no gateway não foi modificada.' });
  } catch (error) {
    const statusCode = error.status || 500;
    if (statusCode >= 500) console.error('Falha ao atualizar assinatura:', error);
    return res.status(statusCode).json({ error: statusCode >= 500 ? 'Não foi possível atualizar a assinatura.' : error.message });
  }
});

router.get('/plans', async (req, res) => {
  try {
    const rows = await dbAll(
      `SELECT plan_key, name, description, price_cents, currency, billing_interval,
              billing_interval_count, max_members, features_json, is_active, is_deleted,
              is_system, updated_at, stripe_product_id, stripe_price_id
         FROM platform_plans ORDER BY is_deleted ASC, CASE plan_key WHEN 'mensal' THEN 1 WHEN 'anual' THEN 2 WHEN 'vitalicio' THEN 3 WHEN 'teste_gratis' THEN 4 ELSE 5 END, name COLLATE NOCASE`
    );
    const plans = rows.map((plan) => ({
      ...plan,
      max_members: Number(plan.max_members) || 0,
      features: parsePlanFeatures(plan.features_json),
      has_stripe_price: Boolean(plan.stripe_price_id ||
        (plan.plan_key === 'mensal' && process.env.STRIPE_MONTHLY_PRICE_ID) ||
        (plan.plan_key === 'vitalicio' && process.env.STRIPE_LIFETIME_PRICE_ID)) ? 1 : 0
    }));
    return res.json({
      plans,
      stripe_configured: Boolean(getStripeClient()),
      feature_catalog: require('../lib/plan-features').FEATURE_CATALOG,
      price_management: 'O preço pode ser atualizado criando um novo preço na Stripe; cobranças e assinaturas antigas não são reescritas.'
    });
  } catch (error) {
    console.error('Falha ao listar planos:', error);
    return res.status(500).json({ error: 'Não foi possível carregar os planos.' });
  }
});

function validatePlanFields(input, existing = null) {
  const name = String(input.name == null ? (existing && existing.name) || '' : input.name).trim();
  const description = String(input.description == null ? (existing && existing.description) || '' : input.description).trim();
  const interval = String(input.billing_interval == null ? (existing && existing.billing_interval) || 'month' : input.billing_interval);
  const intervalCount = Number(input.billing_interval_count == null ? (existing && existing.billing_interval_count) || 1 : input.billing_interval_count);
  const price = Number(input.price_cents == null ? (existing && existing.price_cents) || 0 : input.price_cents);
  const maxMembers = Number(input.max_members == null ? (existing && existing.max_members) ?? 1 : input.max_members);
  if (name.length < 3 || name.length > 80 || description.length > 500) return { error: 'Informe um nome de 3 a 80 caracteres e uma descrição de até 500 caracteres.' };
  if (!Number.isSafeInteger(price) || price < 0 || price > 100000000) return { error: 'O preço deve estar entre R$ 0,00 e R$ 1.000.000,00.' };
  if (!['month', 'once'].includes(interval) || !Number.isInteger(intervalCount) || intervalCount < 1 || intervalCount > 12 || (interval === 'once' && intervalCount !== 1)) {
    return { error: 'Periodicidade inválida. Use pagamento único ou cobrança mensal com intervalo de 1 a 12 meses.' };
  }
  if (!Number.isInteger(maxMembers) || maxMembers < 0 || maxMembers > 500) return { error: 'O limite de acessos deve ser de 0 a 500. Use 0 para ilimitado.' };
  const features = normalizePlanFeatures(input.features == null ? (existing && existing.features) || [] : input.features);
  if (input.features != null && !Array.isArray(input.features)) return { error: 'A lista de funcionalidades é inválida.' };
  return { value: { name, description, interval, intervalCount, price, maxMembers, features } };
}

router.post('/plans', async (req, res) => {
  const fields = validatePlanFields(req.body || {});
  if (fields.error) return res.status(400).json({ error: fields.error });
  const value = fields.value;
  const baseKey = slugify(value.name).slice(0, 36) || 'plano';
  let planKey = baseKey;
  let suffix = 2;
  try {
    while (await dbGet('SELECT plan_key FROM platform_plans WHERE plan_key = ?', [planKey])) {
      planKey = `${baseKey.slice(0, 40 - String(suffix).length - 1)}-${suffix++}`;
    }

    let product = null;
    let stripePrice = null;
    const stripe = getStripeClient();
    if (stripe && value.price > 0) {
      product = await stripe.products.create({
        name: value.name,
        description: value.description || undefined,
        metadata: { platform: 'ksw-confeitaria', plan_key: planKey }
      }, { idempotencyKey: `ksw-product-${crypto.randomUUID()}` });
      stripePrice = await stripe.prices.create({
        product: product.id,
        unit_amount: value.price,
        currency: 'brl',
        ...(value.interval === 'month' ? { recurring: { interval: 'month', interval_count: value.intervalCount } } : {})
      }, { idempotencyKey: `ksw-price-${crypto.randomUUID()}` });
    }

    const active = Boolean(stripePrice);
    await dbRun(
      `INSERT INTO platform_plans
       (plan_key, name, description, price_cents, currency, billing_interval, billing_interval_count,
        max_members, features_json, stripe_product_id, stripe_price_id, is_active, is_deleted, is_system, updated_at)
       VALUES (?, ?, ?, ?, 'BRL', ?, ?, ?, ?, ?, ?, ?, 0, 0, CURRENT_TIMESTAMP)`,
      [planKey, value.name, value.description, value.price, value.interval, value.intervalCount,
        value.maxMembers, JSON.stringify(value.features), product && product.id, stripePrice && stripePrice.id, active ? 1 : 0]
    );
    await writeAudit('plan.created', 'plan', planKey, {
      name: value.name, price_cents: value.price, billing_interval: value.interval,
      billing_interval_count: value.intervalCount, max_members: value.maxMembers,
      features: value.features.map((feature) => feature.key), stripe_price_id: stripePrice && stripePrice.id
    });
    return res.status(201).json({
      ok: true,
      plan: { plan_key: planKey, ...value, currency: 'BRL', is_active: active ? 1 : 0, has_stripe_price: active ? 1 : 0 }
    });
  } catch (error) {
    console.error('Falha ao criar plano:', error.message);
    return res.status(502).json({ error: 'Não foi possível salvar o plano. Confira os dados e a configuração da Stripe.' });
  }
});

router.patch('/plans/:planKey', async (req, res) => {
  const planKey = String(req.params.planKey || '');
  const input = req.body || {};
  try {
    const existing = await dbGet('SELECT * FROM platform_plans WHERE plan_key = ? AND is_deleted = 0', [planKey]);
    if (!existing) return res.status(404).json({ error: 'Plano não encontrado.' });
    const existingFeatures = parsePlanFeatures(existing.features_json);
    const fields = validatePlanFields({
      ...input,
      features: input.features == null ? existingFeatures : input.features
    }, { ...existing, features: existingFeatures });
    if (fields.error) return res.status(400).json({ error: fields.error });
    let value = fields.value;

    if (planKey === 'mensal') {
      if (value.maxMembers < 3) return res.status(400).json({ error: 'O plano Mensal precisa permitir pelo menos 3 pessoas com acesso (proprietário + 2 membros).' });
      if (!value.features.some((feature) => feature.key === 'team')) {
        const teamFeature = normalizePlanFeatures([{ key: 'team' }])[0];
        value = { ...value, features: value.features.concat(teamFeature) };
      }
    }

    if (planKey === 'vitalicio') {
      value = { ...value, features: allPlanFeatures(), maxMembers: 0, interval: 'once', intervalCount: 1 };
    }
    if (planKey === 'teste_gratis') {
      value = { ...value, features: allPlanFeatures(), maxMembers: 0, price: 0, interval: 'month', intervalCount: 1 };
    }

    const priceChanged = value.price !== Number(existing.price_cents) || value.interval !== existing.billing_interval || value.intervalCount !== Number(existing.billing_interval_count || 1);
    let productId = existing.stripe_product_id || null;
    let priceId = existing.stripe_price_id || null;
    let active = Number(existing.is_active) === 1;
    const stripe = getStripeClient();

    if ((priceChanged || (value.price > 0 && !priceId)) && planKey !== 'teste_gratis') {
      if (stripe && value.price > 0) {
        let product;
        if (productId) {
          product = await stripe.products.update(productId, { name: value.name, description: value.description || '' });
        } else {
          product = await stripe.products.create({
            name: value.name, description: value.description || undefined,
            metadata: { platform: 'ksw-confeitaria', plan_key: planKey }
          }, { idempotencyKey: `ksw-product-${crypto.randomUUID()}` });
          productId = product.id;
        }
        const newPrice = await stripe.prices.create({
          product: product.id,
          unit_amount: value.price,
          currency: 'brl',
          ...(value.interval === 'month' ? { recurring: { interval: 'month', interval_count: value.intervalCount } } : {})
        }, { idempotencyKey: `ksw-price-${crypto.randomUUID()}` });
        const oldPriceId = priceId;
        priceId = newPrice.id;
        if (oldPriceId && oldPriceId !== priceId) {
          await stripe.prices.update(oldPriceId, { active: false }).catch((error) => console.warn('Preço antigo mantido ativo na Stripe:', error.message));
        }
        active = true;
      } else {
        // Keep the draft editable without Stripe, but do not expose a broken checkout.
        priceId = null;
        active = false;
      }
    }

    if (typeof input.is_active === 'boolean') {
      if (input.is_active && value.price > 0 && !priceId && !(planKey === 'mensal' && process.env.STRIPE_MONTHLY_PRICE_ID) && !(planKey === 'vitalicio' && process.env.STRIPE_LIFETIME_PRICE_ID)) {
        return res.status(409).json({ error: 'Configure a Stripe e crie um preço antes de ativar as vendas deste plano.' });
      }
      if (planKey !== 'teste_gratis') active = input.is_active;
    }

    if (planKey === 'teste_gratis') active = true;
    const result = await dbRun(
      `UPDATE platform_plans
          SET name = ?, description = ?, price_cents = ?, billing_interval = ?, billing_interval_count = ?,
              max_members = ?, features_json = ?, stripe_product_id = ?, stripe_price_id = ?,
              is_active = ?, updated_at = CURRENT_TIMESTAMP
        WHERE plan_key = ? AND is_deleted = 0`,
      [value.name, value.description, value.price, value.interval, value.intervalCount,
        value.maxMembers, JSON.stringify(value.features), productId, priceId, active ? 1 : 0, planKey]
    );
    if (!result.changes) return res.status(404).json({ error: 'Plano não encontrado.' });
    await writeAudit('plan.updated', 'plan', planKey, {
      fields: Object.keys(input), price_cents: value.price, max_members: value.maxMembers,
      features: value.features.map((feature) => feature.key), is_active: active
    });
    return res.json({ ok: true, plan_key: planKey, is_active: active });
  } catch (error) {
    console.error('Falha ao atualizar plano:', error.message);
    return res.status(502).json({ error: 'Não foi possível atualizar o plano. Verifique a configuração da Stripe e tente novamente.' });
  }
});

router.delete('/plans/:planKey', async (req, res) => {
  const planKey = String(req.params.planKey || '');
  if (['vitalicio', 'teste_gratis'].includes(planKey)) {
    return res.status(409).json({ error: 'Este plano é essencial para o funcionamento do KSW e não pode ser removido.' });
  }
  try {
    const plan = await dbGet('SELECT plan_key, stripe_price_id, stripe_product_id FROM platform_plans WHERE plan_key = ? AND is_deleted = 0', [planKey]);
    if (!plan) return res.status(404).json({ error: 'Plano não encontrado.' });
    const stripe = getStripeClient();
    if (stripe && plan.stripe_price_id) await stripe.prices.update(plan.stripe_price_id, { active: false }).catch(() => {});
    if (stripe && plan.stripe_product_id) await stripe.products.update(plan.stripe_product_id, { active: false }).catch(() => {});
    await dbRun(
      `UPDATE platform_plans SET is_active = 0, is_deleted = 1, updated_at = CURRENT_TIMESTAMP WHERE plan_key = ?`,
      [planKey]
    );
    await writeAudit('plan.removed', 'plan', planKey, { stripe_product_id: plan.stripe_product_id || null });
    return res.json({ ok: true, message: 'Plano removido das novas contratações. O histórico de assinaturas e pagamentos foi preservado.' });
  } catch (error) {
    console.error('Falha ao remover plano:', error.message);
    return res.status(500).json({ error: 'Não foi possível remover o plano.' });
  }
});

router.get('/orders', async (req, res) => {
  const { limit, offset } = parsePagination(req.query);
  try {
    const orders = await dbAll(
      `SELECT o.id, o.user_id, o.plano_tipo, o.valor, o.status, o.gateway,
              o.external_reference, o.payment_id, o.created_at, u.nome AS user_nome, u.email AS user_email
         FROM orders o JOIN users u ON u.id = o.user_id
        ORDER BY o.created_at DESC, o.id DESC LIMIT ? OFFSET ?`,
      [limit, offset]
    );
    const total = await dbGet('SELECT COUNT(*) AS total FROM orders');
    return res.json({ orders, pagination: { limit, offset, total: Number(total && total.total) || 0 } });
  } catch (error) {
    console.error('Falha ao listar pagamentos:', error);
    return res.status(500).json({ error: 'Não foi possível carregar os pagamentos.' });
  }
});

router.get('/audit', async (req, res) => {
  const { limit, offset } = parsePagination(req.query);
  try {
    const entries = await dbAll(
      `SELECT id, actor, action, target_type, target_id, metadata_json, created_at
         FROM platform_audit_logs ORDER BY id DESC LIMIT ? OFFSET ?`,
      [limit, offset]
    );
    const total = await dbGet('SELECT COUNT(*) AS total FROM platform_audit_logs');
    return res.json({ entries: entries.map((entry) => ({ ...entry, metadata: safeParseJson(entry.metadata_json) })), pagination: { limit, offset, total: Number(total && total.total) || 0 } });
  } catch (error) {
    console.error('Falha ao consultar auditoria da plataforma:', error);
    return res.status(500).json({ error: 'Não foi possível carregar a auditoria.' });
  }
});

function safeParseJson(value) {
  try { return JSON.parse(value || '{}'); } catch (_) { return {}; }
}


// Caixa de entrada do chat do plano Vitalício / teste completo.
router.get('/support/threads', async (req, res) => {
  try {
    const threads = await dbAll(`
      SELECT t.id, t.tenant_id, t.status, t.created_at, t.updated_at, t.last_message_at,
             company.nome AS tenant_name, owner.nome AS owner_name, owner.email AS owner_email,
             (SELECT COUNT(*) FROM platform_support_messages m
               WHERE m.thread_id = t.id AND m.sender_type = 'owner' AND m.read_at IS NULL) AS unread_count,
             (SELECT body FROM platform_support_messages m
               WHERE m.thread_id = t.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_message,
             (SELECT sender_type FROM platform_support_messages m
               WHERE m.thread_id = t.id ORDER BY m.created_at DESC, m.id DESC LIMIT 1) AS last_sender_type
        FROM platform_support_threads t
        JOIN tenants company ON company.id = t.tenant_id
        JOIN users owner ON owner.id = t.owner_user_id
       ORDER BY COALESCE(t.last_message_at, t.updated_at) DESC, t.id DESC LIMIT 100`);
    return res.json({ threads });
  } catch (error) {
    console.error('Falha ao listar conversas de suporte:', error);
    return res.status(500).json({ error: 'Não foi possível carregar as conversas de suporte.' });
  }
});

router.get('/support/threads/:threadId', async (req, res) => {
  const threadId = Number(req.params.threadId);
  if (!Number.isSafeInteger(threadId) || threadId <= 0) return res.status(400).json({ error: 'Conversa inválida.' });
  try {
    const thread = await dbGet(`
      SELECT t.id, t.tenant_id, t.status, t.created_at, company.nome AS tenant_name,
             owner.nome AS owner_name, owner.email AS owner_email
        FROM platform_support_threads t
        JOIN tenants company ON company.id = t.tenant_id
        JOIN users owner ON owner.id = t.owner_user_id
       WHERE t.id = ?`, [threadId]);
    if (!thread) return res.status(404).json({ error: 'Conversa não encontrada.' });
    await dbRun(`UPDATE platform_support_messages SET read_at = CURRENT_TIMESTAMP
                  WHERE thread_id = ? AND sender_type = 'owner' AND read_at IS NULL`, [threadId]);
    const messages = await dbAll(`SELECT id, sender_type, body, read_at, created_at
                                    FROM platform_support_messages
                                   WHERE thread_id = ? ORDER BY created_at ASC, id ASC LIMIT 200`, [threadId]);
    return res.json({ thread, messages });
  } catch (error) {
    console.error('Falha ao abrir conversa de suporte:', error);
    return res.status(500).json({ error: 'Não foi possível abrir esta conversa.' });
  }
});

router.post('/support/threads/:threadId/messages', async (req, res) => {
  const threadId = Number(req.params.threadId);
  const body = String((req.body && req.body.body) || '').trim();
  if (!Number.isSafeInteger(threadId) || threadId <= 0) return res.status(400).json({ error: 'Conversa inválida.' });
  if (!body || body.length > 4000) return res.status(400).json({ error: 'A resposta deve ter entre 1 e 4.000 caracteres.' });
  try {
    const message = await db.withTransaction(async (tx) => {
      const thread = await tx.get('SELECT id, tenant_id FROM platform_support_threads WHERE id = ?', [threadId]);
      if (!thread) return null;
      const inserted = await tx.run(
        `INSERT INTO platform_support_messages (thread_id, tenant_id, sender_type, sender_user_id, body)
         VALUES (?, ?, 'admin', NULL, ?)`, [threadId, thread.tenant_id, body]
      );
      await tx.run(`UPDATE platform_support_threads SET status = 'open', updated_at = CURRENT_TIMESTAMP,
                     last_message_at = CURRENT_TIMESTAMP WHERE id = ?`, [threadId]);
      return { id: Number(inserted.lastID), sender_type: 'admin', body, created_at: new Date().toISOString() };
    });
    if (!message) return res.status(404).json({ error: 'Conversa não encontrada.' });
    await writeAudit('support.replied', 'support_thread', threadId, { message_id: message.id });
    return res.status(201).json({ ok: true, message });
  } catch (error) {
    console.error('Falha ao responder conversa de suporte:', error);
    return res.status(500).json({ error: 'Não foi possível enviar a resposta.' });
  }
});

module.exports = router;
module.exports.validateSubscriptionChange = validateSubscriptionChange;
module.exports.subscriptionExpiration = subscriptionExpiration;
module.exports.parsePagination = parsePagination;
module.exports.timingSafeKey = timingSafeKey;
