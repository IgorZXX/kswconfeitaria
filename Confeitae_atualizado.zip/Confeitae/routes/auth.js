const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');

const rateLimit = require('../middleware/rateLimit');
const { JWT_SECRET } = require('../lib/config');
const { listUserTenants } = require('../lib/tenant-service');
const { slugify } = require('../lib/tenant-schema');
const { normalizeUsername } = require('../lib/auth-schema');
const { sendVerificationEmail, isEmailDeliveryConfigured, escapeHtml } = require('../lib/email-delivery');
const { formatSqliteDateTime } = require('../lib/tenant-schema');
const { normalizeCookieConsent } = require('../lib/cookie-consent');

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const isText = (value, max) => typeof value === 'string' && value.length <= max;

// Freio contra força bruta: por IP + e-mail no login, por IP no cadastro e na redefinição.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  key: (req) => `${req.ip}|${String((req.body && req.body.email) || '').toLowerCase().slice(0, 120)}`,
  message: 'Muitas tentativas de login. Aguarde 15 minutos e tente novamente.'
});
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 15,
  message: 'Muitos cadastros a partir desta conexão. Tente novamente mais tarde.'
});
const resetLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'Muitas tentativas. Aguarde alguns minutos e tente novamente.'
});
const cookiePreferencesLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  key: (req) => `cookie-preferences:${req.user ? req.user.id : req.ip}`,
  message: 'Muitas alterações de preferências. Tente novamente mais tarde.'
});
const verifyEmailLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  message: 'Muitas tentativas de confirmação. Aguarde e tente novamente.'
});

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null)));
}

async function uniqueUsername(preferred) {
  const base = normalizeUsername(preferred, 'conta');
  let candidate = base;
  let suffix = 1;
  while (await dbGet('SELECT id FROM users WHERE username = ? COLLATE NOCASE LIMIT 1', [candidate])) {
    const tail = `-${suffix++}`;
    candidate = `${base.slice(0, 30 - tail.length)}${tail}`;
  }
  return candidate;
}

async function refreshSubscriptionState(user) {
  const billingPlan = await dbGet(
    'SELECT name, billing_interval, billing_interval_count FROM platform_plans WHERE plan_key = ?',
    [user.plano_tipo]
  );
  const interval = billingPlan ? billingPlan.billing_interval : (['mensal', 'anual', 'teste', 'teste_gratis'].includes(user.plano_tipo) ? 'month' : (user.plano_tipo === 'vitalicio' ? 'once' : null));
  const recurring = interval === 'month';
  let status = user.status_assinatura || 'inativa';
  if (status === 'ativa' && recurring) {
    const expiration = user.data_vencimento ? new Date(user.data_vencimento).getTime() : NaN;
    if (!Number.isFinite(expiration) || expiration <= Date.now()) {
      status = 'vencida';
      await new Promise((resolve, reject) => db.run(
        'UPDATE users SET status_assinatura = ? WHERE id = ?', [status, user.id], (err) => err ? reject(err) : resolve()
      ));
    }
  }
  return {
    status_assinatura: status,
    billing_interval: interval,
    billing_interval_count: billingPlan ? Number(billingPlan.billing_interval_count) || 1 : 1,
    plan_name: billingPlan ? billingPlan.name : null
  };
}

// Cadastro pendente: os dados ficam isolados em pending_registrations até a pessoa
// confirmar o endereço. Nenhum usuário/tenant é criado antes da confirmação.
function baseUrlForRequest(req) {
  const configured = String(process.env.BASE_URL || '').trim();
  if (configured) {
    let parsed;
    try { parsed = new URL(configured); }
    catch (_) { throw new Error('BASE_URL precisa ser uma URL absoluta válida.'); }
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.search || parsed.hash) {
      throw new Error('BASE_URL contém componentes inválidos.');
    }
    if (process.env.NODE_ENV === 'production' && parsed.protocol !== 'https:') {
      throw new Error('BASE_URL precisa usar HTTPS em produção.');
    }
    return `${parsed.origin}${parsed.pathname.replace(/\/$/, '')}`;
  }
  if (process.env.NODE_ENV === 'production') throw new Error('BASE_URL HTTPS precisa estar configurada em produção.');
  return `${req.protocol}://${req.get('host')}`;
}

function createVerificationToken() {
  const token = crypto.randomBytes(32).toString('hex');
  return { token, hash: crypto.createHash('sha256').update(token).digest('hex') };
}

async function deliverVerification(email, name, token, req) {
  const url = `${baseUrlForRequest(req)}/api/auth/verify-email?token=${encodeURIComponent(token)}`;
  await sendVerificationEmail({ to: email, name, verificationUrl: url });
}

router.post('/register', registerLimiter, async (req, res) => {
  const { nome, email, senha, whatsapp, empresa } = req.body || {};
  const cookieConsent = normalizeCookieConsent(req.body && req.body.cookieConsent);
  if (!cookieConsent) {
    return res.status(400).json({ error: 'Antes de criar a conta, escolha aceitar, rejeitar ou personalizar os cookies opcionais. Os cookies necessários permanecem ativos.' });
  }
  if (!nome || !email || !senha) {
    return res.status(400).json({ error: 'Nome, e-mail e senha são obrigatórios.' });
  }
  if (!isText(nome, 120) || !isText(email, 160) || !isText(senha, 200) ||
      (whatsapp != null && !isText(whatsapp, 30)) || (empresa != null && !isText(empresa, 100))) {
    return res.status(400).json({ error: 'Dados de cadastro inválidos.' });
  }
  if (!nome.trim()) return res.status(400).json({ error: 'Informe seu nome.' });
  if (!EMAIL_PATTERN.test(email.trim())) return res.status(400).json({ error: 'Informe um e-mail válido.' });
  if (senha.length < 8) return res.status(400).json({ error: 'A senha deve ter pelo menos 8 caracteres.' });
  const normalizedEmail = email.toLowerCase().trim();
  try {
    const existing = await dbGet('SELECT id FROM users WHERE email = ? COLLATE NOCASE', [normalizedEmail]);
    if (existing) return res.status(409).json({ error: 'Este e-mail já possui uma conta. Entre usando seu e-mail e senha.' });

    const hashSenha = await bcrypt.hash(senha, 12);
    const trialEndsAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const created = await db.withTransaction(async (tx) => {
      const base = normalizeUsername(nome, 'conta');
      let username = base;
      let suffix = 1;
      while (await tx.get('SELECT id FROM users WHERE username = ? COLLATE NOCASE', [username])) {
        const tail = `-${suffix++}`;
        username = `${base.slice(0, 30 - tail.length)}${tail}`;
      }

      const userResult = await tx.run(
        `INSERT INTO users
         (nome, username, email, senha, whatsapp, email_verified, plano_tipo, status_assinatura, data_vencimento)
         VALUES (?, ?, ?, ?, ?, 1, 'teste_gratis', 'ativa', ?)`,
        [nome.trim(), username, normalizedEmail, hashSenha, String(whatsapp || '').trim(), trialEndsAt]
      );
      const userId = Number(userResult.lastID);
      await tx.run(
        `INSERT INTO user_cookie_preferences
         (user_id, choice, analytics, marketing, consent_version)
         VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET
           choice = excluded.choice, analytics = excluded.analytics, marketing = excluded.marketing,
           consent_version = excluded.consent_version, updated_at = CURRENT_TIMESTAMP`,
        [userId, cookieConsent.choice, cookieConsent.analytics ? 1 : 0,
          cookieConsent.marketing ? 1 : 0, cookieConsent.version]
      );
      await tx.run(
        `INSERT INTO user_cookie_consent_events
         (user_id, choice, analytics, marketing, consent_version, source)
         VALUES (?, ?, ?, ?, ?, 'signup')`,
        [userId, cookieConsent.choice, cookieConsent.analytics ? 1 : 0,
          cookieConsent.marketing ? 1 : 0, cookieConsent.version]
      );
      const tenantName = String(String(empresa || '').trim() || `Confeitaria ${nome}`).slice(0, 100);
      const tenantResult = await tx.run(
        'INSERT INTO tenants (nome, slug, owner_user_id) VALUES (?, ?, ?)',
        [tenantName, `confeitaria-${userId}-${slugify(tenantName)}`, userId]
      );
      const tenantId = Number(tenantResult.lastID);
      await tx.run(
        `INSERT INTO tenant_memberships (tenant_id, user_id, role, status)
         VALUES (?, ?, 'owner', 'active')`, [tenantId, userId]
      );
      // Descarta eventual cadastro pendente antigo para este mesmo e-mail.
      await tx.run('DELETE FROM pending_registrations WHERE email = ? COLLATE NOCASE', [normalizedEmail]);
      return { userId, username, tenantId };
    });

    const storedUser = await dbGet('SELECT role FROM users WHERE id = ?', [created.userId]);
    const user = {
      id: created.userId, nome: nome.trim(), username: created.username, email: normalizedEmail,
      whatsapp: String(whatsapp || '').trim(), role: storedUser ? storedUser.role : null,
      plano_tipo: 'teste_gratis', status_assinatura: 'ativa',
      data_vencimento: trialEndsAt, email_verified: true
    };
    const token = jwt.sign(
      { id: user.id, email: user.email, username: user.username, nome: user.nome, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    const tenantData = await listUserTenants(user.id, String(created.tenantId));
    const billingState = await refreshSubscriptionState(user);
    user.status_assinatura = billingState.status_assinatura;
    return res.status(201).json({
      ok: true, message: 'Conta criada com sucesso!', token,
      user: { ...user, billing_interval: billingState.billing_interval,
        billing_interval_count: billingState.billing_interval_count, plan_name: billingState.plan_name },
      tenants: tenantData.tenants, current_tenant: tenantData.current_tenant
    });
  } catch (err) {
    if (err && (err.code === 'SQLITE_CONSTRAINT' || /UNIQUE constraint failed/i.test(err.message || ''))) {
      return res.status(409).json({ error: 'Este e-mail já possui uma conta. Entre usando seu e-mail e senha.' });
    }
    console.error('Erro ao criar conta:', err);
    return res.status(500).json({ error: 'Não foi possível criar sua conta. Tente novamente.' });
  }
});

router.post('/resend-verification', registerLimiter, async (req, res) => {
  const email = String((req.body && req.body.email) || '').trim().toLowerCase();
  if (!EMAIL_PATTERN.test(email) || email.length > 160) return res.status(400).json({ error: 'Informe um e-mail válido.' });
  if (!isEmailDeliveryConfigured()) return res.status(503).json({ error: 'O envio de e-mails ainda não está configurado no servidor.' });
  try {
    const pending = await dbGet('SELECT id, nome, token_hash, expires_at, created_at FROM pending_registrations WHERE email = ? COLLATE NOCASE', [email]);
    if (pending) {
      const verification = createVerificationToken();
      const expiration = formatSqliteDateTime(Date.now() + 24 * 60 * 60 * 1000);
      await new Promise((resolve, reject) => db.run(
        'UPDATE pending_registrations SET token_hash = ?, expires_at = ?, created_at = CURRENT_TIMESTAMP WHERE id = ?',
        [verification.hash, expiration, pending.id], (err) => err ? reject(err) : resolve()
      ));
      try {
        await deliverVerification(email, pending.nome, verification.token, req);
      } catch (sendError) {
        // Mantém válido o link anterior quando o reenvio não chega a sair.
        await new Promise((resolve) => db.run(
          `UPDATE pending_registrations SET token_hash = ?, expires_at = ?, created_at = ?
            WHERE id = ? AND token_hash = ?`,
          [pending.token_hash, pending.expires_at, pending.created_at, pending.id, verification.hash],
          () => resolve()
        ));
        throw sendError;
      }
    }
    return res.json({ ok: true, message: 'Se houver um cadastro pendente para esse e-mail, enviaremos um novo link de confirmação.' });
  } catch (err) {
    console.error('Falha ao reenviar confirmação:', err.message);
    return res.status(502).json({ error: 'Não foi possível reenviar o e-mail agora. Tente novamente mais tarde.' });
  }
});

async function createAccountFromVerificationToken(token) {
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  return db.withTransaction(async (tx) => {
    const pending = await tx.get(
      `SELECT * FROM pending_registrations
        WHERE token_hash = ? AND datetime(expires_at) > CURRENT_TIMESTAMP`, [tokenHash]
    );
    if (!pending) {
      const error = new Error('Este link de confirmação expirou ou já foi utilizado. Solicite um novo e-mail.');
      error.status = 410;
      throw error;
    }
    const existing = await tx.get('SELECT id FROM users WHERE email = ? COLLATE NOCASE', [pending.email]);
    if (existing) {
      const error = new Error('Este e-mail já possui uma conta. Entre com seu e-mail e senha.');
      error.status = 409;
      throw error;
    }

    const base = normalizeUsername(pending.username || pending.nome, 'conta');
    let username = base;
    let suffix = 1;
    while (await tx.get('SELECT id FROM users WHERE username = ? COLLATE NOCASE', [username])) {
      const tail = `-${suffix++}`;
      username = `${base.slice(0, 30 - tail.length)}${tail}`;
    }
    const trialEndsAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const userResult = await tx.run(
      `INSERT INTO users
       (nome, username, email, senha, whatsapp, email_verified, plano_tipo, status_assinatura, data_vencimento)
       VALUES (?, ?, ?, ?, ?, 1, 'teste_gratis', 'ativa', ?)`,
      [pending.nome, username, pending.email, pending.senha, pending.whatsapp || '', trialEndsAt]
    );
    const userId = Number(userResult.lastID);
    await tx.run(
      `INSERT INTO user_cookie_preferences
       (user_id, choice, analytics, marketing, consent_version)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET
         choice = excluded.choice, analytics = excluded.analytics, marketing = excluded.marketing,
         consent_version = excluded.consent_version, updated_at = CURRENT_TIMESTAMP`,
      [userId, pending.cookie_choice || 'rejected', Number(pending.cookie_analytics) === 1 ? 1 : 0,
        Number(pending.cookie_marketing) === 1 ? 1 : 0, Number(pending.cookie_consent_version) || 2]
    );
    await tx.run(
      `INSERT INTO user_cookie_consent_events
       (user_id, choice, analytics, marketing, consent_version, source)
       VALUES (?, ?, ?, ?, ?, 'signup')`,
      [userId, pending.cookie_choice || 'rejected', Number(pending.cookie_analytics) === 1 ? 1 : 0,
        Number(pending.cookie_marketing) === 1 ? 1 : 0, Number(pending.cookie_consent_version) || 2]
    );
    const tenantName = String(pending.empresa || `Confeitaria ${pending.nome}`).trim().slice(0, 100);
    const tenantResult = await tx.run(
      'INSERT INTO tenants (nome, slug, owner_user_id) VALUES (?, ?, ?)',
      [tenantName, `confeitaria-${userId}-${slugify(tenantName)}`, userId]
    );
    const tenantId = Number(tenantResult.lastID);
    await tx.run(
      `INSERT INTO tenant_memberships (tenant_id, user_id, role, status)
       VALUES (?, ?, 'owner', 'active')`, [tenantId, userId]
    );
    await tx.run('DELETE FROM pending_registrations WHERE id = ?', [pending.id]);
    return { userId, tenantId, email: pending.email };
  });
}

// Abrir o link só exibe a confirmação. Alguns provedores inspecionam links
// automaticamente; a conta só nasce após o clique explícito no botão.
router.get('/verify-email', async (req, res) => {
  const token = String(req.query.token || '').trim();
  if (!/^[a-f0-9]{64}$/i.test(token)) {
    return res.status(400).send('Link de confirmação inválido. Solicite um novo link no KSW.');
  }
  try {
    const pending = await dbGet(
      `SELECT email FROM pending_registrations
        WHERE token_hash = ? AND datetime(expires_at) > CURRENT_TIMESTAMP`,
      [crypto.createHash('sha256').update(token).digest('hex')]
    );
    if (!pending) return res.status(410).send('Este link expirou ou já foi utilizado. Volte ao KSW e solicite um novo e-mail.');
    const safeToken = token;
    res.set({
      'Cache-Control': 'no-store',
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff',
      'X-Frame-Options': 'DENY'
    });
    return res.status(200).type('html').send(`<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Confirmar e-mail — Confeitaê</title><body style="margin:0;background:#f6f0f2;color:#3d2e35;font-family:Arial,sans-serif;min-height:100vh;display:grid;place-items:center;padding:20px;box-sizing:border-box"><main style="width:min(100%,520px);background:#fffaf9;border:1px solid #e5d6dc;border-radius:18px;padding:32px;box-sizing:border-box;box-shadow:0 18px 50px #3d2e3518"><div style="color:#91566e;font-weight:700;letter-spacing:2px;font-size:12px">KSW CONFEITARIA</div><h1 style="font-size:26px;margin:18px 0 10px">Confirme seu e-mail</h1><p>O endereço <strong>${escapeHtml(pending.email)}</strong> está prestes a ser confirmado.</p><p>Ao confirmar, sua conta será criada e seus 7 dias gratuitos começarão. Você poderá entrar com seu e-mail e senha.</p><button id="confirm" type="button" style="margin-top:14px;background:#91566e;color:white;border:0;border-radius:10px;padding:14px 20px;font-weight:700;font-size:15px;cursor:pointer">Confirmar e criar minha conta</button><p id="status" role="status" aria-live="polite" style="color:#74656b;font-size:14px;margin-top:18px"></p></main><script>
const button=document.getElementById('confirm');const status=document.getElementById('status');history.replaceState(null,'','/api/auth/verify-email');button.addEventListener('click',async()=>{button.disabled=true;button.textContent='Confirmando...';status.textContent='';try{const response=await fetch('/api/auth/verify-email',{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({token:'${safeToken}'})});const result=await response.json().catch(()=>({}));if(!response.ok)throw new Error(result.error||'Não foi possível confirmar seu e-mail.');status.textContent='E-mail confirmado. Redirecionando para o KSW...';window.location.assign(result.redirect_url);}catch(error){status.textContent=error.message;button.disabled=false;button.textContent='Tentar confirmar novamente';}});
</script></body></html>`);
  } catch (error) {
    console.error('Falha ao abrir confirmação de e-mail:', error.message);
    return res.status(500).send('Não foi possível abrir a confirmação. Tente novamente.');
  }
});

router.post('/verify-email', verifyEmailLimiter, async (req, res) => {
  const token = String((req.body && req.body.token) || '').trim();
  if (!/^[a-f0-9]{64}$/i.test(token)) {
    return res.status(400).json({ error: 'Link de confirmação inválido. Solicite um novo e-mail.' });
  }
  try {
    await createAccountFromVerificationToken(token);
    const baseUrl = baseUrlForRequest(req);
    return res.json({ ok: true, redirect_url: `${baseUrl}/?email_verified=1` });
  } catch (error) {
    if (error.status) return res.status(error.status).json({ error: error.message });
    console.error('Erro ao confirmar e-mail:', error);
    return res.status(500).json({ error: 'Não foi possível concluir a confirmação. Tente novamente.' });
  }
});

// O acesso principal é pelo e-mail confirmado. O nome de usuário permanece interno
// para compatibilidade com registros antigos e integrações existentes.
router.post('/login', loginLimiter, async (req, res) => {
  const email = String((req.body && req.body.email) || '').trim().toLowerCase();
  const senha = req.body && req.body.senha;
  if (!email || !senha) return res.status(400).json({ error: 'Informe seu e-mail e senha.' });
  if (!EMAIL_PATTERN.test(email) || !isText(email, 160) || !isText(senha, 200)) {
    return res.status(400).json({ error: 'Informe um e-mail e uma senha válidos.' });
  }

  try {
    const user = await dbGet('SELECT * FROM users WHERE email = ? COLLATE NOCASE LIMIT 1', [email]);
    if (!user || !(await bcrypt.compare(senha, user.senha))) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }

    const billingState = await refreshSubscriptionState(user);
    const token = jwt.sign(
      { id: user.id, email: user.email, username: user.username, nome: user.nome, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );
    const tenantData = await listUserTenants(user.id, req.get('x-tenant-id'));
    return res.json({
      message: 'Login realizado com sucesso!', token,
      user: {
        id: user.id, nome: user.nome, username: user.username, email: user.email, whatsapp: user.whatsapp,
        role: user.role, plano_tipo: user.plano_tipo,
        status_assinatura: billingState.status_assinatura, data_vencimento: user.data_vencimento,
        billing_interval: billingState.billing_interval, billing_interval_count: billingState.billing_interval_count,
        plan_name: billingState.plan_name, email_verified: true
      },
      tenants: tenantData.tenants,
      current_tenant: tenantData.current_tenant
    });
  } catch (err) {
    console.error('Erro ao realizar login:', err);
    return res.status(500).json({ error: 'Não foi possível realizar o login.' });
  }
});

// Atualiza a escolha de cookies opcionais do usuário autenticado.
router.post('/cookie-preferences', authMiddleware, cookiePreferencesLimiter, async (req, res) => {
  const consent = normalizeCookieConsent(req.body);
  if (!consent) return res.status(400).json({ error: 'Preferências de cookies inválidas.' });
  try {
    await db.withTransaction(async (tx) => {
      await tx.run(
        `INSERT INTO user_cookie_preferences (user_id, choice, analytics, marketing, consent_version)
         VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET choice = excluded.choice,
           analytics = excluded.analytics, marketing = excluded.marketing,
           consent_version = excluded.consent_version, updated_at = CURRENT_TIMESTAMP`,
        [req.user.id, consent.choice, consent.analytics ? 1 : 0, consent.marketing ? 1 : 0, consent.version]
      );
      await tx.run(
        `INSERT INTO user_cookie_consent_events
         (user_id, choice, analytics, marketing, consent_version, source)
         VALUES (?, ?, ?, ?, ?, 'settings')`,
        [req.user.id, consent.choice, consent.analytics ? 1 : 0, consent.marketing ? 1 : 0, consent.version]
      );
    });
    return res.json({ ok: true, preferences: consent });
  } catch (error) {
    console.error('Falha ao salvar preferências de cookies:', error.message);
    return res.status(500).json({ error: 'Não foi possível salvar suas preferências no servidor.' });
  }
});

// Perfil atualizado: permissões e lista de empresas são sempre consultadas no servidor.
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(
        `SELECT id, nome, username, email, whatsapp, role, plano_tipo, status_assinatura,
                data_vencimento, email_verified, created_at FROM users WHERE id = ?`,
        [req.user.id],
        (err, row) => err ? reject(err) : resolve(row)
      );
    });
    if (!user) return res.status(404).json({ error: 'Usuária não encontrada.' });

    const billingState = await refreshSubscriptionState(user);
    user.status_assinatura = billingState.status_assinatura;
    user.billing_interval = billingState.billing_interval;
    user.billing_interval_count = billingState.billing_interval_count;
    user.plan_name = billingState.plan_name;

    const tenantData = await listUserTenants(user.id, req.get('x-tenant-id'));
    if (tenantData.current_tenant) {
      // O plano efetivo da empresa vem do proprietário, não do funcionário convidado.
      user.plano_tipo = tenantData.current_tenant.plano_tipo;
      user.status_assinatura = tenantData.current_tenant.status_assinatura;
      user.data_vencimento = tenantData.current_tenant.data_vencimento;
      user.tenant_role = tenantData.current_tenant.role;
      user.billing_interval = tenantData.current_tenant.billing_interval;
      user.billing_interval_count = tenantData.current_tenant.billing_interval_count;
    }
    return res.json({ user, tenants: tenantData.tenants, current_tenant: tenantData.current_tenant });
  } catch (err) {
    console.error('Erro ao carregar perfil:', err);
    return res.status(500).json({ error: 'Não foi possível carregar o perfil.' });
  }
});

// Alteração autenticada de senha: exige a senha atual e mantém o hash bcrypt.
router.post('/change-password', authMiddleware, resetLimiter, async (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!isText(currentPassword, 200) || !isText(newPassword, 200)) {
    return res.status(400).json({ error: 'Informe a senha atual e a nova senha.' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'A nova senha deve ter pelo menos 8 caracteres.' });
  }
  if (currentPassword === newPassword) {
    return res.status(400).json({ error: 'A nova senha deve ser diferente da senha atual.' });
  }
  try {
    const user = await dbGet('SELECT id, senha FROM users WHERE id = ?', [req.user.id]);
    if (!user || !(await bcrypt.compare(currentPassword, user.senha))) {
      return res.status(401).json({ error: 'A senha atual está incorreta.' });
    }
    const hash = await bcrypt.hash(newPassword, 12);
    await new Promise((resolve, reject) => db.run('UPDATE users SET senha = ? WHERE id = ?', [hash, user.id], err => err ? reject(err) : resolve()));
    return res.json({ message: 'Senha alterada com sucesso.' });
  } catch (err) {
    console.error('Erro ao alterar senha:', err);
    return res.status(500).json({ error: 'Não foi possível alterar a senha.' });
  }
});

// Solicitar Recuperação de Senha
router.post('/forgot-password', resetLimiter, (req, res) => {
  return res.status(503).json({
    error: 'A recuperação de senha por e-mail ainda não está configurada neste servidor.'
  });
});

// Redefinir Senha
router.post('/reset-password', resetLimiter, async (req, res) => {
  const { token, novaSenha } = req.body || {};
  if (!token || !novaSenha) {
    return res.status(400).json({ error: 'Token e nova senha são obrigatórios.' });
  }
  if (!isText(token, 200) || !isText(novaSenha, 200)) {
    return res.status(400).json({ error: 'Dados inválidos.' });
  }
  if (novaSenha.length < 8) {
    return res.status(400).json({ error: 'A senha deve ter pelo menos 8 caracteres.' });
  }

  db.get(
    'SELECT * FROM password_resets WHERE token = ? AND usado = 0 AND expira_em > CURRENT_TIMESTAMP',
    [token],
    async (err, reset) => {
      if (err || !reset) {
        return res.status(400).json({ error: 'Token de recuperação inválido ou expirado.' });
      }

      const hash = await bcrypt.hash(novaSenha, 10);

      db.run('UPDATE users SET senha = ? WHERE id = ?', [hash, reset.user_id], (err2) => {
        if (err2) return res.status(500).json({ error: 'Erro ao atualizar senha.' });

        db.run('UPDATE password_resets SET usado = 1 WHERE id = ?', [reset.id]);
        return res.json({ message: 'Senha redefinida com sucesso! Faça login com sua nova senha.' });
      });
    }
  );
});

module.exports = router;
