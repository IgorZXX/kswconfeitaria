const express = require('express');
const db = require('../database');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
const { hasCollectionPermission } = require('../lib/tenant-permissions');
const { getTenantPlan } = require('../middleware/plan-feature');
const { parsePlanFeatures, hasPlanFeature } = require('../lib/plan-features');

const router = express.Router();

const MAX_OPS = 1000;            // operações por requisição
const MAX_RECORD_BYTES = 100000; // tamanho de um registro serializado
const ID_PATTERN = /^[A-Za-z0-9_.-]{1,64}$/;

const TABLES = Object.fromEntries(db.DATA_TABLES.map((t) => [t.key, t]));

function text(value, max = 200) {
  return value == null ? '' : String(value).slice(0, max);
}
function number(value) {
  const n = Number(String(value == null ? 0 : value).replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
}

function safeJson(value, fallback = {}) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : fallback;
  } catch (_) { return fallback; }
}

// Extrai as colunas-chave de cada tipo de registro (na ordem de DATA_TABLES[].columns).
const EXTRACTORS = {
  clientes: (r) => [text(r.nome)],
  ingredientes: (r) => [text(r.nome), number(r.est), number(r.min), text(r.val, 10)],
  produtos: (r) => [text(r.nome), number(r.preco)],
  pedidos: (r) => {
    const itens = Array.isArray(r.itens) ? r.itens : [];
    const total = itens.reduce((sum, i) => sum + number(i && i.pu) * number(i && i.q), 0) + number(r.taxa_entrega);
    // Valor pago = soma dos pagamentos registrados (ou o campo antigo "pg", de pedidos anteriores).
    const pago = Array.isArray(r.pagamentos)
      ? r.pagamentos.reduce((sum, x) => sum + number(x && x.v), 0)
      : number(r.pg);
    return [text(r.cli, 64), text(r.ent, 10), text(r.st, 30), total, pago];
  },
  despesas: (r) => [number(r.v), text(r.venc, 10), r.pago ? 1 : 0, text(r.cat, 60), text(r.forn, 64), text(r.dpg, 10)],
  fornecedores: (r) => [text(r.nome)],
  config: (r) => [number(r.cap_pedidos), number(r.cap_unid)],
  mov: (r) => [text(r.ing || r.ingrediente_id || r.item_id, 64), text(r.item_tipo || 'ingrediente', 20), text(r.item_id || r.ingrediente_id || r.ing, 64), text(r.tipo, 30), number(r.qtd), text(r.data || r.criado_em, 40)],
  embalagens: (r) => [text(r.nome, 120), text(r.un || r.unidade || 'un', 20), number(r.preco), number(r.est), number(r.min), text(r.val || r.validade, 10)],
  lotes: (r) => [text(r.item_tipo, 20), text(r.item_id, 64), number(r.quantidade_inicial), number(r.quantidade_disponivel), text(r.unidade, 20), text(r.validade, 10), number(r.custo_unitario), text(r.recebido_em, 40), text(r.fornecedor_id, 64)],
  producao: (r) => [text(r.pedido_id, 64), text(r.produto_id, 64), number(r.quantidade), text(r.data_prevista, 10), text(r.status, 30), text(r.iniciado_em, 40), text(r.concluido_em, 40), r.consumo_aplicado ? 1 : 0],
  perdas: (r) => [text(r.item_tipo, 20), text(r.item_id, 64), number(r.quantidade), text(r.unidade, 20), text(r.motivo, 160), text(r.data, 10), number(r.custo_total)],
  tarefas: (r) => [text(r.titulo, 160), text(r.status, 30), text(r.prazo, 10)],
  orcamentos: (r) => [text(r.cli, 64), text(r.status, 30), number(r.total), text(r.validade, 10)],
  cupons: (r) => [text(r.codigo, 40), text(r.tipo, 20), number(r.valor), text(r.validade, 10)],
  fidelidade: (r) => [text(r.cliente_id, 64), number(r.pontos), text(r.motivo, 160), text(r.data || r.criado_em, 40)],
  auditoria: (r) => [text(r.acao, 80), text(r.entidade, 40), text(r.entidade_id, 64), text(r.data || r.criado_em, 40)]
};

function validateOps(ops) {
  if (!Array.isArray(ops)) return 'Envie a lista de operações em "ops".';
  if (ops.length > MAX_OPS) return `Limite de ${MAX_OPS} operações por requisição.`;

  for (const op of ops) {
    if (!op || typeof op !== 'object' || !TABLES[op.c]) return 'Coleção inválida.';
    if (op.op === 'put') {
      const r = op.r;
      if (!r || typeof r !== 'object' || Array.isArray(r)) return 'Registro inválido.';
      if (!ID_PATTERN.test(String(r.id))) return 'Identificador de registro inválido.';
      if (JSON.stringify(r).length > MAX_RECORD_BYTES) return 'Registro grande demais.';
    } else if (op.op === 'del') {
      if (!ID_PATTERN.test(String(op.id))) return 'Identificador de registro inválido.';
    } else {
      return 'Operação inválida.';
    }
  }
  return null;
}

const COLLECTION_FEATURES = Object.freeze({
  pedidos: 'orders', clientes: 'customers', produtos: 'costing', ingredientes: 'inventory',
  embalagens: 'inventory', lotes: 'inventory', mov: 'inventory', perdas: 'inventory',
  producao: 'production', despesas: 'financial', fornecedores: 'financial', config: 'reports',
  tarefas: 'tasks', orcamentos: 'quotes', cupons: 'loyalty', fidelidade: 'loyalty', auditoria: 'audit'
});

function loadAll(tenantId, tenantRole, features) {
  const keys = Object.keys(TABLES);
  return Promise.all(keys.map((key) => {
    if (!hasCollectionPermission(tenantRole, key, 'read') || (COLLECTION_FEATURES[key] && !hasPlanFeature(features, COLLECTION_FEATURES[key]))) return Promise.resolve([]);
    return new Promise((resolve, reject) => {
      db.all(`SELECT id, data FROM ${TABLES[key].table} WHERE tenant_id = ? ORDER BY rowid`, [tenantId], (err, rows) => {
        if (err) return reject(err);
        resolve(rows.map((row) => {
          try {
            return { ...JSON.parse(row.data), id: row.id };
          } catch (_) {
            return null;
          }
        }).filter(Boolean));
      });
    });
  })).then((lists) => Object.fromEntries(keys.map((key, i) => [key, lists[i]])));
}

// Leitura: liberada para qualquer conta autenticada, para que a confeiteira nunca
// fique sem acesso aos próprios dados (por exemplo, ao exportá-los) se a assinatura vencer.
router.get('/', authMiddleware, tenantContextMiddleware, requirePermission('data.read'), async (req, res) => {
  try {
    const plan = await getTenantPlan(req.tenant.id);
    const features = parsePlanFeatures(plan && plan.features_json);
    const data = await loadAll(req.tenant.id, req.tenantRole, features);
    const restricted_collections = Object.keys(TABLES).filter((key) => !hasCollectionPermission(req.tenantRole, key, 'read') || (COLLECTION_FEATURES[key] && !hasPlanFeature(features, COLLECTION_FEATURES[key])));
    const empty = Object.values(data).every((list) => list.length === 0);
    res.json({ data, empty, restricted_collections });
  } catch (err) {
    console.error('Erro ao ler dados:', err);
    res.status(500).json({ error: 'Não foi possível carregar seus dados.' });
  }
});

// Exportação completa (backup em JSON feito pela própria confeiteira).
router.get('/export', authMiddleware, tenantContextMiddleware, requirePermission('data.read'), async (req, res) => {
  try {
    const plan = await getTenantPlan(req.tenant.id);
    const features = parsePlanFeatures(plan && plan.features_json);
    const data = await loadAll(req.tenant.id, req.tenantRole, features);
    const restricted_collections = Object.keys(TABLES).filter((key) => !hasCollectionPermission(req.tenantRole, key, 'read') || (COLLECTION_FEATURES[key] && !hasPlanFeature(features, COLLECTION_FEATURES[key])));
    res.set('Content-Disposition', 'attachment; filename="ksw-meus-dados.json"');
    res.json({ exportado_em: new Date().toISOString(), data, restricted_collections });
  } catch (err) {
    console.error('Erro ao exportar dados:', err);
    res.status(500).json({ error: 'Não foi possível exportar seus dados.' });
  }
});

// Escrita: exige assinatura ativa. Cada operação é um "put" (cria ou substitui)
// ou um "del". Tudo em uma única transação: ou grava tudo, ou nada.
router.post('/sync', authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePermission('data.write'), async (req, res) => {
  const ops = req.body && req.body.ops;
  const problem = validateOps(ops);
  if (problem) return res.status(400).json({ error: problem });
  const deniedCollection = ops.find((op) => !hasCollectionPermission(req.tenantRole, op.c, 'write'));
  if (deniedCollection) return res.status(403).json({ error: 'Seu perfil não pode alterar informações desta área.', code: 'TENANT_COLLECTION_PERMISSION_DENIED' });
  const plan = await getTenantPlan(req.tenant.id);
  const features = parsePlanFeatures(plan && plan.features_json);
  const deniedFeature = ops.find((op) => COLLECTION_FEATURES[op.c] && !hasPlanFeature(features, COLLECTION_FEATURES[op.c]));
  if (deniedFeature) return res.status(403).json({ error: 'Esta funcionalidade não está incluída no plano atual. Faça upgrade para continuar.', code: 'PLAN_FEATURE_REQUIRED', feature: COLLECTION_FEATURES[deniedFeature.c] });

  const userId = req.user.id;
  const tenantId = req.tenant.id;
  try {
    await db.withTransaction(async (tx) => {
      for (const op of ops) {
        const t = TABLES[op.c];
        if (op.op === 'del') {
          if (op.c === 'orcamentos') {
            const protectedLink = await tx.get(`SELECT status FROM quote_public_links
              WHERE tenant_id = ? AND quote_id = ? AND status IN ('accepted', 'rejected')`, [tenantId, String(op.id)]);
            if (protectedLink) continue; // propostas respondidas ficam preservadas no histórico.
          }
          await tx.run(`DELETE FROM ${t.table} WHERE tenant_id = ? AND id = ?`, [tenantId, String(op.id)]);
          continue;
        }
        let record = { ...op.r, id: String(op.r.id) };
        const cols = t.columns.map((c) => c.name);
        const existing = await tx.get(
          `SELECT user_id, data FROM ${t.table} WHERE tenant_id = ? AND id = ?`,
          [tenantId, record.id]
        );
        if (op.c === 'orcamentos') {
          const publicLink = await tx.get(`SELECT status FROM quote_public_links
            WHERE tenant_id = ? AND quote_id = ?`, [tenantId, record.id]);
          if (publicLink && publicLink.status !== 'pending') {
            // A resposta pública (e o pedido criado por ela) é estado autoritativo do servidor.
            // Um cache antigo aberto em outro aparelho não pode reverter essa decisão.
            continue;
          }
          if (record.status === 'aceito' && (!publicLink || publicLink.status !== 'accepted')) {
            const current = safeJson(existing && existing.data, {});
            record.status = String(current.status || 'enviado');
            delete record.pedido_id;
            delete record.respondido_em;
            delete record.resposta_publica;
          }
        }
        const values = EXTRACTORS[t.key](record);
        if (existing) {
          await tx.run(
            `UPDATE ${t.table} SET ${cols.map((c) => `${c} = ?`).join(', ')},
             data = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND id = ?`,
            [...values, JSON.stringify(record), tenantId, record.id]
          );
        } else {
          await tx.run(
            `INSERT INTO ${t.table} (user_id, tenant_id, id, ${cols.join(', ')}, data, updated_at)
             VALUES (?, ?, ?, ${cols.map(() => '?').join(', ')}, ?, CURRENT_TIMESTAMP)`,
            [userId, tenantId, record.id, ...values, JSON.stringify(record)]
          );
        }
      }
    });
    return res.json({ ok: true, applied: ops.length });
  } catch (err) {
    console.error('Erro ao sincronizar dados:', err);
    return res.status(500).json({ error: 'Não foi possível salvar seus dados.' });
  }
});

module.exports = router;
