'use strict';

const express = require('express');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const db = require('../database');
const rateLimit = require('../middleware/rateLimit');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
const { sanitizeMenuImage, MAX_BYTES } = require('../lib/menu-image-security');

const router = express.Router();
const imageStorageRoot = path.resolve(__dirname, '..', 'storage', 'social-posts');
const videoStorageRoot = path.resolve(__dirname, '..', 'storage', 'social-videos');
const storyImageStorageRoot = path.resolve(__dirname, '..', 'storage', 'social-story-images');
const storyVideoStorageRoot = path.resolve(__dirname, '..', 'storage', 'social-story-videos');
const MAX_VIDEO_BYTES = 30 * 1024 * 1024;
const VIDEO_TENANT_MAX_FILES = 40;
const VIDEO_TENANT_MAX_BYTES = 600 * 1024 * 1024;
const handlePattern = /^[a-z0-9](?:[a-z0-9._-]{1,28}[a-z0-9])?$/;
const postLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 15, key: (req) => `social-post:${req.tenant && req.tenant.id}:${req.ip || 'unknown'}`, message: 'Você publicou muitas vezes. Aguarde um pouco antes de publicar novamente.' });
const avatarLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 10, key: (req) => `social-avatar:${req.tenant && req.tenant.id}:${req.ip || 'unknown'}`, message: 'Você trocou a foto de perfil muitas vezes. Aguarde um pouco antes de tentar novamente.' });
const videoLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 8, key: (req) => `social-video:${req.tenant && req.tenant.id}:${req.ip || 'unknown'}`, message: 'Você enviou muitos vídeos. Aguarde um pouco antes de enviar outro.' });
const commentLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 30, key: (req) => `social-comment:${req.user && req.user.id}:${req.ip || 'unknown'}`, message: 'Muitos comentários em pouco tempo. Aguarde antes de tentar novamente.' });
const followLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 60, key: (req) => `social-follow:${req.tenant && req.tenant.id}:${req.ip || 'unknown'}`, message: 'Muitas alterações de seguidores em pouco tempo. Aguarde antes de tentar novamente.' });
const reportLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 10, key: (req) => `social-report:${req.user && req.user.id}:${req.ip || 'unknown'}`, message: 'Limite de denúncias atingido. Aguarde antes de enviar outra.' });
const conversationLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 30, key: (req) => `social-conversation:${req.tenant && req.tenant.id}:${req.user && req.user.id}:${req.ip || 'unknown'}`, message: 'Você iniciou muitas conversas em pouco tempo. Aguarde antes de tentar novamente.' });
const messageLimiter = rateLimit({ windowMs: 10 * 60 * 1000, max: 60, key: (req) => `social-message:${req.tenant && req.tenant.id}:${req.user && req.user.id}:${req.ip || 'unknown'}`, message: 'Você enviou muitas mensagens em pouco tempo. Aguarde antes de tentar novamente.' });
const storyLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 30, key: (req) => `social-story:${req.tenant && req.tenant.id}:${req.user && req.user.id}:${req.ip || 'unknown'}`, message: 'Você publicou muitos Stories. Aguarde um pouco antes de tentar novamente.' });

function dbGet(sql, params = []) { return new Promise((resolve, reject) => db.get(sql, params, (error, row) => error ? reject(error) : resolve(row || null))); }
function dbAll(sql, params = []) { return new Promise((resolve, reject) => db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows || []))); }
function dbRun(sql, params = []) { return new Promise((resolve, reject) => db.run(sql, params, function (error) { error ? reject(error) : resolve({ changes: this.changes, lastID: this.lastID }); })); }
function safePost(row) {
  return {
    id: Number(row.id), tenant_id: Number(row.tenant_id), handle: row.handle,
    business_name: row.business_name, bio: row.bio || '', caption: row.caption || '',
    image_url: row.image_url, video_url: row.video_url || '', avatar_url: row.avatar_url || '',
    likes_count: Number(row.likes_count || 0), comments_count: Number(row.comments_count || 0),
    liked_by_me: Boolean(row.liked_by_me), followed_by_me: Boolean(row.followed_by_me),
    created_at: row.created_at
  };
}
function imageBelongsToTenant(imageUrl, tenantId) {
  const expected = new RegExp(`^/api/social/images/${Number(tenantId)}/[a-f0-9]{32}\\.png$`);
  return typeof imageUrl === 'string' && expected.test(imageUrl);
}

function videoBelongsToTenant(videoUrl, tenantId) {
  const expected = new RegExp(`^/api/social/videos/${Number(tenantId)}/[a-f0-9]{32}\\.(mp4|webm)$`);
  return typeof videoUrl === 'string' && expected.test(videoUrl);
}
// Identifica o contêiner pelos bytes (nunca pelo nome ou Content-Type enviado). MP4/MOV começam com uma caixa "ftyp"; WebM com EBML + DocType "webm".
function detectVideoExtension(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 4096) return null;
  if (buffer.toString('latin1', 4, 8) === 'ftyp') return 'mp4';
  if (buffer[0] === 0x1a && buffer[1] === 0x45 && buffer[2] === 0xdf && buffer[3] === 0xa3 && buffer.toString('latin1', 0, 64).includes('webm')) return 'webm';
  return null;
}

// Vídeos públicos de publicações: tipo de conteúdo fixado pela extensão gerada no servidor, com suporte a Range.
router.get('/videos/:tenantId/:filename', async (req, res) => {
  const tenantId = String(req.params.tenantId || '');
  const filename = String(req.params.filename || '');
  if (!/^\d{1,12}$/.test(tenantId) || !/^[a-f0-9]{32}\.(mp4|webm)$/.test(filename)) return res.status(404).end();
  const directory = path.resolve(videoStorageRoot, `tenant-${tenantId}`);
  const videoPath = path.resolve(directory, filename);
  if (!videoPath.startsWith(`${directory}${path.sep}`)) return res.status(404).end();
  try {
    const stat = await fs.promises.stat(videoPath);
    if (!stat.isFile() || stat.size <= 0 || stat.size > MAX_VIDEO_BYTES) return res.status(404).end();
    return res.sendFile(videoPath, { dotfiles: 'deny', acceptRanges: true, headers: { 'Content-Type': filename.endsWith('.webm') ? 'video/webm' : 'video/mp4', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline', 'Cache-Control': 'public, max-age=86400', 'Cross-Origin-Resource-Policy': 'same-site' } }, (error) => { if (error && !res.headersSent) res.status(404).end(); });
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Falha ao entregar vídeo social:', error.message);
    return res.status(404).end();
  }
});

// Imagens públicas de publicações: conteúdo sempre raster PNG reprocessado antes de ser servido.
router.get('/images/:tenantId/:filename', async (req, res) => {
  const tenantId = String(req.params.tenantId || '');
  const filename = String(req.params.filename || '');
  if (!/^\d{1,12}$/.test(tenantId) || !/^[a-f0-9]{32}\.png$/.test(filename)) return res.status(404).end();
  const directory = path.resolve(imageStorageRoot, `tenant-${tenantId}`);
  const imagePath = path.resolve(directory, filename);
  if (!imagePath.startsWith(`${directory}${path.sep}`)) return res.status(404).end();
  try {
    const stat = await fs.promises.stat(imagePath);
    if (!stat.isFile() || stat.size <= 0 || stat.size > MAX_BYTES) return res.status(404).end();
    const clean = sanitizeMenuImage(await fs.promises.readFile(imagePath));
    res.set({ 'Content-Type': 'image/png', 'X-Content-Type-Options': 'nosniff', 'Content-Disposition': 'inline; filename="publicacao.png"', 'Cache-Control': 'public, max-age=86400', 'Cross-Origin-Resource-Policy': 'same-site' });
    return res.send(clean.buffer);
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Falha ao entregar imagem social:', error.message);
    return res.status(404).end();
  }
});

// Arquivos de Stories usam diretório e rotas próprios. A mídia deixa de ser
// acessível quando o Story expira ou é removido.
router.get('/story-images/:tenantId/:filename', async (req, res) => {
  const tenantId=String(req.params.tenantId||'');const filename=String(req.params.filename||'');
  if(!/^\d{1,12}$/.test(tenantId)||! /^[a-f0-9]{32}\.png$/.test(filename))return res.status(404).end();
  const url=`/api/social/story-images/${tenantId}/${filename}`;
  try{
    const active=await dbGet(`SELECT id FROM ksw_social_stories WHERE image_url=? AND status='published' AND expires_at>CURRENT_TIMESTAMP LIMIT 1`,[url]);
    if(!active)return res.status(404).end();
    const directory=path.resolve(storyImageStorageRoot,`tenant-${tenantId}`);const imagePath=path.resolve(directory,filename);
    if(!imagePath.startsWith(`${directory}${path.sep}`))return res.status(404).end();
    const stat=await fs.promises.stat(imagePath);if(!stat.isFile()||stat.size<=0||stat.size>MAX_BYTES)return res.status(404).end();
    const clean=sanitizeMenuImage(await fs.promises.readFile(imagePath));
    res.set({'Content-Type':'image/png','X-Content-Type-Options':'nosniff','Content-Disposition':'inline; filename="story.png"','Cache-Control':'private, max-age=60','Cross-Origin-Resource-Policy':'same-site'});
    return res.send(clean.buffer);
  }catch(error){if(error.code!=='ENOENT')console.error('Falha ao entregar imagem de Story:',error.message);return res.status(404).end();}
});
router.get('/story-videos/:tenantId/:filename', async (req, res) => {
  const tenantId=String(req.params.tenantId||'');const filename=String(req.params.filename||'');
  if(!/^\d{1,12}$/.test(tenantId)||! /^[a-f0-9]{32}\.(mp4|webm)$/.test(filename))return res.status(404).end();
  const url=`/api/social/story-videos/${tenantId}/${filename}`;
  try{
    const active=await dbGet(`SELECT id FROM ksw_social_stories WHERE video_url=? AND status='published' AND expires_at>CURRENT_TIMESTAMP LIMIT 1`,[url]);
    if(!active)return res.status(404).end();
    const directory=path.resolve(storyVideoStorageRoot,`tenant-${tenantId}`);const videoPath=path.resolve(directory,filename);
    if(!videoPath.startsWith(`${directory}${path.sep}`))return res.status(404).end();
    const stat=await fs.promises.stat(videoPath);if(!stat.isFile()||stat.size<=0||stat.size>MAX_VIDEO_BYTES)return res.status(404).end();
    return res.sendFile(videoPath,{dotfiles:'deny',acceptRanges:true,headers:{'Content-Type':filename.endsWith('.webm')?'video/webm':'video/mp4','X-Content-Type-Options':'nosniff','Content-Disposition':'inline','Cache-Control':'private, max-age=60','Cross-Origin-Resource-Policy':'same-site'}},(error)=>{if(error&&!res.headersSent)res.status(404).end();});
  }catch(error){if(error.code!=='ENOENT')console.error('Falha ao entregar vídeo de Story:',error.message);return res.status(404).end();}
});

// Endpoint público e mínimo para confirmar se o backend ativo contém a API social.
// Não expõe dados de empresa, usuário ou publicação.
router.get('/health', (req, res) => {
  res.set('Cache-Control', 'no-store');
  return res.json({ ok: true, module: 'ksw-social', api_version: '2026-11-08-stories2' });
});

router.use(authMiddleware, tenantContextMiddleware, checkActiveSubscription);

router.get('/me', async (req, res) => {
  try {
    const profile = await dbGet(`SELECT p.*, t.nome AS business_name FROM ksw_social_profiles p JOIN tenants t ON t.id=p.tenant_id WHERE p.tenant_id=?`, [req.tenant.id]);
    const counts = await dbGet(`SELECT (SELECT COUNT(*) FROM ksw_social_posts WHERE tenant_id=? AND status='published') AS posts_count,
      (SELECT COUNT(*) FROM ksw_social_follows WHERE followed_tenant_id=?) AS followers_count,
      (SELECT COUNT(*) FROM ksw_social_follows WHERE follower_tenant_id=?) AS following_count`, [req.tenant.id, req.tenant.id, req.tenant.id]);
    return res.json({ profile, counts: counts || { posts_count: 0, followers_count: 0, following_count: 0 } });
  } catch (error) { console.error('Social profile load failed:', error); return res.status(500).json({ error: 'Não foi possível carregar seu perfil social.' }); }
});

router.put('/me', requirePermission('data.write'), async (req, res) => {
  const handle = String(req.body && req.body.handle || '').trim().toLowerCase();
  const bio = String(req.body && req.body.bio || '').trim();
  const website = String(req.body && req.body.website || '').trim();
  const isPublic = req.body && req.body.is_public === true ? 1 : 0;
  if (!handlePattern.test(handle) || handle.length < 3 || bio.length > 300 || website.length > 200) return res.status(400).json({ error: 'Confira o @usuário (3 a 30 caracteres), a bio (até 300) e o link (até 200).' });
  if (website && !/^https:\/\//i.test(website)) return res.status(400).json({ error: 'O link do perfil deve começar com https://.' });
  // avatar_url: ausente = manter; '' = remover; caso contrário precisa ser uma imagem enviada por esta própria empresa.
  const hasAvatar = Boolean(req.body) && Object.prototype.hasOwnProperty.call(req.body, 'avatar_url');
  const avatarUrl = hasAvatar ? String(req.body.avatar_url || '').trim() : '';
  if (hasAvatar && avatarUrl && !imageBelongsToTenant(avatarUrl, req.tenant.id)) return res.status(400).json({ error: 'Envie a foto de perfil novamente antes de salvar.' });
  try {
    const existing = await dbGet('SELECT tenant_id, avatar_url FROM ksw_social_profiles WHERE tenant_id=?', [req.tenant.id]);
    const finalAvatar = hasAvatar ? avatarUrl : (existing && existing.avatar_url) || '';
    if (existing) {
      await dbRun(`UPDATE ksw_social_profiles SET handle=?, bio=?, website=?, avatar_url=?, is_public=?, updated_at=CURRENT_TIMESTAMP WHERE tenant_id=?`, [handle, bio, website, finalAvatar, isPublic, req.tenant.id]);
    } else {
      await dbRun(`INSERT INTO ksw_social_profiles (tenant_id, handle, bio, website, avatar_url, is_public) VALUES (?,?,?,?,?,?)`, [req.tenant.id, handle, bio, website, finalAvatar, isPublic]);
    }
    const profile = await dbGet('SELECT * FROM ksw_social_profiles WHERE tenant_id=?', [req.tenant.id]);
    return res.json({ ok: true, profile });
  } catch (error) {
    if (String(error.message).includes('UNIQUE')) return res.status(409).json({ error: 'Esse @usuário já está em uso. Escolha outro.' });
    console.error('Social profile save failed:', error); return res.status(500).json({ error: 'Não foi possível salvar seu perfil.' });
  }
});

async function storeSanitizedImage(req, res) {
  if (!Buffer.isBuffer(req.body) || req.body.length === 0) return res.status(400).json({ error: 'Selecione uma imagem válida.' });
  try {
    const clean = sanitizeMenuImage(req.body);
    const directory = path.resolve(imageStorageRoot, `tenant-${req.tenant.id}`);
    await fs.promises.mkdir(directory, { recursive: true, mode: 0o700 });
    const files = await fs.promises.readdir(directory);
    let bytes = 0;
    for (const file of files) if (/^[a-f0-9]{32}\.png$/.test(file)) { try { bytes += (await fs.promises.stat(path.join(directory, file))).size; } catch (_) {} }
    if (files.length >= 300 || bytes + clean.buffer.length > 150 * 1024 * 1024) return res.status(413).json({ error: 'O limite de armazenamento de fotos da comunidade foi atingido.' });
    const filename = `${crypto.randomBytes(16).toString('hex')}.png`;
    await fs.promises.writeFile(path.join(directory, filename), clean.buffer, { flag: 'wx', mode: 0o600 });
    return res.status(201).json({ image_url: `/api/social/images/${req.tenant.id}/${filename}` });
  } catch (error) {
    if (error.code === 'INVALID_IMAGE') return res.status(400).json({ error: error.message });
    console.error('Social image upload failed:', error); return res.status(500).json({ error: 'Não foi possível processar a foto.' });
  }
}
router.post('/upload-image', requirePermission('data.write'), postLimiter, express.raw({ type: 'application/octet-stream', limit: `${MAX_BYTES}` }), storeSanitizedImage);
router.post('/upload-avatar', requirePermission('data.write'), avatarLimiter, express.raw({ type: 'application/octet-stream', limit: `${MAX_BYTES}` }), storeSanitizedImage);
async function storeSanitizedStoryImage(req,res){
  if(!Buffer.isBuffer(req.body)||req.body.length===0)return res.status(400).json({error:'Selecione uma imagem válida para o Story.'});
  try{
    const clean=sanitizeMenuImage(req.body);const directory=path.resolve(storyImageStorageRoot,`tenant-${req.tenant.id}`);
    await fs.promises.mkdir(directory,{recursive:true,mode:0o700});const files=await fs.promises.readdir(directory);let bytes=0;
    for(const file of files)if(/^[a-f0-9]{32}\.png$/.test(file)){try{bytes+=(await fs.promises.stat(path.join(directory,file))).size;}catch(_){}}
    if(files.length>=200||bytes+clean.buffer.length>100*1024*1024)return res.status(413).json({error:'O limite de armazenamento de Stories foi atingido.'});
    const filename=`${crypto.randomBytes(16).toString('hex')}.png`;await fs.promises.writeFile(path.join(directory,filename),clean.buffer,{flag:'wx',mode:0o600});
    return res.status(201).json({image_url:`/api/social/story-images/${req.tenant.id}/${filename}`});
  }catch(error){if(error.code==='INVALID_IMAGE')return res.status(400).json({error:error.message});console.error('Social story image upload failed:',error);return res.status(500).json({error:'Não foi possível processar a foto do Story.'});}
}
router.post('/upload-story-image',requirePermission('data.write'),storyLimiter,express.raw({type:'application/octet-stream',limit:`${MAX_BYTES}`}),storeSanitizedStoryImage);
router.post('/upload-story-video',requirePermission('data.write'),videoLimiter,express.raw({type:'application/octet-stream',limit:`${MAX_VIDEO_BYTES}`}),async(req,res)=>{
  const extension=detectVideoExtension(req.body);if(!extension)return res.status(400).json({error:'Envie um vídeo MP4 ou WebM válido.'});
  try{
    const directory=path.resolve(storyVideoStorageRoot,`tenant-${req.tenant.id}`);await fs.promises.mkdir(directory,{recursive:true,mode:0o700});
    const files=await fs.promises.readdir(directory);let bytes=0;for(const file of files)if(/^[a-f0-9]{32}\.(mp4|webm)$/.test(file)){try{bytes+=(await fs.promises.stat(path.join(directory,file))).size;}catch(_){}}
    if(files.length>=30||bytes+req.body.length>300*1024*1024)return res.status(413).json({error:'O limite de armazenamento de vídeos dos Stories foi atingido.'});
    const filename=`${crypto.randomBytes(16).toString('hex')}.${extension}`;await fs.promises.writeFile(path.join(directory,filename),req.body,{flag:'wx',mode:0o600});
    return res.status(201).json({video_url:`/api/social/story-videos/${req.tenant.id}/${filename}`});
  }catch(error){console.error('Social story video upload failed:',error);return res.status(500).json({error:'Não foi possível salvar o vídeo do Story.'});}
});

router.post('/upload-video', requirePermission('data.write'), videoLimiter, express.raw({ type: 'application/octet-stream', limit: `${MAX_VIDEO_BYTES}` }), async (req, res) => {
  const extension = detectVideoExtension(req.body);
  if (!extension) return res.status(400).json({ error: 'Envie um vídeo MP4 ou WebM válido.' });
  try {
    const directory = path.resolve(videoStorageRoot, `tenant-${req.tenant.id}`);
    await fs.promises.mkdir(directory, { recursive: true, mode: 0o700 });
    const files = await fs.promises.readdir(directory);
    let bytes = 0;
    for (const file of files) if (/^[a-f0-9]{32}\.(mp4|webm)$/.test(file)) { try { bytes += (await fs.promises.stat(path.join(directory, file))).size; } catch (_) {} }
    if (files.length >= VIDEO_TENANT_MAX_FILES || bytes + req.body.length > VIDEO_TENANT_MAX_BYTES) return res.status(413).json({ error: 'O limite de armazenamento de vídeos da comunidade foi atingido.' });
    const filename = `${crypto.randomBytes(16).toString('hex')}.${extension}`;
    await fs.promises.writeFile(path.join(directory, filename), req.body, { flag: 'wx', mode: 0o600 });
    return res.status(201).json({ video_url: `/api/social/videos/${req.tenant.id}/${filename}` });
  } catch (error) { console.error('Social video upload failed:', error); return res.status(500).json({ error: 'Não foi possível salvar o vídeo.' }); }
});

router.get('/feed', async (req, res) => {
  const limit = Math.min(30, Math.max(1, Number.parseInt(req.query.limit, 10) || 20));
  const before = Number.parseInt(req.query.before, 10);
  const params = [req.tenant.id];
  const onlyVideos = req.query.media === 'video' ? " AND p.video_url<>''" : '';
  let cursor = '';
  if (Number.isSafeInteger(before) && before > 0) { cursor = ' AND p.id < ?'; params.push(before); }
  params.push(limit);
  try {
    const rows = await dbAll(`SELECT p.id,p.tenant_id,p.caption,p.image_url,p.video_url,p.created_at,sp.handle,sp.bio,sp.avatar_url,t.nome AS business_name,
      (SELECT COUNT(*) FROM ksw_social_likes l WHERE l.post_id=p.id) AS likes_count,
      (SELECT COUNT(*) FROM ksw_social_comments c WHERE c.post_id=p.id AND c.status='published') AS comments_count,
      EXISTS(SELECT 1 FROM ksw_social_likes ml WHERE ml.post_id=p.id AND ml.user_id=?) AS liked_by_me,
      EXISTS(SELECT 1 FROM ksw_social_follows f WHERE f.follower_tenant_id=? AND f.followed_tenant_id=p.tenant_id) AS followed_by_me
      FROM ksw_social_posts p JOIN tenants t ON t.id=p.tenant_id JOIN ksw_social_profiles sp ON sp.tenant_id=p.tenant_id
      WHERE p.status='published' AND sp.is_public=1 AND t.status='active'${onlyVideos}${cursor}
      ORDER BY p.id DESC LIMIT ?`, [req.user.id, ...params]);
    return res.json({ posts: rows.map(safePost), next_before: rows.length === limit ? Number(rows[rows.length - 1].id) : null });
  } catch (error) { console.error('Social feed failed:', error); return res.status(500).json({ error: 'Não foi possível carregar o feed.' }); }
});

router.get('/explore', async (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 60);
  try {
    const pattern = `%${q.replace(/[\\%_]/g, '\\$&')}%`;
    const profiles = await dbAll(`SELECT sp.tenant_id,sp.handle,sp.bio,sp.avatar_url,t.nome AS business_name,
      (SELECT COUNT(*) FROM ksw_social_posts p WHERE p.tenant_id=sp.tenant_id AND p.status='published') AS posts_count,
      (SELECT COUNT(*) FROM ksw_social_follows f WHERE f.followed_tenant_id=sp.tenant_id) AS followers_count,
      EXISTS(SELECT 1 FROM ksw_social_follows mf WHERE mf.follower_tenant_id=? AND mf.followed_tenant_id=sp.tenant_id) AS followed_by_me
      FROM ksw_social_profiles sp JOIN tenants t ON t.id=sp.tenant_id WHERE sp.is_public=1 AND t.status='active' AND sp.tenant_id<>? AND (sp.handle LIKE ? ESCAPE '\\' OR sp.bio LIKE ? ESCAPE '\\' OR t.nome LIKE ? ESCAPE '\\')
      ORDER BY followers_count DESC, sp.updated_at DESC LIMIT 40`, [req.tenant.id, req.tenant.id, pattern, pattern, pattern]);
    return res.json({ profiles });
  } catch (error) { console.error('Social explore failed:', error); return res.status(500).json({ error: 'Não foi possível explorar a comunidade.' }); }
});

router.post('/posts', requirePermission('data.write'), postLimiter, async (req, res) => {
  const caption = String(req.body && req.body.caption || '').trim();
  const imageUrl = String(req.body && req.body.image_url || '').trim();
  if (caption.length > 2000) return res.status(400).json({ error: 'A legenda pode ter até 2.000 caracteres.' });
  const videoUrl = String(req.body && req.body.video_url || '').trim();
  if (!imageBelongsToTenant(imageUrl, req.tenant.id)) return res.status(400).json({ error: 'Envie uma foto da publicação antes de publicar.' });
  if (videoUrl && !videoBelongsToTenant(videoUrl, req.tenant.id)) return res.status(400).json({ error: 'Envie o vídeo novamente antes de publicar.' });
  try {
    const profile = await dbGet('SELECT is_public FROM ksw_social_profiles WHERE tenant_id=?', [req.tenant.id]);
    if (!profile || !profile.is_public) return res.status(409).json({ error: 'Ative seu perfil público da Comunidade KSW antes de publicar.' });
    const result = await dbRun(`INSERT INTO ksw_social_posts (tenant_id,author_user_id,caption,image_url,video_url) VALUES (?,?,?,?,?)`, [req.tenant.id, req.user.id, caption, imageUrl, videoUrl]);
    return res.status(201).json({ ok: true, id: result.lastID });
  } catch (error) { console.error('Social post create failed:', error); return res.status(500).json({ error: 'Não foi possível publicar a foto.' }); }
});

router.delete('/posts/:id', requirePermission('data.write'), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Publicação inválida.' });
  try {
    const result = await dbRun(`UPDATE ksw_social_posts SET status='removed',updated_at=CURRENT_TIMESTAMP WHERE id=? AND tenant_id=? AND status<>'removed'`, [id, req.tenant.id]);
    return result.changes ? res.json({ ok: true }) : res.status(404).json({ error: 'Publicação não encontrada.' });
  } catch (error) { console.error('Social post delete failed:', error); return res.status(500).json({ error: 'Não foi possível remover a publicação.' }); }
});

router.post('/posts/:id/like', requirePermission('data.write'), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Publicação inválida.' });
  try {
    const post = await dbGet(`SELECT p.id FROM ksw_social_posts p JOIN ksw_social_profiles sp ON sp.tenant_id=p.tenant_id WHERE p.id=? AND p.status='published' AND sp.is_public=1`, [id]);
    if (!post) return res.status(404).json({ error: 'Publicação não encontrada.' });
    await dbRun('INSERT OR IGNORE INTO ksw_social_likes (post_id,user_id,tenant_id) VALUES (?,?,?)', [id, req.user.id, req.tenant.id]);
    return res.json({ ok: true, liked: true });
  } catch (error) { console.error('Social like failed:', error); return res.status(500).json({ error: 'Não foi possível curtir a publicação.' }); }
});
router.delete('/posts/:id/like', requirePermission('data.write'), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Publicação inválida.' });
  try { await dbRun('DELETE FROM ksw_social_likes WHERE post_id=? AND user_id=?', [id, req.user.id]); return res.json({ ok: true, liked: false }); }
  catch (error) { console.error('Social unlike failed:', error); return res.status(500).json({ error: 'Não foi possível remover a curtida.' }); }
});

router.get('/posts/:id/comments', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Publicação inválida.' });
  try {
    const exists = await dbGet(`SELECT p.id FROM ksw_social_posts p JOIN ksw_social_profiles sp ON sp.tenant_id=p.tenant_id WHERE p.id=? AND p.status='published' AND sp.is_public=1`, [id]);
    if (!exists) return res.status(404).json({ error: 'Publicação não encontrada.' });
    const comments = await dbAll(`SELECT c.id,c.body,c.created_at,t.nome AS author_name,sp.handle FROM ksw_social_comments c JOIN tenants t ON t.id=c.tenant_id JOIN ksw_social_profiles sp ON sp.tenant_id=c.tenant_id WHERE c.post_id=? AND c.status='published' ORDER BY c.id ASC LIMIT 100`, [id]);
    return res.json({ comments });
  } catch (error) { console.error('Social comments load failed:', error); return res.status(500).json({ error: 'Não foi possível carregar os comentários.' }); }
});
router.post('/posts/:id/comments', requirePermission('data.write'), commentLimiter, async (req, res) => {
  const id = Number(req.params.id); const body = String(req.body && req.body.body || '').trim();
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Publicação inválida.' });
  if (!body || body.length > 500) return res.status(400).json({ error: 'O comentário deve ter de 1 a 500 caracteres.' });
  try {
    const post = await dbGet(`SELECT p.id FROM ksw_social_posts p JOIN ksw_social_profiles sp ON sp.tenant_id=p.tenant_id WHERE p.id=? AND p.status='published' AND sp.is_public=1`, [id]);
    if (!post) return res.status(404).json({ error: 'Publicação não encontrada.' });
    const result = await dbRun('INSERT INTO ksw_social_comments (post_id,tenant_id,author_user_id,body) VALUES (?,?,?,?)', [id, req.tenant.id, req.user.id, body]);
    return res.status(201).json({ ok: true, id: result.lastID });
  } catch (error) { console.error('Social comment failed:', error); return res.status(500).json({ error: 'Não foi possível publicar o comentário.' }); }
});
router.delete('/comments/:id', requirePermission('data.write'), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Comentário inválido.' });
  try {
    const result = await dbRun(`UPDATE ksw_social_comments SET status='removed' WHERE id=? AND (author_user_id=? OR EXISTS(SELECT 1 FROM ksw_social_posts p WHERE p.id=ksw_social_comments.post_id AND p.tenant_id=?))`, [id, req.user.id, req.tenant.id]);
    return result.changes ? res.json({ ok: true }) : res.status(404).json({ error: 'Comentário não encontrado.' });
  } catch (error) { console.error('Social comment delete failed:', error); return res.status(500).json({ error: 'Não foi possível remover o comentário.' }); }
});

router.post('/profiles/:tenantId/follow', requirePermission('data.write'), followLimiter, async (req, res) => {
  const target = Number(req.params.tenantId);
  if (!Number.isSafeInteger(target) || target <= 0 || target === req.tenant.id) return res.status(400).json({ error: 'Perfil inválido.' });
  try {
    const profile = await dbGet(`SELECT tenant_id FROM ksw_social_profiles WHERE tenant_id=? AND is_public=1`, [target]);
    if (!profile) return res.status(404).json({ error: 'Perfil não encontrado.' });
    await dbRun('INSERT OR IGNORE INTO ksw_social_follows (follower_tenant_id,followed_tenant_id) VALUES (?,?)', [req.tenant.id, target]);
    return res.json({ ok: true, following: true });
  } catch (error) { console.error('Social follow failed:', error); return res.status(500).json({ error: 'Não foi possível seguir o perfil.' }); }
});
router.delete('/profiles/:tenantId/follow', requirePermission('data.write'), followLimiter, async (req, res) => {
  const target = Number(req.params.tenantId);
  if (!Number.isSafeInteger(target) || target <= 0) return res.status(400).json({ error: 'Perfil inválido.' });
  try { await dbRun('DELETE FROM ksw_social_follows WHERE follower_tenant_id=? AND followed_tenant_id=?', [req.tenant.id, target]); return res.json({ ok: true, following: false }); }
  catch (error) { console.error('Social unfollow failed:', error); return res.status(500).json({ error: 'Não foi possível deixar de seguir o perfil.' }); }
});

router.post('/posts/:id/report', requirePermission('data.write'), reportLimiter, async (req, res) => {
  const id = Number(req.params.id); const reason = String(req.body && req.body.reason || '').trim();
  const reasons = new Set(['spam','inappropriate','copyright','fraud','other']);
  if (!Number.isSafeInteger(id) || id <= 0 || !reasons.has(reason)) return res.status(400).json({ error: 'Selecione um motivo válido para a denúncia.' });
  try {
    const post = await dbGet(`SELECT p.id FROM ksw_social_posts p JOIN ksw_social_profiles sp ON sp.tenant_id=p.tenant_id WHERE p.id=? AND p.status='published' AND sp.is_public=1`, [id]);
    if (!post) return res.status(404).json({ error: 'Publicação não encontrada.' });
    await dbRun('INSERT OR IGNORE INTO ksw_social_reports (post_id,reporter_tenant_id,reporter_user_id,reason) VALUES (?,?,?,?)', [id, req.tenant.id, req.user.id, reason]);
    return res.status(201).json({ ok: true });
  } catch (error) { console.error('Social report failed:', error); return res.status(500).json({ error: 'Não foi possível registrar a denúncia.' }); }
});

async function cleanupExpiredStories(){
  const expired=await dbAll(`SELECT id,tenant_id,image_url,video_url FROM ksw_social_stories WHERE expires_at<=CURRENT_TIMESTAMP OR status='removed'`);
  for(const row of expired){
    const imageMatch=String(row.image_url||'').match(/^\/api\/social\/story-images\/(\d+)\/([a-f0-9]{32}\.png)$/);
    const videoMatch=String(row.video_url||'').match(/^\/api\/social\/story-videos\/(\d+)\/([a-f0-9]{32}\.(?:mp4|webm))$/);
    if(imageMatch){try{await fs.promises.unlink(path.join(storyImageStorageRoot,`tenant-${imageMatch[1]}`,imageMatch[2]));}catch(error){if(error.code!=='ENOENT')console.error('Story image cleanup failed:',error.message);}}
    if(videoMatch){try{await fs.promises.unlink(path.join(storyVideoStorageRoot,`tenant-${videoMatch[1]}`,videoMatch[2]));}catch(error){if(error.code!=='ENOENT')console.error('Story video cleanup failed:',error.message);}}
  }
  if(expired.length)await dbRun(`DELETE FROM ksw_social_stories WHERE expires_at<=CURRENT_TIMESTAMP OR status='removed'`);
}

// Stories são conteúdo temporário separado das publicações do feed. A API
// só lista stories ativos do próprio perfil e de empresas que a confeitaria segue.
router.get('/stories', async (req, res) => {
  try {
    await cleanupExpiredStories();
    const rows = await dbAll(`
      SELECT s.id,s.tenant_id,s.caption,s.image_url,s.video_url,s.created_at,s.expires_at,
        t.nome AS business_name,sp.handle,sp.avatar_url,
        (SELECT COUNT(*) FROM ksw_social_story_views v WHERE v.story_id=s.id) AS views_count,
        EXISTS(SELECT 1 FROM ksw_social_story_views mine WHERE mine.story_id=s.id AND mine.viewer_tenant_id=?) AS viewed_by_me
      FROM ksw_social_stories s
      JOIN tenants t ON t.id=s.tenant_id AND t.status='active'
      JOIN ksw_social_profiles sp ON sp.tenant_id=s.tenant_id AND sp.is_public=1
      WHERE s.status='published' AND s.expires_at>CURRENT_TIMESTAMP
        AND (s.tenant_id=? OR EXISTS(
          SELECT 1 FROM ksw_social_follows f
          WHERE f.follower_tenant_id=? AND f.followed_tenant_id=s.tenant_id
        ))
      ORDER BY s.tenant_id ASC,s.created_at ASC,s.id ASC
      LIMIT 300`, [req.tenant.id, req.tenant.id, req.tenant.id]);
    const stories = rows.map((row) => ({
      id: Number(row.id), tenant_id: Number(row.tenant_id), business_name: row.business_name,
      handle: row.handle, avatar_url: row.avatar_url || '', caption: row.caption || '',
      image_url: row.image_url, video_url: row.video_url || '', created_at: row.created_at,
      expires_at: row.expires_at, views_count: Number(row.views_count || 0), viewed_by_me: Boolean(row.viewed_by_me),
      is_mine: Number(row.tenant_id) === req.tenant.id
    }));
    return res.json({ stories });
  } catch (error) {
    console.error('Social stories load failed:', error);
    return res.status(500).json({ error: 'Não foi possível carregar os Stories.' });
  }
});

router.post('/stories', requirePermission('data.write'), storyLimiter, async (req, res) => {
  const caption = String(req.body && req.body.caption || '').trim();
  const imageUrl = String(req.body && req.body.image_url || '').trim();
  const videoUrl = String(req.body && req.body.video_url || '').trim();
  if (caption.length > 500) return res.status(400).json({ error: 'A legenda do Story pode ter até 500 caracteres.' });
  if (!storyImageBelongsToTenant(imageUrl, req.tenant.id)) return res.status(400).json({ error: 'Envie uma foto ou capa válida para o Story.' });
  if (videoUrl && !storyVideoBelongsToTenant(videoUrl, req.tenant.id)) return res.status(400).json({ error: 'Envie o vídeo novamente antes de publicar o Story.' });
  try {
    const profile = await dbGet(`SELECT sp.is_public,t.status FROM ksw_social_profiles sp JOIN tenants t ON t.id=sp.tenant_id WHERE sp.tenant_id=?`, [req.tenant.id]);
    if (!profile || !profile.is_public || profile.status !== 'active') return res.status(409).json({ error: 'Ative seu perfil público da Comunidade KSW antes de publicar Stories.' });
    const result = await dbRun(`INSERT INTO ksw_social_stories (tenant_id,author_user_id,caption,image_url,video_url,expires_at) VALUES (?,?,?,?,?,datetime('now','+24 hours'))`, [req.tenant.id, req.user.id, caption, imageUrl, videoUrl]);
    const story = await dbGet('SELECT id,created_at,expires_at FROM ksw_social_stories WHERE id=? AND tenant_id=?', [result.lastID, req.tenant.id]);
    return res.status(201).json({ ok: true, id: result.lastID, expires_at: story && story.expires_at });
  } catch (error) {
    console.error('Social story create failed:', error);
    return res.status(500).json({ error: 'Não foi possível publicar o Story.' });
  }
});

router.post('/stories/:id/view', async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Story inválido.' });
  try {
    const story = await dbGet(`SELECT s.id,s.tenant_id FROM ksw_social_stories s
      JOIN ksw_social_profiles sp ON sp.tenant_id=s.tenant_id AND sp.is_public=1
      JOIN tenants t ON t.id=s.tenant_id AND t.status='active'
      WHERE s.id=? AND s.status='published' AND s.expires_at>CURRENT_TIMESTAMP
        AND (s.tenant_id=? OR EXISTS(SELECT 1 FROM ksw_social_follows f WHERE f.follower_tenant_id=? AND f.followed_tenant_id=s.tenant_id))`, [id, req.tenant.id, req.tenant.id]);
    if (!story) return res.status(404).json({ error: 'Este Story não está mais disponível.' });
    if (Number(story.tenant_id) !== req.tenant.id) {
      await dbRun('INSERT OR IGNORE INTO ksw_social_story_views (story_id,viewer_tenant_id) VALUES (?,?)', [id, req.tenant.id]);
    }
    const views = await dbGet('SELECT COUNT(*) AS total FROM ksw_social_story_views WHERE story_id=?', [id]);
    return res.json({ ok: true, views_count: Number(views && views.total || 0) });
  } catch (error) {
    console.error('Social story view failed:', error);
    return res.status(500).json({ error: 'Não foi possível registrar a visualização.' });
  }
});

router.delete('/stories/:id', requirePermission('data.write'), async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id <= 0) return res.status(400).json({ error: 'Story inválido.' });
  try {
    const result = await dbRun(`UPDATE ksw_social_stories SET status='removed' WHERE id=? AND tenant_id=? AND status='published'`, [id, req.tenant.id]);
    return result.changes ? res.json({ ok: true }) : res.status(404).json({ error: 'Story não encontrado.' });
  } catch (error) {
    console.error('Social story delete failed:', error);
    return res.status(500).json({ error: 'Não foi possível remover o Story.' });
  }
});

// Conversas privadas entre empresas. O par de participantes é normalizado no
// banco para impedir conversas duplicadas e todas as leituras validam a empresa atual.
router.get('/conversations', async (req, res) => {
  try {
    const conversations = await dbAll(`
      SELECT c.id,
        peer.id AS peer_tenant_id,
        peer.nome AS business_name,
        COALESCE(sp.handle,'') AS handle,
        COALESCE(sp.avatar_url,'') AS avatar_url,
        (SELECT m.body FROM ksw_social_messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_message,
        (SELECT m.created_at FROM ksw_social_messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_message_at,
        (SELECT COUNT(*) FROM ksw_social_messages unread WHERE unread.conversation_id=c.id AND unread.sender_tenant_id=peer.id AND unread.read_at IS NULL) AS unread_count
      FROM ksw_social_conversations c
      JOIN tenants peer ON peer.id=CASE WHEN c.tenant_low_id=? THEN c.tenant_high_id ELSE c.tenant_low_id END
      LEFT JOIN ksw_social_profiles sp ON sp.tenant_id=peer.id
      WHERE (c.tenant_low_id=? OR c.tenant_high_id=?) AND peer.status='active'
      ORDER BY c.last_message_at DESC,c.id DESC
      LIMIT 100`, [req.tenant.id, req.tenant.id, req.tenant.id]);
    return res.json({ conversations });
  } catch (error) {
    console.error('Social conversations load failed:', error);
    return res.status(500).json({ error: 'Não foi possível carregar suas conversas.' });
  }
});

router.post('/conversations', requirePermission('data.write'), conversationLimiter, async (req, res) => {
  const recipientTenantId = Number(req.body && req.body.recipient_tenant_id);
  if (!Number.isSafeInteger(recipientTenantId) || recipientTenantId <= 0 || recipientTenantId === req.tenant.id) {
    return res.status(400).json({ error: 'Selecione uma confeitaria válida para conversar.' });
  }
  try {
    const ownProfile = await dbGet(`SELECT sp.tenant_id FROM ksw_social_profiles sp JOIN tenants t ON t.id=sp.tenant_id WHERE sp.tenant_id=? AND sp.is_public=1 AND t.status='active'`, [req.tenant.id]);
    if (!ownProfile) return res.status(409).json({ error: 'Ative seu perfil público da Comunidade KSW antes de iniciar conversas.' });
    const recipient = await dbGet(`SELECT sp.tenant_id FROM ksw_social_profiles sp JOIN tenants t ON t.id=sp.tenant_id WHERE sp.tenant_id=? AND sp.is_public=1 AND t.status='active'`, [recipientTenantId]);
    if (!recipient) return res.status(404).json({ error: 'Essa confeitaria não está disponível para novas conversas.' });
    const low = Math.min(req.tenant.id, recipientTenantId);
    const high = Math.max(req.tenant.id, recipientTenantId);
    await dbRun('INSERT OR IGNORE INTO ksw_social_conversations (tenant_low_id,tenant_high_id) VALUES (?,?)', [low, high]);
    const conversation = await dbGet('SELECT id FROM ksw_social_conversations WHERE tenant_low_id=? AND tenant_high_id=?', [low, high]);
    if (!conversation) throw new Error('Conversation could not be created');
    return res.status(201).json({ ok: true, conversation_id: Number(conversation.id) });
  } catch (error) {
    console.error('Social conversation create failed:', error);
    return res.status(500).json({ error: 'Não foi possível iniciar a conversa.' });
  }
});

router.get('/conversations/:id/messages', async (req, res) => {
  const conversationId = Number(req.params.id);
  if (!Number.isSafeInteger(conversationId) || conversationId <= 0) return res.status(400).json({ error: 'Conversa inválida.' });
  const before = Number.parseInt(req.query.before, 10);
  const limit = Math.min(100, Math.max(1, Number.parseInt(req.query.limit, 10) || 50));
  try {
    const conversation = await dbGet('SELECT id FROM ksw_social_conversations WHERE id=? AND (tenant_low_id=? OR tenant_high_id=?)', [conversationId, req.tenant.id, req.tenant.id]);
    if (!conversation) return res.status(404).json({ error: 'Conversa não encontrada.' });
    await dbRun('UPDATE ksw_social_messages SET read_at=CURRENT_TIMESTAMP WHERE conversation_id=? AND sender_tenant_id<>? AND read_at IS NULL', [conversationId, req.tenant.id]);
    let cursor = '';
    const params = [conversationId];
    if (Number.isSafeInteger(before) && before > 0) { cursor = ' AND id < ?'; params.push(before); }
    params.push(limit);
    const rows = await dbAll(`SELECT id,sender_tenant_id,body,created_at,read_at FROM ksw_social_messages WHERE conversation_id=?${cursor} ORDER BY id DESC LIMIT ?`, params);
    const messages = rows.reverse().map((row) => ({
      id: Number(row.id), sender_tenant_id: Number(row.sender_tenant_id),
      is_mine: Number(row.sender_tenant_id) === req.tenant.id,
      body: row.body, created_at: row.created_at, read_at: row.read_at || null
    }));
    return res.json({ messages, next_before: rows.length === limit ? Number(rows[0].id) : null });
  } catch (error) {
    console.error('Social messages load failed:', error);
    return res.status(500).json({ error: 'Não foi possível carregar as mensagens.' });
  }
});

router.post('/conversations/:id/messages', requirePermission('data.write'), messageLimiter, async (req, res) => {
  const conversationId = Number(req.params.id);
  const body = String(req.body && req.body.body || '').trim();
  if (!Number.isSafeInteger(conversationId) || conversationId <= 0) return res.status(400).json({ error: 'Conversa inválida.' });
  if (!body || body.length > 2000) return res.status(400).json({ error: 'A mensagem deve ter de 1 a 2.000 caracteres.' });
  try {
    const conversation = await dbGet(`SELECT c.id FROM ksw_social_conversations c
      JOIN tenants low ON low.id=c.tenant_low_id AND low.status='active'
      JOIN tenants high ON high.id=c.tenant_high_id AND high.status='active'
      WHERE c.id=? AND (c.tenant_low_id=? OR c.tenant_high_id=?)`, [conversationId, req.tenant.id, req.tenant.id]);
    if (!conversation) return res.status(404).json({ error: 'Conversa não encontrada ou indisponível.' });
    const result = await dbRun('INSERT INTO ksw_social_messages (conversation_id,sender_tenant_id,sender_user_id,body) VALUES (?,?,?,?)', [conversationId, req.tenant.id, req.user.id, body]);
    await dbRun('UPDATE ksw_social_conversations SET updated_at=CURRENT_TIMESTAMP,last_message_at=CURRENT_TIMESTAMP WHERE id=?', [conversationId]);
    return res.status(201).json({ ok: true, message: { id: result.lastID, sender_tenant_id: req.tenant.id, is_mine: true, body, created_at: new Date().toISOString() } });
  } catch (error) {
    console.error('Social message send failed:', error);
    return res.status(500).json({ error: 'Não foi possível enviar a mensagem.' });
  }
});

module.exports = router;
