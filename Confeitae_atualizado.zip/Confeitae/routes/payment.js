const express = require('express');
const router = express.Router();
const db = require('../database');
const { MercadoPagoConfig, Payment } = require('mercadopago');
const { timingSafeEqual } = require('crypto');
const { authMiddleware } = require('../middleware/auth');
const Stripe = require('stripe');

const PLANOS = {
  mensal: { nome: 'Plano Mensal Confeitaê', valor: 59.99, dias: 30 },
  vitalicio: { nome: 'Plano Vitalício Confeitaê', valor: 1119.00, dias: 36500 }
};
const HOTMART_TEST = {
  productId: process.env.HOTMART_TEST_PRODUCT_ID || '8862465',
  price: 3.90,
  days: 1
};

function isValidHotmartToken(received, expected) {
  if (!received || !expected) return false;
  const receivedBuffer = Buffer.from(received);
  const expectedBuffer = Buffer.from(expected);
  return receivedBuffer.length === expectedBuffer.length &&
    timingSafeEqual(receivedBuffer, expectedBuffer);
}

function handleHotmartTestPurchase(req, res) {
  const expectedToken = process.env.HOTMART_HOTTOK;
  if (!expectedToken) {
    return res.status(503).json({ error: 'O webhook da Hotmart ainda não está configurado.' });
  }
  if (!isValidHotmartToken(req.get('x-hotmart-hottok'), expectedToken)) {
    return res.status(401).json({ error: 'Token do webhook da Hotmart inválido.' });
  }

  const { event, data } = req.body || {};
  if (event !== 'PURCHASE_APPROVED') return res.status(200).send('Evento ignorado.');

  const productId = data && data.product && data.product.id;
  const buyerEmail = data && data.buyer && data.buyer.email;
  const purchase = data && data.purchase;
  const transaction = purchase && purchase.transaction;
  const amount = Number(purchase && purchase.price && purchase.price.value);
  const currency = purchase && purchase.price && purchase.price.currency_value;

  if (String(productId) !== HOTMART_TEST.productId) {
    return res.status(200).send('Produto ignorado.');
  }
  if (!buyerEmail || !transaction || !Number.isFinite(amount) ||
      amount !== HOTMART_TEST.price || currency !== 'BRL' ||
      purchase.status !== 'APPROVED') {
    return res.status(400).json({ error: 'Os dados da compra de teste não são válidos.' });
  }

  const email = String(buyerEmail).trim().toLowerCase();
  const externalReference = `HOTMART-${String(transaction)}`;
  const expiration = new Date(Date.now() + HOTMART_TEST.days * 86400000).toISOString();

  db.get('SELECT id FROM users WHERE email = ?', [email], (userErr, user) => {
    if (userErr) {
      console.error('Erro ao localizar conta para compra Hotmart:', userErr);
      return res.status(500).json({ error: 'Não foi possível localizar a conta da compra.' });
    }
    if (!user) {
      return res.status(404).json({ error: 'Crie uma conta KSW com o mesmo e-mail usado na compra Hotmart.' });
    }

    db.serialize(() => {
      db.run('BEGIN IMMEDIATE TRANSACTION', (beginErr) => {
        if (beginErr) {
          console.error('Erro ao iniciar transação para compra Hotmart:', beginErr);
          return res.status(500).json({ error: 'Não foi possível registrar a compra Hotmart.' });
        }

        db.run(
          `INSERT OR IGNORE INTO orders
           (user_id, plano_tipo, valor, status, gateway, external_reference, payment_id)
           VALUES (?, 'teste', ?, 'approved', 'hotmart', ?, ?)`,
          [user.id, amount, externalReference, String(transaction)],
          function (insertErr) {
            if (insertErr) {
              return db.run('ROLLBACK', () => {
                console.error('Erro ao registrar compra Hotmart:', insertErr);
                res.status(500).json({ error: 'Não foi possível registrar a compra Hotmart.' });
              });
            }

            if (this.changes === 0) {
              return db.get(
                'SELECT user_id, gateway, status FROM orders WHERE external_reference = ?',
                [externalReference],
                (existingErr, existingOrder) => {
                  if (existingErr || !existingOrder ||
                      existingOrder.user_id !== user.id ||
                      existingOrder.gateway !== 'hotmart' ||
                      existingOrder.status !== 'approved') {
                    return db.run('ROLLBACK', () => {
                      if (existingErr) console.error('Erro ao validar evento Hotmart duplicado:', existingErr);
                      res.status(409).json({ error: 'A transação Hotmart já está associada a outra compra.' });
                    });
                  }
                  db.run('COMMIT', (commitErr) => {
                    if (commitErr) {
                      console.error('Erro ao confirmar evento Hotmart duplicado:', commitErr);
                      return res.status(500).json({ error: 'Não foi possível confirmar a compra Hotmart.' });
                    }
                    res.status(200).send('Compra já processada.');
                  });
                }
              );
            }

            db.run(
              `UPDATE users
               SET plano_tipo = 'teste', status_assinatura = 'ativa', data_vencimento = ?
               WHERE id = ?
                 AND (plano_tipo NOT IN ('mensal', 'vitalicio')
                   OR status_assinatura != 'ativa'
                   OR data_vencimento IS NULL
                   OR datetime(data_vencimento) <= CURRENT_TIMESTAMP)`,
              [expiration, user.id],
              (updateErr) => {
                if (updateErr) {
                  return db.run('ROLLBACK', () => {
                    console.error('Erro ao ativar acesso de teste Hotmart:', updateErr);
                    res.status(500).json({ error: 'Não foi possível ativar o acesso de teste.' });
                  });
                }
                db.run('COMMIT', (commitErr) => {
                  if (commitErr) {
                    console.error('Erro ao confirmar compra Hotmart:', commitErr);
                    return res.status(500).json({ error: 'Não foi possível confirmar a compra Hotmart.' });
                  }
                  return res.status(200).send('Compra aprovada e processada.');
                });
              }
            );
          }
        );
      });
    });
  });
}

function getMercadoPagoToken(){
  const token = process.env.MP_ACCESS_TOKEN;
  if (!token || /seu-access-token-aqui/i.test(token) || !/^(APP_USR|TEST)-/.test(token)) {
    return null;
  }
  return token;
}

function getPaymentClient(){
  const token = getMercadoPagoToken();
  return token ? new Payment(new MercadoPagoConfig({ accessToken: token })) : null;
}

function isPlatformPlanActive(planKey) {
  return new Promise((resolve, reject) => {
    db.get('SELECT is_active FROM platform_plans WHERE plan_key = ?', [planKey], (err, row) => {
      if (err) return reject(err);
      resolve(Boolean(row && Number(row.is_active) === 1));
    });
  });
}

function syncOrderStatus(order, paymentData, callback){
  if (paymentData.external_reference !== order.external_reference ||
      Number(paymentData.transaction_amount) !== Number(order.valor) ||
      paymentData.currency_id !== 'BRL') {
    return callback(new Error('Os dados do pagamento não correspondem ao pedido.'));
  }

  const status = paymentData.status || 'pending';
  const paymentId = String(paymentData.id);
  if (status !== 'approved') {
    return db.run(
      'UPDATE orders SET status = ?, payment_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [status, paymentId, order.id],
      (err) => callback(err, status)
    );
  }

  if (order.status === 'approved') return callback(null, 'approved');

  const plano = PLANOS[order.plano_tipo];
  if (!plano) return callback(new Error('Plano associado ao pedido inválido.'));
  const venceEm = new Date();
  venceEm.setDate(venceEm.getDate() + plano.dias);

  db.serialize(() => {
    db.run(
      'UPDATE orders SET status = ?, payment_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      ['approved', paymentId, order.id],
      (orderErr) => {
        if (orderErr) return callback(orderErr);
        db.run(
          'UPDATE users SET plano_tipo = ?, status_assinatura = ?, data_vencimento = ? WHERE id = ?',
          [order.plano_tipo, 'ativa', venceEm.toISOString(), order.user_id],
          (userErr) => callback(userErr, userErr ? undefined : 'approved')
        );
      }
    );
  });
}

router.get('/availability', async (req, res) => {
  try {
    const plans = await new Promise((resolve, reject) => db.all('SELECT plan_key, is_active FROM platform_plans', (err, rows) => err ? reject(err) : resolve(rows || [])));
    res.json({
      available: Boolean(getMercadoPagoToken() && plans.some((plan) => Number(plan.is_active) === 1)),
      methods: ['pix'],
      provider: 'Mercado Pago',
      plans: plans.reduce((result, plan) => { result[plan.plan_key] = Number(plan.is_active) === 1; return result; }, {})
    });
  } catch (error) {
    console.error('Falha ao consultar disponibilidade dos planos:', error);
    res.status(503).json({ error: 'Não foi possível consultar os planos.' });
  }
});

router.get('/hotmart-test/availability', (req, res) => {
  const hasPublicBaseUrl = /^https:\/\/[^/]+/i.test(process.env.BASE_URL || '');
  const available = Boolean(process.env.HOTMART_HOTTOK && hasPublicBaseUrl);
  res.json({
    available,
    message: available
      ? 'Checkout de teste disponível.'
      : !process.env.HOTMART_HOTTOK
        ? 'Configure HOTMART_HOTTOK para habilitar o checkout de teste.'
        : 'Configure BASE_URL com o endereço HTTPS público para habilitar o checkout de teste.'
  });
});

router.post('/hotmart/webhook', handleHotmartTestPurchase);

router.post('/create-checkout', authMiddleware, async (req, res) => {
  const { plano_tipo } = req.body || {};
  const plano = PLANOS[plano_tipo];
  if (!plano) {
    return res.status(400).json({ error: 'Plano inválido. Escolha "mensal" ou "vitalicio".' });
  }

  try {
    if (!(await isPlatformPlanActive(plano_tipo))) {
      return res.status(403).json({ error: 'Este plano não está disponível para novas compras.' });
    }
  } catch (error) {
    console.error('Falha ao validar disponibilidade do plano:', error);
    return res.status(503).json({ error: 'Não foi possível validar a disponibilidade do plano.' });
  }

  const payment = getPaymentClient();
  if (!payment) {
    return res.status(503).json({
      error: 'Pagamentos indisponíveis. O Mercado Pago ainda não está configurado neste servidor.'
    });
  }

  const external_reference = `KSW-${req.user.id}-${Date.now()}`;
  const body = {
    transaction_amount: plano.valor,
    description: plano.nome,
    payment_method_id: 'pix',
    payer: {
      email: req.user.email,
      first_name: req.user.nome
    },
    external_reference
  };
  const baseUrl = process.env.BASE_URL;
  if (baseUrl && /^https:\/\/[^/]+/i.test(baseUrl)) {
    body.notification_url = `${baseUrl.replace(/\/$/, '')}/api/payment/webhook`;
  }

  let result;
  try {
    result = await payment.create({ body });
  } catch (error) {
    console.error('Erro ao criar pagamento no Mercado Pago:', error);
    return res.status(502).json({ error: 'O Mercado Pago não conseguiu criar o pagamento. Tente novamente.' });
  }

  if (!result || !result.id) {
    console.error('Mercado Pago retornou pagamento sem identificador.');
    return res.status(502).json({ error: 'O Mercado Pago não retornou os dados necessários do pagamento.' });
  }

  const transactionData = result.point_of_interaction?.transaction_data || {};
  db.run(
    `INSERT INTO orders (user_id, plano_tipo, valor, status, gateway, external_reference, payment_id, qr_code, qr_code_base64, ticket_url)
     VALUES (?, ?, ?, ?, 'mercadopago', ?, ?, ?, ?, ?)`,
    [
      req.user.id,
      plano_tipo,
      plano.valor,
      result.status || 'pending',
      external_reference,
      String(result.id),
      transactionData.qr_code || '',
      transactionData.qr_code_base64 || '',
      transactionData.ticket_url || ''
    ],
    function (err) {
      if (err) {
        console.error('Erro ao salvar pedido do Mercado Pago:', err);
        return res.status(500).json({ error: 'Pagamento criado, mas não foi possível registrar o pedido. Contate o suporte antes de tentar novamente.' });
      }

      return res.status(201).json({
        order_id: this.lastID,
        external_reference,
        payment_id: String(result.id),
        status: result.status || 'pending',
        qr_code: transactionData.qr_code || '',
        qr_code_base64: transactionData.qr_code_base64 || '',
        ticket_url: transactionData.ticket_url || '',
        valor: plano.valor,
        plano_tipo
      });
    }
  );
});

router.get('/status/:external_reference', authMiddleware, (req, res) => {
  db.get(
    'SELECT * FROM orders WHERE external_reference = ? AND user_id = ?',
    [req.params.external_reference, req.user.id],
    async (err, order) => {
      if (err) return res.status(500).json({ error: 'Não foi possível consultar o pedido.' });
      if (!order) return res.status(404).json({ error: 'Pedido não encontrado.' });
      if (order.status === 'approved') return res.json({ status: 'approved', plano_tipo: order.plano_tipo });

      const payment = getPaymentClient();
      if (!payment || !order.payment_id) {
        return res.status(503).json({ error: 'Não foi possível consultar o pagamento no Mercado Pago.' });
      }

      try {
        const paymentData = await payment.get({ id: order.payment_id });
        syncOrderStatus(order, paymentData, (syncErr, status) => {
          if (syncErr) {
            console.error('Erro ao sincronizar status de pagamento:', syncErr);
            return res.status(502).json({ error: 'Não foi possível validar o status do pagamento.' });
          }
          return res.json({ status, plano_tipo: order.plano_tipo });
        });
      } catch (error) {
        console.error('Erro ao consultar pagamento no Mercado Pago:', error);
        return res.status(502).json({ error: 'Não foi possível consultar o pagamento. Tente novamente.' });
      }
    }
  );
});

router.post('/webhook', (req, res) => {
  const { type, data } = req.body;
  if (type !== 'payment' || !data || !data.id) return res.status(200).send('OK');

  const payment = getPaymentClient();
  if (!payment) return res.status(200).send('OK');

  payment.get({ id: data.id }).then((paymentData) => {
    const externalReference = paymentData && paymentData.external_reference;
    if (!externalReference) return;

    db.get('SELECT * FROM orders WHERE external_reference = ?', [externalReference], (err, order) => {
      if (err) {
        console.error('Erro ao localizar pedido do webhook:', err);
        return;
      }
      if (!order || order.gateway !== 'mercadopago') return;
      syncOrderStatus(order, paymentData, (syncErr) => {
        if (syncErr) console.error('Erro ao atualizar pedido via webhook:', syncErr);
      });
    });
  }).catch((error) => console.error('Erro ao consultar pagamento do webhook:', error));

  return res.status(200).send('OK');
});

router.post('/cancel-subscription', authMiddleware, async (req, res) => {
  db.get(
    'SELECT subscription_id_gateway, plano_tipo, data_vencimento FROM users WHERE id = ?',
    [req.user.id],
    async (err, user) => {
      if (err) return res.status(500).json({ error: 'Erro ao consultar sua assinatura.' });
      if (!user) return res.status(404).json({ error: 'Conta não encontrada.' });

      const subscriptionId = user.subscription_id_gateway;
      if (subscriptionId && subscriptionId.startsWith('sub_')) {
        const key = process.env.STRIPE_SECRET_KEY;
        if (!key || !key.startsWith('sk_')) {
          return res.status(503).json({ error: 'A integração Stripe não está configurada.' });
        }
        try {
          const stripe = new Stripe(key);
          await stripe.subscriptions.update(subscriptionId, { cancel_at_period_end: true });
          return res.json({
            message: 'O cancelamento da renovação foi agendado. Seu acesso continua até o fim do período já pago.',
            cancelamento_agendado: true,
            data_vencimento: user.data_vencimento
          });
        } catch (stripeError) {
          console.error('Erro ao agendar cancelamento Stripe:', stripeError);
          return res.status(502).json({ error: 'Não foi possível agendar o cancelamento na Stripe.' });
        }
      }

      db.run(
        'UPDATE users SET status_assinatura = "cancelada" WHERE id = ?',
        [req.user.id],
        (updateErr) => {
          if (updateErr) return res.status(500).json({ error: 'Erro ao cancelar assinatura.' });
          return res.json({ message: 'Sua assinatura foi cancelada.' });
        }
      );
    }
  );
});

module.exports = router;
