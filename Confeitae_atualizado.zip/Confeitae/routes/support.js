'use strict';

const express = require('express');
const db = require('../database');
const rateLimit = require('../middleware/rateLimit');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { tenantContextMiddleware } = require('../middleware/tenant');
const { parsePlanFeatures, hasPlanFeature } = require('../lib/plan-features');

const router = express.Router();

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (error, row) => error ? reject(error) : resolve(row || null)));
}
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows || [])));
}

const messageLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 30,
  key: (req) => `support-message:${req.tenant ? req.tenant.id : req.user.id}`,
  message: 'Você enviou muitas mensagens. Aguarde um pouco antes de enviar outra.'
});

async function requireSupportEntitlement(req, res, next) {
  try {
    if (!req.tenant || req.tenantRole !== 'owner' || req.tenant.owner_user_id !== Number(req.user.id)) {
      return res.status(403).json({ error: 'O chat com a administração está disponível apenas para o proprietário da empresa.', code: 'SUPPORT_OWNER_ONLY' });
    }
    const owner = await dbGet(
      `SELECT u.plano_tipo, p.features_json
         FROM users u LEFT JOIN platform_plans p ON p.plan_key = u.plano_tipo
        WHERE u.id = ?`, [req.tenant.owner_user_id]
    );
    const features = parsePlanFeatures(owner && owner.features_json);
    if (!hasPlanFeature(features, 'admin_chat')) {
      return res.status(403).json({ error: 'O chat direto com a administração está disponível no plano Vitalício.', code: 'SUPPORT_PLAN_REQUIRED' });
    }
    return next();
  } catch (error) {
    console.error('Falha ao validar acesso ao suporte:', error);
    return res.status(500).json({ error: 'Não foi possível validar o acesso ao suporte.' });
  }
}

router.use(authMiddleware, tenantContextMiddleware, checkActiveSubscription, requireSupportEntitlement);

async function ensureThread(tenantId, ownerUserId, tx = db) {
  const get = tx === db
    ? (sql, params) => dbGet(sql, params)
    : (sql, params) => tx.get(sql, params);
  const run = tx === db
    ? (sql, params) => new Promise((resolve, reject) => db.run(sql, params, function (error) { error ? reject(error) : resolve({ lastID: this.lastID }); }))
    : (sql, params) => tx.run(sql, params);
  let thread = await get('SELECT id, tenant_id, owner_user_id, status FROM platform_support_threads WHERE tenant_id = ?', [tenantId]);
  if (!thread) {
    try {
      const inserted = await run(
        `INSERT INTO platform_support_threads (tenant_id, owner_user_id, status) VALUES (?, ?, 'open')`,
        [tenantId, ownerUserId]
      );
      thread = { id: Number(inserted.lastID), tenant_id: tenantId, owner_user_id: ownerUserId, status: 'open' };
    } catch (error) {
      // Resolve uma possível criação concorrente usando a chave única por empresa.
      thread = await get('SELECT id, tenant_id, owner_user_id, status FROM platform_support_threads WHERE tenant_id = ?', [tenantId]);
      if (!thread) throw error;
    }
  }
  return thread;
}

router.get('/thread', async (req, res) => {
  try {
    const thread = await db.withTransaction(async (tx) => ensureThread(req.tenant.id, req.tenant.owner_user_id, tx));
    await dbRunMarkOwnerRead(thread.id);
    const messages = await dbAll(
      `SELECT id, sender_type, body, read_at, created_at
         FROM platform_support_messages WHERE thread_id = ?
        ORDER BY created_at DESC, id DESC LIMIT 100`, [thread.id]
    );
    return res.json({ thread: { id: thread.id, status: thread.status }, messages: messages.reverse() });
  } catch (error) {
    console.error('Falha ao carregar conversa de suporte:', error);
    return res.status(500).json({ error: 'Não foi possível carregar a conversa.' });
  }
});

function dbRunMarkOwnerRead(threadId) {
  return new Promise((resolve, reject) => db.run(
    `UPDATE platform_support_messages SET read_at = CURRENT_TIMESTAMP
      WHERE thread_id = ? AND sender_type = 'admin' AND read_at IS NULL`, [threadId],
    (error) => error ? reject(error) : resolve()
  ));
}

router.post('/messages', messageLimiter, async (req, res) => {
  const body = String((req.body && req.body.body) || '').trim();
  if (!body || body.length > 4000) return res.status(400).json({ error: 'A mensagem deve ter entre 1 e 4.000 caracteres.' });
  try {
    const message = await db.withTransaction(async (tx) => {
      const thread = await ensureThread(req.tenant.id, req.tenant.owner_user_id, tx);
      const inserted = await tx.run(
        `INSERT INTO platform_support_messages (thread_id, tenant_id, sender_type, sender_user_id, body)
         VALUES (?, ?, 'owner', ?, ?)`, [thread.id, req.tenant.id, req.user.id, body]
      );
      await tx.run(
        `UPDATE platform_support_threads SET status = 'open', updated_at = CURRENT_TIMESTAMP,
          last_message_at = CURRENT_TIMESTAMP WHERE id = ? AND tenant_id = ?`, [thread.id, req.tenant.id]
      );
      return { id: Number(inserted.lastID), thread_id: thread.id, sender_type: 'owner', body, created_at: new Date().toISOString() };
    });
    return res.status(201).json({ ok: true, message });
  } catch (error) {
    console.error('Falha ao enviar mensagem de suporte:', error);
    return res.status(500).json({ error: 'Não foi possível enviar sua mensagem. Tente novamente.' });
  }
});

module.exports = router;
