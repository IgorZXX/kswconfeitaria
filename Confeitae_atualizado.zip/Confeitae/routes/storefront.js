'use strict';

const express = require('express');
const crypto = require('crypto');
const db = require('../database');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
const rateLimit = require('../middleware/rateLimit');
const config = require('../lib/config');
const { isSubscriptionActive } = require('../lib/platform-admin');
const engine = require('../lib/storefront-engine');
const storefrontCapacity = require('../lib/storefront-capacity');
const { isAllowedRequestOrigin } = require('../lib/storefront-security');

const router = express.Router();
const publicOrderLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 12,
  key: (req) => `store-order:${req.ip || 'unknown'}`,
  message: 'Muitos pedidos enviados deste acesso. Aguarde alguns minutos e tente novamente.'
});

function get(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null)));
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || [])));
}
function run(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function onRun(err) {
    if (err) return reject(err);
    resolve({ changes: this.changes, lastID: this.lastID });
  }));
}
function safeJson(value, fallback) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' ? parsed : fallback;
  } catch (_) {
    return fallback;
  }
}
function parseSettings(row) {
  return {
    enabled: Boolean(row && row.enabled),
    whatsapp: row ? engine.normalizeBrazilWhatsApp(row.whatsapp) : '',
    instagram_url: row ? row.instagram_url : '',
    address: row ? row.address : '',
    pickup_enabled: row ? Boolean(row.pickup_enabled) : true,
    delivery_enabled: row ? Boolean(row.delivery_enabled) : false,
    delivery_fee: row ? Number(row.delivery_fee) : 0,
    minimum_order: row ? Number(row.minimum_order) : 0,
    lead_time_days: row ? Number(row.lead_time_days) : 1,
    instructions: row ? row.instructions : ''
  };
}
async function ensureSettings(tenantId) {
  await run('INSERT OR IGNORE INTO storefront_settings (tenant_id) VALUES (?)', [tenantId]);
  return get('SELECT * FROM storefront_settings WHERE tenant_id = ?', [tenantId]);
}
function isSameOrigin(req) {
  return isAllowedRequestOrigin({
    origin: req.get('origin'),
    secFetchSite: req.get('sec-fetch-site'),
    requestHost: req.get('host'),
    baseUrl: config.BASE_URL,
    isProduction: config.isProd,
    secure: Boolean(req.secure)
  });
}
function localToday() {
  const zone = process.env.KSW_TIME_ZONE || 'America/Sao_Paulo';
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date());
    const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  } catch (_) {
    return new Date().toISOString().slice(0, 10);
  }
}
async function loadStoreCapacity(tenantId, today = localToday()) {
  const configRow = await get("SELECT data FROM configuracoes WHERE tenant_id = ? AND id = 'main'", [tenantId]);
  const capacityConfig = safeJson(configRow && configRow.data, {});
  const capacity = storefrontCapacity.normalizeCapacity(capacityConfig);
  if (!capacity.max_orders_per_day && !capacity.max_units_per_day) {
    return { unavailable_dates: [], checked_until: engine.addDays(today, 60), has_limits: false };
  }
  const checkedUntil = engine.addDays(today, 60);
  const rows = await all(
    `SELECT data_entrega, status, data FROM pedidos
      WHERE tenant_id = ? AND data_entrega >= ? AND data_entrega <= ?
        AND COALESCE(status, '') <> 'cancelado'`,
    [tenantId, today, checkedUntil]
  );
  return {
    unavailable_dates: storefrontCapacity.buildUnavailableDates(rows, capacity),
    checked_until: checkedUntil,
    has_limits: true
  };
}

function validIdempotencyKey(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{16,80}$/.test(value);
}
function makeWhatsAppUrl(phone, order) {
  const message = `Olá! Enviei uma encomenda pela loja virtual. Código: ${order.id.slice(0, 8).toUpperCase()}. Total: R$ ${order.total.toFixed(2).replace('.', ',')}. Gostaria de combinar a confirmação e o pagamento.`;
  return `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
}
function respondWithOrder(res, order, phone, statusCode, replayed) {
  return res.status(statusCode).json({
    ok: true,
    replayed: Boolean(replayed),
    order: {
      id: order.id,
      code: order.id.slice(0, 8).toUpperCase(),
      status: order.st,
      total: order.total_com_entrega
    },
    whatsapp_url: phone ? makeWhatsAppUrl(phone, { id: order.id, total: Number(order.total_com_entrega) }) : null,
    message: 'Encomenda recebida. A confeitaria precisa confirmar disponibilidade e combinar o pagamento.'
  });
}
function publicMenu(row) {
  const sections = safeJson(row.sections_json, []);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    description: row.description,
    sections: Array.isArray(sections) ? sections.map((section) => ({
      id: String(section.id || ''),
      name: String(section.name || ''),
      description: String(section.description || ''),
      visible: section.visible !== false,
      products: (Array.isArray(section.products) ? section.products : []).map((product) => ({
        id: String(product.id || ''),
        name: String(product.name || ''),
        description: String(product.description || ''),
        price: Number(product.price),
        image_url: String(product.image_url || ''),
        visible: product.visible !== false,
        available: product.available !== false
      }))
    })) : []
  };
}

// Configuração da loja, acessível somente a integrantes autorizados da empresa.
router.get('/settings', authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePermission('menus.read'), async (req, res) => {
  try {
    const [row, hub] = await Promise.all([
      ensureSettings(req.tenant.id),
      get('SELECT slug FROM menu_hubs WHERE tenant_id = ?', [req.tenant.id])
    ]);
    res.json({
      settings: parseSettings(row),
      store_slug: hub ? hub.slug : null,
      store_url: hub ? `/loja/${encodeURIComponent(hub.slug)}` : null
    });
  } catch (error) {
    console.error('Falha ao carregar configurações da loja virtual:', error);
    res.status(500).json({ error: 'Não foi possível carregar as configurações da loja.' });
  }
});

router.put('/settings', authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePermission('menus.manage'), async (req, res) => {
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : null;
  if (!body) return res.status(400).json({ error: 'Envie as configurações em um objeto JSON.' });
  const normalized = engine.normalizeSettings(body);
  if (!normalized.ok) return res.status(400).json({ error: normalized.error });
  try {
    const settings = normalized.value;
    await run(
      `INSERT INTO storefront_settings
       (tenant_id, enabled, whatsapp, instagram_url, address, pickup_enabled, delivery_enabled,
        delivery_fee, minimum_order, lead_time_days, instructions, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
       ON CONFLICT(tenant_id) DO UPDATE SET
        enabled = excluded.enabled, whatsapp = excluded.whatsapp, instagram_url = excluded.instagram_url,
        address = excluded.address, pickup_enabled = excluded.pickup_enabled,
        delivery_enabled = excluded.delivery_enabled, delivery_fee = excluded.delivery_fee,
        minimum_order = excluded.minimum_order, lead_time_days = excluded.lead_time_days,
        instructions = excluded.instructions, updated_at = CURRENT_TIMESTAMP`,
      [req.tenant.id, settings.enabled ? 1 : 0, settings.whatsapp, settings.instagram_url,
        settings.address, settings.pickup_enabled ? 1 : 0, settings.delivery_enabled ? 1 : 0,
        settings.delivery_fee, settings.minimum_order, settings.lead_time_days, settings.instructions]
    );
    const row = await get('SELECT * FROM storefront_settings WHERE tenant_id = ?', [req.tenant.id]);
    res.json({ ok: true, settings: parseSettings(row) });
  } catch (error) {
    console.error('Falha ao salvar configurações da loja virtual:', error);
    res.status(500).json({ error: 'Não foi possível salvar as configurações da loja.' });
  }
});

// Página pública da loja. O slug é resolvido no servidor e nunca aceita tenant_id do cliente.
router.get('/public/:slug', async (req, res) => {
  const slug = String(req.params.slug || '').toLowerCase();
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 48) {
    return res.status(404).json({ error: 'Loja não encontrada.' });
  }
  try {
    const tenant = await get(
      `SELECT t.id, t.nome, t.status, h.slug, u.plano_tipo, u.status_assinatura, u.data_vencimento
         FROM menu_hubs h JOIN tenants t ON t.id = h.tenant_id
         JOIN users u ON u.id = t.owner_user_id
        WHERE h.slug = ? AND t.status = 'active'`, [slug]
    );
    if (!tenant || !isSubscriptionActive(tenant)) return res.status(404).json({ error: 'Loja não encontrada ou temporariamente indisponível.' });
    const settingsRow = await get('SELECT * FROM storefront_settings WHERE tenant_id = ?', [tenant.id]);
    const settings = parseSettings(settingsRow);
    if (!settings.enabled) return res.status(404).json({ error: 'Esta loja virtual ainda não está recebendo encomendas.' });
    const capacityOverview = await loadStoreCapacity(tenant.id);
    const menus = await all(
      'SELECT id, slug, title, description, sections_json FROM menus WHERE tenant_id = ? AND published = 1 ORDER BY updated_at DESC',
      [tenant.id]
    );
    const visibleMenus = menus.map(publicMenu).filter((menu) => menu.sections.some((section) =>
      section.visible && section.products.some((product) => product.visible)
    ));
    res.set('Cache-Control', 'public, max-age=15');
    res.json({
      store: {
        slug: tenant.slug,
        owner_name: tenant.nome,
        settings: {
          whatsapp: settings.whatsapp,
          instagram_url: settings.instagram_url,
          address: settings.address,
          pickup_enabled: settings.pickup_enabled,
          delivery_enabled: settings.delivery_enabled,
          delivery_fee: settings.delivery_fee,
          minimum_order: settings.minimum_order,
          lead_time_days: settings.lead_time_days,
          instructions: settings.instructions
        },
        capacity: capacityOverview,
        menus: visibleMenus
      }
    });
  } catch (error) {
    console.error('Falha ao carregar loja pública:', error);
    res.status(500).json({ error: 'Não foi possível carregar esta loja.' });
  }
});

// Recebe encomenda sem pagamento online nesta fase. O pedido entra como "recebido"
// e deve ser confirmado/pago diretamente com a confeitaria.
router.post('/public/:slug/orders', publicOrderLimiter, async (req, res) => {
  if (!isSameOrigin(req)) return res.status(403).json({ error: 'Origem da solicitação não permitida.' });
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : null;
  if (!body) return res.status(400).json({ error: 'Envie os dados da encomenda em JSON.' });
  if (String(body.website || '').trim()) return res.status(400).json({ error: 'Não foi possível validar a solicitação.' });
  if (!validIdempotencyKey(body.idempotency_key)) return res.status(400).json({ error: 'Atualize a página e tente enviar o pedido novamente.' });
  const slug = String(req.params.slug || '').toLowerCase();
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) || slug.length > 48) {
    return res.status(404).json({ error: 'Loja não encontrada.' });
  }

  try {
    const tenant = await get(
      `SELECT t.id, t.nome, t.owner_user_id, t.status, h.slug, u.plano_tipo, u.status_assinatura, u.data_vencimento
         FROM menu_hubs h JOIN tenants t ON t.id = h.tenant_id
         JOIN users u ON u.id = t.owner_user_id
        WHERE h.slug = ? AND t.status = 'active'`, [slug]
    );
    if (!tenant || !isSubscriptionActive(tenant)) return res.status(404).json({ error: 'Loja não encontrada ou temporariamente indisponível.' });
    const settingsRow = await get('SELECT * FROM storefront_settings WHERE tenant_id = ?', [tenant.id]);
    const settings = parseSettings(settingsRow);
    const menusRows = await all(
      'SELECT id, slug, title, description, sections_json FROM menus WHERE tenant_id = ? AND published = 1',
      [tenant.id]
    );
    const menus = menusRows.map(publicMenu);
    // Resolve reenvios antes de validar o catálogo atual: se o preço ou a disponibilidade
    // mudou após um pedido já criado, o cliente ainda recebe a confirmação original.
    const requestFingerprint = engine.fingerprintOrderRequest(body);
    const priorRequest = await get(
      'SELECT order_id, request_hash FROM storefront_order_requests WHERE tenant_id = ? AND idempotency_key = ?',
      [tenant.id, body.idempotency_key]
    );
    if (priorRequest) {
      if (priorRequest.request_hash && priorRequest.request_hash !== requestFingerprint) {
        return res.status(409).json({ error: 'Esta chave de envio já foi usada com outra versão do pedido. Atualize a página e tente novamente.' });
      }
      const priorOrder = await get('SELECT data FROM pedidos WHERE tenant_id = ? AND id = ?', [tenant.id, priorRequest.order_id]);
      if (priorOrder) {
        const order = safeJson(priorOrder.data, null);
        if (!order || typeof order.id !== 'string' || !Number.isFinite(Number(order.total_com_entrega))) {
          return res.status(500).json({ error: 'O pedido anterior não pôde ser recuperado. Entre em contato com a confeitaria.' });
        }
        if (!priorRequest.request_hash) {
          await run('UPDATE storefront_order_requests SET request_hash = ? WHERE tenant_id = ? AND idempotency_key = ?',
            [requestFingerprint, tenant.id, body.idempotency_key]);
        }
        res.set('Cache-Control', 'no-store, private');
        return respondWithOrder(res, order, settings.whatsapp, 200, true);
      }
    }

    const checked = engine.buildOrder(body, settings, menus, localToday());
    if (!checked.ok) return res.status(checked.status || 400).json({ error: checked.error });

    const created = await db.withTransaction(async (tx) => {
      await tx.run("DELETE FROM storefront_order_requests WHERE tenant_id = ? AND created_at < datetime('now', '-90 days')", [tenant.id]);
      const replay = await tx.get(
        'SELECT order_id, request_hash FROM storefront_order_requests WHERE tenant_id = ? AND idempotency_key = ?',
        [tenant.id, body.idempotency_key]
      );
      if (replay) {
        if (replay.request_hash && replay.request_hash !== requestFingerprint) return { conflict: true };
        const existing = await tx.get('SELECT data FROM pedidos WHERE tenant_id = ? AND id = ?', [tenant.id, replay.order_id]);
        if (existing) {
          const order = safeJson(existing.data, null);
          if (!order || typeof order.id !== 'string' || !Number.isFinite(Number(order.total_com_entrega))) {
            return { corrupt: true };
          }
          if (!replay.request_hash) {
            await tx.run('UPDATE storefront_order_requests SET request_hash = ? WHERE tenant_id = ? AND idempotency_key = ?',
              [requestFingerprint, tenant.id, body.idempotency_key]);
          }
          return { order, replayed: true };
        }
        await tx.run('DELETE FROM storefront_order_requests WHERE tenant_id = ? AND idempotency_key = ?', [tenant.id, body.idempotency_key]);
      }

      const configCapacityRow = await tx.get("SELECT data FROM configuracoes WHERE tenant_id = ? AND id = 'main'", [tenant.id]);
      const capacityConfig = safeJson(configCapacityRow && configCapacityRow.data, {});
      const capacity = storefrontCapacity.normalizeCapacity(capacityConfig);
      if (capacity.max_orders_per_day || capacity.max_units_per_day) {
        const existingDayRows = await tx.all(
          `SELECT status, data FROM pedidos
            WHERE tenant_id = ? AND data_entrega = ? AND COALESCE(status, '') <> 'cancelado'`,
          [tenant.id, checked.value.delivery_date]
        );
        const capacityCheck = storefrontCapacity.checkDailyCapacity(
          existingDayRows,
          capacity,
          checked.value.items.map((item) => ({ quantity: item.quantity }))
        );
        if (!capacityCheck.ok) return { capacityExceeded: true, error: capacityCheck.error };
      }

      const customerRows = await tx.all('SELECT id, data FROM clientes WHERE tenant_id = ?', [tenant.id]);
      let clientId = '';
      for (const row of customerRows) {
        const client = safeJson(row.data, {});
        if (engine.digits(client.tel || client.whatsapp || '') === checked.value.customer.phone) {
          clientId = String(row.id);
          client.nome = checked.value.customer.name;
          client.tel = checked.value.customer.phone;
          if (checked.value.customer.email) client.email = checked.value.customer.email;
          await tx.run(
            'UPDATE clientes SET nome = ?, data = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND id = ?',
            [client.nome, JSON.stringify({ ...client, id: clientId }), tenant.id, clientId]
          );
          break;
        }
      }
      if (!clientId) {
        clientId = crypto.randomUUID().replace(/-/g, '');
        const client = {
          id: clientId,
          nome: checked.value.customer.name,
          tel: checked.value.customer.phone,
          email: checked.value.customer.email,
          origem: 'loja_virtual'
        };
        await tx.run(
          `INSERT INTO clientes (user_id, tenant_id, id, nome, data, updated_at)
           VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
          [tenant.owner_user_id, tenant.id, clientId, client.nome, JSON.stringify(client)]
        );
      }

      const orderId = crypto.randomUUID().replace(/-/g, '');
      const order = {
        id: orderId,
        cli: clientId,
        cli_nome: checked.value.customer.name,
        tel: checked.value.customer.phone,
        email: checked.value.customer.email,
        ent: checked.value.delivery_date,
        hora: checked.value.delivery_time,
        obs: checked.value.notes,
        itens: checked.value.items.map((item) => ({
          pid: item.product_id,
          nome: item.name,
          q: item.quantity,
          pu: item.unit_price,
          cu: null,
          menu_id: item.menu_id,
          menu_title: item.menu_title
        })),
        st: 'recebido',
        pagamentos: [],
        pg: 0,
        pd: '',
        origem: 'loja_virtual',
        metodo_entrega: checked.value.fulfillment,
        endereco_entrega: checked.value.address,
        subtotal: checked.value.subtotal,
        taxa_entrega: checked.value.delivery_fee,
        total_com_entrega: checked.value.total,
        criado_em: new Date().toISOString()
      };
      await tx.run(
        `INSERT INTO pedidos (user_id, tenant_id, id, cliente_id, data_entrega, status, total, pago, data, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, CURRENT_TIMESTAMP)`,
        [tenant.owner_user_id, tenant.id, orderId, clientId, order.ent, order.st, order.total_com_entrega, JSON.stringify(order)]
      );
      await tx.run(
        'INSERT INTO storefront_order_requests (tenant_id, idempotency_key, order_id, request_hash) VALUES (?, ?, ?, ?)',
        [tenant.id, body.idempotency_key, orderId, requestFingerprint]
      );
      return { order, replayed: false };
    });

    if (created.conflict) {
      return res.status(409).json({ error: 'Esta chave de envio já foi usada com outra versão do pedido. Atualize a página e tente novamente.' });
    }
    if (created.capacityExceeded) {
      res.set('Cache-Control', 'no-store, private');
      return res.status(409).json({ error: created.error, code: 'STOREFRONT_CAPACITY_EXCEEDED' });
    }
    if (created.corrupt) {
      return res.status(500).json({ error: 'O pedido anterior não pôde ser recuperado. Entre em contato com a confeitaria.' });
    }
    res.set('Cache-Control', 'no-store, private');
    return respondWithOrder(res, created.order, settings.whatsapp, created.replayed ? 200 : 201, created.replayed);
  } catch (error) {
    if (error && error.code === 'SQLITE_CONSTRAINT') {
      return res.status(409).json({ error: 'Este pedido já foi enviado. Atualize a página para conferir o status.' });
    }
    console.error('Falha ao registrar encomenda pública:', error);
    return res.status(500).json({ error: 'Não foi possível registrar a encomenda. Tente novamente.' });
  }
});

module.exports = router;
