'use strict';

const express = require('express');
const crypto = require('crypto');
const db = require('../database');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
const { requirePlanFeature } = require('../middleware/plan-feature');
const rateLimit = require('../middleware/rateLimit');
const config = require('../lib/config');
const { isAllowedRequestOrigin } = require('../lib/storefront-security');
const capacity = require('../lib/storefront-capacity');
const quoteTools = require('../lib/quote-public');

const router = express.Router();
const publicReadLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 40,
  key: (req) => `quote-read:${req.ip || 'unknown'}`,
  message: 'Muitas consultas a orçamentos. Aguarde alguns minutos e tente novamente.'
});
const publicDecisionLimiter = rateLimit({
  windowMs: 10 *  60 * 1000,
  max: 8,
  key: (req) => `quote-decision:${req.ip || 'unknown'}`,
  message: 'Muitas tentativas de resposta. Aguarde alguns minutos e tente novamente.'
});

function get(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null)));
}
function safeJson(value, fallback) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : fallback;
  } catch (_) { return fallback; }
}
function localToday() {
  const zone = process.env.KSW_TIME_ZONE || 'America/Sao_Paulo';
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date());
    const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  } catch (_) { return new Date().toISOString().slice(0, 10); }
}
function validToken(token) {
  return typeof token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(token);
}
function sameOrigin(req) {
  return isAllowedRequestOrigin({
    origin: req.get('origin'),
    secFetchSite: req.get('sec-fetch-site'),
    requestHost: req.get('host'),
    baseUrl: config.BASE_URL,
    isProduction: config.isProd,
    secure: Boolean(req.secure)
  });
}
function quoteStatusFromLink(row, quote) {
  if (row.status === 'accepted') return 'accepted';
  if (row.status === 'rejected') return 'rejected';
  if (row.status === 'expired' || (quote && quote.validade < localToday())) return 'expired';
  if (quote && quote.status === 'recusado') return 'rejected';
  if (quote && quote.status === 'expirado') return 'expired';
  if (quote && quote.status === 'aceito') return 'accepted';
  if (quote && quote.status !== 'enviado') return 'unavailable';
  return 'pending';
}
function publicPayload(row) {
  const quote = safeJson(row.quote_data, {});
  const client = safeJson(row.client_data, {});
  const status = quoteStatusFromLink(row, quote);
  return {
    ok: true,
    state: status,
    business: { name: String(row.business_name || 'Confeitaria').slice(0, 120) },
    client_name: String(client.nome || 'Cliente').slice(0, 120),
    quote: {
      description: String(quote.descricao || '').slice(0, 1000),
      total: Number(quote.total) || 0,
      valid_until: String(quote.validade || row.expires_at),
      delivery_date: String(quote.entrega || ''),
      quantity: Number(quote.quantidade) || 1,
      order_code: row.order_id ? String(row.order_id).slice(0, 8).toUpperCase() : null
    }
  };
}

// Os links públicos usam token aleatório de uso restrito; somente o hash é persistido.
router.get('/public/:token', publicReadLimiter, async (req, res) => {
  const token = String(req.params.token || '');
  if (!validToken(token)) return res.status(404).json({ error: 'Orçamento não encontrado.' });
  try {
    const row = await get(
      `SELECT l.*, q.data AS quote_data, c.data AS client_data, t.nome AS business_name
         FROM quote_public_links l
         JOIN orcamentos q ON q.tenant_id = l.tenant_id AND q.id = l.quote_id
         JOIN tenants t ON t.id = l.tenant_id
         LEFT JOIN clientes c ON c.tenant_id = l.tenant_id AND c.id = json_extract(q.data, '$.cli')
        WHERE l.token_hash = ?`,
      [quoteTools.hashPublicToken(token)]
    );
    if (!row) return res.status(404).json({ error: 'Orçamento não encontrado ou link inválido.' });
    const payload = publicPayload(row);
    if (!row.client_data) return res.status(410).json({ error: 'Não foi possível localizar o cadastro da cliente. Entre em contato com a confeitaria.' });
    if (payload.state === 'expired' && row.status === 'pending') {
      await db.withTransaction((tx) => tx.run(
        "UPDATE quote_public_links SET status = 'expired' WHERE id = ? AND status = 'pending'", [row.id]
      ));
    }
    res.set('Cache-Control', 'no-store, private');
    res.set('Referrer-Policy', 'no-referrer');
    return res.json(payload);
  } catch (error) {
    console.error('Falha ao consultar orçamento público:', error);
    return res.status(500).json({ error: 'Não foi possível consultar este orçamento.' });
  }
});

router.post('/public/:token/decision', publicDecisionLimiter, async (req, res) => {
  if (!sameOrigin(req)) return res.status(403).json({ error: 'Origem da solicitação não permitida.' });
  const token = String(req.params.token || '');
  if (!validToken(token)) return res.status(404).json({ error: 'Orçamento não encontrado.' });
  const action = req.body && req.body.action;
  if (!['accept', 'reject'].includes(action)) return res.status(400).json({ error: 'Resposta inválida.' });
  if (action === 'accept' && req.body.confirmed !== true) return res.status(400).json({ error: 'Confirme que leu e concorda com os detalhes do orçamento.' });

  try {
    const result = await db.withTransaction(async (tx) => {
      const row = await tx.get(
        `SELECT l.*, q.data AS quote_data, t.owner_user_id
           FROM quote_public_links l
           JOIN orcamentos q ON q.tenant_id = l.tenant_id AND q.id = l.quote_id
           JOIN tenants t ON t.id = l.tenant_id
          WHERE l.token_hash = ?`,
        [quoteTools.hashPublicToken(token)]
      );
      if (!row) return { status: 404, error: 'Orçamento não encontrado ou link inválido.' };
      const quote = safeJson(row.quote_data, null);
      if (!quote) return { status: 500, error: 'Os dados deste orçamento estão indisponíveis.' };
      if (row.status === 'accepted') return { ok: true, replayed: true, state: 'accepted', order_code: row.order_id ? row.order_id.slice(0, 8).toUpperCase() : null };
      if (row.status === 'rejected') return { status: 409, error: 'Este orçamento já foi recusado.' };
      if (row.status === 'expired' || String(row.expires_at) < localToday() || String(quote.validade || '') < localToday()) {
        await tx.run("UPDATE quote_public_links SET status = 'expired' WHERE id = ? AND status = 'pending'", [row.id]);
        quote.status = 'expirado';
        await tx.run('UPDATE orcamentos SET status = ?, data = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND id = ?',
          ['expirado', JSON.stringify(quote), row.tenant_id, row.quote_id]);
        return { status: 410, error: 'A validade deste orçamento terminou. Entre em contato com a confeitaria para solicitar uma nova proposta.' };
      }
      if (row.status !== 'pending' || quote.status !== 'enviado') return { status: 409, error: 'Este orçamento não está mais disponível para resposta.' };

      const clientRow = await tx.get('SELECT data FROM clientes WHERE tenant_id = ? AND id = ?', [row.tenant_id, quote.cli]);
      if (!clientRow) return { status: 409, error: 'O cadastro da cliente não está mais disponível. Entre em contato com a confeitaria.' };

      if (action === 'reject') {
        quote.status = 'recusado';
        quote.respondido_em = new Date().toISOString();
        quote.resposta_publica = 'recusado';
        await tx.run('UPDATE orcamentos SET status = ?, data = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND id = ?',
          ['recusado', JSON.stringify(quote), row.tenant_id, row.quote_id]);
        await tx.run("UPDATE quote_public_links SET status = 'rejected', decided_at = CURRENT_TIMESTAMP WHERE id = ?", [row.id]);
        return { ok: true, state: 'rejected' };
      }

      // Se a proposta informa uma data de entrega, a aprovação também respeita a capacidade
      // configurada na Agenda; uma aprovação não reserva silenciosamente um dia lotado.
      if (quote.entrega) {
        const configRow = await tx.get("SELECT data FROM configuracoes WHERE tenant_id = ? AND id = 'main'", [row.tenant_id]);
        const configData = safeJson(configRow && configRow.data, {});
        const normalizedCapacity = capacity.normalizeCapacity(configData);
        if (normalizedCapacity.max_orders_per_day || normalizedCapacity.max_units_per_day) {
          const orders = await tx.all(`SELECT data_entrega, status, data FROM pedidos
            WHERE tenant_id = ? AND data_entrega = ? AND COALESCE(status, '') <> 'cancelado'`, [row.tenant_id, quote.entrega]);
          const check = capacity.checkDailyCapacity(orders, configData, [{ quantity: Number(quote.quantidade) || 1 }]);
          if (!check.ok) return { status: 409, error: `A data ${quote.entrega.split('-').reverse().join('/')} não possui mais disponibilidade. Entre em contato com a confeitaria para combinar outra data; seu orçamento continua aguardando resposta.` };
        }
      }

      const orderId = crypto.randomUUID();
      const order = quoteTools.buildAcceptedOrder(quote, orderId);
      await tx.run(`INSERT INTO pedidos
        (user_id, tenant_id, id, cliente_id, data_entrega, status, total, pago, data, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [row.owner_user_id, row.tenant_id, orderId, order.cli, order.ent, order.st, Number(quote.total), 0, JSON.stringify(order)]);

      quote.status = 'aceito';
      quote.respondido_em = order.aprovado_em;
      quote.resposta_publica = 'aceito';
      quote.pedido_id = orderId;
      await tx.run('UPDATE orcamentos SET status = ?, data = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND id = ?',
        ['aceito', JSON.stringify(quote), row.tenant_id, row.quote_id]);
      await tx.run("UPDATE quote_public_links SET status = 'accepted', order_id = ?, decided_at = CURRENT_TIMESTAMP WHERE id = ?",
        [orderId, row.id]);
      return { ok: true, state: 'accepted', order_code: orderId.slice(0, 8).toUpperCase() };
    });
    if (result.status) return res.status(result.status).json({ error: result.error });
    res.set('Cache-Control', 'no-store, private');
    return res.json(result);
  } catch (error) {
    console.error('Falha ao registrar resposta do orçamento:', error);
    return res.status(500).json({ error: 'Não foi possível registrar sua resposta. Tente novamente.' });
  }
});

// Cria ou renova o link para um orçamento pertencente à empresa autenticada.
router.post('/share', authMiddleware, tenantContextMiddleware, checkActiveSubscription,
  requirePermission('data.write'), requirePlanFeature('quotes'), async (req, res) => {
    const normalized = quoteTools.normalizeQuote(req.body && req.body.quote, localToday());
    if (!normalized.ok) return res.status(400).json({ error: normalized.error });
    const quoteInput = normalized.value;
    try {
      const client = await get('SELECT id FROM clientes WHERE tenant_id = ? AND id = ?', [req.tenant.id, quoteInput.cli]);
      if (!client) return res.status(400).json({ error: 'A cliente selecionada não foi encontrada nesta empresa.' });
      const token = crypto.randomBytes(32).toString('base64url');
      const tokenHash = quoteTools.hashPublicToken(token);
      const now = new Date().toISOString();
      const link = await db.withTransaction(async (tx) => {
        const existing = await tx.get('SELECT data FROM orcamentos WHERE tenant_id = ? AND id = ?', [req.tenant.id, quoteInput.id]);
        const priorQuote = safeJson(existing && existing.data, {});
        if (['aceito', 'recusado'].includes(String(priorQuote.status || '').toLowerCase())) {
          return { error: 'Este orçamento já recebeu uma resposta e não pode ser enviado novamente.' };
        }
        const active = await tx.get('SELECT status FROM quote_public_links WHERE tenant_id = ? AND quote_id = ?', [req.tenant.id, quoteInput.id]);
        if (active && ['accepted', 'rejected'].includes(active.status)) return { error: 'Este orçamento já recebeu uma resposta e não pode ser enviado novamente.' };
        const quote = {
          ...priorQuote,
          ...quoteInput,
          status: 'enviado',
          enviado_em: now
        };
        if (existing) {
          await tx.run(`UPDATE orcamentos SET cliente_id = ?, status = ?, total = ?, validade = ?, data = ?, updated_at = CURRENT_TIMESTAMP
            WHERE tenant_id = ? AND id = ?`,
          [quote.cli, quote.status, quote.total, quote.validade, JSON.stringify(quote), req.tenant.id, quote.id]);
        } else {
          await tx.run(`INSERT INTO orcamentos
            (user_id, tenant_id, id, cliente_id, status, total, validade, data, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
          [req.user.id, req.tenant.id, quote.id, quote.cli, quote.status, quote.total, quote.validade, JSON.stringify(quote)]);
        }
        await tx.run(`INSERT INTO quote_public_links (tenant_id, quote_id, token_hash, status, expires_at, order_id, created_at, decided_at)
          VALUES (?, ?, ?, 'pending', ?, NULL, CURRENT_TIMESTAMP, NULL)
          ON CONFLICT(tenant_id, quote_id) DO UPDATE SET token_hash = excluded.token_hash, status = 'pending',
            expires_at = excluded.expires_at, order_id = NULL, created_at = CURRENT_TIMESTAMP, decided_at = NULL`,
        [req.tenant.id, quote.id, tokenHash, quote.validade]);
        return { quoteId: quote.id, expiresAt: quote.validade };
      });
      if (link.error) return res.status(409).json({ error: link.error });
      const baseUrl = String(config.BASE_URL).replace(/\/+$/, '');
      const url = `${baseUrl}/orcamento/${token}`;
      return res.json({ ok: true, url, expires_at: link.expiresAt, quote_id: link.quoteId, message: 'Link de aprovação criado. Envie-o à cliente.' });
    } catch (error) {
      console.error('Falha ao criar link público do orçamento:', error);
      return res.status(500).json({ error: 'Não foi possível criar o link de aprovação.' });
    }
  }
);

module.exports = router;
