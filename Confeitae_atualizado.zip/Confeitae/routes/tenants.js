'use strict';

const express = require('express');
const crypto = require('crypto');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
const { listUserTenants } = require('../lib/tenant-service');
const { formatSqliteDateTime } = require('../lib/tenant-schema');
const { canAssignRole, canChangeMember, canRemoveMember } = require('../lib/tenant-permissions');
const rateLimit = require('../middleware/rateLimit');
const { parsePlanFeatures, hasPlanFeature } = require('../lib/plan-features');

const router = express.Router();
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const VALID_ROLES = new Set(['admin', 'manager', 'member', 'viewer']);
const inviteLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  key: (req) => `tenant-invite:${req.tenant ? req.tenant.id : req.user.id}`,
  message: 'Muitos convites enviados. Tente novamente mais tarde.'
});

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row || null)));
}
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || [])));
}
function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => db.run(sql, params, function onRun(err) {
    if (err) return reject(err);
    return resolve({ changes: this.changes, lastID: this.lastID });
  }));
}

async function audit(tenantId, actorUserId, action, targetUserId = null, metadata = {}) {
  await dbRun(
    `INSERT INTO tenant_audit_logs (tenant_id, actor_user_id, action, target_user_id, metadata_json)
     VALUES (?, ?, ?, ?, ?)`,
    [tenantId, actorUserId, action, targetUserId, JSON.stringify(metadata)]
  );
}

router.get('/mine', authMiddleware, async (req, res) => {
  try {
    const result = await listUserTenants(req.user.id, req.get('x-tenant-id'));
    return res.json(result);
  } catch (err) {
    console.error('Erro ao listar empresas do usuário:', err);
    return res.status(500).json({ error: 'Não foi possível carregar suas empresas.' });
  }
});

router.get('/current', authMiddleware, tenantContextMiddleware, requirePermission('tenant.read'), async (req, res) => {
  try {
    const tenant = await dbGet(
      `SELECT t.id, t.nome, t.slug, t.created_at,
              owner.plano_tipo, owner.status_assinatura, owner.data_vencimento,
              billing.name AS plan_name, billing.max_members, billing.features_json
         FROM tenants t JOIN users owner ON owner.id = t.owner_user_id
         LEFT JOIN platform_plans billing ON billing.plan_key = owner.plano_tipo
        WHERE t.id = ?`,
      [req.tenant.id]
    );
    if (!tenant) return res.status(404).json({ error: 'Empresa não encontrada.' });

    const membersUsedRow = await dbGet(
      `SELECT COUNT(*) AS total FROM tenant_memberships WHERE tenant_id = ? AND status = 'active'`, [req.tenant.id]
    );
    const membersUsed = Number(membersUsedRow && membersUsedRow.total) || 0;
    const members = req.tenantRole && ['owner', 'admin', 'manager'].includes(req.tenantRole)
      ? await dbAll(
          `SELECT u.id AS user_id, u.nome, u.email, tm.role, tm.status, tm.created_at
             FROM tenant_memberships tm JOIN users u ON u.id = tm.user_id
            WHERE tm.tenant_id = ? ORDER BY CASE tm.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, u.nome COLLATE NOCASE`,
          [req.tenant.id]
        )
      : [];
    return res.json({
      tenant: { ...tenant, id: Number(tenant.id), max_members: Number(tenant.max_members) || 0, features: parsePlanFeatures(tenant.features_json) },
      membership: { role: req.tenantRole },
      members,
      capabilities: {
        can_read_team: ['owner', 'admin', 'manager'].includes(req.tenantRole),
        can_manage_team: ['owner', 'admin'].includes(req.tenantRole),
        can_manage_settings: ['owner', 'admin'].includes(req.tenantRole),
        can_manage_billing: req.tenantRole === 'owner',
        max_members: Number(tenant.max_members) || 0,
        members_used: membersUsed,
        can_invite: ['owner', 'admin'].includes(req.tenantRole) && hasPlanFeature(parsePlanFeatures(tenant.features_json), 'team') && (!(Number(tenant.max_members) > 0) || membersUsed < Number(tenant.max_members))
      }
    });
  } catch (err) {
    console.error('Erro ao carregar empresa:', err);
    return res.status(500).json({ error: 'Não foi possível carregar a empresa.' });
  }
});

router.patch('/current', authMiddleware, tenantContextMiddleware, requirePermission('tenant.settings'), async (req, res) => {
  const nome = String((req.body && req.body.nome) || '').trim();
  if (nome.length < 2 || nome.length > 100) {
    return res.status(400).json({ error: 'O nome da empresa deve ter entre 2 e 100 caracteres.' });
  }
  try {
    await dbRun('UPDATE tenants SET nome = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [nome, req.tenant.id]);
    await audit(req.tenant.id, req.user.id, 'tenant.updated', null, { fields: ['nome'] });
    return res.json({ ok: true, nome });
  } catch (err) {
    console.error('Erro ao atualizar empresa:', err);
    return res.status(500).json({ error: 'Não foi possível atualizar a empresa.' });
  }
});

router.get('/invitations', authMiddleware, tenantContextMiddleware, requirePermission('team.read'), async (req, res) => {
  try {
    const invitations = await dbAll(
      `SELECT id, email, role, expires_at, created_at
         FROM tenant_invitations
        WHERE tenant_id = ? AND accepted_at IS NULL AND expires_at > CURRENT_TIMESTAMP
        ORDER BY created_at DESC`,
      [req.tenant.id]
    );
    return res.json({ invitations });
  } catch (err) {
    console.error('Erro ao carregar convites:', err);
    return res.status(500).json({ error: 'Não foi possível carregar os convites.' });
  }
});

router.post('/invitations', authMiddleware, tenantContextMiddleware, requirePermission('team.manage'), inviteLimiter, async (req, res) => {
  const email = String((req.body && req.body.email) || '').trim().toLowerCase();
  const role = String((req.body && req.body.role) || 'member').trim();
  if (email.length > 160 || !EMAIL_PATTERN.test(email)) return res.status(400).json({ error: 'Informe um e-mail válido.' });
  if (!VALID_ROLES.has(role) || !canAssignRole(req.tenantRole, role)) {
    return res.status(403).json({ error: 'Seu perfil não pode atribuir esse papel.' });
  }

  try {
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const expiresAt = formatSqliteDateTime(Date.now() + 7 * 24 * 60 * 60 * 1000);
    // Reserva o acesso e cria o convite na mesma transação: duas solicitações
    // simultâneas não conseguem ultrapassar o limite de pessoas do plano.
    const created = await db.withTransaction(async (tx) => {
      const plan = await tx.get(
        `SELECT p.max_members, p.features_json, u.plano_tipo
           FROM tenants t JOIN users u ON u.id = t.owner_user_id
           LEFT JOIN platform_plans p ON p.plan_key = u.plano_tipo
          WHERE t.id = ?`, [req.tenant.id]
      );
      const planFeatures = parsePlanFeatures(plan && plan.features_json);
      if (!hasPlanFeature(planFeatures, 'team')) {
        const error = new Error('A gestão de equipe não está incluída no plano atual. Faça upgrade para convidar outras pessoas.');
        error.status = 403; error.code = 'PLAN_FEATURE_REQUIRED'; throw error;
      }

      const invitedUser = await tx.get('SELECT id FROM users WHERE email = ? COLLATE NOCASE', [email]);
      if (invitedUser) {
        const existingMember = await tx.get(
          `SELECT id FROM tenant_memberships WHERE tenant_id = ? AND user_id = ? AND status = 'active'`,
          [req.tenant.id, invitedUser.id]
        );
        if (existingMember) { const error = new Error('Esta pessoa já participa da empresa.'); error.status = 409; throw error; }
      }
      const duplicateInvite = await tx.get(
        `SELECT id FROM tenant_invitations
          WHERE tenant_id = ? AND email = ? COLLATE NOCASE AND accepted_at IS NULL AND datetime(expires_at) > CURRENT_TIMESTAMP
          LIMIT 1`, [req.tenant.id, email]
      );
      if (duplicateInvite) { const error = new Error('Já existe um convite pendente para este e-mail.'); error.status = 409; throw error; }

      const activeMembers = await tx.get(
        `SELECT COUNT(*) AS total FROM tenant_memberships WHERE tenant_id = ? AND status = 'active'`, [req.tenant.id]
      );
      const activeInvites = await tx.get(
        `SELECT COUNT(*) AS total FROM tenant_invitations
          WHERE tenant_id = ? AND accepted_at IS NULL AND datetime(expires_at) > CURRENT_TIMESTAMP`, [req.tenant.id]
      );
      const seatLimit = Number(plan && plan.max_members) || 0;
      const membersCount = Number(activeMembers && activeMembers.total) || 0;
      const pendingCount = Number(activeInvites && activeInvites.total) || 0;
      if (seatLimit > 0 && membersCount + pendingCount >= seatLimit) {
        const error = new Error(`O plano permite ${seatLimit} acesso(s) no total. Remova um convite ou faça upgrade para adicionar mais pessoas.`);
        error.status = 409; error.code = 'TEAM_SEAT_LIMIT'; throw error;
      }
      if (pendingCount >= 30) { const error = new Error('Esta empresa atingiu o limite de 30 convites pendentes.'); error.status = 429; throw error; }

      const result = await tx.run(
        `INSERT INTO tenant_invitations (tenant_id, email, role, token_hash, invited_by, expires_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [req.tenant.id, email, role, tokenHash, req.user.id, expiresAt]
      );
      return { lastID: result.lastID, invitedUserId: invitedUser ? invitedUser.id : null };
    });
    await audit(req.tenant.id, req.user.id, 'team.invitation_created', created.invitedUserId, { email, role });
    const origin = process.env.BASE_URL || `${req.protocol}://${req.get('host')}`;
    return res.status(201).json({
      invitation: {
        id: Number(created.lastID), email, role, expires_at: expiresAt,
        accept_url: `${origin.replace(/\/$/, '')}/#convite=${rawToken}`
      },
      message: 'Convite criado. Compartilhe o link com a pessoa convidada.'
    });
  } catch (err) {
    if (err.status && err.status < 500) return res.status(err.status).json({ error: err.message, ...(err.code ? { code: err.code } : {}) });
    console.error('Erro ao criar convite:', err);
    return res.status(500).json({ error: 'Não foi possível criar o convite.' });
  }
});

// A pessoa precisa estar autenticada e usar exatamente o e-mail convidado.
// Não exige tenantContext porque o usuário ainda pode não fazer parte da empresa.
router.post('/invitations/accept', authMiddleware, async (req, res) => {
  const token = String((req.body && req.body.token) || '').trim();
  if (!/^[a-f0-9]{64}$/i.test(token)) return res.status(400).json({ error: 'Convite inválido.' });
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');

  try {
    const result = await db.withTransaction(async (tx) => {
      const invitation = await tx.get(
        `SELECT i.*, t.nome AS tenant_nome, t.slug AS tenant_slug
           FROM tenant_invitations i JOIN tenants t ON t.id = i.tenant_id
          WHERE i.token_hash = ? AND i.accepted_at IS NULL AND i.expires_at > CURRENT_TIMESTAMP`,
        [tokenHash]
      );
      if (!invitation) {
        const error = new Error('Convite inválido, expirado ou já utilizado.');
        error.status = 404;
        throw error;
      }
      if (String(invitation.email).toLowerCase() !== String(req.user.email || '').toLowerCase()) {
        const user = await tx.get('SELECT email FROM users WHERE id = ?', [req.user.id]);
        if (!user || String(invitation.email).toLowerCase() !== String(user.email).toLowerCase()) {
          const error = new Error('Entre com a conta que recebeu este convite.');
          error.status = 403;
          throw error;
        }
      }
      const plan = await tx.get(
        `SELECT p.max_members, p.features_json
           FROM tenants t JOIN users owner ON owner.id = t.owner_user_id
           LEFT JOIN platform_plans p ON p.plan_key = owner.plano_tipo
          WHERE t.id = ?`, [invitation.tenant_id]
      );
      const planFeatures = parsePlanFeatures(plan && plan.features_json);
      if (!hasPlanFeature(planFeatures, 'team')) {
        const error = new Error('O plano desta empresa não permite adicionar membros.');
        error.status = 403;
        throw error;
      }
      const existing = await tx.get(
        'SELECT id, status FROM tenant_memberships WHERE tenant_id = ? AND user_id = ?',
        [invitation.tenant_id, req.user.id]
      );
      if (existing && existing.status === 'active') {
        const error = new Error('Você já participa desta empresa.');
        error.status = 409;
        throw error;
      }
      const activeMembers = await tx.get(
        `SELECT COUNT(*) AS total FROM tenant_memberships WHERE tenant_id = ? AND status = 'active'`, [invitation.tenant_id]
      );
      const seatLimit = Number(plan && plan.max_members) || 0;
      if ((!existing || existing.status !== 'active') && seatLimit > 0 && Number(activeMembers && activeMembers.total) >= seatLimit) {
        const error = new Error(`Esta empresa já atingiu o limite de ${seatLimit} acessos do plano.`);
        error.status = 409;
        throw error;
      }
      if (existing) {
        await tx.run(
          `UPDATE tenant_memberships SET role = ?, status = 'active', invited_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
          [invitation.role, invitation.invited_by, existing.id]
        );
      } else {
        await tx.run(
          `INSERT INTO tenant_memberships (tenant_id, user_id, role, status, invited_by)
           VALUES (?, ?, ?, 'active', ?)`,
          [invitation.tenant_id, req.user.id, invitation.role, invitation.invited_by]
        );
      }
      await tx.run('UPDATE tenant_invitations SET accepted_at = CURRENT_TIMESTAMP WHERE id = ? AND accepted_at IS NULL', [invitation.id]);
      await tx.run(
        `INSERT INTO tenant_audit_logs (tenant_id, actor_user_id, action, target_user_id, metadata_json)
         VALUES (?, ?, 'team.invitation_accepted', ?, ?)`,
        [invitation.tenant_id, req.user.id, req.user.id, JSON.stringify({ role: invitation.role })]
      );
      return { id: Number(invitation.tenant_id), nome: invitation.tenant_nome, slug: invitation.tenant_slug, role: invitation.role };
    });
    const tenants = await listUserTenants(req.user.id, result.id);
    return res.json({ ok: true, tenant: result, tenants: tenants.tenants, current_tenant: tenants.current_tenant });
  } catch (err) {
    const status = err.status || 500;
    if (status >= 500) console.error('Erro ao aceitar convite:', err);
    return res.status(status).json({ error: status >= 500 ? 'Não foi possível aceitar o convite.' : err.message });
  }
});

router.get('/members', authMiddleware, tenantContextMiddleware, requirePermission('team.read'), async (req, res) => {
  try {
    const members = await dbAll(
      `SELECT u.id AS user_id, u.nome, u.email, tm.role, tm.status, tm.created_at
         FROM tenant_memberships tm JOIN users u ON u.id = tm.user_id
        WHERE tm.tenant_id = ? ORDER BY CASE tm.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, u.nome COLLATE NOCASE`,
      [req.tenant.id]
    );
    return res.json({ members });
  } catch (err) {
    console.error('Erro ao listar membros:', err);
    return res.status(500).json({ error: 'Não foi possível carregar os membros.' });
  }
});

router.patch('/members/:userId', authMiddleware, tenantContextMiddleware, requirePermission('team.manage'), async (req, res) => {
  const targetUserId = Number(req.params.userId);
  const nextRole = String((req.body && req.body.role) || '');
  if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0 || !VALID_ROLES.has(nextRole)) {
    return res.status(400).json({ error: 'Membro ou papel inválido.' });
  }
  try {
    const target = await dbGet('SELECT id, role FROM tenant_memberships WHERE tenant_id = ? AND user_id = ? AND status = \'active\'', [req.tenant.id, targetUserId]);
    if (!target) return res.status(404).json({ error: 'Membro não encontrado.' });
    if (!canChangeMember(req.tenantRole, target.role, nextRole)) return res.status(403).json({ error: 'Você não pode alterar o papel deste membro.' });
    await dbRun('UPDATE tenant_memberships SET role = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND user_id = ?', [nextRole, req.tenant.id, targetUserId]);
    await audit(req.tenant.id, req.user.id, 'team.role_changed', targetUserId, { from: target.role, to: nextRole });
    return res.json({ ok: true });
  } catch (err) {
    console.error('Erro ao alterar papel:', err);
    return res.status(500).json({ error: 'Não foi possível alterar o papel.' });
  }
});

router.delete('/members/:userId', authMiddleware, tenantContextMiddleware, requirePermission('team.manage'), async (req, res) => {
  const targetUserId = Number(req.params.userId);
  if (!Number.isSafeInteger(targetUserId) || targetUserId <= 0) return res.status(400).json({ error: 'Membro inválido.' });
  try {
    const target = await dbGet('SELECT id, role FROM tenant_memberships WHERE tenant_id = ? AND user_id = ? AND status = \'active\'', [req.tenant.id, targetUserId]);
    if (!target) return res.status(404).json({ error: 'Membro não encontrado.' });
    if (!canRemoveMember(req.tenantRole, target.role, targetUserId === Number(req.user.id))) {
      return res.status(403).json({ error: 'Você não pode remover este membro.' });
    }
    await dbRun('DELETE FROM tenant_memberships WHERE tenant_id = ? AND user_id = ?', [req.tenant.id, targetUserId]);
    await audit(req.tenant.id, req.user.id, 'team.member_removed', targetUserId, { previous_role: target.role });
    return res.json({ ok: true });
  } catch (err) {
    console.error('Erro ao remover membro:', err);
    return res.status(500).json({ error: 'Não foi possível remover o membro.' });
  }
});

router.delete('/invitations/:id', authMiddleware, tenantContextMiddleware, requirePermission('team.manage'), async (req, res) => {
  const invitationId = Number(req.params.id);
  if (!Number.isSafeInteger(invitationId) || invitationId <= 0) return res.status(400).json({ error: 'Convite inválido.' });
  try {
    const invitation = await dbGet(
      'SELECT id, role FROM tenant_invitations WHERE id = ? AND tenant_id = ? AND accepted_at IS NULL',
      [invitationId, req.tenant.id]
    );
    if (!invitation) return res.status(404).json({ error: 'Convite não encontrado.' });
    if (invitation.role === 'admin' && req.tenantRole !== 'owner') {
      return res.status(403).json({ error: 'Somente o proprietário pode revogar convites de administrador.' });
    }
    await dbRun('DELETE FROM tenant_invitations WHERE id = ? AND tenant_id = ?', [invitationId, req.tenant.id]);
    await audit(req.tenant.id, req.user.id, 'team.invitation_revoked', null, { invitation_id: invitationId, role: invitation.role });
    return res.json({ ok: true });
  } catch (err) {
    console.error('Erro ao revogar convite:', err);
    return res.status(500).json({ error: 'Não foi possível revogar o convite.' });
  }
});

module.exports = router;
