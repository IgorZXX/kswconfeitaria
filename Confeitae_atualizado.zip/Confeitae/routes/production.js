'use strict';

const express = require('express');
const crypto = require('crypto');
const db = require('../database');
const costing = require('../public/costing');
const productionEngine = require('../public/production-engine');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
const { requirePlanFeature } = require('../middleware/plan-feature');
const rateLimit = require('../middleware/rateLimit');

const router = express.Router();
const DEFINITIONS = Object.fromEntries(db.DATA_TABLES.map((definition) => [definition.key, definition]));
const ID_PATTERN = /^[A-Za-z0-9_.-]{1,64}$/;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const mutationLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  key: (req) => `production-tenant:${req.tenant ? req.tenant.id : req.user.id}`,
  message: 'Muitas movimentações de produção em pouco tempo. Aguarde um minuto.'
});
function today() {
  const timeZone = process.env.KSW_TIME_ZONE || 'America/Sao_Paulo';
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone, year: 'numeric', month: '2-digit', day: '2-digit'
    }).formatToParts(new Date());
    const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
    return `${values.year}-${values.month}-${values.day}`;
  } catch (_) {
    return new Date().toISOString().slice(0, 10);
  }
}
const TODAY = today;

function validCalendarDate(value) {
  if (!DATE_PATTERN.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function number(value) {
  const parsed = typeof value === 'number'
    ? value
    : Number(String(value == null ? '' : value).trim().replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : NaN;
}

function text(value, max = 200) {
  return value == null ? '' : String(value).trim().slice(0, max);
}

function parseRow(row) {
  if (!row) return null;
  try {
    const parsed = JSON.parse(row.data);
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? { ...parsed, id: String(row.id) }
      : null;
  } catch (_) {
    return null;
  }
}

async function getRecord(tx, key, tenantId, id) {
  const definition = DEFINITIONS[key];
  const row = await tx.get(
    `SELECT id, data FROM ${definition.table} WHERE tenant_id = ? AND id = ?`,
    [tenantId, id]
  );
  return parseRow(row);
}

async function getRecords(tx, key, tenantId) {
  const definition = DEFINITIONS[key];
  const rows = await tx.all(`SELECT id, data FROM ${definition.table} WHERE tenant_id = ?`, [tenantId]);
  return rows.map(parseRow).filter(Boolean);
}

function extractColumns(key, record) {
  const qty = (value) => {
    const parsed = number(value == null ? 0 : value);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  switch (key) {
    case 'ingredientes':
      return [text(record.nome, 120), qty(record.est), qty(record.min), text(record.val, 10)];
    case 'embalagens':
      return [text(record.nome, 120), text(record.un || record.unidade || 'un', 20), qty(record.preco), qty(record.est), qty(record.min), text(record.val, 10)];
    case 'lotes':
      return [text(record.item_tipo, 20), text(record.item_id, 64), qty(record.quantidade_inicial), qty(record.quantidade_disponivel), text(record.unidade, 20), text(record.validade, 10), qty(record.custo_unitario), text(record.recebido_em, 40), text(record.fornecedor_id, 64)];
    case 'mov':
      return [text(record.ing || record.ingrediente_id || record.item_id, 64), text(record.item_tipo || 'ingrediente', 20), text(record.item_id || record.ingrediente_id || record.ing, 64), text(record.tipo, 30), qty(record.qtd), text(record.data || record.criado_em, 40)];
    case 'producao':
      return [text(record.pedido_id, 64), text(record.produto_id, 64), qty(record.quantidade), text(record.data_prevista, 10), text(record.status, 30), text(record.iniciado_em, 40), text(record.concluido_em, 40), record.consumo_aplicado ? 1 : 0];
    case 'perdas':
      return [text(record.item_tipo, 20), text(record.item_id, 64), qty(record.quantidade), text(record.unidade, 20), text(record.motivo, 160), text(record.data, 10), qty(record.custo_total)];
    default:
      throw new Error('Coleção não permitida nesta operação.');
  }
}

async function saveRecord(tx, key, tenantId, actorUserId, record) {
  const definition = DEFINITIONS[key];
  const columns = definition.columns.map((column) => column.name);
  const values = extractColumns(key, record);
  const existing = await tx.get(
    `SELECT user_id FROM ${definition.table} WHERE tenant_id = ? AND id = ?`,
    [tenantId, String(record.id)]
  );
  if (existing) {
    await tx.run(
      `UPDATE ${definition.table} SET ${columns.map((column) => `${column} = ?`).join(', ')},
       data = ?, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = ? AND id = ?`,
      [...values, JSON.stringify(record), tenantId, String(record.id)]
    );
    return;
  }
  await tx.run(
    `INSERT INTO ${definition.table} (user_id, tenant_id, id, ${columns.join(', ')}, data, updated_at)
     VALUES (?, ?, ?, ${columns.map(() => '?').join(', ')}, ?, CURRENT_TIMESTAMP)`,
    [actorUserId, tenantId, String(record.id), ...values, JSON.stringify(record)]
  );
}

function stockQuantity(item) {
  const value = item && (item.est != null ? item.est : item.estoque);
  const parsed = number(value == null ? 0 : value);
  return Number.isFinite(parsed) ? parsed : 0;
}

async function consumeInventory(tx, tenantId, actorUserId, itemType, itemId, quantity, date, context) {
  const collection = itemType === 'ingrediente' ? 'ingredientes' : 'embalagens';
  const item = await getRecord(tx, collection, tenantId, itemId);
  if (!item) {
    const error = new Error(itemType === 'ingrediente' ? 'Ingrediente não encontrado.' : 'Embalagem não encontrada.');
    error.status = 404;
    throw error;
  }

  const lots = (await getRecords(tx, 'lotes', tenantId)).filter((lot) =>
    lot.item_tipo === itemType && String(lot.item_id) === String(itemId)
  );
  const allocation = productionEngine.planLotConsumption(lots, stockQuantity(item), quantity, date);
  if (!allocation.valid) {
    const error = new Error(`${item.nome}: ${allocation.error}`);
    error.status = 409;
    throw error;
  }

  for (const update of allocation.lot_updates) {
    const lot = lots.find((entry) => String(entry.id) === update.id);
    if (!lot) continue;
    lot.quantidade_disponivel = update.quantidade_disponivel;
    await saveRecord(tx, 'lotes', tenantId, actorUserId, lot);
  }

  item.est = allocation.stock_after;
  await saveRecord(tx, collection, tenantId, actorUserId, item);

  const unit = text(item.un || item.unidade || 'un', 20);
  const unitCost = Math.max(0, number(item.preco) || 0);
  const estimatedCost = productionEngine.estimateConsumptionCost(allocation, lots, unitCost);
  const movement = {
    id: crypto.randomUUID(),
    ing: item.nome,
    ingrediente_id: itemId,
    item_tipo: itemType,
    item_id: itemId,
    tipo: context.movementType,
    qtd: allocation.requested,
    data: date,
    motivo: text(context.reason, 160),
    producao_id: context.productionId || '',
    pedido_id: context.orderId || '',
    custo_total: estimatedCost,
    lotes_consumidos: allocation.lot_updates
  };
  await saveRecord(tx, 'mov', tenantId, actorUserId, movement);

  return {
    item_type: itemType,
    item_id: itemId,
    name: item.nome,
    quantity: allocation.requested,
    unit,
    stock_after: allocation.stock_after,
    estimated_cost: estimatedCost,
    lot_updates: allocation.lot_updates.map((entry) => ({ id: entry.id, consumed: entry.consumed }))
  };
}

router.post('/:id/consume', authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePlanFeature('production'), requirePermission('production.manage'), mutationLimiter, async (req, res) => {
  const productionId = String(req.params.id || '');
  if (!ID_PATTERN.test(productionId)) return res.status(400).json({ error: 'Identificador da produção inválido.' });

  try {
    const result = await db.withTransaction(async (tx) => {
      const tenantId = req.tenant.id;
      const actorUserId = req.user.id;
      const production = await getRecord(tx, 'producao', tenantId, productionId);
      if (!production) {
        const error = new Error('Ordem de produção não encontrada.');
        error.status = 404;
        throw error;
      }
      if (production.consumo_aplicado || production.status === 'concluida') {
        const error = new Error('O consumo desta produção já foi registrado.');
        error.status = 409;
        error.code = 'CONSUMPTION_ALREADY_APPLIED';
        throw error;
      }
      if (production.status === 'cancelada' || production.status === 'cancelado') {
        const error = new Error('Não é possível consumir estoque de uma produção cancelada.');
        error.status = 409;
        throw error;
      }

      const productId = text(production.produto_id, 64);
      const product = await getRecord(tx, 'produtos', tenantId, productId);
      if (!product) {
        const error = new Error('Produto da ordem não encontrado.');
        error.status = 404;
        throw error;
      }
      const ingredients = await getRecords(tx, 'ingredientes', tenantId);
      const packagings = await getRecords(tx, 'embalagens', tenantId);
      const plan = productionEngine.buildProductionPlan(product, production.quantidade, ingredients, packagings);
      if (!plan.valid) {
        const error = new Error(plan.errors[0] || 'Ficha técnica inválida.');
        error.status = 400;
        throw error;
      }

      const producedResult = productionEngine.validateProducedQuantity(
        req.body && req.body.quantity_produced,
        plan.produced_quantity
      );
      if (!producedResult.valid) {
        const error = new Error(producedResult.error);
        error.status = 400;
        throw error;
      }

      const consumed = [];
      for (const material of plan.materials) {
        consumed.push(await consumeInventory(tx, tenantId, actorUserId, 'ingrediente', material.item_id, material.quantity, TODAY(), {
          movementType: 'saida_producao',
          reason: `Consumo da produção ${productionId} · ${product.nome}`,
          productionId,
          orderId: production.pedido_id
        }));
      }
      if (plan.packaging) {
        consumed.push(await consumeInventory(tx, tenantId, actorUserId, 'embalagem', plan.packaging.item_id, plan.packaging.quantity, TODAY(), {
          movementType: 'saida_producao',
          reason: `Embalagens da produção ${productionId} · ${product.nome}`,
          productionId,
          orderId: production.pedido_id
        }));
      }

      production.status = 'concluida';
      production.consumo_aplicado = true;
      production.quantidade_solicitada = plan.requested_quantity;
      production.quantidade_produzida = producedResult.quantity;
      production.lotes_producao = plan.batches;
      production.consumido_em = TODAY();
      production.concluido_em = new Date().toISOString();
      production.consumos = consumed;
      production.custo_estimado = Math.round(consumed.reduce((sum, entry) => sum + entry.estimated_cost, 0) * 100) / 100;
      production.produto_nome = product.nome;
      await saveRecord(tx, 'producao', tenantId, actorUserId, production);

      return {
        production_id: productionId,
        product_name: product.nome,
        requested_quantity: plan.requested_quantity,
        produced_quantity: producedResult.quantity,
        planned_quantity: plan.produced_quantity,
        batches: plan.batches,
        consumed
      };
    });
    return res.json({ ok: true, production: result });
  } catch (error) {
    const status = error.status || 500;
    if (status >= 500) console.error('Erro ao concluir produção:', error);
    return res.status(status).json({
      error: status >= 500 ? 'Não foi possível concluir a produção.' : error.message,
      code: error.code || undefined
    });
  }
});

router.post('/waste', authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePlanFeature('production'), requirePermission('production.manage'), mutationLimiter, async (req, res) => {
  const body = req.body && typeof req.body === 'object' && !Array.isArray(req.body) ? req.body : {};
  const itemType = body.item_type;
  const itemId = text(body.item_id, 64);
  const quantity = number(body.quantity);
  const reason = text(body.reason, 160);
  const date = text(body.date || TODAY(), 10);
  if (!['ingrediente', 'embalagem'].includes(itemType) || !ID_PATTERN.test(itemId)) {
    return res.status(400).json({ error: 'Selecione um ingrediente ou uma embalagem válidos.' });
  }
  if (!(quantity > 0) || quantity > 100000) return res.status(400).json({ error: 'Informe uma quantidade válida.' });
  if (reason.length < 3) return res.status(400).json({ error: 'Descreva o motivo da perda (mínimo de 3 caracteres).' });
  if (!validCalendarDate(date)) {
    return res.status(400).json({ error: 'Informe uma data válida.' });
  }
  if (date > TODAY()) {
    return res.status(400).json({ error: 'A data da perda não pode estar no futuro.' });
  }

  try {
    const result = await db.withTransaction(async (tx) => {
      const tenantId = req.tenant.id;
      const actorUserId = req.user.id;
      const consumption = await consumeInventory(tx, tenantId, actorUserId, itemType, itemId, quantity, date, {
        movementType: 'saida_perda',
        reason: `Perda registrada: ${reason}`
      });
      const loss = {
        id: crypto.randomUUID(),
        item_tipo: itemType,
        item_id: itemId,
        item_nome: consumption.name,
        quantidade: consumption.quantity,
        unidade: consumption.unit,
        motivo: reason,
        data: date,
        custo_total: consumption.estimated_cost,
        lotes: consumption.lot_updates
      };
      await saveRecord(tx, 'perdas', tenantId, actorUserId, loss);
      return loss;
    });
    return res.status(201).json({ ok: true, loss: result });
  } catch (error) {
    const status = error.status || 500;
    if (status >= 500) console.error('Erro ao registrar perda de estoque:', error);
    return res.status(status).json({ error: status >= 500 ? 'Não foi possível registrar a perda.' : error.message });
  }
});

module.exports = router;
