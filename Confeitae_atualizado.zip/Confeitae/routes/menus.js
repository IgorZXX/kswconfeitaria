const express = require('express');
const crypto = require('crypto');
const fs = require('node:fs');
const path = require('node:path');
const db = require('../database');
const rateLimit = require('../middleware/rateLimit');
const { sanitizeMenuImage, MAX_BYTES } = require('../lib/menu-image-security');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');
const { requirePlanFeature } = require('../middleware/plan-feature');
const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');

const router = express.Router();
const slugPattern = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
const uploadLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 24,
  key: (req) => `menu-image:${req.user && req.user.id}:${req.tenant && req.tenant.id}:${req.ip || 'unknown'}`,
  message: 'Limite de uploads atingido. Aguarde alguns minutos antes de enviar outras imagens.'
});
const imageStorageRoot = path.resolve(__dirname, '..', 'storage', 'menu-products');

function slugify(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 48) || 'cardapio';
}

function parseMenu(row) {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    description: row.description,
    published: Boolean(row.published),
    sections: JSON.parse(row.sections_json),
    created_at: row.created_at,
    updated_at: row.updated_at
  };
}

function hasJsonObjectBody(req, res) {
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Envie os dados do cardápio em um objeto JSON.' });
    return false;
  }
  return true;
}

function normalizeSections(value, tenantId) {
  if (!Array.isArray(value) || value.length > 40) {
    return { error: 'Adicione até 40 seções ao cardápio.' };
  }

  const sections = [];
  for (const section of value) {
    if (!section || typeof section !== 'object' ||
        typeof section.name !== 'string' || !section.name.trim() ||
        section.name.trim().length > 70 ||
        !Array.isArray(section.products) || section.products.length > 100) {
      return { error: 'Revise os nomes e os produtos das seções.' };
    }

    const products = [];
    for (const product of section.products) {
      const rawPrice = product && product.price;
      const price = Number(rawPrice);
      if (!product || typeof product !== 'object' ||
          typeof product.name !== 'string' || !product.name.trim() ||
          product.name.trim().length > 100 ||
          (typeof rawPrice !== 'number' && typeof rawPrice !== 'string') ||
          (typeof rawPrice === 'string' && !rawPrice.trim()) ||
          !Number.isFinite(price) || price < 0 || price > 1000000 ||
          (product.description != null && String(product.description).length > 500) ||
          (product.image_url && !isAllowedImageReference(product.image_url, tenantId))) {
        return { error: 'Revise o nome, o preço, a descrição e a imagem dos produtos.' };
      }

      products.push({
        id: String(product.id || crypto.randomBytes(8).toString('hex')).slice(0, 40),
        name: product.name.trim(),
        description: String(product.description || '').trim(),
        price,
        image_url: String(product.image_url || '').trim(),
        visible: product.visible !== false,
        available: product.available !== false
      });
    }

    sections.push({
      id: String(section.id || crypto.randomBytes(8).toString('hex')).slice(0, 40),
      name: section.name.trim(),
      description: String(section.description || '').trim().slice(0, 180),
      visible: section.visible !== false,
      products
    });
  }

  return { sections };
}

function isAllowedImageReference(value, tenantId) {
  if (typeof value !== 'string' || value.length > 2000) return false;
  if (new RegExp('^/api/menus/images/' + Number(tenantId) + '/[a-f0-9]{32}\\.png$').test(value)) return true;
  // Compatibilidade temporária com links externos já cadastrados em cardápios antigos.
  return isHttpUrl(value);
}

function isHttpUrl(value) {
  if (typeof value !== 'string' || value.length > 2000) return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch (error) {
    return false;
  }
}

function ensureHub(tenantId, ownerUserId, callback) {
  db.get('SELECT slug FROM menu_hubs WHERE tenant_id = ?', [tenantId], (existingErr, existing) => {
    if (existingErr) return callback(existingErr);
    if (existing) return callback(null, existing);
    const slug = `confeitaria-${tenantId}-${crypto.randomBytes(3).toString('hex')}`;
    db.run(
      'INSERT OR IGNORE INTO menu_hubs (user_id, tenant_id, slug) VALUES (?, ?, ?)',
      [ownerUserId, tenantId, slug],
      (insertErr) => {
        if (insertErr) return callback(insertErr);
        db.get('SELECT slug FROM menu_hubs WHERE tenant_id = ?', [tenantId], callback);
      }
    );
  });
}

// Imagens de produtos publicadas nos cardápios. O arquivo é entregue como PNG
// raster, sem execução de conteúdo e com MIME fixo + nosniff.
router.get('/images/:tenantId/:filename', async (req, res) => {
  const tenantId = String(req.params.tenantId || '');
  const filename = String(req.params.filename || '');
  if (!/^\d{1,12}$/.test(tenantId) || !/^[a-f0-9]{32}\.png$/.test(filename)) {
    return res.status(404).json({ error: 'Imagem não encontrada.' });
  }
  const tenantDirectory = path.resolve(imageStorageRoot, `tenant-${tenantId}`);
  const imagePath = path.resolve(tenantDirectory, filename);
  if (!imagePath.startsWith(`${tenantDirectory}${path.sep}`)) return res.status(404).end();
  try {
    const stat = await fs.promises.stat(imagePath);
    if (!stat.isFile() || stat.size <= 0 || stat.size > MAX_BYTES) return res.status(404).json({ error: 'Imagem não encontrada ou inválida.' });
    const image = await fs.promises.readFile(imagePath);
    // Defesa em profundidade: valida e entrega a versão reconstruída, sem metadados.
    const cleanImage = sanitizeMenuImage(image);
    res.set({
      'Content-Type': 'image/png',
      'X-Content-Type-Options': 'nosniff',
      'Content-Disposition': 'inline; filename="produto.png"',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'Cross-Origin-Resource-Policy': 'same-site'
    });
    return res.status(200).send(cleanImage.buffer);
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('Falha ao entregar imagem de cardápio:', error.message);
    return res.status(404).json({ error: 'Imagem não encontrada ou inválida.' });
  }
});

router.get('/public/menus/:slug', (req, res) => {
  db.get(
    `SELECT menus.*, tenants.nome AS owner_name
     FROM menus JOIN tenants ON tenants.id = menus.tenant_id
     WHERE menus.slug = ? AND menus.published = 1 AND menus.tenant_id IS NOT NULL AND tenants.status = 'active'`,
    [req.params.slug],
    (err, row) => {
      if (err) return res.status(500).json({ error: 'Não foi possível carregar este cardápio.' });
      if (!row) return res.status(404).json({ error: 'Este cardápio não foi encontrado ou não está publicado.' });
      const menu = parseMenu(row);
      menu.owner_name = row.owner_name;
      res.json({ menu });
    }
  );
});

router.get('/public/links/:slug', (req, res) => {
  db.get(
    `SELECT menu_hubs.tenant_id, tenants.nome AS owner_name
       FROM menu_hubs JOIN tenants ON tenants.id = menu_hubs.tenant_id
      WHERE menu_hubs.slug = ? AND tenants.status = 'active'`,
    [req.params.slug],
    (hubErr, hub) => {
      if (hubErr) return res.status(500).json({ error: 'Não foi possível carregar esta vitrine.' });
      if (!hub) return res.status(404).json({ error: 'Esta vitrine não foi encontrada.' });
      db.all(
        'SELECT id, slug, title, description FROM menus WHERE tenant_id = ? AND published = 1 ORDER BY updated_at DESC',
        [hub.tenant_id],
        (menusErr, menus) => {
          if (menusErr) return res.status(500).json({ error: 'Não foi possível carregar os cardápios publicados.' });
          res.json({ owner_name: hub.owner_name, menus });
        }
      );
    }
  );
});

router.use(authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePlanFeature('digital_menu'));

// Recebe somente PNG raster enviado pelo navegador após decodificação e rasterização
// de JPG/PNG/WebP. O servidor verifica assinatura, CRC, dimensões, pixels e fluxo
// zlib, reconstrói o PNG e descarta metadados/chunks auxiliares.
router.post('/upload-image', requirePermission('menus.manage'), uploadLimiter,
  express.raw({ type: 'application/octet-stream', limit: `${MAX_BYTES}` }), async (req, res) => {
    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      return res.status(400).json({ error: 'Selecione uma imagem válida para enviar.' });
    }
    try {
      const cleanImage = sanitizeMenuImage(req.body);
      const tenantDirectory = path.resolve(imageStorageRoot, `tenant-${req.tenant.id}`);
      await fs.promises.mkdir(tenantDirectory, { recursive: true, mode: 0o700 });
      const existingFiles = await fs.promises.readdir(tenantDirectory);
      let existingBytes = 0;
      for (const existingFile of existingFiles) {
        if (!/^[a-f0-9]{32}\.png$/.test(existingFile)) continue;
        try { existingBytes += (await fs.promises.stat(path.join(tenantDirectory, existingFile))).size; } catch (_) { /* arquivo removido durante a leitura */ }
      }
      if (existingFiles.length >= 500 || existingBytes + cleanImage.buffer.length > 250 * 1024 * 1024) {
        return res.status(413).json({ error: 'O espaço reservado para imagens desta empresa atingiu o limite. Remova fotos antigas ou fale com o suporte.' });
      }
      const filename = `${crypto.randomBytes(16).toString('hex')}.png`;
      const imagePath = path.resolve(tenantDirectory, filename);
      if (!imagePath.startsWith(`${tenantDirectory}${path.sep}`)) {
        return res.status(400).json({ error: 'Destino de imagem inválido.' });
      }
      await fs.promises.writeFile(imagePath, cleanImage.buffer, { flag: 'wx', mode: 0o600 });
      return res.status(201).json({
        image_url: `/api/menus/images/${req.tenant.id}/${filename}`,
        mime_type: cleanImage.mimeType,
        width: cleanImage.width,
        height: cleanImage.height,
        size: cleanImage.buffer.length
      });
    } catch (error) {
      if (error.code === 'INVALID_IMAGE') return res.status(400).json({ error: error.message });
      console.error('Falha no upload da imagem do cardápio:', error);
      return res.status(500).json({ error: 'Não foi possível processar a imagem. Tente outro arquivo.' });
    }
  }
);

router.get('/', requirePermission('menus.read'), (req, res) => {
  db.all(
    'SELECT * FROM menus WHERE tenant_id = ? ORDER BY updated_at DESC, title COLLATE NOCASE',
    [req.tenant.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Não foi possível carregar os cardápios.' });
      ensureHub(req.tenant.id, req.tenant.owner_user_id, (hubErr, hub) => {
        if (hubErr) return res.status(500).json({ error: 'Não foi possível carregar o link da vitrine.' });
        res.json({ menus: rows.map(parseMenu), hub_slug: hub.slug });
      });
    }
  );
});

router.put('/hub/slug', requirePermission('menus.manage'), (req, res) => {
  if (!hasJsonObjectBody(req, res)) return;
  const slug = String(req.body.slug || '').trim().toLowerCase();
  if (!slugPattern.test(slug) || slug.length < 3 || slug.length > 48) {
    return res.status(400).json({ error: 'Use de 3 a 48 caracteres: letras minúsculas, números e hífens.' });
  }

  ensureHub(req.tenant.id, req.tenant.owner_user_id, (ensureErr) => {
    if (ensureErr) return res.status(500).json({ error: 'Não foi possível atualizar o link da vitrine.' });
    db.run('UPDATE menu_hubs SET slug = ? WHERE tenant_id = ?', [slug, req.tenant.id], function (err) {
      if (err && err.code === 'SQLITE_CONSTRAINT') {
        return res.status(409).json({ error: 'Este link já está sendo usado. Escolha outro.' });
      }
      if (err) return res.status(500).json({ error: 'Não foi possível atualizar o link da vitrine.' });
      res.json({ hub_slug: slug });
    });
  });
});

router.post('/', requirePermission('menus.manage'), (req, res) => {
  if (!hasJsonObjectBody(req, res)) return;
  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim();
  const normalized = normalizeSections(req.body.sections, req.tenant.id);
  if (!title || title.length > 100 || description.length > 500) {
    return res.status(400).json({ error: 'Informe um título de até 100 caracteres e uma descrição de até 500 caracteres.' });
  }
  if (normalized.error) return res.status(400).json({ error: normalized.error });

  const id = crypto.randomBytes(12).toString('hex');
  const slug = `${slugify(title)}-${crypto.randomBytes(3).toString('hex')}`;
  db.run(
    `INSERT INTO menus (id, user_id, tenant_id, slug, title, description, sections_json)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [id, req.user.id, req.tenant.id, slug, title, description, JSON.stringify(normalized.sections)],
    (err) => {
      if (err) return res.status(500).json({ error: 'Não foi possível criar o cardápio.' });
      db.get('SELECT * FROM menus WHERE id = ? AND tenant_id = ?', [id, req.tenant.id], (readErr, row) => {
        if (readErr || !row) return res.status(500).json({ error: 'O cardápio foi criado, mas não pôde ser carregado.' });
        res.status(201).json({ menu: parseMenu(row) });
      });
    }
  );
});

router.put('/:id', requirePermission('menus.manage'), (req, res) => {
  if (!hasJsonObjectBody(req, res)) return;
  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim();
  const normalized = normalizeSections(req.body.sections, req.tenant.id);
  if (!title || title.length > 100 || description.length > 500) {
    return res.status(400).json({ error: 'Informe um título de até 100 caracteres e uma descrição de até 500 caracteres.' });
  }
  if (normalized.error) return res.status(400).json({ error: normalized.error });
  if (typeof req.body.published !== 'boolean') {
    return res.status(400).json({ error: 'Informe se o cardápio deve estar publicado.' });
  }
  if (req.body.published && !normalized.sections.some((section) =>
    section.visible && section.products.some((product) => product.visible)
  )) {
    return res.status(400).json({ error: 'Adicione ao menos um produto visível antes de publicar.' });
  }

  db.run(
    `UPDATE menus SET title = ?, description = ?, sections_json = ?, published = ?,
     updated_at = CURRENT_TIMESTAMP WHERE id = ? AND tenant_id = ?`,
    [title, description, JSON.stringify(normalized.sections), req.body.published ? 1 : 0, req.params.id, req.tenant.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Não foi possível salvar o cardápio.' });
      if (!this.changes) return res.status(404).json({ error: 'Cardápio não encontrado.' });
      db.get('SELECT * FROM menus WHERE id = ? AND tenant_id = ?', [req.params.id, req.tenant.id], (readErr, row) => {
        if (readErr || !row) return res.status(500).json({ error: 'O cardápio foi salvo, mas não pôde ser carregado.' });
        res.json({ menu: parseMenu(row) });
      });
    }
  );
});

router.delete('/:id', requirePermission('menus.manage'), (req, res) => {
  db.run('DELETE FROM menus WHERE id = ? AND tenant_id = ?', [req.params.id, req.tenant.id], function (err) {
    if (err) return res.status(500).json({ error: 'Não foi possível remover o cardápio.' });
    if (!this.changes) return res.status(404).json({ error: 'Cardápio não encontrado.' });
    res.json({ message: 'Cardápio removido.' });
  });
});


module.exports = router;
