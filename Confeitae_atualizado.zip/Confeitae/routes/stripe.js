const express = require('express');
const Stripe = require('stripe');
const crypto = require('crypto');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');
const { isSubscriptionActive } = require('../lib/platform-admin');
const { parsePlanFeatures } = require('../lib/plan-features');

const router = express.Router();

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key || !key.startsWith('sk_') || /sua_chave|coloque|example/i.test(key)) {
    return null;
  }
  return new Stripe(key);
}

function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({ changes: this.changes, lastID: this.lastID });
    });
  });
}

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
  });
}

function getPriceId(plan) {
  return plan === 'mensal'
    ? process.env.STRIPE_MONTHLY_PRICE_ID
    : plan === 'vitalicio'
      ? process.env.STRIPE_LIFETIME_PRICE_ID
      : null;
}
async function getPlatformPlan(planKey) {
  const plan = await dbGet(
    `SELECT plan_key, name, description, price_cents, currency, billing_interval,
            billing_interval_count, is_active, stripe_price_id, stripe_product_id
       FROM platform_plans WHERE plan_key = ? AND COALESCE(is_deleted, 0) = 0`, [planKey]
  );
  if (!plan) return null;
  return {
    ...plan,
    stripe_price_id: plan.stripe_price_id || getPriceId(planKey) || null,
    billing_interval: plan.billing_interval || (planKey === 'vitalicio' ? 'once' : 'month'),
    billing_interval_count: Number(plan.billing_interval_count) || 1
  };
}

function isPlatformPlanActive(planKey) {
  return new Promise((resolve, reject) => {
    db.get('SELECT is_active FROM platform_plans WHERE plan_key = ? AND COALESCE(is_deleted, 0) = 0', [planKey], (err, row) => {
      if (err) return reject(err);
      resolve(Boolean(row && Number(row.is_active) === 1));
    });
  });
}

function getBaseUrl(req) {
  const configured = process.env.BASE_URL;
  if (configured && /^https:\/\/[^/]+/i.test(configured)) {
    return configured.replace(/\/$/, '');
  }
  if (process.env.NODE_ENV === 'production') return null;
  return `${req.protocol}://${req.get('host')}`;
}

router.get('/plans', async (req, res) => {
  try {
    const rows = await new Promise((resolve, reject) => db.all(
      `SELECT plan_key, name, description, price_cents, currency, billing_interval,
              billing_interval_count, is_active, stripe_price_id, max_members, features_json
         FROM platform_plans WHERE is_active = 1 AND COALESCE(is_deleted, 0) = 0 ORDER BY price_cents ASC, name COLLATE NOCASE`,
      (err, result) => err ? reject(err) : resolve(result || [])
    ));
    const plans = rows.map((row) => ({
      plan_key: row.plan_key,
      name: row.name,
      description: row.description,
      price_cents: Number(row.price_cents),
      currency: row.currency || 'BRL',
      billing_interval: row.billing_interval,
      billing_interval_count: Number(row.billing_interval_count) || 1,
      max_members: Number(row.max_members) || 0,
      features: parsePlanFeatures(row.features_json),
      available: Boolean(row.stripe_price_id || getPriceId(row.plan_key))
    })).filter((row) => row.available);
    return res.json({ plans });
  } catch (error) {
    console.error('Falha ao listar planos públicos Stripe:', error);
    return res.status(503).json({ error: 'Não foi possível carregar os planos disponíveis.' });
  }
});

router.get('/availability', async (req, res) => {
  const stripe = getStripe();
  try {
    const rows = await new Promise((resolve, reject) => db.all(
      `SELECT plan_key, is_active, stripe_price_id, is_deleted FROM platform_plans WHERE COALESCE(is_deleted, 0) = 0`,
      (err, result) => err ? reject(err) : resolve(result || [])
    ));
    const planStatus = {};
    const availableKeys = [];
    rows.forEach((row) => {
      const priceReady = Boolean(row.stripe_price_id || getPriceId(row.plan_key));
      planStatus[row.plan_key] = Number(row.is_active) === 1 && Number(row.is_deleted || 0) === 0 && priceReady;
      if (Number(row.is_active) === 1 && Number(row.is_deleted || 0) === 0 && priceReady) availableKeys.push(row.plan_key);
    });
    const available = Boolean(stripe && availableKeys.length);
    return res.json({
      available,
      provider: 'Stripe',
      methods: ['card'],
      plans: planStatus,
      available_plan_keys: availableKeys,
      message: available
        ? 'Checkout da Stripe disponível para os planos ativos.'
        : 'Configure STRIPE_SECRET_KEY e os preços dos planos na Stripe.'
    });
  } catch (error) {
    console.error('Falha ao consultar planos da Stripe:', error);
    return res.status(503).json({ error: 'Não foi possível consultar a disponibilidade dos planos.' });
  }
});

router.post('/create-checkout', authMiddleware, async (req, res) => {
  const planKey = String((req.body && (req.body.plan_key || req.body.plano_tipo)) || '').trim();
  if (!/^[a-z0-9][a-z0-9-]{1,39}$/.test(planKey)) {
    return res.status(400).json({ error: 'Plano inválido.' });
  }

  const stripe = getStripe();
  const baseUrl = getBaseUrl(req);
  let plan;
  try {
    plan = await getPlatformPlan(planKey);
  } catch (error) {
    console.error('Falha ao consultar o plano:', error);
    return res.status(503).json({ error: 'Não foi possível consultar o plano.' });
  }
  if (!plan || Number(plan.is_active) !== 1) {
    return res.status(403).json({ error: 'Este plano não está disponível para novas compras.' });
  }
  if (!stripe || !plan.stripe_price_id || !baseUrl) {
    return res.status(503).json({ error: 'Stripe indisponível. Confira STRIPE_SECRET_KEY, BASE_URL e o preço deste plano.' });
  }

  const userId = Number(req.user.id);
  const amount = Number(plan.price_cents) / 100;
  const orderReference = `STRIPE-${crypto.randomUUID()}`;
  const recurring = plan.billing_interval === 'month';
  try {
    await dbRun(
      `INSERT INTO orders
       (user_id, plano_tipo, valor, status, gateway, external_reference)
       VALUES (?, ?, ?, 'pending', 'stripe', ?)`,
      [userId, planKey, amount, orderReference]
    );
    const metadata = { userId: String(userId), planKey, planType: planKey, orderReference };
    const session = await stripe.checkout.sessions.create({
      mode: recurring ? 'subscription' : 'payment',
      line_items: [{ price: plan.stripe_price_id, quantity: 1 }],
      customer_email: req.user.email,
      client_reference_id: String(userId),
      metadata,
      ...(recurring ? { subscription_data: { metadata } } : { payment_intent_data: { metadata } }),
      success_url: `${baseUrl}/?stripe_payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/?stripe_payment=cancelled`
    });
    await dbRun(
      `UPDATE orders SET payment_id = ?, updated_at = CURRENT_TIMESTAMP
       WHERE external_reference = ? AND user_id = ?`,
      [session.id, orderReference, userId]
    );
    return res.status(201).json({ checkout_url: session.url, session_id: session.id, plan_key: planKey });
  } catch (error) {
    console.error('Erro ao criar Checkout Stripe:', error);
    await dbRun(
      `UPDATE orders SET status = 'failed', updated_at = CURRENT_TIMESTAMP
       WHERE external_reference = ?`, [orderReference]
    ).catch(() => {});
    return res.status(502).json({ error: 'Não foi possível iniciar o pagamento pela Stripe. Tente novamente.' });
  }
});

async function activateUserForSession(session, stripe) {
  const metadata = session.metadata || {};
  const userId = Number(metadata.userId || session.client_reference_id);
  const planKey = String(metadata.planKey || metadata.planType || '');
  if (!Number.isInteger(userId) || userId <= 0 || !planKey) {
    throw new Error('Metadados do Checkout inválidos.');
  }
  if (session.payment_status !== 'paid' && session.mode !== 'subscription') return;
  const plan = await getPlatformPlan(planKey);
  if (!plan) throw new Error('Plano associado ao pagamento não existe mais.');

  let subscriptionId = null;
  let expiration = null;
  if (plan.billing_interval === 'month') {
    subscriptionId = typeof session.subscription === 'string'
      ? session.subscription
      : session.subscription && session.subscription.id;
    if (!subscriptionId) throw new Error('Assinatura Stripe não encontrada.');
    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    if (subscription.status !== 'active' && subscription.status !== 'trialing') {
      throw new Error('A assinatura ainda não está ativa.');
    }
    if (subscription.current_period_end) expiration = new Date(subscription.current_period_end * 1000).toISOString();
    if (!expiration) throw new Error('A Stripe não informou a data de renovação da assinatura.');
  } else if (session.payment_status !== 'paid') {
    return;
  }

  await dbRun(
    `UPDATE users SET plano_tipo = ?, status_assinatura = 'ativa', data_vencimento = ?,
       subscription_id_gateway = ? WHERE id = ?`,
    [planKey, expiration, subscriptionId, userId]
  );
  if (metadata.orderReference) {
    await dbRun(
      `UPDATE orders SET status = 'approved', updated_at = CURRENT_TIMESTAMP
       WHERE external_reference = ? AND user_id = ? AND gateway = 'stripe'`,
      [metadata.orderReference, userId]
    );
  } else {
    await dbRun(
      `UPDATE orders SET status = 'approved', updated_at = CURRENT_TIMESTAMP
       WHERE payment_id = ? AND user_id = ? AND gateway = 'stripe'`,
      [session.id, userId]
    );
  }
}

async function syncSubscription(subscription, statusOverride) {
  const userId = Number(subscription.metadata && subscription.metadata.userId);
  if (!Number.isInteger(userId) || userId <= 0) return;
  const state = statusOverride || subscription.status;
  const mappedStatus = ['active', 'trialing'].includes(state)
    ? 'ativa'
    : (['past_due', 'unpaid', 'incomplete_expired'].includes(state) ? 'vencida' : 'cancelada');
  const expiration = subscription.current_period_end
    ? new Date(subscription.current_period_end * 1000).toISOString()
    : null;
  await dbRun(
    `UPDATE users SET status_assinatura = ?, data_vencimento = COALESCE(?, data_vencimento),
       subscription_id_gateway = ? WHERE id = ? AND subscription_id_gateway = ?`,
    [mappedStatus, expiration, subscription.id, userId, subscription.id]
  );
}

async function webhookHandler(req, res) {
  const stripe = getStripe();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const signature = req.headers['stripe-signature'];

  if (!stripe || !webhookSecret || !Buffer.isBuffer(req.body)) {
    return res.status(503).send('Webhook Stripe não configurado.');
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, webhookSecret);
  } catch (error) {
    console.error('Assinatura do webhook Stripe inválida:', error.message);
    return res.status(400).send('Assinatura inválida.');
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed':
      case 'checkout.session.async_payment_succeeded':
        await activateUserForSession(event.data.object, stripe);
        break;

      case 'invoice.paid': {
        const invoice = event.data.object;
        const subId = typeof invoice.subscription === 'string'
          ? invoice.subscription
          : invoice.parent && invoice.parent.subscription_details &&
            invoice.parent.subscription_details.subscription;
        if (subId) {
          const subscription = await stripe.subscriptions.retrieve(subId);
          await syncSubscription(subscription, 'active');
        }
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        const subId = typeof invoice.subscription === 'string'
          ? invoice.subscription
          : invoice.parent && invoice.parent.subscription_details &&
            invoice.parent.subscription_details.subscription;
        if (subId) {
          const subscription = await stripe.subscriptions.retrieve(subId);
          await syncSubscription(subscription, 'past_due');
        }
        break;
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        await syncSubscription(event.data.object);
        break;

      default:
        break;
    }

    return res.json({ received: true });
  } catch (error) {
    console.error('Erro ao processar webhook Stripe:', error);
    return res.status(500).send('Erro ao processar evento.');
  }
}

router.get('/session-status', authMiddleware, async (req, res) => {
  const sessionId = String(req.query.session_id || '');
  if (!sessionId.startsWith('cs_')) {
    return res.status(400).json({ error: 'Sessão inválida.' });
  }

  const stripe = getStripe();
  if (!stripe) return res.status(503).json({ error: 'Stripe não configurada.' });

  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    const userId = Number(session.metadata && session.metadata.userId);
    if (userId !== Number(req.user.id)) {
      return res.status(403).json({ error: 'Esta sessão não pertence à sua conta.' });
    }

    if (session.payment_status === 'paid' || session.mode === 'subscription') {
      await activateUserForSession(session, stripe);
    }

    const user = await dbGet(
      `SELECT u.plano_tipo, u.status_assinatura, u.data_vencimento,
              p.billing_interval, p.billing_interval_count
         FROM users u LEFT JOIN platform_plans p ON p.plan_key = u.plano_tipo
        WHERE u.id = ?`,
      [req.user.id]
    );

    return res.json({
      payment_status: session.payment_status,
      access_active: Boolean(user && isSubscriptionActive(user)),
      user
    });
  } catch (error) {
    console.error('Erro ao consultar sessão Stripe:', error);
    return res.status(502).json({ error: 'Não foi possível consultar o pagamento.' });
  }
});

module.exports = { router, webhookHandler };
