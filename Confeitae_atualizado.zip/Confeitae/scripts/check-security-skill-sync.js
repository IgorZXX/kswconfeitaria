'use strict';

const fs = require('node:fs');
const path = require('node:path');
const {
  computeFingerprint,
  readFingerprintMarker,
} = require('./security-skill-fingerprint');

const root = path.resolve(__dirname, '..');
const canonicalRel = '.agents/skills/ksw-security/SKILL.md';
const mirrorRel = '.claude/skills/ksw-security/SKILL.md';
const canonical = path.join(root, canonicalRel);
const mirror = path.join(root, mirrorRel);

function fail(message) {
  console.error(`ERRO: ${message}`);
  process.exit(1);
}

if (!fs.existsSync(canonical) || !fs.existsSync(mirror)) {
  fail('Uma das cópias da skill ksw-security não existe.');
}

const source = fs.readFileSync(canonical);
const copy = fs.readFileSync(mirror);
if (!source.equals(copy)) {
  fail('As cópias .agents e .claude estão diferentes. Execute: npm run security:skill:sync');
}

const sourceText = source.toString('utf8');
if (/^- \*\*[^\n]*PENDENTE DE REVISÃO DA IA[^\n]*$/m.test(sourceText)) {
  fail('A skill contém uma revisão pendente. Substitua a nota automática por um resumo real do impacto e dos testes antes de concluir.');
}
for (const marker of [
  '## Atualização obrigatória após toda modificação do projeto',
  'Histórico de atualização da skill',
]) {
  if (!sourceText.includes(marker)) fail(`A skill não contém o marcador obrigatório: ${marker}`);
}

const agentsFile = path.join(root, 'AGENTS.md');
if (!fs.existsSync(agentsFile) || !fs.readFileSync(agentsFile, 'utf8').includes('Depois de toda modificação no projeto, atualize a skill')) {
  fail('AGENTS.md não contém a regra permanente de atualização da skill.');
}

const expectedFingerprint = readFingerprintMarker(sourceText);
if (!expectedFingerprint) fail('A skill não possui a impressão digital do projeto. Execute: npm run security:skill:sync');

const actualFingerprint = computeFingerprint(root);
if (expectedFingerprint !== actualFingerprint) {
  fail([
    'O projeto mudou desde a última atualização da skill.',
    'Revise o impacto da mudança, atualize o histórico/controles da skill e execute:',
    'npm run security:skill:sync',
  ].join('\n'));
}

console.log('OK: skill sincronizada, instruções presentes e impressão digital do projeto atualizada.');
console.log(`SHA-256 do projeto: ${actualFingerprint}`);
