'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const zlib = require('node:zlib');
const { sanitizeMenuImage, crc32 } = require('../lib/menu-image-security');

const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
function chunk(type, data) {
  const name = Buffer.from(type, 'ascii');
  const length = Buffer.alloc(4); length.writeUInt32BE(data.length);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(Buffer.concat([name, data])));
  return Buffer.concat([length, name, data, crc]);
}
function png(width = 2, height = 2, ancillary = null) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; ihdr[9] = 6;
  const raw = Buffer.alloc((width * 4 + 1) * height);
  for (let y = 0; y < height; y += 1) raw[y * (width * 4 + 1)] = 0;
  const chunks = [chunk('IHDR', ihdr)];
  if (ancillary) chunks.push(chunk('tEXt', Buffer.from(ancillary)));
  chunks.push(chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0)));
  return Buffer.concat([signature, ...chunks]);
}

test('aceita PNG válido e reconstrói a imagem sem chunks de metadados', () => {
  const output = sanitizeMenuImage(png(3, 2, 'Comment\0metadata that must be removed'));
  assert.equal(output.mimeType, 'image/png');
  assert.equal(output.width, 3);
  assert.equal(output.height, 2);
  assert.equal(output.buffer.includes(Buffer.from('tEXt')), false);
  assert.deepEqual(sanitizeMenuImage(output.buffer).buffer, output.buffer);
});

test('rejeita arquivo executável renomeado para PNG', () => {
  assert.throws(() => sanitizeMenuImage(Buffer.from('MZ\x00malware')), /PNG/);
});

test('rejeita dados anexados depois do IEND (poliglota/trailing payload)', () => {
  assert.throws(() => sanitizeMenuImage(Buffer.concat([png(), Buffer.from('<script>payload</script>')])), /dados extras/);
});

test('rejeita CRC alterado e imagem corrompida', () => {
  const bad = png(); bad[bad.length - 8] ^= 0x01;
  assert.throws(() => sanitizeMenuImage(bad), /corrompida|inválida/);
});

test('rejeita dimensões acima do limite', () => {
  assert.throws(() => sanitizeMenuImage(png(2001, 1)), /excede os limites/);
});

test('rejeita sequência comprimida com tamanho de pixels inconsistente', () => {
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(2, 0); ihdr.writeUInt32BE(2, 4); ihdr[8] = 8; ihdr[9] = 6;
  const bad = Buffer.concat([signature, chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(Buffer.alloc(3))), chunk('IEND', Buffer.alloc(0))]);
  assert.throws(() => sanitizeMenuImage(bad), /pixels inconsistentes/);
});

test('rejeita upload vazio e upload maior que 5 MB', () => {
  assert.throws(() => sanitizeMenuImage(Buffer.alloc(0)), /5 MB/);
  assert.throws(() => sanitizeMenuImage(Buffer.alloc(5 * 1024 * 1024 + 1)), /5 MB/);
});
