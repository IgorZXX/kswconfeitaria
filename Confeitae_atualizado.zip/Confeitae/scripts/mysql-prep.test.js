'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  readMysqlConfig,
  createMysqlPool,
  withMysqlTransaction,
  checkMysqlServer
} = require('../lib/mysql-pool');
const {
  quoteIdentifier,
  mapSqliteType,
  extractCheckConstraints,
  normalizeTableMetadata,
  buildForeignKeyDDL,
  buildIndexesDDL,
  validateForeignKeyCompatibility,
  validateIndexWidths,
  topologicalTableOrder,
  normalizeForComparison,
  createDigestAccumulator
} = require('../lib/mysql-migration');
const { schemaSqlFromReport, inspectSqlite, describeInventory } = require('./migrate-sqlite-to-mysql');
const { spawnSync } = require('node:child_process');
const path = require('node:path');

const baseEnv = {
  DB_HOST: '127.0.0.1', DB_PORT: '3306', DB_NAME: 'ksw_test',
  DB_USER: 'ksw_test', DB_PASSWORD: 'test-only', DB_CONNECTION_LIMIT: '5', DB_SSL: 'false'
};

test('configuração MySQL exige host, schema, usuário e porta válida', () => {
  const config = readMysqlConfig(baseEnv);
  assert.equal(config.charset, 'utf8mb4');
  assert.equal(config.dateStrings, true);
  assert.equal(config.decimalNumbers, false);
  assert.equal(config.connectionLimit, 5);
  assert.throws(() => readMysqlConfig({ ...baseEnv, DB_HOST: '' }), /DB_HOST/);
  assert.throws(() => readMysqlConfig({ ...baseEnv, DB_PORT: '70000' }), /DB_PORT/);
  assert.throws(() => readMysqlConfig({ ...baseEnv, DB_CONNECTION_LIMIT: '0' }), /DB_CONNECTION_LIMIT/);
});

test('pool usa mysql2/promise injetado e configura utf8mb4 sem converter DECIMAL para float', () => {
  let options;
  const driver = { createPool(value) { options = value; return { marker: true }; } };
  const pool = createMysqlPool(baseEnv, driver);
  assert.equal(pool.marker, true);
  assert.equal(options.charset, 'utf8mb4');
  assert.equal(options.decimalNumbers, false);
  assert.equal(options.supportBigNumbers, true);
  assert.equal(options.waitForConnections, true);
});

test('transação MySQL confirma e sempre libera a conexão', async () => {
  const calls = [];
  const connection = {
    async beginTransaction() { calls.push('begin'); },
    async commit() { calls.push('commit'); },
    async rollback() { calls.push('rollback'); },
    release() { calls.push('release'); }
  };
  const pool = { async getConnection() { return connection; } };
  const result = await withMysqlTransaction(pool, async (tx) => { assert.equal(tx, connection); calls.push('work'); return 42; });
  assert.equal(result, 42);
  assert.deepEqual(calls, ['begin', 'work', 'commit', 'release']);
});

test('transação MySQL faz rollback em erro e libera a conexão', async () => {
  const calls = [];
  const connection = {
    async beginTransaction() { calls.push('begin'); },
    async commit() { calls.push('commit'); },
    async rollback() { calls.push('rollback'); },
    release() { calls.push('release'); }
  };
  await assert.rejects(withMysqlTransaction({ async getConnection() { return connection; } }, async () => { throw new Error('falha de teste'); }), /falha de teste/);
  assert.deepEqual(calls, ['begin', 'rollback', 'release']);
});

test('nível de isolamento SQL é allowlist, não aceita texto arbitrário', async () => {
  const calls = [];
  const connection = {
    async query(sql) { calls.push(sql); },
    async beginTransaction() {}, async commit() {}, async rollback() {}, release() {}
  };
  const pool = { async getConnection() { return connection; } };
  await withMysqlTransaction(pool, async () => 'ok', { isolationLevel: 'READ COMMITTED' });
  assert.equal(calls[0], 'SET TRANSACTION ISOLATION LEVEL READ COMMITTED');
  await assert.rejects(withMysqlTransaction(pool, async () => 'x', { isolationLevel: 'READ COMMITTED; DROP TABLE users' }), /não permitido/);
});

test('valida MySQL 8.0.16 ou superior e InnoDB', async () => {
  const good = { async query() { return [[{ version: '8.0.36', character_set_server: 'utf8mb4', collation_server: 'utf8mb4_0900_ai_ci', default_storage_engine: 'InnoDB' }]]; } };
  assert.equal((await checkMysqlServer(good)).version, '8.0.36');
  const old = { async query() { return [[{ version: '8.0.15', default_storage_engine: 'InnoDB' }]]; } };
  await assert.rejects(checkMysqlServer(old), /8.0.16/);
  const maria = { async query() { return [[{ version: '10.11.4-MariaDB', default_storage_engine: 'InnoDB' }]]; } };
  await assert.rejects(checkMysqlServer(maria), /MySQL 8.x/);
  const myisam = { async query() { return [[{ version: '8.0.36', default_storage_engine: 'MyISAM' }]]; } };
  await assert.rejects(checkMysqlServer(myisam), /InnoDB/);
});

test('identificadores SQL são validados e escapados', () => {
  assert.equal(quoteIdentifier('tenant_id'), '`tenant_id`');
  assert.throws(() => quoteIdentifier('tenant_id; DROP TABLE users'), /não permitido/);
});

test('tipos SQLite são mapeados para DECIMAL, inteiros, booleanos e texto', () => {
  assert.equal(mapSqliteType({ name: 'preco', type: 'REAL' }).type, 'DECIMAL(20,6)');
  assert.equal(mapSqliteType({ name: 'quantidade', type: 'REAL' }).type, 'DECIMAL(20,6)');
  assert.equal(mapSqliteType({ name: 'consumo_aplicado', type: 'INTEGER' }).type, 'TINYINT(1)');
  assert.equal(mapSqliteType({ name: 'id', type: 'INTEGER', pk: 1 }, { autoIncrement: true }).type, 'BIGINT');
  assert.equal(mapSqliteType({ name: 'payload', type: 'TEXT' }).type, 'LONGTEXT');
});

test('CHECK expressions são extraídas respeitando parênteses e aspas', () => {
  assert.deepEqual(extractCheckConstraints("CREATE TABLE x (a TEXT CHECK(length(a) > 0), b INTEGER CHECK(b IN (0, 1)))"), ['length(a) > 0', 'b IN (0, 1)']);
  assert.throws(() => extractCheckConstraints('CREATE TABLE x (a TEXT CHECK(a GLOB "x*"))'), /revisão manual/);
});

test('schema preserva PK composta, FK e índices de consulta', () => {
  const table = normalizeTableMetadata({
    name: 'pedidos',
    createSql: 'CREATE TABLE pedidos (tenant_id INTEGER NOT NULL, id TEXT NOT NULL, cliente_id TEXT, valor REAL, PRIMARY KEY (tenant_id, id))',
    columns: [
      { name: 'tenant_id', type: 'INTEGER', notnull: 1, pk: 1 },
      { name: 'id', type: 'TEXT', notnull: 1, pk: 2 },
      { name: 'cliente_id', type: 'TEXT', notnull: 0, pk: 0 },
      { name: 'valor', type: 'REAL', notnull: 0, pk: 0 }
    ],
    indexes: [{ name: 'ix_pedidos_data', unique: false, partial: false, columns: ['tenant_id'] }],
    foreignKeys: [{ id: 0, seq: 0, table: 'clientes', from: 'cliente_id', to: 'id', on_update: 'NO ACTION', on_delete: 'CASCADE' }]
  });
  assert.match(table.createTableSql, /PRIMARY KEY \(`tenant_id`, `id`\)/);
  assert.equal(table.columns.find((column) => column.name === 'cliente_id').mysqlType, 'VARCHAR(191)');
  assert.match(buildForeignKeyDDL(table)[0], /ON DELETE CASCADE/);
  assert.match(buildIndexesDDL(table)[0], /CREATE INDEX/);
});

test('bloqueia índices parciais e collation NOCASE para revisão manual', () => {
  const base = {
    name: 'items', createSql: 'CREATE TABLE items (id INTEGER PRIMARY KEY, code TEXT)',
    columns: [{ name: 'id', type: 'INTEGER', pk: 1 }, { name: 'code', type: 'TEXT' }],
    foreignKeys: []
  };
  assert.throws(() => normalizeTableMetadata({ ...base, indexes: [{ name: 'ux', unique: true, partial: true, columns: ['code'] }] }), /índice parcial/);
  assert.throws(() => normalizeTableMetadata({ ...base, createSql: 'CREATE TABLE items (id INTEGER PRIMARY KEY, code TEXT COLLATE NOCASE)', indexes: [] }), /COLLATE NOCASE/);
});

test('topologia de cópia coloca tabelas pai antes de tabelas filhas', () => {
  const order = topologicalTableOrder([
    { name: 'child', foreignKeys: [{ id: 0, table: 'parent', seq: 0, from: 'parent_id', to: 'id' }] },
    { name: 'parent', foreignKeys: [] }
  ]);
  assert.ok(order.indexOf('parent') < order.indexOf('child'));
});

test('digest multiconjunto é independente da ordem e detecta conteúdo diferente', () => {
  const one = createDigestAccumulator();
  const two = createDigestAccumulator();
  const three = createDigestAccumulator();
  one.add(['1', 'bolo']); one.add(['2', 'torta']);
  two.add(['2', 'torta']); two.add(['1', 'bolo']);
  three.add(['1', 'bolo']); three.add(['2', 'doce']);
  assert.deepEqual(one.result(), two.result());
  assert.notDeepEqual(one.result(), three.result());
});

test('normalização numérica preserva inteiros grandes e escala decimal', () => {
  assert.equal(normalizeForComparison('9007199254740993', { mysqlType: 'BIGINT' }), '9007199254740993');
  assert.equal(normalizeForComparison('12.3', { mysqlType: 'DECIMAL(20,6)', scale: 6 }), '12.300000');
});

test('DDL gerado inclui InnoDB e utf8mb4 para schema auditável', () => {
  const table = normalizeTableMetadata({ name: 'demo', createSql: 'CREATE TABLE demo (id INTEGER PRIMARY KEY AUTOINCREMENT, amount REAL)', columns: [
    { name: 'id', type: 'INTEGER', pk: 1 }, { name: 'amount', type: 'REAL' }
  ], indexes: [], foreignKeys: [] });
  const sql = schemaSqlFromReport({ tables: [{ mysql: table }] });
  assert.match(sql, /ENGINE=InnoDB/);
  assert.match(sql, /utf8mb4/);
  assert.match(sql, /AUTO_INCREMENT/);
});


test('inventário não interrompe o relatório quando uma tabela exige revisão manual', async () => {
  const fake = {
    all(sql, params, callback) {
      let rows = [];
      if (sql === 'PRAGMA integrity_check') rows = [{ integrity_check: 'ok' }];
      else if (sql === 'PRAGMA foreign_key_check') rows = [];
      else if (sql.includes("sqlite_master WHERE type = 'table'")) rows = [{ name: 'legacy_items', sql: 'CREATE TABLE legacy_items (id INTEGER PRIMARY KEY, code TEXT COLLATE NOCASE)' }];
      else if (sql.startsWith('PRAGMA table_xinfo')) rows = [
        { name: 'id', type: 'INTEGER', notnull: 0, pk: 1, hidden: 0 },
        { name: 'code', type: 'TEXT', notnull: 0, pk: 0, hidden: 0 }
      ];
      else if (sql.startsWith('PRAGMA index_list')) rows = [];
      else if (sql.startsWith('PRAGMA foreign_key_list')) rows = [];
      else if (sql.startsWith('SELECT COUNT(*)')) rows = [{ total: 3 }];
      else if (sql.includes("sqlite_master WHERE type = 'view'")) rows = [];
      else if (sql.includes("sqlite_master WHERE type = 'trigger'")) rows = [];
      callback(null, rows);
    },
    get(sql, params, callback) { callback(null, null); }
  };
  const report = await inspectSqlite(fake);
  assert.equal(report.tables.length, 1);
  assert.match(report.tables[0].unsupportedMigrationReason, /COLLATE NOCASE/);
  assert.match(describeInventory(report), /BLOQUEIO:.*COLLATE NOCASE/);
});

test('runtime recusa DB_DRIVER=mysql enquanto as rotas continuam SQLite', () => {
  const entry = path.resolve(__dirname, '..', 'database.js');
  const child = spawnSync(process.execPath, ['-e', `require(${JSON.stringify(entry)})`], {
    encoding: 'utf8',
    env: { ...process.env, DB_DRIVER: 'mysql' }
  });
  assert.notEqual(child.status, 0);
  assert.match(`${child.stderr}\\n${child.stdout}`, /DB_DRIVER=mysql ainda não está habilitado/);
  assert.doesNotMatch(`${child.stderr}\\n${child.stdout}`, /Cannot find module 'sqlite3'/);
});


test('pré-valida tipos e chaves únicas de FKs antes de criar o schema MySQL', () => {
  const parentMysql = normalizeTableMetadata({
    name: 'parents', createSql: 'CREATE TABLE parents (id INTEGER PRIMARY KEY)',
    columns: [{ name: 'id', type: 'INTEGER', pk: 1 }], indexes: [], foreignKeys: []
  });
  const childMismatchMysql = normalizeTableMetadata({
    name: 'children', createSql: 'CREATE TABLE children (id INTEGER PRIMARY KEY, parent_id TEXT)',
    columns: [{ name: 'id', type: 'INTEGER', pk: 1 }, { name: 'parent_id', type: 'TEXT' }], indexes: [],
    foreignKeys: [{ id: 0, seq: 0, table: 'parents', from: 'parent_id', to: 'id', on_update: 'NO ACTION', on_delete: 'NO ACTION' }]
  });
  assert.throws(() => validateForeignKeyCompatibility([
    { name: 'parents', mysql: parentMysql, foreignKeys: [] },
    { name: 'children', mysql: childMismatchMysql, foreignKeys: [{ id: 0, seq: 0, table: 'parents', from: 'parent_id', to: 'id' }] }
  ]), /Tipo incompatível/);

  const childValidMysql = normalizeTableMetadata({
    name: 'children', createSql: 'CREATE TABLE children (id INTEGER PRIMARY KEY, parent_id INTEGER)',
    columns: [{ name: 'id', type: 'INTEGER', pk: 1 }, { name: 'parent_id', type: 'INTEGER' }], indexes: [],
    foreignKeys: [{ id: 0, seq: 0, table: 'parents', from: 'parent_id', to: 'id', on_update: 'NO ACTION', on_delete: 'NO ACTION' }]
  });
  assert.equal(validateForeignKeyCompatibility([
    { name: 'parents', mysql: parentMysql, foreignKeys: [] },
    { name: 'children', mysql: childValidMysql, foreignKeys: [{ id: 0, seq: 0, table: 'parents', from: 'parent_id', to: 'id' }] }
  ]), true);
});

test('pré-valida largura total dos índices InnoDB', () => {
  const safe = normalizeTableMetadata({ name: 'safe_items', createSql: 'CREATE TABLE safe_items (id INTEGER PRIMARY KEY, code TEXT)',
    columns: [{ name: 'id', type: 'INTEGER', pk: 1 }, { name: 'code', type: 'TEXT' }],
    indexes: [{ name: 'ix_code', unique: false, partial: false, columns: ['code'] }], foreignKeys: [] });
  assert.equal(validateIndexWidths([{ name: 'safe_items', mysql: safe }]), true);
  const wide = normalizeTableMetadata({ name: 'wide_items', createSql: 'CREATE TABLE wide_items (a TEXT, b TEXT, c TEXT, d TEXT, e TEXT, PRIMARY KEY(a,b,c,d,e))',
    columns: [{ name: 'a', type: 'TEXT', pk: 1 }, { name: 'b', type: 'TEXT', pk: 2 }, { name: 'c', type: 'TEXT', pk: 3 }, { name: 'd', type: 'TEXT', pk: 4 }, { name: 'e', type: 'TEXT', pk: 5 }],
    indexes: [], foreignKeys: [] });
  assert.throws(() => validateIndexWidths([{ name: 'wide_items', mysql: wide }]), /exceder o limite InnoDB/);
});
