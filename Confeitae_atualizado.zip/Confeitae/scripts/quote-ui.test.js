'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');

const routes = fs.readFileSync(path.join(root, 'routes/quotes.js'), 'utf8');
const page = fs.readFileSync(path.join(root, 'public/orcamento-publico.html'), 'utf8');
const client = fs.readFileSync(path.join(root, 'public/orcamento-publico.js'), 'utf8');
const resources = fs.readFileSync(path.join(root, 'public/recursos.js'), 'utf8');
const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
const dataRoute = fs.readFileSync(path.join(root, 'routes/data.js'), 'utf8');

test('API publica somente dados essenciais e não usa tenant_id informado pelo visitante', () => {
  assert.match(routes, /router\.get\('\/public\/:token'/);
  assert.match(routes, /router\.post\('\/public\/:token\/decision'/);
  assert.match(routes, /hashPublicToken\(token\)/);
  assert.match(routes, /JOIN tenants t ON t\.id = l\.tenant_id/);
  assert.doesNotMatch(routes, /req\.body\.tenant_id/);
});

test('aprovação e recusa são transacionais e repetição não duplica o pedido', () => {
  assert.match(routes, /db\.withTransaction\(async \(tx\)/);
  assert.match(routes, /row\.status === 'accepted'/);
  assert.match(routes, /INSERT INTO pedidos/);
  assert.match(routes, /quantity: Number\(quote\.quantidade\) \|\| 1/);
  assert.match(routes, /UPDATE quote_public_links SET status = 'accepted'/);
  assert.match(routes, /UPDATE quote_public_links SET status = 'rejected'/);
});

test('página pública exige confirmação antes de aprovar e escapa texto exibido', () => {
  assert.match(page, /orcamento-publico\.js/);
  assert.match(client, /confirmed: confirmed === true/);
  assert.match(client, /Li a descrição, o valor e a validade/);
  assert.match(client, /Unidades estimadas/);
  assert.match(client, /function esc\(/);
});

test('gestão gera link público e oferece copiar ou WhatsApp', () => {
  assert.match(resources, /shareQuoteKSW/);
  assert.match(resources, /copyQuoteLinkKSW/);
  assert.match(resources, /Enviar no WhatsApp/);
  assert.match(resources, /A aprovação cria uma encomenda no KSW/);
  assert.match(resources, /id="q-quantity"/);
});

test('servidor expõe página pública e rota API do orçamento', () => {
  assert.match(server, /app\.use\('\/api\/quotes'/);
  assert.match(server, /app\.get\('\/orcamento\/:token'/);
});

test('sincronização não reverte aprovações públicas nem apaga propostas respondidas', () => {
  assert.match(dataRoute, /publicLink\.status !== 'pending'/);
  assert.match(dataRoute, /status IN \('accepted', 'rejected'\)/);
  assert.match(dataRoute, /record\.status === 'aceito'/);
});
