'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');
const route = fs.readFileSync(path.join(root, 'routes/menus.js'), 'utf8');

function between(source, start, end) {
  const a = source.indexOf(start);
  const b = source.indexOf(end, a + start.length);
  assert.ok(a >= 0 && b > a, `trecho ${start} deve existir`);
  return source.slice(a, b);
}

test('cardápios sem produtos continuam listados com ações visíveis de editar e excluir', () => {
  const list = between(html, "h+='<div class=\"menu-list\"", '  if(menuEditor.draft){');
  assert.match(list, /productCount===0\?'Editar e adicionar produtos':'Editar cardápio'/);
  assert.match(list, /deleteMenuById/);
  assert.match(list, /Excluir/);
  assert.match(list, /ainda sem produtos — você pode editar e adicionar depois/);
});

test('editor apresenta uma ação para criar a primeira seção mesmo com cardápio vazio', () => {
  const editor = between(html, 'if(menuEditor.draft){', '  return h;');
  assert.match(editor, /menu-empty-builder/);
  assert.match(editor, /Criar primeira seção/);
  assert.match(editor, /Salvar rascunho/);
  assert.match(editor, /Adicionar primeiro produto/);
});

test('rascunhos podem ser salvos sem produtos e editados depois', () => {
  const newMenu = between(html, 'function newMenu(){', 'function editMenu(menuId){');
  const editMenu = between(html, 'function editMenu(menuId){', 'function addMenuSection(){');
  const saveMenu = between(html, 'async function saveMenu(){', 'async function toggleMenuPublish(){');
  assert.match(newMenu, /sections:\[\]/);
  assert.match(editMenu, /menuEditor\.menus\.filter/);
  assert.match(editMenu, /menu-editor-panel/);
  assert.match(saveMenu, /draft\.sections\.some/);
  assert.match(saveMenu, /draft\.id\?\s*'\/menus\/'/);
  assert.doesNotMatch(saveMenu, /sections\.length\s*===?\s*0/);
});

test('exclusão pode ser feita diretamente na lista e atualiza a lista após a API confirmar', () => {
  const deleteFn = between(html, 'async function deleteMenuById(menuId){', 'async function changeHubSlug(){');
  assert.match(deleteFn, /confirm\(/);
  assert.match(deleteFn, /listedMenu=menuEditor\.menus\.filter/);
  assert.match(deleteFn, /apiCall\('\/menus\/'\+encodeURIComponent\(menuId\),'DELETE'\)/);
  assert.match(deleteFn, /String\(menuEditor\.draft\.id\)===String\(menuId\)/);
  assert.match(deleteFn, /var list=await apiCall\('\/menus'\)/);
  assert.match(deleteFn, /menuEditor\.menus=list\.menus/);
});


test('ações de edição e exclusão respeitam menus.manage e links públicos continuam compartilháveis', () => {
  const view = between(html, 'function vCat(){', 'async function saveStorefrontSettings(){');
  assert.match(view, /var canManageMenus=tenantHasPermission\('menus\.manage'\)/);
  assert.match(view, /canManageMenus\?'<button class=\"btn ghost sm\" type=\"button\" onclick=\"editMenu/);
  assert.match(view, /if\(canManageMenus\)actions\+='<button[\s\S]*?deleteMenuById/);
  assert.match(view, /Acesso somente para leitura/);
  assert.match(view, /copyMenuLink/);
});

test('exclusão no backend exige autenticação, assinatura ativa, permissão e escopo da empresa', () => {
  assert.match(route, /router\.use\(authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePlanFeature\('digital_menu'\)\)/);
  assert.match(route, /router\.delete\('\/:id', requirePermission\('menus\.manage'\)/);
  assert.match(route, /DELETE FROM menus WHERE id = \? AND tenant_id = \?/);
  assert.match(route, /\[req\.params\.id, req\.tenant\.id\]/);
});
