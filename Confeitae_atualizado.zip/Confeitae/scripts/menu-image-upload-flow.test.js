'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'public', 'index.html'), 'utf8');
const route = fs.readFileSync(path.join(root, 'routes', 'menus.js'), 'utf8');
const processor = fs.readFileSync(path.join(root, 'lib', 'menu-image-security.js'), 'utf8');

test('editor de cardápio oferece upload e não pede URL como entrada de imagem', () => {
  assert.match(html, /type="file" accept="image\/png,image\/jpeg,image\/webp"/);
  assert.match(html, /uploadMenuProductImage\(this,/);
  assert.doesNotMatch(html, /Imagem \(URL http\/https/);
});

test('cliente rasteriza fotos para PNG antes do envio', () => {
  assert.match(html, /createImageBitmap\(file\)/);
  assert.match(html, /canvas\.toBlob\(resolve,'image\/png'\)/);
  assert.match(html, /Content-Type':'application\/octet-stream/);
});

test('endpoint de upload fica após autenticação, contexto de empresa e verificação de permissão', () => {
  const authIndex = route.indexOf('router.use(authMiddleware, tenantContextMiddleware, checkActiveSubscription, requirePlanFeature(\'digital_menu\'))');
  const uploadIndex = route.indexOf("router.post('/upload-image'");
  assert.ok(authIndex >= 0 && uploadIndex > authIndex, 'a autenticação, assinatura, recurso do plano e o contexto da empresa devem ser aplicados antes do upload');
  assert.match(route.slice(uploadIndex, uploadIndex + 300), /requirePermission\('menus\.manage'\)/);
  assert.match(route.slice(uploadIndex, uploadIndex + 500), /uploadLimiter/);
  assert.match(route.slice(uploadIndex, uploadIndex + 700), /express\.raw\(\{ type: 'application\/octet-stream', limit:/);
});

test('arquivos são salvos fora da raiz pública e com nomes aleatórios gerados no servidor', () => {
  assert.match(route, /path\.resolve\(__dirname, '\.\.', 'storage', 'menu-products'\)/);
  assert.match(route, /crypto\.randomBytes\(16\)\.toString\('hex'\)/);
  assert.match(route, /flag: 'wx', mode: 0o600/);
  assert.match(route, /250 \* 1024 \* 1024/);
});

test('servidor valida PNG e reconstrói a imagem antes de armazenar', () => {
  assert.match(processor, /PNG_SIGNATURE/);
  assert.match(processor, /crc32/);
  assert.match(processor, /inflateSync/);
  assert.match(processor, /deflateSync/);
  assert.match(processor, /MAX_DIMENSION/);
  assert.match(processor, /MAX_PIXELS/);
  assert.match(route, /sanitizeMenuImage\(req\.body\)/);
  assert.match(route, /'X-Content-Type-Options': 'nosniff'/);
});

test('URL de imagem salva é limitada à área de uploads da própria empresa', () => {
  assert.match(route, /function isAllowedImageReference\(value, tenantId\)/);
  assert.match(route, /normalizeSections\(req\.body\.sections, req\.tenant\.id\)/);
  assert.match(route, /\/api\/menus\/images\//);
});
