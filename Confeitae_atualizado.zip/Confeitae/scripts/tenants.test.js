'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { migrateTenantSchema, formatSqliteDateTime } = require('../lib/tenant-schema');
const {
  hasPermission,
  canAssignRole,
  canChangeMember,
  canRemoveMember,
  hasCollectionPermission
} = require('../lib/tenant-permissions');
const { DATA_TABLES, ensureDataTable } = require('../lib/data-tables');

class SqliteCallbackAdapter {
  constructor() {
    this.sqlite = new DatabaseSync(':memory:');
  }

  run(sql, params, callback) {
    if (typeof params === 'function') {
      callback = params;
      params = [];
    }
    try {
      const result = this.sqlite.prepare(sql).run(...(params || []));
      const context = {
        changes: Number(result.changes),
        lastID: Number(result.lastInsertRowid || 0)
      };
      if (callback) callback.call(context, null);
      return context;
    } catch (error) {
      if (callback) return callback.call({}, error);
      throw error;
    }
  }

  get(sql, params, callback) {
    if (typeof params === 'function') {
      callback = params;
      params = [];
    }
    try {
      const row = this.sqlite.prepare(sql).get(...(params || []));
      callback(null, row || undefined);
    } catch (error) {
      callback(error);
    }
  }

  all(sql, params, callback) {
    if (typeof params === 'function') {
      callback = params;
      params = [];
    }
    try {
      callback(null, this.sqlite.prepare(sql).all(...(params || [])));
    } catch (error) {
      callback(error);
    }
  }

  close() {
    this.sqlite.close();
  }
}

function createLegacyDatabase(withOrphan = false) {
  const db = new SqliteCallbackAdapter();
  db.sqlite.exec(`
    CREATE TABLE users (
      id INTEGER PRIMARY KEY,
      nome TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE
    );
    INSERT INTO users (id, nome, email) VALUES
      (1, 'Ana', 'ana@example.com'),
      (2, 'Beatriz', 'bia@example.com');

    CREATE TABLE menus (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      published INTEGER NOT NULL DEFAULT 0,
      sections_json TEXT NOT NULL DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE menu_hubs (user_id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL);
    INSERT INTO menus (id, user_id, slug, title) VALUES ('menu-ana', 1, 'ana-cardapio', 'Ana');
    INSERT INTO menu_hubs (user_id, slug) VALUES (1, 'ana');
  `);
  for (const definition of DATA_TABLES) {
    const columns = definition.columns.map((column) => `${column.name} ${column.type}`).join(', ');
    db.sqlite.exec(`CREATE TABLE ${definition.table} (
      user_id INTEGER NOT NULL, id TEXT NOT NULL, ${columns},
      data TEXT NOT NULL, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, id)
    )`);
  }
  db.sqlite.prepare('INSERT INTO clientes (user_id, id, nome, data) VALUES (?, ?, ?, ?)')
    .run(1, 'mesmo-id', 'Cliente da Ana', '{"nome":"Cliente da Ana"}');
  db.sqlite.prepare('INSERT INTO clientes (user_id, id, nome, data) VALUES (?, ?, ?, ?)')
    .run(2, 'mesmo-id', 'Cliente da Beatriz', '{"nome":"Cliente da Beatriz"}');
  db.sqlite.prepare('INSERT INTO produtos (user_id, id, nome, preco, data) VALUES (?, ?, ?, ?, ?)')
    .run(1, 'bolo', 'Bolo da Ana', 50, '{"nome":"Bolo da Ana"}');
  db.sqlite.prepare('INSERT INTO produtos (user_id, id, nome, preco, data) VALUES (?, ?, ?, ?, ?)')
    .run(2, 'bolo', 'Bolo da Beatriz', 70, '{"nome":"Bolo da Beatriz"}');
  if (withOrphan) {
    db.sqlite.prepare('INSERT INTO clientes (user_id, id, nome, data) VALUES (?, ?, ?, ?)')
      .run(999, 'orphan', 'Sem usuário', '{"nome":"Sem usuário"}');
  }
  return db;
}

test('preparação do schema legado adiciona tenant_id antes de criar índices', async () => {
  const db = createLegacyDatabase();
  try {
    for (const definition of DATA_TABLES) {
      await ensureDataTable(db, definition);
    }
    const columns = db.sqlite.prepare('PRAGMA table_info(clientes)').all().map((column) => column.name);
    assert.ok(columns.includes('tenant_id'));
    const index = db.sqlite.prepare("PRAGMA index_info('idx_pedidos_tenant_cliente_id')").all().map((column) => column.name);
    assert.deepEqual(index, ['tenant_id', 'cliente_id']);
    await migrateTenantSchema(db, DATA_TABLES);
    const rows = db.sqlite.prepare('SELECT tenant_id, id FROM clientes ORDER BY user_id').all();
    assert.equal(rows.length, 2);
    assert.ok(rows.every((row) => Number(row.tenant_id) > 0));
  } finally {
    db.close();
  }
});

test('migração cria uma empresa e associação owner para cada conta antiga', async () => {
  const db = createLegacyDatabase();
  try {
    await migrateTenantSchema(db, DATA_TABLES);
    const tenants = db.sqlite.prepare('SELECT id, owner_user_id FROM tenants ORDER BY owner_user_id').all();
    const memberships = db.sqlite.prepare('SELECT tenant_id, user_id, role FROM tenant_memberships ORDER BY user_id').all();
    assert.equal(tenants.length, 2);
    assert.deepEqual(memberships.map((m) => [m.user_id, m.role]), [[1, 'owner'], [2, 'owner']]);
    assert.notEqual(tenants[0].id, tenants[1].id);
  } finally {
    db.close();
  }
});

test('migração separa dados antigos por tenant e reconstrói chave primária por empresa', async () => {
  const db = createLegacyDatabase();
  try {
    await migrateTenantSchema(db, DATA_TABLES);
    const info = db.sqlite.prepare('PRAGMA table_info(clientes)').all();
    const pk = info.filter((column) => Number(column.pk) > 0).sort((a, b) => a.pk - b.pk).map((column) => column.name);
    assert.deepEqual(pk, ['tenant_id', 'id']);

    const rows = db.sqlite.prepare('SELECT user_id, tenant_id, id, nome FROM clientes ORDER BY user_id').all();
    assert.equal(rows.length, 2);
    assert.notEqual(rows[0].tenant_id, rows[1].tenant_id);
    assert.equal(rows[0].nome, 'Cliente da Ana');
    assert.equal(rows[1].nome, 'Cliente da Beatriz');
  } finally {
    db.close();
  }
});

test('mesmo ID pode existir em empresas diferentes, mas não se repetir dentro da mesma empresa', async () => {
  const db = createLegacyDatabase();
  try {
    await migrateTenantSchema(db, DATA_TABLES);
    const tenants = db.sqlite.prepare('SELECT id FROM tenants ORDER BY id').all();
    db.sqlite.prepare('INSERT INTO clientes (user_id, tenant_id, id, nome, data) VALUES (?, ?, ?, ?, ?)')
      .run(1, tenants[0].id, 'novo-id', 'Ana A', '{}');
    db.sqlite.prepare('INSERT INTO clientes (user_id, tenant_id, id, nome, data) VALUES (?, ?, ?, ?, ?)')
      .run(2, tenants[1].id, 'novo-id', 'Beatriz B', '{}');
    assert.throws(() => {
      db.sqlite.prepare('INSERT INTO clientes (user_id, tenant_id, id, nome, data) VALUES (?, ?, ?, ?, ?)')
        .run(1, tenants[0].id, 'novo-id', 'Duplicado', '{}');
    }, /UNIQUE constraint failed/);
  } finally {
    db.close();
  }
});

test('migração é idempotente e não duplica empresas nem membros', async () => {
  const db = createLegacyDatabase();
  try {
    await migrateTenantSchema(db, DATA_TABLES);
    await migrateTenantSchema(db, DATA_TABLES);
    assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM tenants').get().n, 2);
    assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS n FROM tenant_memberships').get().n, 2);
  } finally {
    db.close();
  }
});

test('migração interrompe e reverte tudo quando há registro órfão sem usuário', async () => {
  const db = createLegacyDatabase(true);
  try {
    await assert.rejects(() => migrateTenantSchema(db, DATA_TABLES), /sem empresa/);
    assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name = 'tenants'").get().n, 0);
    const info = db.sqlite.prepare('PRAGMA table_info(clientes)').all();
    assert.equal(info.some((column) => column.name === 'tenant_id'), false);
    assert.equal(db.sqlite.prepare("SELECT COUNT(*) AS n FROM clientes WHERE id = 'orphan'").get().n, 1);
  } finally {
    db.close();
  }
});

test('isolamento SQL retorna apenas registros do tenant selecionado', async () => {
  const db = createLegacyDatabase();
  try {
    await migrateTenantSchema(db, DATA_TABLES);
    const tenants = db.sqlite.prepare('SELECT id FROM tenants ORDER BY id').all();
    const anaRows = db.sqlite.prepare('SELECT nome FROM clientes WHERE tenant_id = ?').all(tenants[0].id);
    const biaRows = db.sqlite.prepare('SELECT nome FROM clientes WHERE tenant_id = ?').all(tenants[1].id);
    assert.deepEqual(anaRows.map((row) => row.nome), ['Cliente da Ana']);
    assert.deepEqual(biaRows.map((row) => row.nome), ['Cliente da Beatriz']);
  } finally {
    db.close();
  }
});

test('menus e hubs antigos recebem tenant do proprietário', async () => {
  const db = createLegacyDatabase();
  try {
    await migrateTenantSchema(db, DATA_TABLES);
    const menu = db.sqlite.prepare('SELECT tenant_id FROM menus WHERE id = ?').get('menu-ana');
    const hub = db.sqlite.prepare('SELECT tenant_id FROM menu_hubs WHERE user_id = 1').get();
    assert.ok(menu.tenant_id > 0);
    assert.equal(menu.tenant_id, hub.tenant_id);
  } finally {
    db.close();
  }
});

test('papéis aplicam permissões esperadas e não permitem escalada para owner', () => {
  assert.equal(hasPermission('owner', 'billing.manage'), true);
  assert.equal(hasPermission('admin', 'billing.manage'), false);
  assert.equal(hasPermission('manager', 'team.read'), true);
  assert.equal(hasPermission('manager', 'team.manage'), false);
  assert.equal(hasPermission('manager', 'finance.read'), true);
  assert.equal(hasPermission('member', 'finance.read'), false);
  assert.equal(hasPermission('member', 'data.write'), true);
  assert.equal(hasPermission('viewer', 'data.read'), true);
  assert.equal(hasPermission('viewer', 'data.write'), false);
  assert.equal(hasCollectionPermission('member', 'despesas', 'read'), false);
  assert.equal(hasCollectionPermission('member', 'fornecedores', 'write'), false);
  assert.equal(hasCollectionPermission('manager', 'despesas', 'write'), true);
  assert.equal(hasCollectionPermission('viewer', 'produtos', 'read'), true);
  assert.equal(canAssignRole('admin', 'admin'), false);
  assert.equal(canAssignRole('owner', 'owner'), false);
  assert.equal(canChangeMember('owner', 'member', 'owner'), false);
  assert.equal(canChangeMember('admin', 'admin', 'member'), false);
  assert.equal(canRemoveMember('admin', 'admin', false), false);
  assert.equal(canRemoveMember('owner', 'owner', false), false);
});


test('datas de expiração usam o formato UTC compatível com CURRENT_TIMESTAMP do SQLite', () => {
  const value = formatSqliteDateTime(new Date('2026-11-12T15:45:30.123Z'));
  assert.equal(value, '2026-11-12 15:45:30');
  assert.match(value, /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
});

test('middleware só aceita empresa associada ao usuário autenticado', () => {
  const Module = require('node:module');
  const path = require('node:path');
  const databasePath = require.resolve('../database');
  const fakeDatabase = {
    get(sql, params, callback) {
      const userId = Number(params[0]);
      const tenantId = params.length > 1 ? Number(params[1]) : null;
      const memberships = [
        { userId: 2, tenantId: 101, role: 'member' },
        { userId: 2, tenantId: 202, role: 'viewer' },
        { userId: 3, tenantId: 202, role: 'owner' }
      ];
      const entry = memberships.find((m) => m.userId === userId && (!tenantId || m.tenantId === tenantId));
      callback(null, entry ? {
        tenant_id: entry.tenantId,
        tenant_nome: `Empresa ${entry.tenantId}`,
        tenant_slug: `empresa-${entry.tenantId}`,
        owner_user_id: entry.tenantId === 101 ? 1 : 3,
        tenant_role: entry.role,
        membership_status: 'active'
      } : undefined);
    }
  };
  const fakeModule = new Module(databasePath);
  fakeModule.filename = databasePath;
  fakeModule.loaded = true;
  fakeModule.exports = fakeDatabase;
  require.cache[databasePath] = fakeModule;
  const middlewarePath = require.resolve('../middleware/tenant');
  delete require.cache[middlewarePath];
  try {
    const { tenantContextMiddleware, requirePermission } = require('../middleware/tenant');
    function invoke(userId, selectedTenant) {
      const req = { user: { id: userId }, get: () => selectedTenant == null ? undefined : String(selectedTenant) };
      const res = {
        statusCode: 200,
        body: null,
        status(code) { this.statusCode = code; return this; },
        json(body) { this.body = body; return this; }
      };
      let nextCalled = false;
      tenantContextMiddleware(req, res, () => { nextCalled = true; });
      return { req, res, nextCalled };
    }
    const memberA = invoke(2, 101);
    assert.equal(memberA.nextCalled, true);
    assert.equal(memberA.req.tenant.id, 101);
    assert.equal(memberA.req.tenantRole, 'member');

    const memberB = invoke(2, 202);
    assert.equal(memberB.nextCalled, true);
    assert.equal(memberB.req.tenant.id, 202);
    assert.equal(memberB.req.tenantRole, 'viewer');

    const denied = invoke(2, 303);
    assert.equal(denied.nextCalled, false);
    assert.equal(denied.res.statusCode, 403);
    assert.equal(denied.res.body.code, 'TENANT_ACCESS_DENIED');

    const invalid = invoke(2, 'abc');
    assert.equal(invalid.nextCalled, false);
    assert.equal(invalid.res.statusCode, 400);

    const memberWrite = { tenant: { id: 101 }, tenantRole: 'viewer' };
    let permissionNext = false;
    const permissionResponse = { statusCode: 200, body: null, status(code) { this.statusCode = code; return this; }, json(body) { this.body = body; return this; } };
    requirePermission('data.write')(memberWrite, permissionResponse, () => { permissionNext = true; });
    assert.equal(permissionNext, false);
    assert.equal(permissionResponse.statusCode, 403);
  } finally {
    delete require.cache[middlewarePath];
    delete require.cache[databasePath];
  }
});
