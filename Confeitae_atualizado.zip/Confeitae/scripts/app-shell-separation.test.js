const fs = require('fs');
const path = require('path');
const assert = require('assert');
const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
assert(html.includes("var commerceMode = tab === 'planos' && !currentUser && !demoMode;"), 'Marketing mode must be limited to signed-out visitors');
assert(html.includes('function vMinhaAssinatura()'), 'Signed-in users need an app-native subscription view');
assert(html.includes("tab = 'entregas';\n    closeCheckout();\n    render();"), 'Successful login without checkout must open the app');
assert(html.includes("if(tab === 'planos') tab = 'entregas';"), 'Restored sessions must open the app');
console.log('4 testes de separação entre site público e sistema passaram.');
