'use strict';

// Backup consistente do banco SQLite (seguro com o servidor rodando).
// Uso: npm run backup            -> grava em ./backups/ksw-AAAA-MM-DD_HHMMSS.sqlite
//      BACKUP_DIR=/caminho npm run backup
// Mantém os 14 backups mais recentes. Agende no cron/Task Scheduler (ex.: 1x por dia)
// e copie a pasta para outro lugar (nuvem, HD externo): backup no mesmo disco não protege contra perda do disco.

const fs = require('fs');
const path = require('path');
const db = require('../database');

const KEEP = 14;

function run(sql) {
  return new Promise((resolve, reject) => {
    db.run(sql, (err) => (err ? reject(err) : resolve()));
  });
}

async function main() {
  let backupDir;
  let target;

  try {
    // O backup também respeita o contrato de inicialização do banco.
    await db.ready;

    backupDir = path.resolve(process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups'));
    fs.mkdirSync(backupDir, { recursive: true });

    const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '_').slice(0, 15);
    target = path.join(backupDir, `ksw-${stamp}.sqlite`);

    // VACUUM INTO recebe um literal SQL; aspas simples no caminho são duplicadas.
    await run(`VACUUM INTO '${target.replace(/'/g, "''")}'`);

    const files = fs.readdirSync(backupDir)
      .filter((filename) => /^ksw-.*\.sqlite$/.test(filename))
      .sort();
    files.slice(0, Math.max(0, files.length - KEEP)).forEach((filename) => {
      fs.rmSync(path.join(backupDir, filename), { force: true });
    });

    console.log(`Backup criado: ${target} (${(fs.statSync(target).size / 1024).toFixed(0)} KB)`);
  } catch (err) {
    console.error('Falha ao gerar backup:', err.message);
    process.exitCode = 1;
  } finally {
    try {
      await db.closeAll();
    } catch (err) {
      console.error('Falha ao fechar as conexões SQLite:', err.message);
      process.exitCode = 1;
    }
  }
}

main();
