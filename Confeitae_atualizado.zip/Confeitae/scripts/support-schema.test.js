'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializeSupportSchema } = require('../lib/support-schema');

class SqliteCallbackAdapter {
  constructor() {
    this.sqlite = new DatabaseSync(':memory:');
    this.sqlite.exec('PRAGMA foreign_keys = ON');
  }
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    try {
      const result = this.sqlite.prepare(sql).run(...(params || []));
      const context = { changes: Number(result.changes), lastID: Number(result.lastInsertRowid || 0) };
      if (callback) callback.call(context, null);
      return context;
    } catch (error) {
      if (callback) return callback.call({}, error);
      throw error;
    }
  }
  close() { this.sqlite.close(); }
}

test('cria o esquema do chat administrativo de forma idempotente', async () => {
  const db = new SqliteCallbackAdapter();
  try {
    db.sqlite.exec(`
      CREATE TABLE users (id INTEGER PRIMARY KEY, nome TEXT NOT NULL);
      CREATE TABLE tenants (id INTEGER PRIMARY KEY, nome TEXT NOT NULL);
      INSERT INTO users (id, nome) VALUES (1, 'Proprietária');
      INSERT INTO tenants (id, nome) VALUES (10, 'Confeitaria');
    `);
    await initializeSupportSchema(db);
    await initializeSupportSchema(db);

    const tables = db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all().map((row) => row.name);
    assert.ok(tables.includes('platform_support_threads'));
    assert.ok(tables.includes('platform_support_messages'));
    const indexes = db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type = 'index'").all().map((row) => row.name);
    assert.ok(indexes.includes('idx_support_messages_thread_created'));
    assert.ok(indexes.includes('idx_support_threads_updated'));
  } finally { db.close(); }
});

test('mantém uma conversa por empresa e valida remetentes e tamanho das mensagens', async () => {
  const db = new SqliteCallbackAdapter();
  try {
    db.sqlite.exec(`
      CREATE TABLE users (id INTEGER PRIMARY KEY, nome TEXT NOT NULL);
      CREATE TABLE tenants (id INTEGER PRIMARY KEY, nome TEXT NOT NULL);
      INSERT INTO users (id, nome) VALUES (1, 'Proprietária');
      INSERT INTO tenants (id, nome) VALUES (10, 'Confeitaria');
    `);
    await initializeSupportSchema(db);
    const thread = db.sqlite.prepare(`INSERT INTO platform_support_threads (tenant_id, owner_user_id) VALUES (10, 1)`).run();
    assert.throws(() => db.sqlite.prepare(`INSERT INTO platform_support_threads (tenant_id, owner_user_id) VALUES (10, 1)`).run(), /UNIQUE constraint failed/);

    db.sqlite.prepare(`INSERT INTO platform_support_messages (thread_id, tenant_id, sender_type, sender_user_id, body) VALUES (?, 10, 'owner', 1, 'Preciso de ajuda')`).run(Number(thread.lastInsertRowid));
    assert.throws(() => db.sqlite.prepare(`INSERT INTO platform_support_messages (thread_id, tenant_id, sender_type, body) VALUES (?, 10, 'unknown', 'Mensagem')`).run(Number(thread.lastInsertRowid)), /CHECK constraint failed/);
    assert.throws(() => db.sqlite.prepare(`INSERT INTO platform_support_messages (thread_id, tenant_id, sender_type, body) VALUES (?, 10, 'admin', ?)`).run(Number(thread.lastInsertRowid), 'x'.repeat(4001)), /CHECK constraint failed/);
    assert.equal(Number(db.sqlite.prepare('SELECT COUNT(*) AS total FROM platform_support_messages').get().total), 1);
  } finally { db.close(); }
});
