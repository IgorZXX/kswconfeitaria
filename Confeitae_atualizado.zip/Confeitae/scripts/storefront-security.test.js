'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { isAllowedRequestOrigin } = require('../lib/storefront-security');

const base = {
  requestHost: 'loja.example.com',
  baseUrl: 'https://loja.example.com',
  isProduction: true,
  secure: true
};

test('aceita origem HTTPS do mesmo host em produção', () => {
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'https://loja.example.com', secFetchSite: 'same-origin' }), true);
});

test('aceita origem pública configurada atrás do proxy confiável', () => {
  assert.equal(isAllowedRequestOrigin({ ...base, requestHost: 'app-interno:3000', origin: 'https://loja.example.com' }), true);
});

test('rejeita origem de outro domínio e navegação cross-site', () => {
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'https://attacker.example' }), false);
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'https://loja.example.com', secFetchSite: 'cross-site' }), false);
});

test('rejeita Origin malformada, com caminho ou credenciais', () => {
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'null' }), false);
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'https://loja.example.com/path' }), false);
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'https://user:pass@loja.example.com' }), false);
});

test('exige HTTPS e Origin presente em produção', () => {
  assert.equal(isAllowedRequestOrigin({ ...base, origin: 'https://loja.example.com', secure: false }), false);
  assert.equal(isAllowedRequestOrigin({ ...base, origin: '' }), false);
});

test('permite Origin ausente apenas em desenvolvimento', () => {
  assert.equal(isAllowedRequestOrigin({ ...base, isProduction: false, secure: false, origin: '' }), true);
});
