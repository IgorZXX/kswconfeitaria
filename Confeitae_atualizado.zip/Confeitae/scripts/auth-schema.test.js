'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializeAuthSchema, normalizeUsername } = require('../lib/auth-schema');

class SqliteCallbackAdapter {
  constructor() { this.sqlite = new DatabaseSync(':memory:'); }
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    try {
      const result = this.sqlite.prepare(sql).run(...(params || []));
      const context = { changes: Number(result.changes), lastID: Number(result.lastInsertRowid || 0) };
      if (callback) callback.call(context, null);
      return context;
    } catch (error) { if (callback) return callback.call({}, error); throw error; }
  }
  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    try { callback(null, this.sqlite.prepare(sql).all(...(params || []))); }
    catch (error) { callback(error); }
  }
  get(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    try { callback(null, this.sqlite.prepare(sql).get(...(params || [])) || null); }
    catch (error) { callback(error); }
  }
  close() { this.sqlite.close(); }
}

test('normaliza usuário removendo acentos e caracteres inválidos', () => {
  assert.equal(normalizeUsername('  Doce Encanto / Ana  ', 1), 'doce-encanto-ana');
  assert.equal(normalizeUsername('!!!', 9), 'usuario-9');
});

test('migra usuários legados, evita nomes duplicados e é idempotente', async () => {
  const db = new SqliteCallbackAdapter();
  try {
    db.sqlite.exec(`CREATE TABLE users (id INTEGER PRIMARY KEY, nome TEXT NOT NULL, email TEXT NOT NULL UNIQUE, senha TEXT NOT NULL);`);
    db.sqlite.prepare('INSERT INTO users (id, nome, email, senha) VALUES (1, ?, ?, ?), (2, ?, ?, ?), (3, ?, ?, ?)')
      .run('Ana Silva', 'ana1@example.com', 'hash-1', 'Ana Silva', 'ana2@example.com', 'hash-2', 'João & Maria', 'ana3@example.com', 'hash-3');
    await initializeAuthSchema(db);
    await initializeAuthSchema(db);
    const users = db.sqlite.prepare('SELECT username FROM users ORDER BY id').all().map((row) => row.username);
    assert.deepEqual(users, ['ana-silva', 'ana-silva-1', 'joao-maria']);
    const verificationColumns = db.sqlite.prepare('PRAGMA table_info(users)').all();
    assert.equal(verificationColumns.some((column) => column.name === 'email_verified'), true);
    assert.equal(Number(db.sqlite.prepare('SELECT email_verified FROM users WHERE id = 1').get().email_verified), 1, 'contas existentes continuam verificadas');
    assert.equal(db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='pending_registrations'").get().name, 'pending_registrations');
    const pendingColumns = db.sqlite.prepare('PRAGMA table_info(pending_registrations)').all();
    assert.ok(pendingColumns.some((column) => column.name === 'cookie_choice'));
    assert.equal(db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='user_cookie_preferences'").get().name, 'user_cookie_preferences');
    assert.equal(db.sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='user_cookie_consent_events'").get().name, 'user_cookie_consent_events');
    const credentials = db.sqlite.prepare('SELECT email, senha FROM users ORDER BY id').all()
      .map((row) => ({ email: row.email, senha: row.senha }));
    assert.deepEqual(credentials, [
      { email: 'ana1@example.com', senha: 'hash-1' },
      { email: 'ana2@example.com', senha: 'hash-2' },
      { email: 'ana3@example.com', senha: 'hash-3' }
    ]);
    assert.equal(db.sqlite.prepare('PRAGMA index_list(users)').all().some((row) => row.name === 'ux_users_username_nocase'), true);
    assert.throws(() => db.sqlite.prepare('INSERT INTO users (nome, username, email, senha) VALUES (?, ?, ?, ?)').run('Outra Ana', 'ANA-SILVA', 'other@example.com', 'hash-4'));
  } finally { db.close(); }
});

test('migra cadastros pendentes legados sem sobrescrever registros e aplica recusa opcional como padrão', async () => {
  const db = new SqliteCallbackAdapter();
  try {
    db.sqlite.exec(`
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        senha TEXT NOT NULL
      );
      CREATE TABLE pending_registrations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        username TEXT NOT NULL,
        email TEXT NOT NULL COLLATE NOCASE UNIQUE,
        senha TEXT NOT NULL,
        whatsapp TEXT NOT NULL DEFAULT '',
        empresa TEXT NOT NULL DEFAULT '',
        token_hash TEXT NOT NULL UNIQUE,
        expires_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      );
      INSERT INTO pending_registrations
        (nome, username, email, senha, token_hash, expires_at)
      VALUES ('Pessoa', 'pessoa', 'pessoa@example.com', 'hash', 'token-hash', datetime('now', '+1 day'));
    `);

    await initializeAuthSchema(db);
    await initializeAuthSchema(db);

    const pending = db.sqlite.prepare('SELECT * FROM pending_registrations WHERE email = ?').get('pessoa@example.com');
    assert.equal(pending.nome, 'Pessoa');
    assert.equal(pending.token_hash, 'token-hash');
    assert.equal(pending.cookie_choice, 'rejected');
    assert.equal(Number(pending.cookie_analytics), 0);
    assert.equal(Number(pending.cookie_marketing), 0);
    assert.equal(Number(pending.cookie_consent_version), 2);
  } finally { db.close(); }
});
