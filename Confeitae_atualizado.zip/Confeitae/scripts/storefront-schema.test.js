'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializeStorefrontSchema } = require('../lib/storefront-schema');

class CallbackSqliteAdapter {
  constructor() { this.db = new DatabaseSync(':memory:'); }
  run(sql, params, callback) {
    try {
      const result = this.db.prepare(sql).run(...(params || []));
      callback.call({ changes: Number(result.changes), lastID: Number(result.lastInsertRowid || 0) }, null);
    } catch (error) { callback(error); }
  }
  all(sql, params, callback) {
    try { callback(null, this.db.prepare(sql).all(...(params || []))); }
    catch (error) { callback(error); }
  }
  close() { this.db.close(); }
}

test('cria as tabelas da loja e mantém migração idempotente', async () => {
  const db = new CallbackSqliteAdapter();
  try {
    db.db.exec('CREATE TABLE tenants (id INTEGER PRIMARY KEY)');
    await initializeStorefrontSchema(db);
    await initializeStorefrontSchema(db);
    const columns = db.db.prepare('PRAGMA table_info(storefront_order_requests)').all().map((row) => row.name);
    assert.ok(columns.includes('request_hash'));
    assert.ok(db.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='storefront_settings'").get());
  } finally { db.close(); }
});

test('adiciona request_hash em tabela de idempotência legada', async () => {
  const db = new CallbackSqliteAdapter();
  try {
    db.db.exec(`CREATE TABLE tenants (id INTEGER PRIMARY KEY);
      CREATE TABLE storefront_order_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tenant_id INTEGER NOT NULL,
        idempotency_key TEXT NOT NULL,
        order_id TEXT NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(tenant_id, idempotency_key)
      );`);
    await initializeStorefrontSchema(db);
    const columns = db.db.prepare('PRAGMA table_info(storefront_order_requests)').all().map((row) => row.name);
    assert.ok(columns.includes('request_hash'));
    assert.equal(columns.filter((name) => name === 'request_hash').length, 1);
  } finally { db.close(); }
});

test('a chave de idempotência é única por empresa, não entre empresas', async () => {
  const db = new CallbackSqliteAdapter();
  try {
    db.db.exec('CREATE TABLE tenants (id INTEGER PRIMARY KEY)');
    await initializeStorefrontSchema(db);
    db.db.exec("INSERT INTO tenants (id) VALUES (1), (2)");
    db.db.prepare(`INSERT INTO storefront_order_requests (tenant_id, idempotency_key, order_id, request_hash)
      VALUES (?, ?, ?, ?)`).run(1, 'same-key', 'order-a', 'hash-a');
    db.db.prepare(`INSERT INTO storefront_order_requests (tenant_id, idempotency_key, order_id, request_hash)
      VALUES (?, ?, ?, ?)`).run(2, 'same-key', 'order-b', 'hash-b');
    assert.equal(db.db.prepare('SELECT COUNT(*) AS count FROM storefront_order_requests WHERE idempotency_key = ?').get('same-key').count, 2);
    assert.throws(() => db.db.prepare(`INSERT INTO storefront_order_requests (tenant_id, idempotency_key, order_id, request_hash)
      VALUES (?, ?, ?, ?)`).run(1, 'same-key', 'order-c', 'hash-c'));
  } finally { db.close(); }
});
