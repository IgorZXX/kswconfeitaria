'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializeQuoteSchema } = require('../lib/quote-schema');

class CallbackSqliteAdapter {
  constructor() { this.db = new DatabaseSync(':memory:'); }
  run(sql, params, callback) {
    try {
      const result = this.db.prepare(sql).run(...(params || []));
      callback.call({ changes: Number(result.changes), lastID: Number(result.lastInsertRowid || 0) }, null);
    } catch (error) { callback(error); }
  }
  close() { this.db.close(); }
}

test('cria e atualiza o schema de links de orçamento de forma idempotente', async () => {
  const db = new CallbackSqliteAdapter();
  try {
    db.db.exec('CREATE TABLE tenants (id INTEGER PRIMARY KEY)');
    await initializeQuoteSchema(db);
    await initializeQuoteSchema(db);
    const columns = db.db.prepare('PRAGMA table_info(quote_public_links)').all().map((row) => row.name);
    for (const name of ['tenant_id', 'quote_id', 'token_hash', 'status', 'expires_at', 'order_id', 'decided_at']) {
      assert.ok(columns.includes(name), `coluna ${name} ausente`);
    }
    assert.ok(db.db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name='idx_quote_public_links_status_expiry'").get());
  } finally { db.close(); }
});

test('tokens e orçamentos são únicos no escopo esperado', async () => {
  const db = new CallbackSqliteAdapter();
  try {
    db.db.exec('CREATE TABLE tenants (id INTEGER PRIMARY KEY); INSERT INTO tenants (id) VALUES (1), (2)');
    await initializeQuoteSchema(db);
    const insert = db.db.prepare(`INSERT INTO quote_public_links (tenant_id, quote_id, token_hash, status, expires_at)
      VALUES (?, ?, ?, 'pending', ?)`);
    insert.run(1, 'quote-1', 'hash-1', '2026-11-20');
    insert.run(2, 'quote-1', 'hash-2', '2026-11-20');
    assert.throws(() => insert.run(1, 'quote-1', 'hash-3', '2026-11-20'));
    assert.throws(() => insert.run(1, 'quote-2', 'hash-1', '2026-11-20'));
  } finally { db.close(); }
});


test('consulta pública resolve cliente e empresa por token hash, e o pedido usa o schema de gestão existente', async () => {
  const db = new CallbackSqliteAdapter();
  try {
    db.db.exec(`CREATE TABLE tenants (id INTEGER PRIMARY KEY, nome TEXT, owner_user_id INTEGER);
      CREATE TABLE clientes (user_id INTEGER NOT NULL, tenant_id INTEGER NOT NULL, id TEXT NOT NULL, nome TEXT, data TEXT, PRIMARY KEY (tenant_id, id));
      CREATE TABLE orcamentos (user_id INTEGER NOT NULL, tenant_id INTEGER NOT NULL, id TEXT NOT NULL, cliente_id TEXT, status TEXT, total REAL, validade TEXT, data TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (tenant_id, id));
      CREATE TABLE pedidos (user_id INTEGER NOT NULL, tenant_id INTEGER NOT NULL, id TEXT NOT NULL, cliente_id TEXT, data_entrega TEXT, status TEXT, total REAL, pago REAL, data TEXT, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (tenant_id, id));
      INSERT INTO tenants (id, nome, owner_user_id) VALUES (1, 'Doce da Ana', 10);
      INSERT INTO clientes (user_id, tenant_id, id, nome, data) VALUES (10, 1, 'client-01', 'Ana Cliente', '{"id":"client-01","nome":"Ana Cliente"}');
      INSERT INTO orcamentos (user_id, tenant_id, id, cliente_id, status, total, validade, data)
        VALUES (10, 1, 'quote-01', 'client-01', 'enviado', 150.5, '2026-11-20', '{"id":"quote-01","cli":"client-01","total":150.5,"validade":"2026-11-20","descricao":"Bolo de aniversário","status":"enviado"}');`);
    await initializeQuoteSchema(db);
    db.db.prepare(`INSERT INTO quote_public_links (tenant_id, quote_id, token_hash, status, expires_at)
      VALUES (?, ?, ?, 'pending', ?)`).run(1, 'quote-01', 'a'.repeat(64), '2026-11-20');
    const publicRow = db.db.prepare(`SELECT l.*, q.data AS quote_data, c.data AS client_data, t.nome AS business_name
      FROM quote_public_links l
      JOIN orcamentos q ON q.tenant_id = l.tenant_id AND q.id = l.quote_id
      JOIN tenants t ON t.id = l.tenant_id
      LEFT JOIN clientes c ON c.tenant_id = l.tenant_id AND c.id = json_extract(q.data, '$.cli')
      WHERE l.token_hash = ?`).get('a'.repeat(64));
    assert.equal(publicRow.business_name, 'Doce da Ana');
    assert.equal(JSON.parse(publicRow.client_data).nome, 'Ana Cliente');
    const orderId = 'order-01';
    const order = require('../lib/quote-public').buildAcceptedOrder(JSON.parse(publicRow.quote_data), orderId);
    db.db.prepare(`INSERT INTO pedidos (user_id, tenant_id, id, cliente_id, data_entrega, status, total, pago, data)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(10, 1, orderId, order.cli, order.ent, order.st, 150.5, 0, JSON.stringify(order));
    const savedOrder = db.db.prepare('SELECT data, total, pago FROM pedidos WHERE tenant_id = ? AND id = ?').get(1, orderId);
    assert.equal(JSON.parse(savedOrder.data).orcamento_id, 'quote-01');
    assert.equal(savedOrder.total, 150.5);
    assert.equal(savedOrder.pago, 0);
  } finally { db.close(); }
});
