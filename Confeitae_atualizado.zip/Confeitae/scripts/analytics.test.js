'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const analytics = require('../public/analytics-engine');

function fixture() {
  return {
    pedidos: [
      {
        id: 'p1', ent: '2026-11-03', st: 'entregue',
        itens: [
          { pid: 'bolo', nome: 'Bolo de chocolate', q: 2, pu: 80, cu: 32 },
          { pid: 'brig', nome: 'Brigadeiros', q: 20, pu: 3, cu: 1.2 }
        ],
        pagamentos: [
          { id: 'pay1', v: 100, data: '2026-11-02', forma: 'Pix' },
          { id: 'pay2', v: 60, data: '2026-11-03', forma: 'Pix' }
        ]
      },
      {
        id: 'p2', ent: '2026-11-15', st: 'confirmado',
        itens: [{ pid: 'bolo', nome: 'Bolo de chocolate', q: 1, pu: 80, cu: 34 }],
        pagamentos: []
      },
      {
        id: 'p3', ent: '2026-11-20', st: 'cancelado',
        itens: [{ pid: 'bolo', nome: 'Bolo de chocolate', q: 10, pu: 80, cu: 30 }],
        pagamentos: [{ v: 800, data: '2026-11-20' }]
      },
      {
        id: 'p4', ent: '2026-10-20', st: 'entregue',
        itens: [{ pid: 'brig', nome: 'Brigadeiros', q: 10, pu: 3, cu: 1 }],
        pg: 15, pd: '2026-11-04'
      },
      {
        id: 'p5', ent: '2026-11-22', st: 'recebido',
        itens: [{ pid: 'sem-custo', nome: 'Produto sem custo', q: 1, pu: 10 }],
        pagamentos: []
      }
    ],
    despesas: [
      { id: 'd1', desc: 'Energia', v: 200, venc: '2026-11-08', cat: 'Energia', pago: true, dpg: '2026-11-09' },
      { id: 'd2', desc: 'Ingredientes', v: 150, venc: '2026-11-12', cat: 'Insumos', pago: false, dpg: '' },
      { id: 'd3', desc: 'Aluguel', v: 500, venc: '2026-10-01', cat: 'Aluguel', pago: true, dpg: '2026-11-01' }
    ],
    perdas: [
      { id: 'l1', data: '2026-11-05', custo_total: 12.5 },
      { id: 'l2', data: '2026-10-05', custo_total: 80 }
    ]
  };
}

test('resume pedidos da competência e exclui pedidos cancelados', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.orders_count, 3);
  assert.equal(result.revenue, 310);
  assert.equal(result.units, 24);
});

test('separa faturamento por entrega de entradas por data de pagamento', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.received, 975);
  assert.equal(result.cash_entries.filter((entry) => entry.type === 'Entrada').length, 4);
});

test('lista somente pedidos ativos com saldo e calcula valores no formato brasileiro', () => {
  const orders = [
    { id: 'open', st: 'confirmado', itens: [{ q: '2', pu: '35,50' }], taxa_entrega: '8,50', pagamentos: [{ v: '20,00' }] },
    { id: 'paid', st: 'entregue', itens: [{ q: 1, pu: 25 }], pagamentos: [{ v: 25 }] },
    { id: 'cancelled', st: 'cancelado', itens: [{ q: 1, pu: 90 }], pagamentos: [] }
  ];
  assert.deepEqual(analytics.openReceivables(orders).map((order) => order.id), ['open']);
  assert.equal(analytics.orderBalance(orders[0]), 59.5);
  assert.equal(analytics.summarize({ pedidos: orders }, '2026-11').receivables, 59.5);
});

test('saldo de caixa atual não inclui lançamentos futuros', () => {
  assert.equal(analytics.cashBalanceAsOf([
    { date: '2026-11-04', value: 100 },
    { date: '2026-11-05T12:00:00Z', value: -25 },
    { date: '2026-11-06', value: 300 },
    { date: '', value: 500 }
  ], '2026-11-05'), 75);
  assert.throws(() => analytics.cashBalanceAsOf([], ''), /data válida/i);
});


test('mantém recebimentos registrados de pedidos cancelados no caixa, sem contar no faturamento', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.revenue, 310);
  assert.equal(result.received, 975);
  assert.ok(result.cash_entries.some((entry) => entry.description.includes('p3') && entry.value === 800));
});

test('calcula custo congelado e identifica itens sem custo histórico', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.cost, 122);
  assert.equal(result.missing_cost_items, 1);
  assert.equal(result.products.find((product) => product.id === 'bolo').cost, 98);
});

test('separa despesas provisionadas, pagas e fluxo de caixa', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.accrued_expenses, 350);
  assert.equal(result.paid_expenses, 700);
  assert.equal(result.payables, 150);
  assert.equal(result.cash_result, 275);
});

test('calcula resultado gerencial, margem e ticket médio', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.gross_profit, 188);
  assert.equal(result.managerial_result, -174.5);
  assert.equal(result.average_ticket, 310 / 3);
  assert.equal(result.gross_margin_percent, 188 / 310 * 100);
});

test('soma desperdício apenas na competência selecionada', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.equal(result.waste_cost, 12.5);
});

test('gera série de meses em ordem, inclusive mudança de ano', () => {
  const series = analytics.monthlySeries(fixture(), '2026-01', 3);
  assert.deepEqual(series.map((item) => item.month), ['2025-11', '2025-12', '2026-01']);
});

test('agrega despesas por categoria e produtos por contribuição', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.deepEqual(result.expense_categories, [
    { category: 'Insumos', value: 150 },
    { category: 'Energia', value: 200 }
  ].sort((a, b) => b.value - a.value));
  assert.equal(result.products[0].id, 'bolo');
  assert.equal(result.products[0].contribution, 142);
});

test('usa compatibilidade com pedidos antigos sem array de pagamentos', () => {
  const result = analytics.summarize(fixture(), '2026-11');
  assert.ok(result.cash_entries.some((entry) => entry.description.includes('p4') && entry.value === 15));
});

test('protege células CSV contra fórmulas em conteúdo textual', () => {
  assert.equal(analytics.csvCell('=HYPERLINK("https://example.com")'), '"\'=HYPERLINK(""https://example.com"")"');
  assert.equal(analytics.csvCell('Cliente normal'), '"Cliente normal"');
});

test('rejeita competência inválida e séries fora do limite', () => {
  assert.throws(() => analytics.summarize(fixture(), '2026-13'), /mês/i);
  assert.throws(() => analytics.monthlySeries(fixture(), '2026-11', 25), /entre 1 e 24/i);
});


test('inclui taxa percentual congelada na linha do pedido no custo e no lucro', () => {
  const data = {
    pedidos: [{
      id: 'taxed', ent: '2026-11-06', st: 'entregue',
      itens: [{ pid: 'bolo', nome: 'Bolo', q: 2, pu: 50, cu: 30, taxa_venda_pct: 5 }],
      pagamentos: []
    }]
  };
  const line = analytics.orderCost(data.pedidos[0]);
  assert.equal(line.direct_cost, 60);
  assert.equal(line.variable_fees, 5);
  assert.equal(line.total, 65);
  const summary = analytics.summarize(data, '2026-11');
  assert.equal(summary.cost, 65);
  assert.equal(summary.variable_fees, 5);
  assert.equal(summary.gross_profit, 35);
  assert.equal(summary.products[0].contribution, 35);
  assert.equal(summary.missing_fee_items, 0);
});

test('identifica que pedidos antigos não guardavam taxa variável sem inventar uma taxa', () => {
  const line = analytics.orderCost({ itens: [{ q: 1, pu: 20, cu: 10 }] });
  assert.equal(line.total, 10);
  assert.equal(line.variable_fees, 0);
  assert.equal(line.missing_fee_items, 1);
});


test('zero percentual sem confirmação explícita não é tratado como taxa conhecida', () => {
  const data = { pedidos: [{ id: 'legacy-zero', ent: '2026-11-06', st: 'entregue', itens: [{ pid: 'bolo', q: 1, pu: 20, cu: 10, taxa_venda_pct: 0 }] }] };
  const line = analytics.orderCost(data.pedidos[0]);
  assert.equal(line.variable_fees, 0);
  assert.equal(line.missing_fee_items, 1);
  const summary = analytics.summarize(data, '2026-11');
  assert.equal(summary.missing_fee_items, 1);
  assert.equal(summary.products[0].missing_fee_items, 1);
});

test('taxa zero explicitamente confirmada entra no histórico sem alerta de dado ausente', () => {
  const line = analytics.orderCost({ itens: [{ q: 1, pu: 20, cu: 10, taxa_venda_pct: 0, taxa_venda_informada: true }] });
  assert.equal(line.total, 10);
  assert.equal(line.missing_fee_items, 0);
});
