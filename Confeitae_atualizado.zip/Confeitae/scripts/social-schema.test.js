'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializeSocialSchema } = require('../lib/social-schema');

class Adapter {
  constructor() { this.db = new DatabaseSync(':memory:'); }
  run(sql, params, callback) {
    try { this.db.prepare(sql).run(...(params || [])); callback(null); }
    catch (error) { callback(error); }
  }
  close() { this.db.close(); }
}

test('cria o schema social de forma idempotente e isolada por empresa', async () => {
  const db = new Adapter();
  try {
    db.db.exec('CREATE TABLE tenants (id INTEGER PRIMARY KEY); CREATE TABLE users (id INTEGER PRIMARY KEY);');
    await initializeSocialSchema(db);
    await initializeSocialSchema(db);
    const tables = db.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'ksw_social_%'").all().map(row => row.name);
    assert.deepEqual(new Set(tables), new Set(['ksw_social_profiles','ksw_social_posts','ksw_social_likes','ksw_social_comments','ksw_social_follows','ksw_social_reports','ksw_social_conversations','ksw_social_messages','ksw_social_stories','ksw_social_story_views']));
    db.db.exec("INSERT INTO tenants(id) VALUES (1),(2); INSERT INTO users(id) VALUES (10),(20);");
    db.db.prepare('INSERT INTO ksw_social_profiles (tenant_id,handle,is_public) VALUES (?,?,1)').run(1,'doce-arte');
    assert.throws(() => db.db.prepare('INSERT INTO ksw_social_profiles (tenant_id,handle,is_public) VALUES (?,?,1)').run(2,'DOCE-ARTE'));
    db.db.prepare('INSERT INTO ksw_social_profiles (tenant_id,handle,is_public) VALUES (?,?,1)').run(2,'doce-arte-2');
    db.db.prepare('INSERT INTO ksw_social_posts (tenant_id,author_user_id,caption,image_url) VALUES (?,?,?,?)').run(1,10,'Bolo','/api/social/images/1/a'.padEnd(32,'a')+'.png');
    assert.equal(db.db.prepare('SELECT COUNT(*) AS total FROM ksw_social_posts').get().total,1);
    const conversation = db.db.prepare('INSERT INTO ksw_social_conversations (tenant_low_id,tenant_high_id) VALUES (?,?)').run(1,2);
    db.db.prepare('INSERT INTO ksw_social_messages (conversation_id,sender_tenant_id,sender_user_id,body) VALUES (?,?,?,?)').run(Number(conversation.lastInsertRowid),1,10,'Olá, tudo bem?');
    assert.equal(db.db.prepare('SELECT body FROM ksw_social_messages WHERE conversation_id=?').get(Number(conversation.lastInsertRowid)).body,'Olá, tudo bem?');
    assert.throws(() => db.db.prepare('INSERT INTO ksw_social_conversations (tenant_low_id,tenant_high_id) VALUES (?,?)').run(1,2));
    assert.throws(() => db.db.prepare('INSERT INTO ksw_social_conversations (tenant_low_id,tenant_high_id) VALUES (?,?)').run(2,1));
    assert.equal(db.db.prepare('SELECT avatar_url FROM ksw_social_profiles WHERE tenant_id=1').get().avatar_url,'');
    const story=db.db.prepare('INSERT INTO ksw_social_stories (tenant_id,author_user_id,caption,image_url) VALUES (?,?,?,?)').run(1,10,'Bastidores','/api/social/story-images/1/test.png');
    const savedStory=db.db.prepare('SELECT created_at,expires_at FROM ksw_social_stories WHERE id=?').get(Number(story.lastInsertRowid));
    assert.ok(savedStory.expires_at>savedStory.created_at,'Story recebe prazo de expiração');
    assert.ok(db.db.prepare("SELECT expires_at>datetime('now','+23 hours') AS active FROM ksw_social_stories WHERE id=?").get(Number(story.lastInsertRowid)).active);
    db.db.prepare('INSERT INTO ksw_social_story_views (story_id,viewer_tenant_id) VALUES (?,?)').run(Number(story.lastInsertRowid),2);
    assert.equal(db.db.prepare('SELECT COUNT(*) AS total FROM ksw_social_story_views WHERE story_id=?').get(Number(story.lastInsertRowid)).total,1);
    assert.throws(()=>db.db.prepare('INSERT INTO ksw_social_story_views (story_id,viewer_tenant_id) VALUES (?,?)').run(Number(story.lastInsertRowid),2));
  } finally { db.close(); }
});

test('migra banco antigo sem avatar_url preservando perfis existentes', async () => {
  const db = new Adapter();
  try {
    db.db.exec("CREATE TABLE tenants (id INTEGER PRIMARY KEY); CREATE TABLE users (id INTEGER PRIMARY KEY); INSERT INTO tenants(id) VALUES (1);");
    db.db.exec("CREATE TABLE ksw_social_profiles (tenant_id INTEGER PRIMARY KEY, handle TEXT NOT NULL UNIQUE COLLATE NOCASE, bio TEXT NOT NULL DEFAULT '', website TEXT NOT NULL DEFAULT '', is_public INTEGER NOT NULL DEFAULT 0, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP); INSERT INTO ksw_social_profiles(tenant_id,handle,is_public) VALUES (1,'antiga',1);");
    await initializeSocialSchema(db);
    await initializeSocialSchema(db);
    const row = db.db.prepare('SELECT handle, avatar_url FROM ksw_social_profiles WHERE tenant_id=1').get();
    assert.equal(row.handle, 'antiga');
    assert.equal(row.avatar_url, '');
    assert.equal(db.db.prepare("SELECT COUNT(*) AS n FROM pragma_table_info('ksw_social_posts') WHERE name='video_url'").get().n, 1);
  } finally { db.close(); }
});
