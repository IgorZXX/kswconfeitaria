'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const engine = require('../lib/storefront-engine');

const SETTINGS = Object.freeze({
  enabled: true,
  whatsapp: '5511999999999',
  pickup_enabled: true,
  delivery_enabled: true,
  address: 'Zona Norte, São Paulo',
  delivery_fee: 7.5,
  minimum_order: 20,
  lead_time_days: 1
});

const MENUS = Object.freeze([{
  id: 'menu-a',
  title: 'Bolos',
  sections: [{
    id: 'section-a', name: 'Bolos', visible: true,
    products: [
      { id: 'cake-a', name: 'Bolo de chocolate', price: 25, visible: true, available: true },
      { id: 'cake-b', name: 'Bolo indisponível', price: 30, visible: true, available: false },
      { id: 'cake-c', name: 'Produto oculto', price: 30, visible: false, available: true }
    ]
  }, {
    id: 'section-hidden', name: 'Oculta', visible: false,
    products: [{ id: 'cake-d', name: 'Seção oculta', price: 100, visible: true, available: true }]
  }]
}]);

function validInput(overrides = {}) {
  return {
    idempotency_key: 'abcdefghijklmnop123456',
    customer: { name: 'Maria da Silva', phone: '(11) 99999-9999', email: 'maria@example.com' },
    fulfillment: 'retirada',
    delivery_date: '2026-11-06',
    delivery_time: '14:30',
    address: '',
    notes: 'Sem lactose',
    items: [{ menu_id: 'menu-a', product_id: 'cake-a', quantity: 2, price: 0.01 }],
    ...overrides
  };
}

test('normaliza configurações válidas e limita prazo de antecedência', () => {
  const result = engine.normalizeSettings({
    enabled: true, whatsapp: '+55 (11) 99999-9999', pickup_enabled: true,
    delivery_enabled: true, address: 'Zona Norte', delivery_fee: '5,50',
    minimum_order: '30,00', lead_time_days: '2'
  });
  assert.equal(result.ok, true);
  assert.equal(result.value.whatsapp, '5511999999999');
  assert.equal(result.value.delivery_fee, 5.5);
  assert.equal(result.value.minimum_order, 30);
  assert.equal(result.value.lead_time_days, 2);
});

test('não ativa loja sem WhatsApp de contato', () => {
  const result = engine.normalizeSettings({ enabled: true, whatsapp: '', pickup_enabled: true });
  assert.equal(result.ok, false);
  assert.match(result.error, /WhatsApp/);
});

test('rejeita configuração sem retirada nem entrega', () => {
  const result = engine.normalizeSettings({ enabled: false, pickup_enabled: false, delivery_enabled: false });
  assert.equal(result.ok, false);
});

test('exige região/endereço ao habilitar entrega', () => {
  const result = engine.normalizeSettings({ enabled: false, pickup_enabled: true, delivery_enabled: true, address: '' });
  assert.equal(result.ok, false);
  assert.match(result.error, /endereço/i);
});

test('rejeita link de Instagram fora do domínio permitido', () => {
  const result = engine.normalizeSettings({ enabled: false, pickup_enabled: true, instagram_url: 'https://example.com/perfil' });
  assert.equal(result.ok, false);
});

test('rejeita taxa negativa, mínimo inválido e prazo fora do intervalo', () => {
  assert.equal(engine.normalizeSettings({ pickup_enabled: true, delivery_fee: -1 }).ok, false);
  assert.equal(engine.normalizeSettings({ pickup_enabled: true, minimum_order: 'abc' }).ok, false);
  assert.equal(engine.normalizeSettings({ pickup_enabled: true, lead_time_days: 61 }).ok, false);
});

test('normaliza telefone sem truncar silenciosamente entradas excessivas', () => {
  assert.equal(engine.digits('+55 (11) 99999-9999'), '5511999999999');
  assert.equal(engine.digits('123456789012345678'), '123456789012345678');
  assert.equal(engine.buildOrder(validInput({ customer: { name: 'Maria', phone: '12345678901234' } }), SETTINGS, MENUS, '2026-11-05').ok, false);
});

test('rejeita preço ausente ou inválido no cardápio, sem converter null para zero', () => {
  const menus = [{ ...MENUS[0], sections: [{ ...MENUS[0].sections[0], products: [{ ...MENUS[0].sections[0].products[0], price: null }] }] }];
  const result = engine.buildOrder(validInput(), SETTINGS, menus, '2026-11-05');
  assert.equal(result.ok, false);
});

test('calcula o pedido com preço vindo do servidor, não do navegador', () => {
  const result = engine.buildOrder(validInput(), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, true);
  assert.equal(result.value.items[0].unit_price, 25);
  assert.equal(result.value.subtotal, 50);
  assert.equal(result.value.delivery_fee, 0);
  assert.equal(result.value.total, 50);
});

test('adiciona taxa de entrega ao total sem alterar o preço do produto', () => {
  const result = engine.buildOrder(validInput({
    fulfillment: 'entrega', address: 'Rua das Flores, 123'
  }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, true);
  assert.equal(result.value.subtotal, 50);
  assert.equal(result.value.delivery_fee, 7.5);
  assert.equal(result.value.total, 57.5);
});

test('rejeita loja desativada', () => {
  const result = engine.buildOrder(validInput(), { ...SETTINGS, enabled: false }, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
  assert.equal(result.status, 404);
});

test('bloqueia data anterior ao prazo mínimo', () => {
  const result = engine.buildOrder(validInput({ delivery_date: '2026-11-05' }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
  assert.match(result.error, /2026-11-06/);
});

test('bloqueia data impossível de calendário', () => {
  const result = engine.buildOrder(validInput({ delivery_date: '2026-02-30' }), SETTINGS, MENUS, '2026-02-01');
  assert.equal(result.ok, false);
});

test('bloqueia método de entrega desativado', () => {
  const result = engine.buildOrder(validInput({ fulfillment: 'entrega', address: 'Rua das Flores, 123' }),
    { ...SETTINGS, delivery_enabled: false }, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
});

test('exige endereço válido para entrega', () => {
  const result = engine.buildOrder(validInput({ fulfillment: 'entrega', address: 'Rua' }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
  assert.match(result.error, /endereço/i);
});

test('bloqueia produto marcado como indisponível', () => {
  const result = engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-b', quantity: 1 }] }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
  assert.equal(result.status, 409);
});

test('bloqueia produtos ocultos e seções ocultas', () => {
  const hiddenProduct = engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-c', quantity: 1 }] }), SETTINGS, MENUS, '2026-11-05');
  const hiddenSection = engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-d', quantity: 1 }] }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(hiddenProduct.ok, false);
  assert.equal(hiddenSection.ok, false);
});

test('bloqueia cardápio e produto que não pertencem à loja resolvida', () => {
  const result = engine.buildOrder(validInput({ items: [{ menu_id: 'tenant-b-menu', product_id: 'cake-a', quantity: 1 }] }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
});

test('valida quantidades inteiras e limites por item', () => {
  assert.equal(engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-a', quantity: 0 }] }), SETTINGS, MENUS, '2026-11-05').ok, false);
  assert.equal(engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-a', quantity: 1.5 }] }), SETTINGS, MENUS, '2026-11-05').ok, false);
  assert.equal(engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-a', quantity: 51 }] }), SETTINGS, MENUS, '2026-11-05').ok, false);
});

test('exige pedido mínimo', () => {
  const result = engine.buildOrder(validInput({ items: [{ menu_id: 'menu-a', product_id: 'cake-a', quantity: 1 }] }),
    { ...SETTINGS, minimum_order: 30 }, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
  assert.match(result.error, /pedido mínimo/i);
});

test('rejeita telefone e horário inválidos', () => {
  assert.equal(engine.buildOrder(validInput({ customer: { name: 'Maria', phone: '123' } }), SETTINGS, MENUS, '2026-11-05').ok, false);
  assert.equal(engine.buildOrder(validInput({ delivery_time: '29:90' }), SETTINGS, MENUS, '2026-11-05').ok, false);
});

test('rejeita mais de 30 linhas de pedido', () => {
  const items = Array.from({ length: 31 }, (_, index) => ({ menu_id: 'menu-a', product_id: `cake-${index}`, quantity: 1 }));
  const result = engine.buildOrder(validInput({ items }), SETTINGS, MENUS, '2026-11-05');
  assert.equal(result.ok, false);
});


test('fingerprint de idempotência ignora o preço e detecta alteração da intenção do pedido', () => {
  const input = validInput();
  const original = engine.fingerprintOrderRequest(input);
  const changedPrice = { ...input, items: input.items.map((item) => ({ ...item, price: 999 })) };
  const changedQuantity = { ...input, items: input.items.map((item) => ({ ...item, quantity: item.quantity + 1 })) };
  const reformattedPhone = { ...input, customer: { ...input.customer, phone: '(11) 99999 9999' } };
  assert.equal(engine.fingerprintOrderRequest(changedPrice), original);
  assert.equal(engine.fingerprintOrderRequest(reformattedPhone), original);
  assert.notEqual(engine.fingerprintOrderRequest(changedQuantity), original);
});


test('normaliza WhatsApp brasileiro local para formato internacional do link', () => {
  assert.equal(engine.normalizeBrazilWhatsApp('(11) 99999-9999'), '5511999999999');
  assert.equal(engine.normalizeBrazilWhatsApp('+55 (11) 3333-4444'), '551133334444');
});
