'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializePlatformAdminSchema } = require('../lib/platform-admin-schema');

class SqliteCallbackAdapter {
  constructor() { this.sqlite = new DatabaseSync(':memory:'); }
  run(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    try {
      const result = this.sqlite.prepare(sql).run(...(params || []));
      const context = { changes: Number(result.changes), lastID: Number(result.lastInsertRowid || 0) };
      if (callback) callback.call(context, null);
      return context;
    } catch (error) { if (callback) return callback.call({}, error); throw error; }
  }
  all(sql, params, callback) {
    if (typeof params === 'function') { callback = params; params = []; }
    try { callback(null, this.sqlite.prepare(sql).all(...(params || []))); }
    catch (error) { callback(error); }
  }
  close() { this.sqlite.close(); }
}

function createLegacyDb() {
  const db = new SqliteCallbackAdapter();
  db.sqlite.exec(`CREATE TABLE tenants (
    id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, slug TEXT NOT NULL UNIQUE,
    owner_user_id INTEGER NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );`);
  return db;
}

test('schema Super Admin adiciona status a tenants antigos sem remover dados', async () => {
  const db = createLegacyDb();
  try {
    db.sqlite.prepare('INSERT INTO tenants (nome, slug, owner_user_id) VALUES (?, ?, ?)').run('Doce Ana', 'doce-ana', 7);
    await initializePlatformAdminSchema(db);
    const tenant = db.sqlite.prepare('SELECT id, nome, status, suspended_at, suspended_reason FROM tenants').get();
    assert.equal(tenant.nome, 'Doce Ana');
    assert.equal(tenant.status, 'active');
    assert.equal(tenant.suspended_at, null);
    assert.equal(tenant.suspended_reason, null);
  } finally { db.close(); }
});

test('schema cria catálogo comercial, sessões revogáveis e auditoria', async () => {
  const db = createLegacyDb();
  try {
    await initializePlatformAdminSchema(db);
    const plans = db.sqlite.prepare('SELECT plan_key, price_cents, billing_interval, is_active, max_members, features_json FROM platform_plans ORDER BY plan_key').all();
    assert.equal(plans.length, 4);
    const byKey = Object.fromEntries(plans.map((plan) => [plan.plan_key, plan]));
    assert.deepEqual([Number(byKey.mensal.price_cents), Number(byKey.anual.price_cents), Number(byKey.vitalicio.price_cents), Number(byKey.teste_gratis.price_cents)], [5999, 0, 111900, 0]);
    assert.equal(Number(byKey.anual.is_active), 0, 'anual sem preço permanece como rascunho');
    assert.equal(Number(byKey.mensal.max_members), 3);
    assert.ok(JSON.parse(byKey.mensal.features_json).some((feature) => feature.key === 'team'));
    assert.equal(Number(byKey.anual.max_members), 3);
    assert.equal(Number(byKey.vitalicio.max_members), 0);
    assert.equal(Number(byKey.teste_gratis.max_members), 0);
    assert.ok(JSON.parse(byKey.vitalicio.features_json).length >= 14);
    assert.ok(JSON.parse(byKey.vitalicio.features_json).some((feature) => feature.key === 'admin_chat'));
    assert.ok(JSON.parse(byKey.teste_gratis.features_json).some((feature) => feature.key === 'team'));
    assert.ok(JSON.parse(byKey.teste_gratis.features_json).some((feature) => feature.key === 'admin_chat'));
    assert.ok(!JSON.parse(byKey.anual.features_json).some((feature) => feature.key === 'admin_chat'));
    db.sqlite.prepare('INSERT INTO platform_admin_sessions (id, expires_at) VALUES (?, ?)').run('a'.repeat(48), '2099-01-01T00:00:00.000Z');
    db.sqlite.prepare("INSERT INTO platform_audit_logs (action, target_type, target_id, metadata_json) VALUES ('test.action', 'test', '1', '{}')").run();
    assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS total FROM platform_admin_sessions').get().total, 1);
    assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS total FROM platform_audit_logs').get().total, 1);
  } finally { db.close(); }
});


test('migração corrige plano mensal legado e adiciona chat a vitalício/teste sem apagar recursos', async () => {
  const db = createLegacyDb();
  try {
    await initializePlatformAdminSchema(db);
    db.sqlite.prepare("UPDATE platform_plans SET max_members = 1, features_json = '[]' WHERE plan_key = 'mensal'").run();
    db.sqlite.prepare("UPDATE platform_plans SET features_json = '[{\"key\":\"orders\",\"label\":\"Pedidos\"}]' WHERE plan_key IN ('vitalicio','teste_gratis')").run();
    db.sqlite.prepare("UPDATE platform_plans SET price_cents = 12345 WHERE plan_key = 'vitalicio'").run();
    await initializePlatformAdminSchema(db);
    const monthly = db.sqlite.prepare("SELECT max_members, features_json FROM platform_plans WHERE plan_key = 'mensal'").get();
    assert.equal(Number(monthly.max_members), 3);
    assert.ok(JSON.parse(monthly.features_json).some((feature) => feature.key === 'team'));
    const lifetime = db.sqlite.prepare("SELECT price_cents, features_json FROM platform_plans WHERE plan_key = 'vitalicio'").get();
    const lifetimeFeatures = JSON.parse(lifetime.features_json);
    assert.equal(Number(lifetime.price_cents), 12345);
    assert.ok(lifetimeFeatures.some((feature) => feature.key === 'orders'));
    assert.ok(lifetimeFeatures.some((feature) => feature.key === 'admin_chat'));
    const trial = db.sqlite.prepare("SELECT features_json FROM platform_plans WHERE plan_key = 'teste_gratis'").get();
    assert.ok(JSON.parse(trial.features_json).some((feature) => feature.key === 'admin_chat'));
  } finally { db.close(); }
});

test('migração do Super Admin é idempotente', async () => {
  const db = createLegacyDb();
  try {
    await initializePlatformAdminSchema(db);
    await initializePlatformAdminSchema(db);
    assert.equal(db.sqlite.prepare('SELECT COUNT(*) AS total FROM platform_plans').get().total, 4);
    const statusColumns = db.sqlite.prepare('PRAGMA table_info(tenants)').all().filter((column) => column.name === 'status');
    assert.equal(statusColumns.length, 1);
  } finally { db.close(); }
});
