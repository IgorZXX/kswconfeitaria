// Teste de integração: sobe o servidor com um banco temporário e exercita a API.
// Uso: npm test
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const PORT = 3900 + Math.floor(Math.random() * 90);
const BASE = `http://127.0.0.1:${PORT}`;
const dbFile = path.join(os.tmpdir(), `ksw-test-${Date.now()}.sqlite`);
const ADMIN_KEY = 'chave-admin-de-teste-123';
let adminCookie = '';

let passed = 0;
const EXPECTED_COLLECTIONS = [
  'auditoria', 'clientes', 'config', 'cupons', 'despesas', 'embalagens', 'fidelidade',
  'fornecedores', 'ingredientes', 'lotes', 'mov', 'orcamentos', 'pedidos', 'perdas', 'producao', 'produtos', 'tarefas'
];
async function check(name, fn) {
  try { await fn(); passed++; console.log('  ok  ', name); }
  catch (e) { console.error('  FAIL', name, '\n      ', e.message); process.exitCode = 1; }
}
async function api(method, url, body, token, headers = {}) {
  const requestHeaders = { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...headers };
  if (url.startsWith('/api/admin/') && ['POST', 'PATCH', 'PUT', 'DELETE'].includes(method.toUpperCase()) && !Object.prototype.hasOwnProperty.call(requestHeaders, 'Origin')) {
    requestHeaders.Origin = BASE;
  }
  if (url.startsWith('/api/admin/') && adminCookie && !Object.prototype.hasOwnProperty.call(requestHeaders, 'Cookie')) {
    requestHeaders.Cookie = adminCookie;
  }
  const res = await fetch(BASE + url, {
    method,
    headers: requestHeaders,
    body: body ? JSON.stringify(body) : undefined
  });
  let json = {};
  try { json = await res.json(); } catch (_) {}
  return { status: res.status, json, headers: res.headers };
}
const put = (c, r) => ({ c, op: 'put', r });
const del = (c, id) => ({ c, op: 'del', id });

async function main() {
  // Simula um banco criado pela versão anterior (tabela despesas sem as colunas novas)
  // para garantir que a atualização migra sem apagar nada.
  let legacyDb = false;
  try {
    const { DatabaseSync } = require('node:sqlite');
    const h = new DatabaseSync(dbFile);
    h.exec(`CREATE TABLE users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, email TEXT UNIQUE NOT NULL, senha TEXT NOT NULL,
      whatsapp TEXT, role TEXT DEFAULT 'user', plano_tipo TEXT DEFAULT 'free', status_assinatura TEXT DEFAULT 'inativa',
      data_vencimento DATETIME, subscription_id_gateway TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    INSERT INTO users (id, nome, email, senha) VALUES (99, 'Conta legada', 'legada@teste.com', 'hash-legado');
    CREATE TABLE despesas (user_id INTEGER NOT NULL, id TEXT NOT NULL, valor REAL, vencimento TEXT, pago INTEGER,
            data TEXT NOT NULL, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id, id))`);
    h.prepare('INSERT INTO despesas (user_id, id, valor, vencimento, pago, data) VALUES (99, ?, 10, ?, 0, ?)').run('antiga', '2026-01-01', '{"id":"antiga","v":10}');
    h.close();
    legacyDb = true;
  } catch (_) { /* Node < 22.5: etapa ignorada */ }

  const server = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT, DATABASE_PATH: dbFile, JWT_SECRET: 'x'.repeat(48), ADMIN_SECRET_KEY: ADMIN_KEY, NODE_ENV: 'test' },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let startupOutput = '';
  server.stdout.on('data', (chunk) => { startupOutput += chunk.toString(); });
  server.stderr.on('data', (chunk) => { startupOutput += chunk.toString(); });

  // Aguarda a resposta HTTP real; a aplicação só deve escutar depois do schema estar pronto.
  let serverReady = false;
  for (let i = 0; i < 100; i++) {
    if (server.exitCode !== null) break;
    try {
      const response = await fetch(BASE + '/api/__smoke_test_readiness');
      serverReady = response.status === 404;
      if (serverReady) break;
    } catch (_) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  }

  if (!serverReady) {
    if (server.exitCode === null) server.kill();
    await new Promise((resolve) => {
      if (server.exitCode !== null || server.signalCode !== null) return resolve();
      server.once('exit', resolve);
    });
    for (const ext of ['', '-wal', '-shm']) fs.rmSync(dbFile + ext, { force: true });
    throw new Error(`Servidor de teste não ficou pronto. Saída: ${startupOutput || '(sem saída)'}`);
  }

  try {
    const a = (await api('POST', '/api/auth/register', { nome: 'Ana', email: 'ana@teste.com', senha: 'senha-forte-1' })).json;
    const b = (await api('POST', '/api/auth/register', { nome: 'Bia', email: 'bia@teste.com', senha: 'senha-forte-2' })).json;

    await check('cadastro rejeita senha curta e e-mail inválido', async () => {
      assert.strictEqual((await api('POST', '/api/auth/register', { nome: 'X', email: 'x@y.com', senha: '123' })).status, 400);
      assert.strictEqual((await api('POST', '/api/auth/register', { nome: 'X', email: 'invalido', senha: '12345678' })).status, 400);
      assert.strictEqual((await api('POST', '/api/auth/register', { nome: {}, email: [], senha: 1 })).status, 400);
    });

    await check('dados exigem login', async () => {
      assert.strictEqual((await api('GET', '/api/data')).status, 401);
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [] })).status, 401);
    });

    await check('leitura funciona e vem vazia para conta nova', async () => {
      const r = await api('GET', '/api/data', null, a.token);
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.json.empty, true);
      assert.deepStrictEqual(Object.keys(r.json.data).sort(), EXPECTED_COLLECTIONS.slice().sort());
    });

    await check('escrita é bloqueada sem assinatura ativa', async () => {
      const r = await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c1', nome: 'Maria' })] }, a.token);
      assert.strictEqual(r.status, 403);
    });

    await check('Super Admin rejeita origem ausente ou cruzada antes do login', async () => {
      assert.strictEqual((await api('POST', '/api/admin/session', null, null, { 'x-admin-key': ADMIN_KEY, Origin: '' })).status, 403);
      assert.strictEqual((await api('POST', '/api/admin/session', null, null, { 'x-admin-key': ADMIN_KEY, Origin: 'https://atacante.example' })).status, 403);
    });

    await check('Super Admin exige chave correta e cria cookie HttpOnly de sessão curta', async () => {
      const denied = await api('POST', '/api/admin/session', null, null, { 'x-admin-key': 'errada' });
      assert.strictEqual(denied.status, 403);
      const login = await api('POST', '/api/admin/session', null, null, { 'x-admin-key': ADMIN_KEY });
      assert.strictEqual(login.status, 200);
      assert.strictEqual(login.json.authenticated, true);
      const cookie = login.headers.get('set-cookie');
      assert.ok(cookie && cookie.includes('HttpOnly') && cookie.includes('SameSite=Strict'));
      adminCookie = cookie.split(';')[0];
      assert.strictEqual((await api('GET', '/api/admin/session')).status, 200);
    });

    await check('rotas administrativas negam acesso sem cookie mesmo com chave no header', async () => {
      assert.strictEqual((await api('GET', '/api/admin/users', null, null, { 'x-admin-key': ADMIN_KEY, Cookie: '' })).status, 401);
      assert.strictEqual((await api('GET', '/api/admin/users')).status, 200);
    });

    await check('Super Admin apresenta métricas e empresas sem expor dados de senha', async () => {
      const overview = await api('GET', '/api/admin/overview');
      assert.strictEqual(overview.status, 200);
      assert.strictEqual(overview.json.metrics.companies_total, 2);
      assert.strictEqual(overview.json.metrics.users_total, 2);
      const users = await api('GET', '/api/admin/users');
      assert.strictEqual(users.status, 200);
      assert.ok(users.json.users.every((user) => !Object.prototype.hasOwnProperty.call(user, 'senha')));
      assert.strictEqual((await api('GET', '/api/admin/tenants')).json.pagination.total, 2);
    });

    await check('Super Admin suspende e reativa empresa sem excluir dados', async () => {
      const tenant = await api('GET', '/api/tenants/mine', null, b.token);
      const tenantId = tenant.json.tenants[0].id;
      assert.strictEqual((await api('PATCH', `/api/admin/tenants/${tenantId}/status`, { status: 'suspended', reason: 'Revisão administrativa' })).status, 200);
      const blocked = await api('GET', '/api/app-status', null, b.token, { 'x-tenant-id': String(tenantId) });
      assert.strictEqual(blocked.status, 403);
      assert.strictEqual(blocked.json.code, 'TENANT_SUSPENDED');
      assert.strictEqual((await api('PATCH', `/api/admin/tenants/${tenantId}/status`, { status: 'active' })).status, 200);
    });

    await check('desativar plano bloqueia novas compras e não altera assinatura existente', async () => {
      assert.strictEqual((await api('PATCH', '/api/admin/plans/mensal', { is_active: false })).status, 200);
      const availability = await api('GET', '/api/payment/availability');
      assert.strictEqual(availability.json.plans.mensal, false);
      // A validação do plano ocorre antes de exigir credenciais reais do gateway.
      assert.strictEqual((await api('POST', '/api/payment/create-checkout', { plano_tipo: 'mensal' }, a.token)).status, 403);
      assert.strictEqual((await api('POST', '/api/payment/stripe/create-checkout', { plano_tipo: 'mensal' }, a.token)).status, 403);
      assert.strictEqual((await api('PATCH', '/api/admin/plans/mensal', { is_active: true })).status, 200);
    });

    // Ativa as duas contas pelo Super Admin; o ajuste afeta o acesso local, não o gateway.
    for (const u of [a.user.id, b.user.id]) {
      await api('POST', `/api/admin/users/${u}/update-subscription`, { plano_tipo: 'vitalicio', status_assinatura: 'ativa' });
    }

    await check('grava, lê e atualiza registros', async () => {
      const ops = [
        put('clientes', { id: 'c1', nome: 'Maria', tel: '11999990000', obs: 'sem lactose' }),
        put('ingredientes', { id: 'i1', nome: 'Leite condensado', un: 'lata', preco: 7.5, est: 10, min: 3, val: '2027-01-10' }),
        put('produtos', { id: 'p1', nome: 'Brigadeiro', rend: 50, margem: 50, itens: [{ ing: 'i1', qtd: 2 }], emb: 0.5, mo: 0, out: 0, preco: 2.5 }),
        put('pedidos', { id: 'o1', cli: 'c1', ent: '2026-12-01', st: 'recebido', pg: 10, itens: [{ pid: 'p1', nome: 'Brigadeiro', q: 20, pu: 2.5, cu: 1.8 }] })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      let r = (await api('GET', '/api/data', null, a.token)).json;
      assert.strictEqual(r.empty, false);
      assert.strictEqual(r.data.clientes[0].nome, 'Maria');
      assert.strictEqual(r.data.pedidos[0].itens[0].q, 20);
      assert.strictEqual(r.data.ingredientes[0].val, '2027-01-10');

      await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c1', nome: 'Maria Souza' })] }, a.token);
      r = (await api('GET', '/api/data', null, a.token)).json;
      assert.strictEqual(r.data.clientes.length, 1, 'upsert não deve duplicar');
      assert.strictEqual(r.data.clientes[0].nome, 'Maria Souza');
    });

    await check('colunas-chave são preenchidas para relatórios', async () => {
      let DatabaseSync;
      try { ({ DatabaseSync } = require('node:sqlite')); } catch (_) { return; } // Node < 22.5: verificação ignorada
      const h = new DatabaseSync(dbFile);
      const row = h.prepare('SELECT total, pago, status, data_entrega FROM pedidos WHERE id = ?').get('o1');
      assert.strictEqual(row.total, 50);
      assert.strictEqual(row.pago, 10);
      assert.strictEqual(row.status, 'recebido');
      assert.strictEqual(row.data_entrega, '2026-12-01');
      h.close();
    });

    await check('isolamento: outra usuária não vê nem altera os dados', async () => {
      const r = (await api('GET', '/api/data', null, b.token)).json;
      assert.strictEqual(r.empty, true);
      // Bia usa o mesmo id "c1": cria o PRÓPRIO registro, sem tocar no da Ana.
      await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c1', nome: 'Cliente da Bia' })] }, b.token);
      const ana = (await api('GET', '/api/data', null, a.token)).json;
      const bia = (await api('GET', '/api/data', null, b.token)).json;
      assert.strictEqual(ana.data.clientes[0].nome, 'Maria Souza');
      assert.strictEqual(bia.data.clientes[0].nome, 'Cliente da Bia');
      // Bia tenta apagar "o1" (que só existe na Ana): não pode afetar.
      await api('POST', '/api/data/sync', { ops: [del('pedidos', 'o1')] }, b.token);
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.pedidos.length, 1);
    });

    await check('exclusão remove o registro', async () => {
      await api('POST', '/api/data/sync', { ops: [del('pedidos', 'o1')] }, a.token);
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.pedidos.length, 0);
    });

    await check('transação é atômica: uma operação inválida não grava nada', async () => {
      const r = await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c9', nome: 'Nova' }), put('clientes', { id: 'id inválido!', nome: 'X' })] }, a.token);
      assert.strictEqual(r.status, 400);
      const list = (await api('GET', '/api/data', null, a.token)).json.data.clientes;
      assert.ok(!list.some((c) => c.id === 'c9'));
    });

    await check('validação rejeita coleção, operação e excesso', async () => {
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [put('users', { id: 'x' })] }, a.token)).status, 400);
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [{ c: 'clientes', op: 'drop' }] }, a.token)).status, 400);
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: 'x' }, a.token)).status, 400);
      const many = Array.from({ length: 1001 }, (_, i) => put('clientes', { id: 'm' + i, nome: 'n' }));
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: many }, a.token)).status, 400);
    });

    await check('injeção SQL em ids/valores é tratada como texto', async () => {
      const evil = "x'); DROP TABLE clientes;--";
      await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c2', nome: evil })] }, a.token);
      const list = (await api('GET', '/api/data', null, a.token)).json.data.clientes;
      assert.ok(list.some((c) => c.nome === evil));
    });

    await check('lote grande (migração) de 800 registros grava em uma transação', async () => {
      const ops = Array.from({ length: 800 }, (_, i) => put('ingredientes', { id: 'g' + i, nome: 'Ing ' + i, preco: i, est: 1 }));
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.ingredientes.length, 801);
    });

    await check('escritas simultâneas não corrompem nem travam', async () => {
      const results = await Promise.all(Array.from({ length: 20 }, (_, i) =>
        api('POST', '/api/data/sync', { ops: [put('despesas', { id: 'd' + i, v: i, pago: i % 2 === 0, venc: '2026-12-01' })] }, a.token)));
      assert.ok(results.every((r) => r.status === 200));
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.despesas.length, 20);
    });

    await check('exportação devolve os dados em JSON', async () => {
      const r = await api('GET', '/api/data/export', null, a.token);
      assert.strictEqual(r.status, 200);
      assert.ok(r.json.exportado_em && r.json.data.clientes.length >= 1);
    });

    await check('migração: banco antigo ganha as colunas novas e mantém os dados', async () => {
      if (!legacyDb) return;
      const { DatabaseSync } = require('node:sqlite');
      const h = new DatabaseSync(dbFile);
      const cols = h.prepare('PRAGMA table_info(despesas)').all().map((c) => c.name);
      for (const c of ['categoria', 'fornecedor_id', 'data_pagamento']) assert.ok(cols.includes(c), 'falta coluna ' + c);
      assert.strictEqual(h.prepare("SELECT valor FROM despesas WHERE id = 'antiga'").get().valor, 10);
      h.close();
    });

    await check('pedido: valor pago vem da soma dos pagamentos registrados', async () => {
      const o = { id: 'o2', cli: 'c1', ent: '2026-12-05', st: 'confirmado', itens: [{ pid: 'p1', nome: 'Bolo', q: 1, pu: 100, cu: 40 }],
                  pagamentos: [{ id: 'a', v: 30, data: '2026-11-01', forma: 'Pix' }, { id: 'b', v: 20.5, data: '2026-11-10', forma: 'Dinheiro' }] };
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [put('pedidos', o)] }, a.token)).status, 200);
      let pago;
      try {
        const { DatabaseSync } = require('node:sqlite');
        const h = new DatabaseSync(dbFile);
        pago = h.prepare("SELECT pago, total FROM pedidos WHERE id = 'o2' AND user_id = ?").get(a.user.id);
        h.close();
      } catch (_) { return; }
      assert.strictEqual(pago.pago, 50.5);
      assert.strictEqual(pago.total, 100);
    });

    await check('fornecedores, configurações e despesas com categoria são gravados', async () => {
      const ops = [
        put('fornecedores', { id: 'f1', nome: 'Atacadão Doces', tel: '11988887777' }),
        put('config', { id: 'main', cap_pedidos: 8, cap_unid: 120 }),
        put('despesas', { id: 'dx', desc: 'Energia', v: 230.9, venc: '2026-12-10', cat: 'Energia, água e gás', forn: 'f1', pago: true, dpg: '2026-12-09' })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      const r = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(r.fornecedores[0].nome, 'Atacadão Doces');
      assert.strictEqual(r.config[0].cap_pedidos, 8);
      assert.strictEqual(r.despesas.find((d) => d.id === 'dx').cat, 'Energia, água e gás');
    });

    await check('uma conta não consegue selecionar o tenant de outra empresa', async () => {
      const denied = await api('GET', '/api/data', null, a.token, { 'X-Tenant-ID': String(b.current_tenant.id) });
      assert.strictEqual(denied.status, 403);
      assert.strictEqual(denied.json.code, 'TENANT_ACCESS_DENIED');
    });

    let sharedTenantId = null;
    await check('proprietário convida outra conta e o membro aceita com o e-mail correto', async () => {
      sharedTenantId = a.current_tenant.id;
      const created = await api('POST', '/api/tenants/invitations', { email: 'bia@teste.com', role: 'member' }, a.token, { 'X-Tenant-ID': String(sharedTenantId) });
      assert.strictEqual(created.status, 201);
      assert.ok(created.json.invitation.accept_url.includes('convite='));
      const inviteUrl = new URL(created.json.invitation.accept_url);
      const rawToken = new URLSearchParams(inviteUrl.hash.replace(/^#/, '')).get('convite') || inviteUrl.searchParams.get('convite');
      assert.match(rawToken || '', /^[a-f0-9]{64}$/i);
      const accepted = await api('POST', '/api/tenants/invitations/accept', { token: rawToken }, b.token);
      assert.strictEqual(accepted.status, 200);
      assert.strictEqual(accepted.json.current_tenant.id, sharedTenantId);
      assert.strictEqual(accepted.json.current_tenant.role, 'member');
      assert.equal(accepted.json.tenants.length, 2);
    });

    await check('membro acessa somente empresa compartilhada e não lê nem grava financeiro', async () => {
      const headers = { 'X-Tenant-ID': String(sharedTenantId) };
      const read = await api('GET', '/api/data', null, b.token, headers);
      assert.strictEqual(read.status, 200);
      assert.ok(read.json.restricted_collections.includes('despesas'));
      assert.deepStrictEqual(read.json.data.despesas, []);
      assert.deepStrictEqual(read.json.data.fornecedores, []);
      assert.ok(read.json.data.clientes.some((item) => item.id === 'c1'));

      const deniedFinance = await api('POST', '/api/data/sync', { ops: [put('despesas', { id: 'member-expense', desc: 'Não autorizado', v: 20 })] }, b.token, headers);
      assert.strictEqual(deniedFinance.status, 403);
      assert.strictEqual(deniedFinance.json.code, 'TENANT_COLLECTION_PERMISSION_DENIED');

      const permittedOperation = await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'cliente-equipe', nome: 'Cliente compartilhado' })] }, b.token, headers);
      assert.strictEqual(permittedOperation.status, 200);
      const ownerView = await api('GET', '/api/data', null, a.token, { 'X-Tenant-ID': String(sharedTenantId) });
      assert.ok(ownerView.json.data.clientes.some((item) => item.id === 'cliente-equipe'));
    });

    await check('membro não administra equipe e o proprietário pode removê-lo', async () => {
      const headers = { 'X-Tenant-ID': String(sharedTenantId) };
      assert.strictEqual((await api('GET', '/api/tenants/members', null, b.token, headers)).status, 403);
      assert.strictEqual((await api('DELETE', `/api/tenants/members/${b.user.id}`, null, a.token, headers)).status, 200);
      assert.strictEqual((await api('GET', '/api/data', null, b.token, headers)).status, 403);
    });

    await check('produção exige autenticação e respeita o usuário proprietário', async () => {
      assert.strictEqual((await api('POST', '/api/production/prod-a/consume', {})).status, 401);
      assert.strictEqual((await api('POST', '/api/production/prod-a/consume', {}, b.token)).status, 404);
    });

    await check('produção baixa ingredientes e embalagens por lote, em uma transação', async () => {
      const ops = [
        put('ingredientes', { id: 'ing-prod', nome: 'Farinha', un: 'kg', preco: 8, est: 1, min: 0 }),
        put('embalagens', { id: 'pack-prod', nome: 'Caixa', un: 'un', preco: 1.25, est: 20, min: 0 }),
        put('lotes', { id: 'lot-ing-prod', item_tipo: 'ingrediente', item_id: 'ing-prod', quantidade_inicial: 1, quantidade_disponivel: 1, unidade: 'kg', validade: '2026-12-01', custo_unitario: 9.2, recebido_em: '2026-11-01' }),
        put('lotes', { id: 'lot-pack-prod', item_tipo: 'embalagem', item_id: 'pack-prod', quantidade_inicial: 20, quantidade_disponivel: 20, unidade: 'un', validade: '', custo_unitario: 1.4, recebido_em: '2026-11-01' }),
        put('produtos', { id: 'product-prod', nome: 'Bolo teste', rend: 10, margem: 50, itens: [{ ing: 'ing-prod', qtd: 500, un: 'g' }], embalagem_id: 'pack-prod', embalagem_qtd: 1, emb: 0, mo: 0, en: 0, out: 0, preco: 30, custo_unitario: 5 }),
        put('producao', { id: 'prod-a', produto_id: 'product-prod', quantidade: 15, data_prevista: '2026-11-06', status: 'em_producao', consumo_aplicado: false })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);

      const consumed = await api('POST', '/api/production/prod-a/consume', {}, a.token);
      assert.strictEqual(consumed.status, 200);
      assert.strictEqual(consumed.json.production.requested_quantity, 15);
      assert.strictEqual(consumed.json.production.produced_quantity, 20);
      assert.strictEqual(consumed.json.production.batches, 2);
      assert.strictEqual(consumed.json.production.consumed.length, 2);
      assert.strictEqual(consumed.json.production.consumed[0].estimated_cost, 9.2);
      assert.strictEqual(consumed.json.production.consumed[1].estimated_cost, 28);

      const data = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(data.ingredientes.find((x) => x.id === 'ing-prod').est, 0);
      assert.strictEqual(data.embalagens.find((x) => x.id === 'pack-prod').est, 0);
      assert.strictEqual(data.lotes.find((x) => x.id === 'lot-ing-prod').quantidade_disponivel, 0);
      assert.strictEqual(data.lotes.find((x) => x.id === 'lot-pack-prod').quantidade_disponivel, 0);
      assert.strictEqual(data.producao.find((x) => x.id === 'prod-a').consumo_aplicado, true);
      assert.strictEqual(data.producao.find((x) => x.id === 'prod-a').custo_estimado, 37.2);
      assert.strictEqual(data.mov.filter((x) => x.producao_id === 'prod-a').length, 2);

      const repeated = await api('POST', '/api/production/prod-a/consume', {}, a.token);
      assert.strictEqual(repeated.status, 409);
      assert.strictEqual(repeated.json.code, 'CONSUMPTION_ALREADY_APPLIED');
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.mov.filter((x) => x.producao_id === 'prod-a').length, 2);
    });

    await check('produção insuficiente reverte todas as alterações', async () => {
      const ops = [
        put('ingredientes', { id: 'ing-short', nome: 'Cacau', un: 'kg', preco: 20, est: 0.1, min: 0 }),
        put('lotes', { id: 'lot-short', item_tipo: 'ingrediente', item_id: 'ing-short', quantidade_inicial: 0.1, quantidade_disponivel: 0.1, unidade: 'kg', validade: '2026-12-01', custo_unitario: 20, recebido_em: '2026-11-01' }),
        put('produtos', { id: 'product-short', nome: 'Trufa', rend: 1, margem: 50, itens: [{ ing: 'ing-short', qtd: 0.5, un: 'kg' }], preco: 10, custo_unitario: 10 }),
        put('producao', { id: 'prod-short', produto_id: 'product-short', quantidade: 1, data_prevista: '2026-11-06', status: 'em_producao', consumo_aplicado: false })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      const response = await api('POST', '/api/production/prod-short/consume', {}, a.token);
      assert.strictEqual(response.status, 409);
      const data = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(data.ingredientes.find((x) => x.id === 'ing-short').est, 0.1);
      assert.strictEqual(data.lotes.find((x) => x.id === 'lot-short').quantidade_disponivel, 0.1);
      assert.strictEqual(data.producao.find((x) => x.id === 'prod-short').consumo_aplicado, false);
      assert.ok(!data.mov.some((x) => x.producao_id === 'prod-short'));
    });

    await check('desperdício reduz estoque, consome lote e registra custo', async () => {
      const ops = [
        put('ingredientes', { id: 'ing-waste', nome: 'Morango', un: 'kg', preco: 12, est: 3, min: 0 }),
        put('lotes', { id: 'lot-waste', item_tipo: 'ingrediente', item_id: 'ing-waste', quantidade_inicial: 3, quantidade_disponivel: 3, unidade: 'kg', validade: '2026-12-10', custo_unitario: 12, recebido_em: '2026-11-01' })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      const response = await api('POST', '/api/production/waste', { item_type: 'ingrediente', item_id: 'ing-waste', quantity: 1.5, reason: 'Quebra no transporte', date: '2026-11-05' }, a.token);
      assert.strictEqual(response.status, 201);
      assert.strictEqual(response.json.loss.custo_total, 18);
      const data = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(data.ingredientes.find((x) => x.id === 'ing-waste').est, 1.5);
      assert.strictEqual(data.lotes.find((x) => x.id === 'lot-waste').quantidade_disponivel, 1.5);
      assert.ok(data.perdas.some((x) => x.item_id === 'ing-waste' && x.quantidade === 1.5));
    });

    await check('custo da perda usa o preço dos lotes efetivamente consumidos', async () => {
      const ops = [
        put('ingredientes', { id: 'ing-cost-lots', nome: 'Chocolate branco', un: 'kg', preco: 10, est: 4, min: 0 }),
        put('lotes', { id: 'lot-cost-old', item_tipo: 'ingrediente', item_id: 'ing-cost-lots', quantidade_inicial: 1, quantidade_disponivel: 1, unidade: 'kg', validade: '2026-12-01', custo_unitario: 5, recebido_em: '2026-10-01' }),
        put('lotes', { id: 'lot-cost-new', item_tipo: 'ingrediente', item_id: 'ing-cost-lots', quantidade_inicial: 3, quantidade_disponivel: 3, unidade: 'kg', validade: '2026-12-02', custo_unitario: 12, recebido_em: '2026-11-01' })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      const response = await api('POST', '/api/production/waste', { item_type: 'ingrediente', item_id: 'ing-cost-lots', quantity: 2, reason: 'Avaria na embalagem', date: '2026-11-05' }, a.token);
      assert.strictEqual(response.status, 201);
      assert.strictEqual(response.json.loss.custo_total, 17);
      const data = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(data.lotes.find((x) => x.id === 'lot-cost-old').quantidade_disponivel, 0);
      assert.strictEqual(data.lotes.find((x) => x.id === 'lot-cost-new').quantidade_disponivel, 2);
      assert.strictEqual(data.mov.find((x) => x.tipo === 'saida_perda' && x.item_id === 'ing-cost-lots').custo_total, 17);
    });

    await check('lote vencido não é consumido em produção', async () => {
      const ops = [
        put('ingredientes', { id: 'ing-expired', nome: 'Creme', un: 'kg', preco: 15, est: 2, min: 0 }),
        put('lotes', { id: 'lot-expired', item_tipo: 'ingrediente', item_id: 'ing-expired', quantidade_inicial: 2, quantidade_disponivel: 2, unidade: 'kg', validade: '2026-11-04', custo_unitario: 15, recebido_em: '2026-10-01' }),
        put('produtos', { id: 'product-expired', nome: 'Doce', rend: 1, margem: 50, itens: [{ ing: 'ing-expired', qtd: 1, un: 'kg' }], preco: 10, custo_unitario: 10 }),
        put('producao', { id: 'prod-expired', produto_id: 'product-expired', quantidade: 1, data_prevista: '2026-11-06', status: 'em_producao', consumo_aplicado: false })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      const response = await api('POST', '/api/production/prod-expired/consume', {}, a.token);
      assert.strictEqual(response.status, 409);
      const data = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(data.ingredientes.find((x) => x.id === 'ing-expired').est, 2);
    });

    await check('desperdício rejeita quantidade inválida e motivo curto', async () => {
      assert.strictEqual((await api('POST', '/api/production/waste', { item_type: 'ingrediente', item_id: 'ing-waste', quantity: -1, reason: 'teste' }, a.token)).status, 400);
      assert.strictEqual((await api('POST', '/api/production/waste', { item_type: 'ingrediente', item_id: 'ing-waste', quantity: 1, reason: 'x' }, a.token)).status, 400);
    });

    await check('desperdício rejeita data impossível e data futura', async () => {
      const baseWaste = { item_type: 'ingrediente', item_id: 'ing-waste', quantity: 0.1, reason: 'Teste de data' };
      assert.strictEqual((await api('POST', '/api/production/waste', { ...baseWaste, date: '2026-02-31' }, a.token)).status, 400);
      assert.strictEqual((await api('POST', '/api/production/waste', { ...baseWaste, date: '2999-01-01' }, a.token)).status, 400);
    });

    await check('login: limite de tentativas por e-mail (429 após 10)', async () => {
      let last;
      for (let i = 0; i < 12; i++) last = await api('POST', '/api/auth/login', { email: 'ana@teste.com', senha: 'errada-errada' });
      assert.strictEqual(last.status, 429);
      // outro e-mail na mesma conexão não é afetado
      assert.strictEqual((await api('POST', '/api/auth/login', { email: 'bia@teste.com', senha: 'senha-forte-2' })).status, 200);
    });

    await check('rotas públicas existentes continuam respondendo', async () => {
      assert.strictEqual((await api('GET', '/api/app-status', null, a.token)).status, 200);
    });

    await check('logout do Super Admin revoga a sessão no servidor', async () => {
      const result = await api('DELETE', '/api/admin/session');
      assert.strictEqual(result.status, 200);
      assert.strictEqual((await api('GET', '/api/admin/session')).status, 401);
      adminCookie = '';
    });
  } finally {
    if (server.exitCode === null && server.signalCode === null) {
      server.kill();
      await new Promise((resolve) => server.once('exit', resolve));
    }
    for (const ext of ['', '-wal', '-shm']) fs.rmSync(dbFile + ext, { force: true });
    console.log(`\n${passed} verificações passaram${process.exitCode ? ' (HÁ FALHAS)' : ''}.`);
  }
}
main();
