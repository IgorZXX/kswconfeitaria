'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const quote = require('../lib/quote-public');

const validQuote = {
  id: 'quote_20261108_a1',
  cli: 'client-01',
  total: '325,50',
  validade: '2026-11-20',
  entrega: '2026-11-25',
  quantidade: 12,
  descricao: 'Bolo de dois andares, massa de baunilha e recheio de brigadeiro.'
};

test('normaliza orçamento e valor monetário em centavos', () => {
  const result = quote.normalizeQuote(validQuote, '2026-11-08');
  assert.equal(result.ok, true);
  assert.equal(result.value.total, 325.5);
  assert.equal(result.value.cli, 'client-01');
  assert.equal(result.value.entrega, '2026-11-25');
  assert.equal(result.value.quantidade, 12);
});

test('recusa orçamento expirado, data impossível, valor inválido e descrição vazia', () => {
  assert.match(quote.normalizeQuote({ ...validQuote, validade: '2026-11-07' }, '2026-11-08').error, /validade/i);
  assert.match(quote.normalizeQuote({ ...validQuote, entrega: '2026-02-30' }, '2026-11-08').error, /entrega/i);
  assert.match(quote.normalizeQuote({ ...validQuote, total: 0 }, '2026-11-08').error, /valor/i);
  assert.match(quote.normalizeQuote({ ...validQuote, quantidade: 1.5 }, '2026-11-08').error, /quantidade/i);
  assert.match(quote.normalizeQuote({ ...validQuote, quantidade: 0 }, '2026-11-08').error, /quantidade/i);
  assert.match(quote.normalizeQuote({ ...validQuote, descricao: '  ' }, '2026-11-08').error, /descreva/i);
});

test('rejeita identificadores que possam escapar do escopo de registros', () => {
  assert.equal(quote.normalizeQuote({ ...validQuote, id: '../other-tenant' }, '2026-11-08').ok, false);
  assert.equal(quote.normalizeQuote({ ...validQuote, cli: 'client id' }, '2026-11-08').ok, false);
});

test('monta pedido compatível com o módulo de encomendas sem marcar pagamento', () => {
  const order = quote.buildAcceptedOrder({ ...quote.normalizeQuote(validQuote, '2026-11-08').value }, 'order-123', '2026-11-08T12:00:00.000Z');
  assert.equal(order.id, 'order-123');
  assert.equal(order.cli, 'client-01');
  assert.equal(order.ent, '2026-11-25');
  assert.equal(order.st, 'recebido');
  assert.equal(order.itens[0].q, 1);
  assert.equal(order.unidades_estimadas, 12);
  assert.equal(order.itens[0].pu, 325.5);
  assert.equal(order.itens[0].cu, null);
  assert.equal(order.pg, 0);
  assert.deepEqual(order.pagamentos, []);
  assert.equal(order.origem, 'orcamento_online');
});

test('hash do token é SHA-256 hexadecimal e não reproduz o token', () => {
  const token = 'x'.repeat(43);
  const hash = quote.hashPublicToken(token);
  assert.match(hash, /^[a-f0-9]{64}$/);
  assert.notEqual(hash, token);
});
