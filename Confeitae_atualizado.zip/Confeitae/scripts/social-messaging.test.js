'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { DatabaseSync } = require('node:sqlite');
const { initializeSocialSchema } = require('../lib/social-schema');

class Adapter {
  constructor() { this.db = new DatabaseSync(':memory:'); }
  run(sql, params, callback) {
    try { this.db.prepare(sql).run(...(params || [])); callback(null); }
    catch (error) { callback(error); }
  }
  close() { this.db.close(); }
}

async function createFixture() {
  const adapter = new Adapter();
  adapter.db.exec(`
    CREATE TABLE tenants (id INTEGER PRIMARY KEY, nome TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active');
    CREATE TABLE users (id INTEGER PRIMARY KEY);
    INSERT INTO tenants(id,nome,status) VALUES (1,'Ateliê Ana','active'),(2,'Doces da Bia','active'),(3,'Confeitaria Carol','active');
    INSERT INTO users(id) VALUES (11),(22),(33);
  `);
  await initializeSocialSchema(adapter);
  adapter.db.exec(`
    INSERT INTO ksw_social_profiles (tenant_id,handle,is_public) VALUES (1,'atelie-ana',1),(2,'doces-bia',1),(3,'carol-doces',1);
    INSERT INTO ksw_social_conversations (tenant_low_id,tenant_high_id) VALUES (1,2);
    INSERT INTO ksw_social_messages (conversation_id,sender_tenant_id,sender_user_id,body) VALUES (1,2,22,'Oi, tudo bem?');
  `);
  return adapter;
}

const conversationListSql = `
  SELECT c.id,
    peer.id AS peer_tenant_id,
    peer.nome AS business_name,
    COALESCE(sp.handle,'') AS handle,
    COALESCE(sp.avatar_url,'') AS avatar_url,
    (SELECT m.body FROM ksw_social_messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_message,
    (SELECT m.created_at FROM ksw_social_messages m WHERE m.conversation_id=c.id ORDER BY m.id DESC LIMIT 1) AS last_message_at,
    (SELECT COUNT(*) FROM ksw_social_messages unread WHERE unread.conversation_id=c.id AND unread.sender_tenant_id=peer.id AND unread.read_at IS NULL) AS unread_count
  FROM ksw_social_conversations c
  JOIN tenants peer ON peer.id=CASE WHEN c.tenant_low_id=? THEN c.tenant_high_id ELSE c.tenant_low_id END
  LEFT JOIN ksw_social_profiles sp ON sp.tenant_id=peer.id
  WHERE (c.tenant_low_id=? OR c.tenant_high_id=?) AND peer.status='active'
  ORDER BY c.last_message_at DESC,c.id DESC
  LIMIT 100`;

test('mensagens: cada empresa lista apenas conversas das quais participa', async () => {
  const adapter = await createFixture();
  try {
    const ana = adapter.db.prepare(conversationListSql).all(1, 1, 1);
    const bia = adapter.db.prepare(conversationListSql).all(2, 2, 2);
    const carol = adapter.db.prepare(conversationListSql).all(3, 3, 3);
    assert.equal(ana.length, 1);
    assert.equal(ana[0].business_name, 'Doces da Bia');
    assert.equal(bia.length, 1);
    assert.equal(bia[0].business_name, 'Ateliê Ana');
    assert.equal(carol.length, 0);
    assert.equal(ana[0].last_message, 'Oi, tudo bem?');
    assert.equal(ana[0].unread_count, 1);
  } finally { adapter.close(); }
});

test('mensagens: abrir conversa marca como lidas somente as mensagens recebidas', async () => {
  const adapter = await createFixture();
  try {
    adapter.db.prepare('INSERT INTO ksw_social_messages (conversation_id,sender_tenant_id,sender_user_id,body) VALUES (?,?,?,?)').run(1, 1, 11, 'Tudo ótimo!');
    adapter.db.prepare('UPDATE ksw_social_messages SET read_at=CURRENT_TIMESTAMP WHERE conversation_id=? AND sender_tenant_id<>? AND read_at IS NULL').run(1, 1);
    const rows = adapter.db.prepare('SELECT sender_tenant_id,read_at FROM ksw_social_messages WHERE conversation_id=? ORDER BY id').all(1);
    assert.ok(rows[0].read_at, 'mensagem recebida fica marcada como lida');
    assert.equal(rows[1].read_at, null, 'mensagem enviada não é marcada como recebida');
    const unread = adapter.db.prepare('SELECT COUNT(*) AS total FROM ksw_social_messages WHERE conversation_id=? AND sender_tenant_id=? AND read_at IS NULL').get(1, 2);
    assert.equal(unread.total, 0);
  } finally { adapter.close(); }
});
