require('dotenv').config();
const Stripe = require('stripe');
const fs = require('fs');
const path = require('path');

async function main() {
  const secret = process.env.STRIPE_SECRET_KEY;
  if (!secret || !secret.startsWith('sk_test_')) {
    throw new Error('Por segurança, este script só cria produtos em modo de teste. Configure STRIPE_SECRET_KEY com uma chave sk_test_ no .env.');
  }

  if (process.env.STRIPE_MONTHLY_PRICE_ID || process.env.STRIPE_LIFETIME_PRICE_ID) {
    throw new Error('Já existem IDs de preço no .env. O script foi interrompido para evitar produtos duplicados.');
  }

  const stripe = new Stripe(secret);

  console.log('Criando os produtos no modo de teste da Stripe...');

  const monthlyProduct = await stripe.products.create({
    name: 'Confeitaê - Mensal',
    description: 'Acesso mensal ao sistema Confeitaê'
  });
  const monthlyPrice = await stripe.prices.create({
    product: monthlyProduct.id,
    currency: 'brl',
    unit_amount: 5999,
    recurring: { interval: 'month' }
  });

  const lifetimeProduct = await stripe.products.create({
    name: 'Confeitaê - Vitalício',
    description: 'Acesso vitalício ao sistema Confeitaê'
  });
  const lifetimePrice = await stripe.prices.create({
    product: lifetimeProduct.id,
    currency: 'brl',
    unit_amount: 111900
  });

  const envPath = path.resolve(process.cwd(), '.env');
  const lines = fs.existsSync(envPath)
    ? fs.readFileSync(envPath, 'utf8').split(/\r?\n/)
    : [];

  lines.push(
    `STRIPE_MONTHLY_PRICE_ID=${monthlyPrice.id}`,
    `STRIPE_LIFETIME_PRICE_ID=${lifetimePrice.id}`
  );
  fs.writeFileSync(envPath, lines.join('\n').replace(/\n+$/, '') + '\n', 'utf8');

  console.log('\nProdutos criados e IDs salvos no .env.');
  console.log(`Mensal: ${monthlyPrice.id} (R$ 59,99/mês)`);
  console.log(`Vitalício: ${lifetimePrice.id} (R$ 1.119,00 pagamento único)`);
  console.log('\nNão compartilhe o arquivo .env.');
}

main().catch((error) => {
  console.error('\nFalha ao criar produtos:', error.message);
  process.exitCode = 1;
});
