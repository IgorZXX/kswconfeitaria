'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeCookieConsent, COOKIE_CONSENT_VERSION } = require('../lib/cookie-consent');

test('não considera ausência de escolha como consentimento', () => {
  assert.equal(normalizeCookieConsent(null), null);
  assert.equal(normalizeCookieConsent({}), null);
  assert.equal(normalizeCookieConsent({ choice: 'unknown' }), null);
});

test('aceitar e rejeitar aplicam escolhas explícitas e coerentes', () => {
  assert.deepEqual(normalizeCookieConsent({ choice: 'accepted', analytics: false, marketing: false }), {
    choice: 'accepted', necessary: true, analytics: true, marketing: true, version: COOKIE_CONSENT_VERSION
  });
  assert.deepEqual(normalizeCookieConsent({ choice: 'rejected', analytics: true, marketing: true }), {
    choice: 'rejected', necessary: true, analytics: false, marketing: false, version: COOKIE_CONSENT_VERSION
  });
});

test('escolha personalizada preserva apenas as categorias marcadas', () => {
  assert.deepEqual(normalizeCookieConsent({ choice: 'custom', analytics: true, marketing: false }), {
    choice: 'custom', necessary: true, analytics: true, marketing: false, version: COOKIE_CONSENT_VERSION
  });
  assert.equal(normalizeCookieConsent({ choice: 'custom', analytics: 'true', marketing: 1 }).analytics, false);
});
