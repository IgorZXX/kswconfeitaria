'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const routes = fs.readFileSync(path.join(root,'routes/social.js'),'utf8');
const schema = fs.readFileSync(path.join(root,'lib/social-schema.js'),'utf8');
const ui = fs.readFileSync(path.join(root,'public/social-ui.js'),'utf8');
const app = fs.readFileSync(path.join(root,'public/index.html'),'utf8');
const server = fs.readFileSync(path.join(root,'server.js'),'utf8');

test('Comunidade usa contexto autenticado e assinatura ativa nas ações', () => {
  assert.match(routes,/router\.use\(authMiddleware, tenantContextMiddleware, checkActiveSubscription\)/);
  assert.match(routes,/requirePermission\('data\.write'\)/);
  assert.match(routes,/imageBelongsToTenant\(imageUrl, req\.tenant\.id\)/);
});
test('Comunidade oferece feed, publicações, curtidas, comentários, seguir e denúncia', () => {
  for (const route of ['/feed','/posts','/like','/comments','/follow','/report','/explore']) assert.ok(routes.includes(route));
  assert.match(schema,/FOREIGN KEY\(tenant_id\) REFERENCES tenants/);
});
test('Interface da Comunidade integra navegação e usa texto escapado', () => {
  assert.match(app,/\['social','Comunidade'/);
  assert.match(app,/id="ksw-social-root"/);
  assert.match(ui,/function esc\(/);
  assert.match(ui,/createImageBitmap/);
  assert.match(server,/app\.use\('\/api\/social'/);
});

test('conteúdo social usa nome público da empresa e limita abuso nas ações', () => {
  assert.match(routes,/t\.nome AS business_name/);
  assert.match(routes,/t\.nome AS author_name/);
  assert.doesNotMatch(routes,/u\.nome/);
  assert.match(routes,/followLimiter/);
  assert.match(routes,/reportLimiter/);
  assert.match(routes,/commentLimiter/);
  assert.match(routes,/caption.length > 2000/);
  assert.match(routes,/body.length > 500/);
});

test('feed não exibe o cartão redundante de criação; publicação fica na ação Criar', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  assert.doesNotMatch(ui,/O que você criou hoje\?/);
  assert.doesNotMatch(ui,/ksw-social-composer-row|ksw-social-composer-trigger/);
  assert.match(ui,/\['create','plus','Criar'\]/);
  assert.match(ui,/KSWSocial\.create\(\)/);
  assert.match(ui,/role="dialog" aria-modal="true"/);
  assert.match(ui,/event\.key==='Escape'/);
  assert.match(ui,/openComposer:openComposer,closeComposer:closeComposer/);
  assert.match(ui,/ksw-social-photo/);
  assert.match(ui,/ksw-social-caption/);
  assert.match(css,/\.ksw-social-modal-backdrop\{position:fixed/);
});

test('foto de perfil: recorte quadrado no navegador, upload próprio e URL validada', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  assert.match(ui,/\/api\/social\/upload-avatar/);
  assert.match(ui,/avatar_url/);
  assert.match(ui,/function avatarInner\(/);
  assert.match(ui,/\[a-f0-9\]\{32\}\\\.png/);
  assert.match(ui,/ksw-social-avatar-file/);
  assert.match(routes,/upload-avatar/);
  assert.match(routes,/avatarLimiter/);
  assert.match(routes,/imageBelongsToTenant\(avatarUrl, req\.tenant\.id\)/);
  assert.match(schema,/avatar_url TEXT NOT NULL DEFAULT ''/);
  assert.match(css,/\.ksw-social-avatar img\{/);
});
test('envio de foto da publicação usa área com arrastar e soltar e prévia', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  assert.match(ui,/Arraste sua foto ou vídeo aqui/);
  assert.match(ui,/KSWSocial\.drop\(event\)/);
  assert.match(ui,/clearPhoto/);
  assert.match(css,/\.ksw-social-drop\{/);
});

test('layout estilo rede social: faixa de confeitarias e barra inferior, sem coluna lateral', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  for (const label of ['Início','Explorar','Criar','Vídeos','Perfil']) assert.ok(ui.includes(label), label);
  assert.match(ui,/function bottomBar\(/);
  assert.match(ui,/function stories\(/);
  assert.match(ui,/function suggestionsCard\(/);
  assert.match(ui,/function profileSummary\(/);
  assert.doesNotMatch(ui,/<aside/);
  assert.doesNotMatch(ui,/function sidebar\(/);
  assert.doesNotMatch(ui,/ksw-social-tabs/);
  assert.match(css,/\.ksw-social-bottom\{position:sticky/);
});
test('vídeos: upload com assinatura de contêiner, limites, Range e URL validada', () => {
  assert.match(routes,/router\.post\('\/upload-video'/);
  assert.match(routes,/detectVideoExtension\(req\.body\)/);
  assert.match(routes,/videoLimiter/);
  assert.match(routes,/MAX_VIDEO_BYTES/);
  assert.match(routes,/videoBelongsToTenant\(videoUrl, req\.tenant\.id\)/);
  assert.match(routes,/router\.get\('\/videos\/:tenantId\/:filename'/);
  assert.match(routes,/'X-Content-Type-Options': 'nosniff'/);
  assert.match(routes,/media === 'video'/);
  assert.match(schema,/video_url TEXT NOT NULL DEFAULT ''/);
  assert.match(ui,/\/api\/social\/upload-video/);
  assert.match(ui,/function videoUrlOk\(/);
  assert.match(ui,/duration>90/);
});

test('navegação da Comunidade integra o histórico do navegador e tem botão Voltar', () => {
  assert.match(ui,/history\.pushState\(\{kswSocial:value/);
  assert.match(ui,/addEventListener\('popstate'/);
  assert.match(ui,/KSWSocial\.back\(\)/);
  assert.match(ui,/back:back/);
});

test('Explorar usa mosaico de publicações, abre detalhe e mantém imagens e vídeos', () => {
  assert.match(ui,/state\.posts\.map\(exploreTile\)/);
  assert.match(ui,/function exploreTile\(/);
  assert.match(ui,/function openPost\(/);
  assert.match(ui,/function closePost\(/);
  assert.match(ui,/function explorePostModal\(/);
  assert.match(ui,/KSWSocial\.openPost\(/);
  assert.match(ui,/ksw-social-explore-mosaic/);
  assert.match(ui,/ksw-social-explore-profile/);
  assert.match(ui,/Nenhuma confeitaria encontrada/);
  assert.match(ui,/el\.hidden=!state\.profiles\.length&&!state\.exploreQuery/);
  assert.match(ui,/state\.videoPosts\.filter\(function\(post\)\{return videoUrlOk\(post\.video_url\);\}\)/);
  assert.match(ui,/postCard\(post,true\)/);
  assert.match(ui,/if\(videosOnly&&!isVideo\)return ''/);
  assert.match(ui,/!videosOnly&&post\.image_url/);
});

test('compositor aceita vídeos pelos tipos MIME e extensões comuns', () => {
  assert.match(ui,/\.mp4,\.webm,\.mov/);
  assert.match(ui,/function isVideoFile\(file\)/);
  assert.match(ui,/video\\\/\(mp4\|webm\|quicktime\)/);
  assert.match(ui,/api\/social\/upload-video/);
  assert.match(ui,/prepareVideo\(file\)/);
});

test('mensagens privadas: API autenticada, conversas únicas e mensagens isoladas por empresa', () => {
  assert.match(schema,/CREATE TABLE IF NOT EXISTS ksw_social_conversations/);
  assert.match(schema,/UNIQUE\(tenant_low_id, tenant_high_id\)/);
  assert.match(schema,/CREATE TABLE IF NOT EXISTS ksw_social_messages/);
  assert.match(routes,/router\.get\('\/conversations'/);
  assert.match(routes,/router\.post\('\/conversations'/);
  assert.match(routes,/router\.get\('\/conversations\/:id\/messages'/);
  assert.match(routes,/router\.post\('\/conversations\/:id\/messages'/);
  assert.match(routes,/tenant_low_id=\? OR tenant_high_id=\?/);
  assert.match(routes,/messageLimiter/);
  assert.match(routes,/conversationLimiter/);
  assert.match(routes,/body\.length > 2000/);
  assert.match(ui,/\['messages','message','Mensagens'\]/);
  assert.match(ui,/KSWSocial\.startConversation/);
  assert.match(ui,/KSWSocial\.sendMessage/);
  assert.match(ui,/setInterval\(function\(\).*refreshMessages/s);
  assert.match(ui,/aria-live="polite"/);
  assert.match(ui,/function messageBubble\(/);
});


test('mensagens usam caixa de entrada em duas colunas e adaptam a navegação no celular', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  assert.match(ui,/function messagesSection\(\)/);
  assert.match(ui,/ksw-social-messages-shell/);
  assert.match(ui,/ksw-social-conversations-panel/);
  assert.match(ui,/ksw-social-chat-panel/);
  assert.match(ui,/aria-current=\"true\"/);
  assert.match(ui,/KSWSocial\.closeConversation\(\)/);
  assert.match(ui,/sec===\'messages\'\?\' is-messages\'/);
  assert.match(css,/\.ksw-social-messages-shell\{display:grid;grid-template-columns:minmax\(270px,340px\) minmax\(0,1fr\)/);
  assert.match(css,/\.ksw-social-messages-shell\.has-active \.ksw-social-conversations-panel\{display:none\}/);
  assert.match(css,/@media\(max-width:760px\)/);
  assert.match(app,/social-ui\.css\?v=20261108-stories2/);
  assert.match(app,/social-ui\.js\?v=20261108-stories2/);
  assert.match(css,/#ksw-social-root\.card\{/);
  assert.match(css,/--social-canvas:#F6EEE9/);
  assert.match(css,/--pri:#96435A/);
  assert.match(css,/html\[data-theme=\"dark\"\] #ksw-social-root\.card/);
});

test('Explorar tem busca compacta, grade 3 colunas, mosaico responsivo e modal acessível', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  assert.match(css,/\.ksw-social-explore-mosaic\{display:grid;grid-template-columns:repeat\(3,minmax\(0,1fr\)\)/);
  assert.match(css,/\.ksw-social-explore-tile\.is-featured\{grid-row:span 2\}/);
  assert.match(css,/\.ksw-social-explore-detail-backdrop\{position:fixed/);
  assert.match(css,/\.ksw-social-explore-detail-dialog/);
  assert.match(css,/@media\(max-width:650px\)/);
  assert.match(ui,/aria-modal=\"true\" aria-label=\"Publicação de/);
  assert.match(ui,/placeholder=\"Buscar confeitarias por nome ou @\"/);
});


test('Stories são um formato separado do feed com validade de 24 horas', () => {
  const css = fs.readFileSync(path.join(root,'public/social-ui.css'),'utf8');
  assert.match(schema,/CREATE TABLE IF NOT EXISTS ksw_social_stories/);
  assert.match(schema,/expires_at DATETIME NOT NULL DEFAULT \(datetime\('now', '\+24 hours'\)\)/);
  assert.match(schema,/CREATE TABLE IF NOT EXISTS ksw_social_story_views/);
  assert.match(routes,/router\.get\('\/stories'/);
  assert.match(routes,/router\.post\('\/stories'/);
  assert.match(routes,/router\.post\('\/stories\/:id\/view'/);
  assert.match(routes,/router\.delete\('\/stories\/:id'/);
  assert.match(routes,/s\.expires_at>CURRENT_TIMESTAMP/);
  assert.match(routes,/storyLimiter/);
  assert.match(routes,/storyImageBelongsToTenant/);
  assert.match(routes,/storyVideoBelongsToTenant/);
  assert.match(routes,/upload-story-image/);
  assert.match(routes,/upload-story-video/);
  assert.match(routes,/cleanupExpiredStories/);
  assert.match(routes,/story-images\/\:tenantId/);
  assert.match(routes,/story-videos\/\:tenantId/);
  assert.match(ui,/function createStory\(/);
  assert.match(ui,/function openComposer\(mode\)/);
  assert.doesNotMatch(ui,/function openComposer\(\)/);
  assert.match(ui,/openComposer\('story'\)/);
  assert.match(ui,/request\(mode==='story'\?'\/stories':'\/posts'/);
  assert.match(ui,/mode==='story'\?'\/api\/social\/upload-story-image'/);
  assert.match(ui,/mode==='story'\?'\/api\/social\/upload-story-video'/);
  assert.match(ui,/function storyViewerModal\(/);
  assert.match(ui,/function showStory\(/);
  assert.match(ui,/function nextStory\(/);
  assert.match(ui,/function removeStory\(/);
  assert.match(ui,/storyViewerModal\(\)/);
  assert.match(ui,/loadStories\(\)/);
  assert.match(css,/\.ksw-social-story-viewer-backdrop/);
  assert.match(css,/\.ksw-social-story-media-stage/);
  assert.match(css,/\.ksw-social-story-progress-segment/);
});


test('API da Comunidade é montada antes dos arquivos estáticos e oferece diagnóstico de versão', () => {
  const mount = server.indexOf("app.use('/api/social'");
  const statics = server.indexOf("app.use(express.static");
  assert.ok(mount >= 0 && statics >= 0 && mount < statics, 'a API social deve vir antes do middleware estático');
  assert.match(routes, /router\.get\('\/health'/);
  assert.match(routes, /api_version: '2026-11-08-stories2'/);
  assert.match(ui, /request\('\/health'\)/);
  assert.match(ui, /O servidor da Comunidade não está disponível neste ambiente/);
  assert.match(ui, /Para testar localmente/);
  assert.match(ui, /http:\/\/localhost:3000\/api\/social\/health/);
  assert.match(ui, /error\.endpoint=endpoint/);
  assert.match(app, /social-ui\.js\?v=20261108-stories2/);
});
