'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const production = require('../public/production-engine');

const ingredients = [
  { id: 'flour', nome: 'Farinha', un: 'kg', preco: 8.5, est: 10 },
  { id: 'egg', nome: 'Ovos', un: 'un', preco: 0.8, est: 100 }
];
const packagings = [
  { id: 'box', nome: 'Caixa', un: 'un', preco: 1.25, est: 100 }
];

const product = {
  id: 'cake', nome: 'Bolo', rend: 10, preco: 35, custo_unitario: 12.5,
  itens: [
    { ing: 'flour', qtd: 1, un: 'kg' },
    { ing: 'egg', qtd: 4, un: 'un' }
  ],
  embalagem_id: 'box', embalagem_qtd: 1
};

test('planeja produção em lotes inteiros e arredonda para cima', () => {
  const plan = production.buildProductionPlan(product, 15, ingredients, packagings);
  assert.equal(plan.valid, true);
  assert.equal(plan.batches, 2);
  assert.equal(plan.requested_quantity, 15);
  assert.equal(plan.produced_quantity, 20);
  assert.deepEqual(plan.materials.map((item) => item.quantity), [2, 8]);
  assert.equal(plan.packaging.quantity, 20);
});

test('recusa quantidade inválida e ficha sem ingredientes', () => {
  assert.equal(production.buildProductionPlan(product, 0, ingredients, packagings).valid, false);
  assert.equal(production.buildProductionPlan({ ...product, itens: [] }, 5, ingredients, packagings).valid, false);
});

test('embalagem vinculada deve existir e possuir quantidade por unidade', () => {
  const missing = production.buildProductionPlan({ ...product, embalagem_id: 'missing' }, 5, ingredients, packagings);
  assert.equal(missing.valid, false);
  const noQty = production.buildProductionPlan({ ...product, embalagem_qtd: 0 }, 5, ingredients, packagings);
  assert.equal(noQty.valid, false);
});

test('FEFO consome primeiro o lote válido com vencimento mais próximo', () => {
  const lots = [
    { id: 'late', quantidade_disponivel: 4, validade: '2027-02-01', recebido_em: '2026-10-01' },
    { id: 'early', quantidade_disponivel: 3, validade: '2026-12-01', recebido_em: '2026-10-10' },
    { id: 'expired', quantidade_disponivel: 5, validade: '2026-10-01' }
  ];
  const plan = production.planLotConsumption(lots, 12, 5, '2026-11-05');
  assert.equal(plan.valid, true);
  assert.deepEqual(plan.lot_updates.map((entry) => entry.id), ['early', 'late']);
  assert.deepEqual(plan.lot_updates.map((entry) => entry.consumed), [3, 2]);
  assert.equal(plan.legacy_used, 0);
});

test('lotes vencidos não podem ser consumidos, mesmo quando aparecem no saldo', () => {
  const lots = [{ id: 'expired', quantidade_disponivel: 5, validade: '2026-11-04' }];
  const plan = production.planLotConsumption(lots, 5, 1, '2026-11-05');
  assert.equal(plan.valid, false);
  assert.match(plan.error, /Estoque válido insuficiente/);
});

test('estoque legado sem lote continua disponível para compatibilidade', () => {
  const plan = production.planLotConsumption([], 7, 2.5, '2026-11-05');
  assert.equal(plan.valid, true);
  assert.equal(plan.legacy_used, 2.5);
  assert.equal(plan.stock_after, 4.5);
});

test('consumo não permite saldo negativo ou quantidade zero', () => {
  assert.equal(production.planLotConsumption([], 2, 3, '2026-11-05').valid, false);
  assert.equal(production.planLotConsumption([], 2, 0, '2026-11-05').valid, false);
});


test('agrupa linhas repetidas do mesmo produto em um pedido', () => {
  const grouped = production.aggregateOrderItems([
    { pid: 'cake', q: 4 },
    { pid: 'brownie', q: 2 },
    { pid: 'cake', q: '3,5' },
    { pid: '', q: 99 },
    { pid: 'invalid', q: 0 }
  ]);
  assert.deepEqual(grouped, [
    { pid: 'cake', q: 7.5 },
    { pid: 'brownie', q: 2 }
  ]);
});

test('custo de consumo usa o preço dos lotes efetivamente baixados', () => {
  const lots = [
    { id: 'old', custo_unitario: 8.5 },
    { id: 'new', custo_unitario: 12 }
  ];
  const allocation = {
    valid: true,
    legacy_used: 1,
    lot_updates: [
      { id: 'old', consumed: 2 },
      { id: 'new', consumed: 1.5 }
    ]
  };
  assert.equal(production.estimateConsumptionCost(allocation, lots, 10), 45);
});

test('custo de consumo rejeita alocação inválida', () => {
  assert.equal(Number.isNaN(production.estimateConsumptionCost({ valid: false }, [], 10)), true);
});


test('quantidade efetivamente produzida é validada contra o lote planejado', () => {
  assert.deepEqual(production.validateProducedQuantity('17', 20), { valid: true, quantity: 17, usedDefault: false });
  assert.deepEqual(production.validateProducedQuantity('', 20), { valid: true, quantity: 20, usedDefault: true });
  assert.equal(production.validateProducedQuantity('0', 20).valid, false);
  assert.equal(production.validateProducedQuantity('21', 20).valid, false);
  assert.equal(production.validateProducedQuantity('abc', 20).valid, false);
});

test('calcula materiais em falta para pedidos e produções sem duplicar ordens vinculadas', () => {
  const result = production.calculateDemandShortages({
    orders: [{ id: 'order-1', st: 'confirmado', itens: [{ pid: 'cake', q: 15 }] }],
    productions: [],
    products: [product],
    ingredients: [
      { id: 'flour', nome: 'Farinha', un: 'kg', preco: 8.5, est: 1 },
      { id: 'egg', nome: 'Ovos', un: 'un', preco: 0.8, est: 10 }
    ],
    packagings: [{ id: 'box', nome: 'Caixa', un: 'un', preco: 1.25, est: 3 }],
    lots: []
  }, '2026-11-07');
  assert.equal(result.considered_orders, 1);
  assert.equal(result.demand_count, 1);
  assert.deepEqual(result.shortages.map((entry) => [entry.item_id, entry.required, entry.available, entry.shortage]), [
    ['box', 20, 3, 17],
    ['flour', 2, 1, 1]
  ]);

  const linked = production.calculateDemandShortages({
    orders: [{ id: 'order-1', st: 'confirmado', itens: [{ pid: 'cake', q: 15 }] }],
    productions: [{ id: 'prod-1', pedido_id: 'order-1', produto_id: 'cake', quantidade: 15, status: 'planejada' }],
    products: [product], ingredients, packagings, lots: []
  }, '2026-11-07');
  assert.equal(linked.demand_count, 1);
  assert.equal(linked.considered_orders, 0);
  assert.equal(linked.considered_productions, 1);
});

test('necessidade de materiais desconsidera estoque vencido e respeita saldo legado', () => {
  const result = production.calculateDemandShortages({
    orders: [{ id: 'order-1', st: 'confirmado', itens: [{ pid: 'cake', q: 10 }] }],
    productions: [], products: [product],
    ingredients: [{ id: 'flour', nome: 'Farinha', un: 'kg', preco: 8.5, est: 3 }, { id: 'egg', nome: 'Ovos', un: 'un', preco: 0.8, est: 100 }],
    packagings: [{ id: 'box', nome: 'Caixa', un: 'un', preco: 1.25, est: 0 }],
    lots: [
      { id: 'expired-flour', item_tipo: 'ingrediente', item_id: 'flour', quantidade_disponivel: 2, validade: '2026-11-01' },
      { id: 'valid-flour', item_tipo: 'ingrediente', item_id: 'flour', quantidade_disponivel: 1, validade: '2026-12-01' }
    ]
  }, '2026-11-07');
  const flour = result.items.find((entry) => entry.item_id === 'flour');
  assert.equal(flour.required, 1);
  assert.equal(flour.available, 1);
  assert.equal(flour.shortage, 0);
});

test('não inventa necessidade quando falta ficha técnica ou produto', () => {
  const result = production.calculateDemandShortages({
    orders: [{ id: 'order-1', itens: [{ pid: 'missing', q: 5 }] }],
    productions: [], products: [], ingredients, packagings, lots: []
  }, '2026-11-07');
  assert.equal(result.items.length, 0);
  assert.equal(result.shortages.length, 0);
  assert.equal(result.skipped.length, 1);
  assert.match(result.skipped[0].reason, /não encontrado/i);
});

test('ignora pedidos cancelados ou entregues e produções canceladas ou já consumidas', () => {
  const result = production.calculateDemandShortages({
    orders: [
      { id: 'cancelled', st: 'cancelado', itens: [{ pid: 'cake', q: 10 }] },
      { id: 'delivered', st: 'entregue', itens: [{ pid: 'cake', q: 10 }] }
    ],
    productions: [
      { id: 'cancelled-prod', pedido_id: '', produto_id: 'cake', quantidade: 10, status: 'cancelada' },
      { id: 'done-prod', pedido_id: '', produto_id: 'cake', quantidade: 10, status: 'concluida', consumo_aplicado: true }
    ],
    products: [product], ingredients, packagings, lots: []
  }, '2026-11-07');
  assert.equal(result.demand_count, 0);
  assert.equal(result.items.length, 0);
});

test('lista de compras une pedidos e estoque mínimo sem contar duas vezes', () => {
  const result = production.buildShoppingList({
    orders: [{ id: 'order-1', st: 'confirmado', itens: [{ pid: 'cake', q: 15 }] }],
    productions: [], products: [product],
    ingredients: [
      { id: 'flour', nome: 'Farinha', un: 'kg', preco: 8.5, est: 1, min: 2 },
      { id: 'egg', nome: 'Ovos', un: 'un', preco: 0.8, est: 10, min: 30 },
      { id: 'sugar', nome: 'Açúcar', un: 'kg', preco: 5, est: 10, min: 2 }
    ],
    packagings: [{ id: 'box', nome: 'Caixa', un: 'un', preco: 1.25, est: 3 }],
    lots: []
  }, '2026-11-07');
  const by = Object.fromEntries(result.items.map((row) => [row.item_id, row]));
  // Farinha: pedido exige 2 kg, mínimo 2 kg, saldo 1 kg => comprar 3 kg (e não 1 + 1).
  assert.equal(by.flour.quantity, 3);
  assert.equal(by.flour.reason, 'pedidos');
  assert.equal(by.flour.estimated_cost, 25.5);
  // Ovos: pedido exige 8, mínimo 30, saldo 10 => 28; só o mínimo não cobre sozinho.
  assert.equal(by.egg.quantity, 28);
  // Caixa: 20 necessárias, saldo 3, sem mínimo => 17.
  assert.equal(by.box.quantity, 17);
  assert.equal(by.sugar, undefined);
  assert.equal(result.total_estimated, 25.5 + 22.4 + 21.25);
  assert.equal(result.partial, false);
});

test('lista de compras não transforma preço ausente em zero e ignora lote vencido', () => {
  const result = production.buildShoppingList({
    orders: [], productions: [], products: [],
    ingredients: [{ id: 'cream', nome: 'Creme', un: 'L', est: 5, min: 4 }],
    packagings: [],
    lots: [{ item_tipo: 'ingrediente', item_id: 'cream', quantidade_disponivel: 5, validade: '2026-11-01' }]
  }, '2026-11-07');
  assert.equal(result.items.length, 1);
  assert.equal(result.items[0].available, 0);
  assert.equal(result.items[0].quantity, 4);
  assert.equal(result.items[0].reason, 'minimo');
  assert.equal(result.items[0].estimated_cost, null);
  assert.equal(result.missing_price_count, 1);
  assert.equal(result.total_estimated, 0);
  assert.equal(result.partial, true);
});

test('lista de compras sinaliza produtos sem ficha como parcial', () => {
  const result = production.buildShoppingList({
    orders: [{ id: 'o', st: 'confirmado', itens: [{ pid: 'ghost', q: 3 }] }],
    productions: [], products: [], ingredients: [], packagings: [], lots: []
  }, '2026-11-07');
  assert.equal(result.items.length, 0);
  assert.equal(result.partial, true);
});

test('texto da lista de compras indica itens, custo e total parcial', () => {
  const shopping = production.buildShoppingList({
    orders: [], productions: [], products: [],
    ingredients: [
      { id: 'a', nome: 'Leite', un: 'L', preco: 5, est: 0, min: 2 },
      { id: 'b', nome: 'Creme', un: 'L', est: 0, min: 1 }
    ],
    packagings: [], lots: []
  }, '2026-11-07');
  const text = production.formatShoppingListText(shopping, 'Compras');
  const lines = text.split('\n');
  assert.equal(lines[0], 'Compras');
  assert.match(lines[1], /^• Creme: 1 L \(preço não cadastrado\)$/);
  assert.match(lines[2], /^• Leite: 2 L \(≈ R\$\s10,00\)$/);
  assert.match(lines[3], /^Custo estimado: pelo menos R\$\s10,00$/);
  assert.equal(production.formatShoppingListText({ items: [] }), '');
});
