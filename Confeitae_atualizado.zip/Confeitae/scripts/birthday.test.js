'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const birthdays = require('../public/birthday-engine');

test('aceita aniversário sem ano e normaliza formatos legados', () => {
  assert.deepEqual(birthdays.parse('05/11'), { month: 11, day: 5, value: '11-05' });
  assert.deepEqual(birthdays.parse('11-05'), { month: 11, day: 5, value: '11-05' });
  assert.deepEqual(birthdays.parse('1990-11-05'), { month: 11, day: 5, value: '11-05' });
  assert.equal(birthdays.format('1990-11-05'), '05/11');
  assert.equal(birthdays.parse(''), null);
});

test('rejeita datas inexistentes e permite 29 de fevereiro', () => {
  assert.equal(birthdays.parse('31/04'), null);
  assert.equal(birthdays.parse('29/02/'), null);
  assert.equal(birthdays.parse('29/02').value, '02-29');
  assert.equal(birthdays.parse('1991-02-29'), null);
});

test('calcula aniversários próximos, hoje e a virada do ano', () => {
  assert.deepEqual(birthdays.nextBirthday('05/11', '2026-11-05'), {
    date: '2026-11-05',
    daysUntil: 0,
    year: 2026
  });
  assert.deepEqual(birthdays.nextBirthday('02/01', '2026-12-30'), {
    date: '2027-01-02',
    daysUntil: 3,
    year: 2027
  });
});

test('lista aniversariantes do mês em ordem de dia e lembretes no intervalo solicitado', () => {
  const clients = [
    { id: 'later', nome: 'Bia', nasc: '1995-11-20' },
    { id: 'today', nome: 'Ana', nasc: '05/11' },
    { id: 'tomorrow', nome: 'Dora', nasc: '11-06' },
    { id: 'none', nome: 'Sem data', nasc: '' }
  ];
  assert.deepEqual(birthdays.inMonth(clients, 11, '2026-11-05').map((entry) => entry.client.id), ['today', 'tomorrow', 'later']);
  assert.deepEqual(birthdays.upcoming(clients, '2026-11-05', 1).map((entry) => entry.client.id), ['today', 'tomorrow']);
  assert.equal(birthdays.isToday('1995-11-05', '2026-11-05'), true);
  assert.equal(birthdays.isToday('1995-11-06', '2026-11-05'), false);
});

test('lembrete de 29/02 cai em 01/03 nos anos não bissextos', () => {
  assert.deepEqual(birthdays.nextBirthday('29/02', '2025-02-28'), {
    date: '2025-03-01',
    daysUntil: 1,
    year: 2025
  });
});
