'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { createMysqlPool, checkMysqlServer } = require('../lib/mysql-pool');
const {
  quoteIdentifier,
  normalizeTableMetadata,
  buildForeignKeyDDL,
  buildIndexesDDL,
  validateForeignKeyCompatibility,
  validateIndexWidths,
  topologicalTableOrder,
  normalizeForComparison,
  createDigestAccumulator
} = require('../lib/mysql-migration');

const ROOT = path.resolve(__dirname, '..');
const BATCH_SIZE = 200;

function callbackCall(target, method, ...args) {
  return new Promise((resolve, reject) => {
    target[method](...args, (error, value) => (error ? reject(error) : resolve(value)));
  });
}

function sqliteAll(database, sql, params = []) {
  return new Promise((resolve, reject) => database.all(sql, params, (error, rows) => (error ? reject(error) : resolve(rows || []))));
}

function sqliteGet(database, sql, params = []) {
  return new Promise((resolve, reject) => database.get(sql, params, (error, row) => (error ? reject(error) : resolve(row || null))));
}

async function openReadonlySqlite(sqlite3, sourcePath) {
  const mode = sqlite3.OPEN_READONLY || 1;
  const database = await new Promise((resolve, reject) => {
    const connection = new sqlite3.Database(sourcePath, mode, (error) => error ? reject(error) : resolve(connection));
  });
  await callbackCall(database, 'run', 'BEGIN');
  return database;
}

async function inspectSqlite(database) {
  const integrityRows = await sqliteAll(database, 'PRAGMA integrity_check');
  const integrity = integrityRows.map((row) => row.integrity_check || Object.values(row)[0]).filter(Boolean);
  const foreignKeyErrors = await sqliteAll(database, 'PRAGMA foreign_key_check');
  const tableRows = await sqliteAll(database,
    "SELECT name, sql FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
  );
  const tables = [];

  for (const row of tableRows) {
    const tableName = String(row.name);
    const quoted = quoteIdentifier(tableName);
    const columns = await sqliteAll(database, `PRAGMA table_xinfo(${quoted})`);
    const hiddenColumns = columns.filter((column) => Number(column.hidden || 0) !== 0);
    const indexRows = await sqliteAll(database, `PRAGMA index_list(${quoted})`);
    const indexes = [];
    for (const index of indexRows) {
      const info = await sqliteAll(database, `PRAGMA index_info(${quoteIdentifier(index.name)})`);
      const details = await sqliteAll(database, `PRAGMA index_xinfo(${quoteIdentifier(index.name)})`);
      const indexSql = await sqliteGet(database, 'SELECT sql FROM sqlite_master WHERE type = ? AND name = ?', ['index', index.name]);
      indexes.push({
        name: index.name,
        unique: Number(index.unique) === 1,
        partial: Number(index.partial) === 1,
        createSql: indexSql && indexSql.sql || '',
        collations: details.map((item) => item.coll).filter(Boolean),
        columns: info.map((item) => item.name).filter(Boolean)
      });
    }
    const foreignKeys = await sqliteAll(database, `PRAGMA foreign_key_list(${quoted})`);
    const countRow = await sqliteGet(database, `SELECT COUNT(*) AS total FROM ${quoted}`);
    const table = {
      name: tableName,
      createSql: row.sql || '',
      columns: columns.filter((column) => Number(column.hidden || 0) === 0),
      hiddenColumns,
      indexes,
      foreignKeys,
      count: Number(countRow && countRow.total || 0)
    };
    try {
      if (/^\s*CREATE\s+VIRTUAL\s+TABLE/i.test(table.createSql)) {
        throw new Error(`A tabela ${tableName} é virtual e exige estratégia de migração específica.`);
      }
      if (hiddenColumns.length) {
        throw new Error(`A tabela ${tableName} possui coluna gerada/oculta. Revise a expressão antes da migração.`);
      }
      table.mysql = normalizeTableMetadata(table);
    } catch (error) {
      table.unsupportedMigrationReason = error.message;
    }
    tables.push(table);
  }

  const viewRows = await sqliteAll(database, "SELECT name, sql FROM sqlite_master WHERE type = 'view' ORDER BY name");
  const triggerRows = await sqliteAll(database, "SELECT name, tbl_name, sql FROM sqlite_master WHERE type = 'trigger' ORDER BY name");
  return { integrity, foreignKeyErrors, tables, views: viewRows, triggers: triggerRows };
}

function describeInventory(report) {
  const lines = [];
  lines.push('INVENTÁRIO SQLITE → MYSQL');
  lines.push(`Integridade SQLite: ${report.integrity.join('; ') || 'sem retorno'}`);
  lines.push(`Tabelas: ${report.tables.length}`);
  lines.push(`Violações de chaves estrangeiras: ${report.foreignKeyErrors.length}`);
  lines.push(`Views não migradas automaticamente: ${(report.views || []).length}`);
  lines.push(`Triggers não migradas automaticamente: ${(report.triggers || []).length}`);
  (report.views || []).forEach((view) => lines.push(`  VIEW: ${view.name}`));
  (report.triggers || []).forEach((trigger) => lines.push(`  TRIGGER: ${trigger.name} · tabela: ${trigger.tbl_name}`));
  lines.push('');
  report.tables.forEach((table) => {
    const pk = table.mysql && table.mysql.primaryKey.length ? table.mysql.primaryKey.join(', ') : '(não mapeada / exige revisão)';
    lines.push(`${table.name}: ${table.count} registro(s) · ${table.columns.length} coluna(s) · ${table.indexes.length} índice(s) · ${table.foreignKeys.length} FK(s) · PK: ${pk}`);
    if (table.unsupportedMigrationReason) lines.push(`  BLOQUEIO: ${table.unsupportedMigrationReason}`);
    table.columns.forEach((column) => {
      const mapped = table.mysql && table.mysql.columns.find((item) => item.name === column.name);
      lines.push(`  - ${column.name}: ${column.type || '(sem tipo)'} → ${mapped ? mapped.mysqlType : '(revisão manual)' }${Number(column.notnull) ? ' NOT NULL' : ''}${Number(column.pk) ? ' PK' : ''}`);
    });
  });
  return lines.join('\n');
}

async function validateIndexedTextLengths(database, table) {
  if (!table.mysql) throw new Error(table.unsupportedMigrationReason || `Schema da tabela ${table.name} não foi convertido.`);
  const indexed = new Set();
  table.indexes.forEach((index) => (index.columns || []).forEach((name) => indexed.add(name)));
  table.mysql.primaryKey.forEach((name) => indexed.add(name));
  for (const column of table.columns) {
    if (!indexed.has(column.name) || !/^(TEXT|VARCHAR|CHAR)/i.test(String(column.type || ''))) continue;
    const max = await sqliteGet(database,
      `SELECT COALESCE(MAX(LENGTH(${quoteIdentifier(column.name)})), 0) AS max_length FROM ${quoteIdentifier(table.name)}`
    );
    if (Number(max && max.max_length) > 191) {
      throw new Error(`A coluna indexada ${table.name}.${column.name} contém texto maior que 191 caracteres. Revise o índice antes da migração para não truncar nem alterar unicidade.`);
    }
  }
}

async function mysqlTargetState(connection) {
  const [rows] = await connection.query(
    `SELECT TABLE_NAME, TABLE_TYPE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() ORDER BY TABLE_NAME`
  );
  return rows || [];
}

async function assertEmptyMysqlTarget(connection) {
  const objects = await mysqlTargetState(connection);
  if (objects.length) {
    throw new Error(`O schema MySQL de destino não está vazio (${objects.length} objeto(s)). Use um schema novo e exclusivo para homologação; nada foi sobrescrito.`);
  }
}

function dependencyOrder(report) {
  return topologicalTableOrder(report.tables);
}

async function createMysqlSchema(connection, report) {
  for (const table of report.tables) await connection.query(table.mysql.createTableSql);
}

async function createMysqlForeignKeys(connection, report) {
  // FKs são criadas somente depois da cópia: isso permite preservar referências
  // cíclicas/auto-referenciadas sem desativar a verificação referencial.
  for (const table of report.tables) {
    for (const statement of buildForeignKeyDDL(table)) await connection.query(statement);
  }
}

async function computeSourceDigest(source, table) {
  const accumulator = createDigestAccumulator();
  const names = table.columns.map((column) => column.name);
  const selection = names.map(quoteIdentifier).join(', ');
  const quotedTable = quoteIdentifier(table.name);
  let offset = 0;
  while (true) {
    const rows = await sqliteAll(source, `SELECT ${selection} FROM ${quotedTable} LIMIT ? OFFSET ?`, [BATCH_SIZE, offset]);
    if (!rows.length) break;
    rows.forEach((row) => accumulator.add(table.columns.map((column) => normalizeForComparison(row[column.name], table.mysql.columns.find((item) => item.name === column.name)))));
    offset += rows.length;
  }
  return accumulator.result();
}

async function computeMysqlDigest(connection, table) {
  const accumulator = createDigestAccumulator();
  const quotedTable = quoteIdentifier(table.name);
  const columns = table.columns.map((column) => column.name);
  let offset = 0;
  while (true) {
    const [rows] = await connection.query(`SELECT * FROM ${quotedTable} LIMIT ? OFFSET ?`, [BATCH_SIZE, offset]);
    if (!rows.length) break;
    rows.forEach((row) => accumulator.add(columns.map((name) => normalizeForComparison(row[name], table.mysql.columns.find((item) => item.name === name)))));
    offset += rows.length;
  }
  return accumulator.result();
}

function schemaSqlFromReport(report) {
  const statements = [];
  report.tables.forEach((table) => statements.push(`${table.mysql.createTableSql};`));
  report.tables.forEach((table) => buildForeignKeyDDL(table).forEach((statement) => statements.push(`${statement};`)));
  report.tables.forEach((table) => buildIndexesDDL(table).forEach((statement) => statements.push(`${statement};`)));
  return `-- Schema MySQL 8 gerado a partir do SQLite real. Revise antes de homologar.\n-- Engine: InnoDB | Charset: utf8mb4 | Collation: utf8mb4_0900_bin\n\n${statements.join('\n\n')}\n`;
}

async function copyTable(connection, source, table) {
  const columnNames = table.columns.map((column) => column.name);
  if (!columnNames.length) return 0;
  const selectColumns = columnNames.map(quoteIdentifier).join(', ');
  const primary = table.mysql.primaryKey;
  const orderBy = primary.length
    ? ` ORDER BY ${primary.map(quoteIdentifier).join(', ')}`
    : ' ORDER BY rowid';
  const destination = quoteIdentifier(table.name);
  const columnsSql = columnNames.map(quoteIdentifier).join(', ');
  let offset = 0;
  let copied = 0;

  while (true) {
    const rows = await sqliteAll(source,
      `SELECT ${selectColumns} FROM ${destination}${orderBy} LIMIT ? OFFSET ?`, [BATCH_SIZE, offset]
    );
    if (!rows.length) break;
    const values = [];
    const tuple = `(${columnNames.map(() => '?').join(', ')})`;
    const tuples = rows.map((row) => {
      columnNames.forEach((name) => values.push(row[name] == null ? null : row[name]));
      return tuple;
    }).join(', ');
    await connection.execute(`INSERT INTO ${destination} (${columnsSql}) VALUES ${tuples}`, values);
    copied += rows.length;
    offset += rows.length;
  }
  return copied;
}

function numericSourceColumns(table) {
  return table.columns.filter((column) => /^(INTEGER|INT|REAL|NUMERIC|DECIMAL|FLOAT|DOUBLE)/i.test(String(column.type || '')));
}

async function validateDestination(connection, source, table, copiedCount) {
  const destination = quoteIdentifier(table.name);
  const sourceCount = await sqliteGet(source, `SELECT COUNT(*) AS total FROM ${destination}`);
  const [countRows] = await connection.query(`SELECT COUNT(*) AS total FROM ${destination}`);
  const sourceTotal = Number(sourceCount && sourceCount.total || 0);
  const targetTotal = Number(countRows[0] && countRows[0].total || 0);
  if (sourceTotal !== targetTotal || copiedCount !== targetTotal) {
    throw new Error(`Quantidade de registros divergente na tabela ${table.name}: SQLite=${sourceTotal}, MySQL=${targetTotal}, copiados=${copiedCount}.`);
  }

  for (const column of numericSourceColumns(table)) {
    const name = quoteIdentifier(column.name);
    const sourceSum = await sqliteGet(source, `SELECT SUM(${name}) AS total FROM ${destination}`);
    const [targetSumRows] = await connection.query(`SELECT SUM(${name}) AS total FROM ${destination}`);
    const a = sourceSum && sourceSum.total == null ? 0 : Number(sourceSum && sourceSum.total);
    const b = targetSumRows[0] && targetSumRows[0].total == null ? 0 : Number(targetSumRows[0] && targetSumRows[0].total);
    const tolerance = Math.max(0.00001, Math.abs(a) * 1e-10);
    if (!Number.isFinite(a) || !Number.isFinite(b) || Math.abs(a - b) > tolerance) {
      throw new Error(`Soma numérica divergente em ${table.name}.${column.name}: SQLite=${a}, MySQL=${b}.`);
    }
  }

  // Verificação integral do conteúdo, não apenas contagem/soma/amostra.
  const sourceDigest = await computeSourceDigest(source, table);
  const targetDigest = await computeMysqlDigest(connection, table);
  if (sourceDigest.count !== targetDigest.count || sourceDigest.xor !== targetDigest.xor || sourceDigest.sum !== targetDigest.sum) {
    throw new Error(`Digest integral divergente na tabela ${table.name}. A migração precisa ser investigada; o destino não deve ser promovido.`);
  }

  // Amostra legível adicional nas extremidades para facilitar diagnóstico.
  if (sourceTotal > 0 && table.mysql.primaryKey.length) {
    const orderBy = table.mysql.primaryKey.map(quoteIdentifier).join(', ');
    const sourceRows = await sqliteAll(source, `SELECT * FROM ${destination} ORDER BY ${orderBy} LIMIT 1`);
    const targetOrder = table.mysql.primaryKey.map((name) => quoteIdentifier(name)).join(', ');
    const [targetRows] = await connection.query(`SELECT * FROM ${destination} ORDER BY ${targetOrder} LIMIT 1`);
    if (sourceRows.length && targetRows.length) {
      const sourceSample = table.columns.map((column) => normalizeForComparison(sourceRows[0][column.name], table.mysql.columns.find((item) => item.name === column.name)));
      const targetSample = table.columns.map((column) => normalizeForComparison(targetRows[0][column.name], table.mysql.columns.find((item) => item.name === column.name)));
      if (JSON.stringify(sourceSample) !== JSON.stringify(targetSample)) {
        throw new Error(`A amostra inicial divergiu na tabela ${table.name}. Revise tipos e conversões antes de liberar a migração.`);
      }
    }
  }
  return { table: table.name, source: sourceTotal, destination: targetTotal, status: 'OK' };
}

async function run() {
  const args = new Set(process.argv.slice(2));
  const modes = ['--report', '--dry-run', '--execute'].filter((mode) => args.has(mode));
  if (modes.length !== 1) {
    console.log('Uso:\n  node scripts/migrate-sqlite-to-mysql.js --report [--schema-out caminho.sql]\n  node scripts/migrate-sqlite-to-mysql.js --dry-run [--schema-out caminho.sql]\n  CONFIRM_MYSQL_MIGRATION=YES node scripts/migrate-sqlite-to-mysql.js --execute');
    process.exitCode = 2;
    return;
  }

  const mode = modes[0];
  if (mode === '--execute' && process.env.CONFIRM_MYSQL_MIGRATION !== 'YES') {
    throw new Error('Migração bloqueada. Para gravar em um schema MySQL novo, defina CONFIRM_MYSQL_MIGRATION=YES e execute --execute. O app não será apontado para MySQL automaticamente.');
  }

  const sourcePath = path.resolve(process.env.DATABASE_PATH || path.join(ROOT, 'ksw_database.sqlite'));
  if (!fs.existsSync(sourcePath)) throw new Error(`Banco SQLite não encontrado em ${sourcePath}. O ZIP não inclui banco físico; aponte DATABASE_PATH para uma cópia de trabalho do banco atual.`);

  let sqlite3;
  try { sqlite3 = require('sqlite3').verbose(); }
  catch (_) { throw new Error('O driver sqlite3 não está instalado. Execute npm ci no Windows do projeto.'); }

  let source;
  let pool;
  let connection;
  try {
    source = await openReadonlySqlite(sqlite3, sourcePath);
    const report = await inspectSqlite(source);
    if (report.integrity.length !== 1 || !/^ok$/i.test(String(report.integrity[0] || ''))) {
      throw new Error(`A verificação de integridade SQLite falhou: ${report.integrity.join('; ') || 'sem retorno'}`);
    }
    if (report.foreignKeyErrors.length) throw new Error(`O SQLite possui ${report.foreignKeyErrors.length} violação(ões) de chave estrangeira. Corrija-as antes da migração; nenhum dado foi alterado.`);
    if (!report.tables.length) throw new Error('O SQLite não contém tabelas de aplicação para migrar.');
    let order = [];
    if (mode !== '--report') {
      if ((report.views || []).length || (report.triggers || []).length) {
        throw new Error(`Migração bloqueada: há ${(report.views || []).length} view(s) e ${(report.triggers || []).length} trigger(s) SQLite que exigem conversão manual. Use --report para obter o inventário; nenhum dado foi alterado.`);
      }
      const unsupported = report.tables.filter((table) => table.unsupportedMigrationReason);
      if (unsupported.length) {
        throw new Error(`Migração bloqueada por ${unsupported.length} tabela(s) que exigem revisão manual: ${unsupported.map((table) => `${table.name}: ${table.unsupportedMigrationReason}`).join(' | ')}`);
      }
      for (const table of report.tables) await validateIndexedTextLengths(source, table);
      validateForeignKeyCompatibility(report.tables);
      validateIndexWidths(report.tables);
      order = dependencyOrder(report);
      // Constrói todas as instruções antes de conectar/escrever para detectar
      // índices parciais, expressões e ações de FK incompatíveis com InnoDB.
      report.tables.forEach((table) => {
        buildForeignKeyDDL(table);
        buildIndexesDDL(table);
      });
    }

    const schemaOutArg = process.argv.find((argument) => argument.startsWith('--schema-out='));
    const schemaOutIndex = process.argv.indexOf('--schema-out');
    const schemaOutRaw = schemaOutArg ? schemaOutArg.slice('--schema-out='.length) : (schemaOutIndex >= 0 ? process.argv[schemaOutIndex + 1] : '');
    if (schemaOutRaw) {
      const unsupported = report.tables.filter((table) => table.unsupportedMigrationReason);
      if (unsupported.length) throw new Error(`Não foi possível gerar DDL: ${unsupported.map((table) => table.name).join(', ')} exigem revisão manual.`);
      const schemaPath = path.resolve(schemaOutRaw);
      fs.mkdirSync(path.dirname(schemaPath), { recursive: true });
      fs.writeFileSync(schemaPath, schemaSqlFromReport(report), { flag: 'wx', mode: 0o600 });
      console.log(`DDL MySQL gerado (sem dados): ${schemaPath}`);
    }

    if (mode === '--report') {
      console.log(describeInventory(report));
      return;
    }

    pool = createMysqlPool(process.env);
    connection = await pool.getConnection();
    const server = await checkMysqlServer(pool);
    await assertEmptyMysqlTarget(connection);
    console.log(`MySQL validado: ${server.version} · ${server.default_storage_engine} · ${server.character_set_server}`);
    console.log(`Destino vazio: ${process.env.DB_NAME}. Tabelas de origem: ${report.tables.length}. Ordem de cópia: ${order.join(' → ')}`);

    if (mode === '--dry-run') {
      console.log('DRY RUN concluído: nenhuma tabela ou linha foi escrita no MySQL.');
      console.log('Schema, índices, constraints, compatibilidade de tipos e ordem de cópia foram validados em memória; execute --execute somente após revisar o relatório e confirmar que o destino é um schema novo de homologação.');
      return;
    }

    await createMysqlSchema(connection, report);
    await connection.beginTransaction();
    let transactionStarted = true;
    try {
      const copiedByTable = new Map();
      for (const tableName of order) {
        const table = report.tables.find((entry) => entry.name === tableName);
        const copied = await copyTable(connection, source, table);
        copiedByTable.set(tableName, copied);
      }
      await connection.commit();
      transactionStarted = false;
      await createMysqlForeignKeys(connection, report);
      const validations = [];
      for (const table of report.tables) {
        validations.push(await validateDestination(connection, source, table, copiedByTable.get(table.name) || 0));
      }
      for (const table of report.tables) {
        for (const statement of buildIndexesDDL(table)) await connection.query(statement);
      }
      console.log('MIGRAÇÃO PARA SCHEMA DE HOMOLOGAÇÃO CONCLUÍDA.');
      console.table(validations);
      console.log('O banco SQLite de origem permaneceu somente leitura. O servidor KSW continua configurado para SQLite; nenhuma troca de produção foi realizada.');
    } catch (error) {
      if (transactionStarted) {
        try { await connection.rollback(); } catch (_) { /* mantém o erro original */ }
      }
      throw error;
    }
  } finally {
    if (connection) connection.release();
    if (pool) await pool.end();
    if (source) {
      try { await callbackCall(source, 'run', 'ROLLBACK'); } catch (_) { /* conexão READ ONLY será encerrada */ }
      await callbackCall(source, 'close');
    }
  }
}

if (require.main === module) {
  run().catch((error) => {
    console.error('Migração SQLite → MySQL não concluída:', error.message);
    process.exitCode = 1;
  });
}

module.exports = {
  openReadonlySqlite,
  inspectSqlite,
  describeInventory,
  validateIndexedTextLengths,
  mysqlTargetState,
  assertEmptyMysqlTarget,
  dependencyOrder,
  createMysqlSchema,
  createMysqlForeignKeys,
  computeSourceDigest,
  computeMysqlDigest,
  schemaSqlFromReport,
  copyTable,
  validateDestination,
  run
};
