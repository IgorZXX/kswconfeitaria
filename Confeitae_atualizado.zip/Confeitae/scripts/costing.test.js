'use strict';

const path = require('node:path');
const fs = require('node:fs');

const test = require('node:test');
const assert = require('node:assert/strict');
const costing = require('../public/costing');

const ingredients = [
  { id: 'choc', nome: 'Chocolate', un: 'kg', preco: 38.90 },
  { id: 'leite', nome: 'Leite', un: 'L', preco: 7.50 },
  { id: 'lata', nome: 'Leite condensado', un: 'lata', preco: 6.80 },
  { id: 'ovo', nome: 'Ovo', un: 'un', preco: 0.85 }
];


test('calcula mão de obra por unidade a partir do valor da hora e do tempo ativo do lote', () => {
  const result = costing.calculateLaborCostPerUnit(30, 45, 15);
  assert.equal(result.valid, true);
  assert.equal(result.batchCost, 22.5);
  assert.equal(result.costPerUnit, 1.5);
});

test('não calcula mão de obra com hora, tempo ou rendimento inválidos', () => {
  assert.equal(costing.calculateLaborCostPerUnit(0, 45, 15).valid, false);
  assert.equal(costing.calculateLaborCostPerUnit(30, -1, 15).valid, false);
  assert.equal(costing.calculateLaborCostPerUnit(30, 45, 0).valid, false);
});

test('interpreta números no formato brasileiro e internacional', () => {
  assert.equal(costing.parseNumber('1.234,56'), 1234.56);
  assert.equal(costing.parseNumber('1234,56'), 1234.56);
  assert.equal(costing.parseNumber('1234.56'), 1234.56);
  assert.equal(costing.parseNumber(''), Number.NaN);
});

test('converte gramas para quilogramas e mantém o custo correto', () => {
  assert.equal(costing.convertQuantity(250, 'g', 'kg'), 0.25);
  assert.equal(costing.convertQuantity(1.5, 'kg', 'g'), 1500);
  assert.equal(costing.convertQuantity(250, 'g', 'kg') * 38.9, 9.725);
});

test('converte mililitros para litros', () => {
  assert.equal(costing.convertQuantity(250, 'ml', 'L'), 0.25);
  assert.equal(costing.convertQuantity(1.2, 'L', 'ml'), 1200);
});

test('não converte grandezas incompatíveis nem unidades personalizadas distintas', () => {
  assert.equal(costing.convertQuantity(1, 'kg', 'L'), null);
  assert.equal(costing.convertQuantity(2, 'lata', 'un'), null);
  assert.equal(costing.convertQuantity(2, 'pacote', 'caixa'), null);
});

test('unidades de contagem equivalentes podem ser convertidas', () => {
  assert.equal(costing.convertQuantity(12, 'un', 'unidade'), 12);
  assert.equal(costing.convertQuantity(2, 'dúzia', 'dúzia'), 2);
  assert.equal(costing.convertQuantity(1, 'dúzia', 'un'), 12);
  assert.equal(costing.convertQuantity(2, 'dúzia', 'un'), 24);
});

test('ingrediente comprado por dúzia pode ser usado em unidades', () => {
  const result = costing.calculateRecipe({
    rend: 6,
    itens: [{ ing: 'ovos-doze', qtd: 6, un: 'un' }]
  }, [{ id: 'ovos-doze', nome: 'Ovos', un: 'dúzia', preco: 10 }]);
  assert.equal(result.valid, true);
  assert.equal(result.ingredientsBatch, 5);
  assert.ok(Math.abs(result.unitCost - (5 / 6)) < 1e-10);
});

test('calcula custos do lote, por unidade e custos adicionais', () => {
  const result = costing.calculateRecipe({
    rend: 10,
    itens: [{ ing: 'choc', qtd: 250, un: 'g' }],
    emb: 0.30,
    mo: 0.50,
    en: 0.10,
    out: 0.05
  }, ingredients);

  assert.equal(result.valid, true);
  assert.equal(result.ingredientsBatch, 9.725);
  assert.ok(Math.abs(result.ingredientsPerUnit - 0.9725) < 1e-10);
  assert.ok(Math.abs(result.additionsPerUnit - 0.95) < 1e-10);
  assert.ok(Math.abs(result.unitCost - 1.9225) < 1e-10);
  assert.ok(Math.abs(result.batchCost - 19.225) < 1e-10);
});

test('inclui embalagem vinculada no custo e não sugere preço sem quantidade válida', () => {
  const product = {
    rend: 1,
    itens: [{ ing: 'choc', qtd: 100, un: 'g' }],
    emb: 0.1,
    embalagem_id: 'box',
    embalagem_qtd: 2
  };
  const packagings = [{ id: 'box', nome: 'Caixa', preco: '1,25' }];
  const calculated = costing.calculateProductCost(product, ingredients, packagings);
  assert.equal(calculated.valid, true);
  assert.equal(calculated.unitCost, 6.49);
  assert.equal(calculated.additions.packaging, 2.6);
  assert.match(costing.calculateProductCost({ ...product, embalagem_qtd: 0 }, ingredients, packagings).errors[0], /quantidade/i);
  assert.match(costing.calculateProductCost({ ...product, embalagem_id: 'missing' }, ingredients, packagings).errors[0], /não está cadastrada/i);
});

test('receitas antigas sem unidade usam a unidade cadastrada no ingrediente', () => {
  const result = costing.calculateRecipe({
    rend: 10,
    itens: [{ ing: 'lata', qtd: 2 }],
    emb: 0.25
  }, ingredients);
  assert.equal(result.valid, true);
  assert.equal(result.ingredientsBatch, 13.6);
  assert.ok(Math.abs(result.unitCost - 1.61) < 1e-10);
});

test('sinaliza ingrediente inexistente, quantidade zero e rendimento inválido', () => {
  const result = costing.calculateRecipe({
    rend: 0,
    itens: [{ ing: 'ausente', qtd: 0, un: 'g' }]
  }, ingredients);
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((message) => message.includes('rendimento')));
  assert.ok(result.errors.some((message) => message.includes('ingrediente')));
});

test('rejeita quantidade em unidade incompatível e custo adicional negativo', () => {
  const result = costing.calculateRecipe({
    rend: 1,
    itens: [{ ing: 'choc', qtd: 1, un: 'L' }],
    emb: -1
  }, ingredients);
  assert.equal(result.valid, false);
  assert.ok(result.errors.some((message) => message.includes('converter')));
  assert.ok(result.errors.some((message) => message.includes('negativo')));
});

test('sugere preço a partir da margem e limita margem máxima a 90%', () => {
  assert.equal(costing.suggestPrice(10, 50), 20);
  assert.ok(Math.abs(costing.suggestPrice(10, 90) - 100) < 1e-10);
  assert.ok(Math.abs(costing.suggestPrice(10, 95) - 100) < 1e-10);
  assert.equal(costing.suggestPrice(10, -5), 10);
});

test('rejeita margem ausente ou não numérica ao sugerir preço', () => {
  assert.equal(costing.suggestPrice(10, ''), null);
  assert.equal(costing.suggestPrice(10, 'inválida'), null);
  assert.equal(costing.suggestPrice(-1, 50), null);
});

test('calcula lucro e margem real do preço informado', () => {
  const result = costing.analyzePrice(8, 12);
  assert.equal(result.valid, true);
  assert.equal(result.profit, 4);
  assert.ok(Math.abs(result.margin - (100 / 3)) < 1e-10);
  assert.equal(costing.analyzePrice(8, 0).valid, false);
});

test('snapshot da ficha preserva composição e custos calculados', () => {
  const recipe = { rend: 10, itens: [{ ing: 'choc', qtd: 250, un: 'g' }], emb: 0.2 };
  const calculation = costing.calculateRecipe(recipe, ingredients);
  const snapshot = costing.makeSnapshot(recipe, calculation, '2026-11-05T12:00:00.000Z');
  assert.equal(snapshot.version, 3);
  assert.equal(snapshot.calculatedAt, '2026-11-05T12:00:00.000Z');
  assert.equal(snapshot.unitCost, 1.17);
  assert.equal(snapshot.items[0].purchaseQuantity, 0.25);
  assert.equal(snapshot.items[0].purchaseUnit, 'kg');
  assert.equal(snapshot.variableFeeKnown, false);
  assert.equal(snapshot.variableFeePercent, null);
  const knownFeeSnapshot = costing.makeSnapshot({ ...recipe, taxa_venda_pct: 0, taxa_venda_informada: true }, calculation, '2026-11-05T12:00:00.000Z');
  assert.equal(knownFeeSnapshot.variableFeeKnown, true);
  assert.equal(knownFeeSnapshot.variableFeePercent, 0);
});

test('identifica prejuízo unitário e calcula quanto a confeiteira perde no pedido', () => {
  const result = costing.assessProfitability(8, 7.90, {
    quantity: 20,
    targetMargin: 50,
    variableFeePercent: 0
  });
  assert.equal(result.valid, true);
  assert.equal(result.status, 'loss');
  assert.equal(result.lossPerUnit, 0.10);
  assert.equal(result.estimatedLoss, 2);
  assert.equal(result.recommendedPrice, 16);
  assert.match(result.recommendation, /compare fornecedores|reduza perdas/i);
});

test('inclui taxas e impostos percentuais no prejuízo e no preço recomendado', () => {
  const result = costing.assessProfitability(8, 7.90, {
    quantity: 20,
    targetMargin: 50,
    variableFeePercent: 5
  });
  assert.equal(result.valid, true);
  assert.equal(result.status, 'loss');
  assert.equal(result.feeAmountPerUnit, 0.40);
  assert.equal(result.lossPerUnit, 0.50);
  assert.equal(result.estimatedLoss, 9.90);
  assert.equal(result.recommendedPrice, 17.78);
  assert.equal(costing.suggestPrice(8, 50, 5), 8 / 0.45);
});

test('distingue preço de equilíbrio e margem abaixo da meta sem chamar de prejuízo', () => {
  const breakEven = costing.assessProfitability(10, 10, { targetMargin: 40 });
  assert.equal(breakEven.status, 'break_even');
  assert.equal(breakEven.estimatedLoss, 0);

  const belowTarget = costing.assessProfitability(8, 12, {
    targetMargin: 40,
    variableFeePercent: 5
  });
  assert.equal(belowTarget.status, 'below_target');
  assert.equal(belowTarget.profitPerUnit, 3.4);
  assert.ok(belowTarget.margin < 40);
  assert.equal(belowTarget.recommendedPrice, 14.55);
});

test('não inventa perda quando faltam dados e rejeita taxas incompatíveis', () => {
  const missing = costing.assessProfitability('', 10, { quantity: 2 });
  assert.equal(missing.valid, false);
  assert.equal(missing.status, 'insufficient_data');
  assert.equal(missing.estimatedLoss, null);

  const impossible = costing.assessProfitability(8, 7, {
    targetMargin: 50,
    variableFeePercent: 50
  });
  assert.equal(impossible.valid, true);
  assert.equal(impossible.status, 'loss');
  assert.equal(impossible.recommendedPrice, null);
});


test('taxa de venda em branco não é presumida como zero e não gera preço recomendado', () => {
  const result = costing.assessProfitability(8, 12, {
    quantity: 4, targetMargin: 50, variableFeePercent: 0, variableFeeKnown: false
  });
  assert.equal(result.valid, true);
  assert.equal(result.status, 'fees_unknown');
  assert.equal(result.profitPerUnit, 4);
  assert.equal(result.estimatedProfit, 16);
  assert.equal(result.variableFeesIncluded, false);
  assert.equal(result.recommendedPrice, null);
  assert.match(result.recommendation, /antes dessas taxas/i);
});

test('zero só é taxa confirmada quando a confeiteira informou explicitamente', () => {
  assert.equal(costing.hasKnownVariableFee({ taxa_venda_pct: 0 }), false);
  assert.equal(costing.hasKnownVariableFee({ taxa_venda_pct: 0, taxa_venda_informada: true }), true);
  assert.equal(costing.hasKnownVariableFee({ taxa_venda_pct: 5 }), true);
  assert.equal(costing.hasKnownVariableFee({ taxa_venda_pct: 5, taxa_venda_informada: false }), false);
});


test('exemplo prático de lote de brownies calcula perda mínima e perda com taxa', () => {
  const brownieIngredients = [
    { id: 'chocolate', nome: 'Chocolate', un: 'kg', preco: 36 },
    { id: 'farinha', nome: 'Farinha', un: 'kg', preco: 6 },
    { id: 'ovos', nome: 'Ovos', un: 'un', preco: 0.8 },
    { id: 'manteiga', nome: 'Manteiga', un: 'kg', preco: 30 },
    { id: 'acucar', nome: 'Açúcar', un: 'kg', preco: 5 }
  ];
  const recipe = {
    rend: 10,
    itens: [
      { ing: 'chocolate', qtd: 500, un: 'g' },
      { ing: 'farinha', qtd: 300, un: 'g' },
      { ing: 'ovos', qtd: 3, un: 'un' },
      { ing: 'manteiga', qtd: 200, un: 'g' },
      { ing: 'acucar', qtd: 300, un: 'g' }
    ],
    emb: 0.6, mo: 1.5, en: 0.3, out: 0.3
  };
  const calculation = costing.calculateRecipe(recipe, brownieIngredients);
  assert.equal(calculation.valid, true);
  assert.ok(Math.abs(calculation.unitCost - 5.67) < 1e-10);
  const withoutFee = costing.assessProfitability(calculation.unitCost, 5.50, {
    quantity: 20, targetMargin: 30, variableFeePercent: 0, variableFeeKnown: false
  });
  assert.equal(withoutFee.status, 'loss');
  assert.equal(withoutFee.lossPerUnit, 0.17);
  assert.equal(withoutFee.estimatedLoss, 3.4);
  assert.equal(withoutFee.recommendedPrice, null);
  const withFee = costing.assessProfitability(calculation.unitCost, 5.50, {
    quantity: 20, targetMargin: 30, variableFeePercent: 4.99, variableFeeKnown: true
  });
  assert.equal(withFee.status, 'loss');
  assert.equal(withFee.estimatedLoss, 8.89);
  assert.equal(withFee.recommendedPrice, 8.72);
});


test('rateia despesas fixas por unidade e ignora despesas inativas', () => {
  const allocation = costing.calculateFixedCostAllocation([
    { id: 'rent', name: 'Aluguel', monthly_value: '500,00' },
    { id: 'internet', name: 'Internet', monthly_value: '100,00' },
    { id: 'old', name: 'Serviço cancelado', monthly_value: 300, active: false }
  ], 200);
  assert.equal(allocation.valid, true);
  assert.equal(allocation.configured, true);
  assert.equal(allocation.monthlyTotal, 600);
  assert.equal(allocation.costPerUnit, 3);
  assert.equal(allocation.itemCount, 2);
});

test('não calcula rateio fixo com previsão mensal ausente ou inválida', () => {
  const missing = costing.calculateFixedCostAllocation([
    { name: 'Aluguel', monthly_value: 500 }
  ], '');
  assert.equal(missing.valid, false);
  assert.equal(missing.costPerUnit, null);
  assert.match(missing.errors.join(' '), /quantas unidades/i);

  const invalid = costing.calculateFixedCostAllocation([
    { name: 'Internet', monthly_value: 'não sei' }
  ], 100);
  assert.equal(invalid.valid, false);
  assert.equal(invalid.costPerUnit, null);
  assert.match(invalid.errors.join(' '), /valor mensal válido/i);
});

test('inclui rateio confirmado no resultado, na perda total e no preço recomendado', () => {
  const result = costing.assessProfitability(7, 9, {
    quantity: 10,
    targetMargin: 30,
    variableFeePercent: 0,
    variableFeeKnown: true,
    fixedCostPerUnit: 3,
    fixedCostKnown: true
  });
  assert.equal(result.status, 'loss');
  assert.equal(result.directProfitPerUnit, 2);
  assert.equal(result.fullyLoadedCostPerUnit, 10);
  assert.equal(result.lossPerUnit, 1);
  assert.equal(result.estimatedLoss, 10);
  assert.equal(result.recommendedPrice, 14.29);
  assert.equal(result.fixedCostsIncluded, true);
});

test('não presume despesas fixas zeradas quando o rateio ainda é desconhecido', () => {
  const result = costing.assessProfitability(7, 9, {
    quantity: 10,
    targetMargin: 30,
    variableFeePercent: 0,
    variableFeeKnown: true,
    fixedCostKnown: false
  });
  assert.equal(result.status, 'fixed_costs_unknown');
  assert.equal(result.estimatedProfit, 20);
  assert.equal(result.recommendedPrice, null);
  assert.equal(result.fixedCostsIncluded, false);
  assert.match(result.recommendation, /Financeiro > Custos fixos/i);
});

test('prejuízo mínimo continua explícito quando despesas ou taxas não estão completas', () => {
  const result = costing.assessProfitability(8, 7.5, {
    quantity: 12,
    targetMargin: 40,
    variableFeeKnown: false,
    fixedCostKnown: false
  });
  assert.equal(result.status, 'loss');
  assert.equal(result.estimatedLoss, 6);
  assert.equal(result.recommendedPrice, null);
  assert.match(result.recommendation, /perda exibida é mínima/i);
  assert.match(result.recommendation, /taxas de venda/i);
  assert.match(result.recommendation, /rateio das despesas fixas/i);
});


test('fixed-cost estimate uses recent order history without requiring manual arithmetic', () => {
  const source = fs.readFileSync(path.join(__dirname, '..', 'public', 'gestao.js'), 'utf8');
  assert.match(source, /function estimateMonthlyUnitsFromOrders\(\)/);
  assert.match(source, /order\.st === 'cancelado'/);
  assert.match(source, /orderCount < 3/);
  assert.match(source, /observedDays < 14/);
  assert.match(source, /estimate\.units/);
  assert.match(source, /Estimativa automática baseada em/);
});
