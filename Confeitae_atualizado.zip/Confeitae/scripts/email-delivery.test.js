'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { isEmailDeliveryConfigured, sendVerificationEmail } = require('../lib/email-delivery');

const originalEnv = {
  RESEND_API_KEY: process.env.RESEND_API_KEY,
  EMAIL_FROM: process.env.EMAIL_FROM
};
const originalFetch = global.fetch;

test('exige API key e remetente configurados para enviar e-mail', async () => {
  delete process.env.RESEND_API_KEY;
  delete process.env.EMAIL_FROM;
  assert.equal(isEmailDeliveryConfigured(), false);
  await assert.rejects(() => sendVerificationEmail({
    to: 'pessoa@example.com', name: 'Pessoa', verificationUrl: 'https://ksw.example/verify'
  }), (error) => error.code === 'EMAIL_NOT_CONFIGURED');
});

test('envia mensagem de confirmação com conteúdo escapado e formato texto/HTML', async () => {
  let captured;
  process.env.RESEND_API_KEY = 're_' + 'x'.repeat(32);
  process.env.EMAIL_FROM = 'Confeitaê <no-reply@ksw.example>';
  global.fetch = async (url, options) => {
    captured = { url, options, body: JSON.parse(options.body) };
    return { ok: true, status: 200, json: async () => ({ id: 'resend_message_123' }) };
  };
  try {
    assert.equal(isEmailDeliveryConfigured(), true);
    const sent = await sendVerificationEmail({
      to: 'Pessoa@Example.com',
      name: '<Pessoa & Cia>',
      verificationUrl: 'https://ksw.example/api/auth/verify-email?token=abc'
    });
    assert.equal(sent.id, 'resend_message_123');
    assert.equal(captured.url, 'https://api.resend.com/emails');
    assert.equal(captured.options.headers.Authorization, `Bearer ${process.env.RESEND_API_KEY}`);
    assert.ok(captured.options.headers['Idempotency-Key'].startsWith('ksw-'));
    assert.deepEqual(captured.body.to, ['pessoa@example.com']);
    assert.match(captured.body.html, /&lt;Pessoa &amp; Cia&gt;/);
    assert.match(captured.body.text, /https:\/\/ksw\.example\/api\/auth\/verify-email/);
    assert.equal(captured.body.subject, 'Confirme seu e-mail — Confeitaê');
  } finally {
    global.fetch = originalFetch;
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
});


test('não considera aceito um envio sem ID de mensagem válido do Resend', async () => {
  process.env.RESEND_API_KEY = 're_' + 'x'.repeat(32);
  process.env.EMAIL_FROM = 'Confeitaê <no-reply@ksw.example>';
  global.fetch = async () => ({ ok: true, status: 200, json: async () => ({}) });
  try {
    await assert.rejects(() => sendVerificationEmail({
      to: 'pessoa@example.com', name: 'Pessoa', verificationUrl: 'https://ksw.example/verify?token=abc'
    }), (error) => error.code === 'EMAIL_PROVIDER_INVALID_RESPONSE');
  } finally {
    global.fetch = originalFetch;
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
});

test('normaliza falha HTTP do Resend sem expor detalhes do provedor ao cliente', async () => {
  process.env.RESEND_API_KEY = 're_' + 'x'.repeat(32);
  process.env.EMAIL_FROM = 'Confeitaê <no-reply@ksw.example>';
  global.fetch = async () => ({ ok: false, status: 422, json: async () => ({ message: 'invalid recipient' }) });
  try {
    await assert.rejects(() => sendVerificationEmail({
      to: 'pessoa@example.com', name: 'Pessoa', verificationUrl: 'https://ksw.example/verify?token=abc'
    }), (error) => {
      assert.equal(error.code, 'EMAIL_PROVIDER_ERROR');
      assert.equal(error.providerStatus, 422);
      assert.equal(error.providerMessage, 'invalid recipient');
      assert.ok(!error.message.includes('invalid recipient'));
      return true;
    });
  } finally {
    global.fetch = originalFetch;
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
});

test('normaliza indisponibilidade de rede sem revelar credenciais', async () => {
  process.env.RESEND_API_KEY = 're_' + 'x'.repeat(32);
  process.env.EMAIL_FROM = 'Confeitaê <no-reply@ksw.example>';
  global.fetch = async () => { throw new Error('socket secret detail'); };
  try {
    await assert.rejects(() => sendVerificationEmail({
      to: 'pessoa@example.com', name: 'Pessoa', verificationUrl: 'https://ksw.example/verify?token=abc'
    }), (error) => {
      assert.equal(error.code, 'EMAIL_PROVIDER_UNAVAILABLE');
      assert.ok(!error.message.includes('socket secret detail'));
      return true;
    });
  } finally {
    global.fetch = originalFetch;
    for (const [key, value] of Object.entries(originalEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
  }
});
