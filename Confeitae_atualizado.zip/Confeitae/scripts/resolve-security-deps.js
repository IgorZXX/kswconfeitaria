'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const {
  computeFingerprint,
  writeFingerprintMarker,
} = require('./security-skill-fingerprint');

const root = path.resolve(__dirname, '..');
const canonicalRel = '.agents/skills/ksw-security/SKILL.md';
const mirrorRel = '.claude/skills/ksw-security/SKILL.md';
const canonical = path.join(root, canonicalRel);
const mirror = path.join(root, mirrorRel);
const historyHeading = '### Histórico de atualização da skill';

function compareVersions(a, b) {
  const left = String(a).split('.').map((part) => Number.parseInt(part, 10) || 0);
  const right = String(b).split('.').map((part) => Number.parseInt(part, 10) || 0);
  for (let i = 0; i < 3; i += 1) {
    const delta = (left[i] || 0) - (right[i] || 0);
    if (delta !== 0) return delta;
  }
  return 0;
}

function packageInstances(lock, packageName) {
  const suffix = `/node_modules/${packageName}`;
  return Object.entries(lock.packages || {})
    .filter(([location]) => location === `node_modules/${packageName}` || location.endsWith(suffix))
    .map(([location, metadata]) => ({ location, version: metadata.version }));
}

function validateLock(lock) {
  const requirements = [
    ['tar', '7.5.21'],
    ['@tootallnate/once', '2.0.1'],
    ['uuid', '11.1.1'],
  ];

  for (const [name, minimum] of requirements) {
    const instances = packageInstances(lock, name);
    if (!instances.length) throw new Error(`O lockfile não contém a dependência esperada: ${name}.`);
    const vulnerable = instances.filter((item) => compareVersions(item.version, minimum) < 0);
    if (vulnerable.length) {
      throw new Error(`${name} ainda possui versões abaixo de ${minimum}: ${vulnerable.map((item) => `${item.location}=${item.version}`).join(', ')}`);
    }
  }

  const minimatch = packageInstances(lock, 'minimatch');
  const vulnerableMinimatch = minimatch.filter(({ version }) => {
    const major = Number.parseInt(String(version).split('.')[0], 10);
    return major >= 7 && compareVersions(version, '11.0.1') < 0;
  });
  if (vulnerableMinimatch.length) {
    throw new Error(`minimatch ainda possui versões vulneráveis: ${vulnerableMinimatch.map((item) => `${item.location}=${item.version}`).join(', ')}`);
  }
  if (!minimatch.some(({ version }) => compareVersions(version, '11.0.1') >= 0)) {
    throw new Error('O lockfile não contém minimatch corrigido (11.0.1 ou superior).');
  }
}

function updateSkillHistory() {
  if (!fs.existsSync(canonical)) throw new Error(`Skill canônica ausente: ${canonicalRel}`);
  let content = fs.readFileSync(canonical, 'utf8');
  if (!content.includes(historyHeading)) throw new Error('A seção de histórico da skill não foi encontrada.');

  // Remove um caractere solto que já existia entre o fingerprint e o frontmatter YAML.
  content = content.replace(/^(<!-- KSW_PROJECT_FINGERPRINT: sha256:[a-f0-9]{64} -->)\na\n/m, '$1\n');

  const date = new Date().toISOString().slice(0, 10);
  const inline = (value) => String.fromCharCode(96) + value + String.fromCharCode(96);
  const entry = `\n- **${date} — Mitigação de dependências transitivas vulneráveis:** revisados ${inline('package.json')}, ${inline('package-lock.json')}, ${inline('scripts/security-skill-fingerprint.js')} e o mecanismo de guard. Adicionados overrides limitados para ${inline('tar')} (7.5.22), ${inline('minimatch')} (11.0.1 sob Nodemon), ${inline('@tootallnate/once')} (2.0.1 sob http-proxy-agent) e ${inline('uuid')} (11.1.1 sob Mercado Pago), evitando atualizar as versões principais de ${inline('sqlite3')}, ${inline('mercadopago')} e ${inline('nodemon')}. O script ${inline('scripts/resolve-security-deps.js')} regenera o lockfile, confirma as versões mínimas corrigidas e registra novamente a impressão digital nas duas cópias da skill. Impacto: cadeia de fornecimento/dependências (OWASP A06); sem mudança em rotas, autenticação, autorização, isolamento de contas, pagamentos, schema, segredos ou dados da aplicação. O override de ${inline('tar')} substitui uma dependência transitiva usada pelo ferramental de instalação; compatibilidade precisa ser confirmada pelo ${inline('npm ci')} em Windows. Evidências nesta revisão: validação estática do script e do manifesto; validação do lockfile ocorre ao executar ${inline('npm run security:deps:resolve')}. ${inline('npm audit')}, instalação nativa de SQLite e suíte completa ainda dependem da execução no Windows com acesso ao registry; A06 permanece NÃO VERIFICADO até a auditoria pós-instalação.\n`;

  const pending = /^- \*\*[^\n]*PENDENTE DE REVISÃO DA IA[^\n]*\n?/m;
  if (pending.test(content)) content = content.replace(pending, entry.trimStart());
  else content = content.replace(historyHeading, `${historyHeading}${entry}`);

  const fingerprint = computeFingerprint(root);
  content = writeFingerprintMarker(content, fingerprint);
  fs.writeFileSync(canonical, content, 'utf8');
  fs.mkdirSync(path.dirname(mirror), { recursive: true });
  fs.writeFileSync(mirror, content, 'utf8');
  return fingerprint;
}

function main() {
  const npmCommand = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const install = spawnSync(npmCommand, [
    'install', '--package-lock-only', '--ignore-scripts', '--no-audit', '--no-fund',
  ], {
    cwd: root,
    stdio: 'inherit',
    shell: process.platform === 'win32',
  });

  if (install.error) throw install.error;
  if (install.status !== 0) throw new Error(`npm install --package-lock-only terminou com código ${install.status}.`);

  const lockPath = path.join(root, 'package-lock.json');
  if (!fs.existsSync(lockPath)) throw new Error('package-lock.json não foi gerado.');
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  validateLock(lock);

  const fingerprint = updateSkillHistory();
  const guard = spawnSync(process.execPath, [path.join(root, 'scripts/check-security-skill-sync.js'), '--guard'], {
    cwd: root,
    stdio: 'inherit',
  });
  if (guard.error) throw guard.error;
  if (guard.status !== 0) throw new Error('O guard da skill não passou após a atualização.');

  console.log('\nLockfile atualizado e dependências vulneráveis verificadas nas versões corrigidas.');
  console.log(`Fingerprint atualizado: ${fingerprint}`);
  console.log('Próximos passos: npm ci --include=dev ; npm audit ; npm test');
}

try {
  main();
} catch (error) {
  console.error(`ERRO: ${error.message}`);
  process.exitCode = 1;
}
