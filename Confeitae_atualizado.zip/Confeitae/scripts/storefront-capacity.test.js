'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const capacity = require('../lib/storefront-capacity');

function row(date, status, quantities) {
  return {
    data_entrega: date,
    status,
    data: JSON.stringify({
      st: status,
      ent: date,
      itens: quantities.map((quantity) => ({ q: quantity }))
    })
  };
}

test('normaliza limites diários e trata zero/valores inválidos como sem limite', () => {
  assert.deepEqual(capacity.normalizeCapacity({ cap_pedidos: '3', cap_unid: '25.8' }), {
    max_orders_per_day: 3,
    max_units_per_day: 25
  });
  assert.deepEqual(capacity.normalizeCapacity({ cap_pedidos: -1, cap_unid: 'abc' }), {
    max_orders_per_day: 0,
    max_units_per_day: 0
  });
});

test('permite pedido dentro da capacidade', () => {
  const result = capacity.checkDailyCapacity(
    [row('2026-11-10', 'recebido', [2, 1])],
    { cap_pedidos: 3, cap_unid: 10 },
    [{ quantity: 4 }]
  );
  assert.equal(result.ok, true);
  assert.equal(result.current.orders, 1);
  assert.equal(result.current.units, 3);
  assert.equal(result.requested_units, 4);
});

test('bloqueia encomenda que ultrapassa quantidade máxima de pedidos', () => {
  const result = capacity.checkDailyCapacity(
    [row('2026-11-10', 'confirmado', [1]), row('2026-11-10', 'recebido', [2])],
    { cap_pedidos: 2, cap_unid: 0 },
    [{ quantity: 1 }]
  );
  assert.equal(result.ok, false);
  assert.equal(result.status, 409);
  assert.match(result.error, /2 pedido/);
});

test('bloqueia encomenda que ultrapassa quantidade máxima de unidades', () => {
  const result = capacity.checkDailyCapacity(
    [row('2026-11-10', 'recebido', [4, 3])],
    { cap_pedidos: 0, cap_unid: 8 },
    [{ quantity: 2 }]
  );
  assert.equal(result.ok, false);
  assert.match(result.error, /8 unidade/);
});

test('pedidos cancelados não consomem capacidade', () => {
  const result = capacity.checkDailyCapacity(
    [row('2026-11-10', 'cancelado', [10])],
    { cap_pedidos: 1, cap_unid: 5 },
    [{ quantity: 5 }]
  );
  assert.equal(result.ok, true);
});

test('identifica datas já esgotadas sem expor dados dos pedidos', () => {
  const dates = capacity.buildUnavailableDates([
    row('2026-11-10', 'recebido', [2]),
    row('2026-11-10', 'confirmado', [3]),
    row('2026-11-11', 'recebido', [9]),
    row('2026-11-12', 'cancelado', [100])
  ], { cap_pedidos: 2, cap_unid: 10 });
  assert.deepEqual(dates, ['2026-11-10']);
});

test('sem limites configurados não marca datas como indisponíveis', () => {
  assert.deepEqual(capacity.buildUnavailableDates([
    row('2026-11-10', 'recebido', [500])
  ], { cap_pedidos: 0, cap_unid: 0 }), []);
});

test('usa unidades estimadas de orçamentos aprovados sem multiplicar o valor da encomenda', () => {
  const order = { itens: [{ q: 1, pu: 325.5 }], unidades_estimadas: 12 };
  assert.equal(capacity.orderUnits(order), 12);
  assert.equal(capacity.summarizeDay([{ data: JSON.stringify(order), status: 'recebido' }]).units, 12);
});
