'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  allPlanFeatures, normalizePlanFeatures, generateFeatureDescription,
  parsePlanFeatures, hasPlanFeature, slugFeature
} = require('../lib/plan-features');

test('catálogo tem recursos reconhecidos e gestão de equipe', () => {
  const features = allPlanFeatures();
  assert.ok(features.some((feature) => feature.key === 'team'));
  assert.ok(features.some((feature) => feature.key === 'financial'));
});

test('descrição de funcionalidade personalizada é gerada automaticamente e sem HTML', () => {
  const description = generateFeatureDescription('  Integração com fornecedores! ');
  assert.match(description, /integração com fornecedores/i);
  assert.doesNotMatch(description, /<script/i);
});

test('normaliza, limita, remove duplicatas e cria slug estável', () => {
  const features = normalizePlanFeatures([
    { label: 'Integração com fornecedores' },
    { label: 'Integração com fornecedores' },
    'team',
    { key: 'danger', label: '<script>alert(1)</script>' }
  ]);
  assert.equal(features.length, 3);
  assert.equal(features[0].key, 'integracao-com-fornecedores');
  assert.ok(features[0].description.length > 30);
  assert.equal(slugFeature('  Açúcar & Café  '), 'acucar-cafe');
  assert.equal(hasPlanFeature(features, 'team'), true);
});

test('mantém chaves com underscore e normaliza chaves legadas com hífen', () => {
  const parsed = parsePlanFeatures(JSON.stringify([
    { key: 'digital-menu', label: 'Cardápio digital' },
    { key: 'admin-chat', label: 'Chat com administração' }
  ]));
  assert.equal(hasPlanFeature(parsed, 'digital_menu'), true);
  assert.equal(hasPlanFeature(parsed, 'admin_chat'), true);
  assert.equal(normalizePlanFeatures([{ key: 'admin_chat' }])[0].key, 'admin_chat');
});

test('parsePlanFeatures protege contra JSON inválido', () => {
  assert.deepEqual(parsePlanFeatures('{bad json'), []);
  assert.equal(parsePlanFeatures(JSON.stringify([{ label: 'Agendamento VIP' }]))[0].key, 'agendamento-vip');
});
