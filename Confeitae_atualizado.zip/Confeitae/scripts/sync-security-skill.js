'use strict';

const fs = require('node:fs');
const path = require('node:path');
const {
  computeFingerprint,
  readFingerprintMarker,
  writeFingerprintMarker,
} = require('./security-skill-fingerprint');

const root = path.resolve(__dirname, '..');
const canonical = path.join(root, '.agents', 'skills', 'ksw-security', 'SKILL.md');
const mirror = path.join(root, '.claude', 'skills', 'ksw-security', 'SKILL.md');
const historyHeading = '### Histórico de atualização da skill';
const pendingEntryPattern = /^- \*\*[^\n]*PENDENTE DE REVISÃO DA IA[^\n]*$/m;

if (!fs.existsSync(canonical)) {
  console.error(`Skill canônica não encontrada: ${path.relative(root, canonical)}`);
  process.exit(1);
}

let content = fs.readFileSync(canonical, 'utf8');
if (!content.includes('## Atualização obrigatória após toda modificação do projeto')) {
  console.error('A skill canônica não contém o protocolo obrigatório de atualização.');
  process.exit(1);
}

const previousFingerprint = readFingerprintMarker(content);
const fingerprint = computeFingerprint(root);

// Ao detectar arquivos de projeto modificados desde a última sincronização,
// exige que o agente registre o impacto real antes de a validação ser aprovada.
if (previousFingerprint && previousFingerprint !== fingerprint && !pendingEntryPattern.test(content)) {
  if (!content.includes(historyHeading)) {
    console.error('A seção de histórico não foi encontrada na skill canônica.');
    process.exit(1);
  }
  const date = new Date().toISOString().slice(0, 10);
  const pendingEntry = `\n- **${date} — PENDENTE DE REVISÃO DA IA:** a impressão digital do projeto mudou para \`${fingerprint.slice(0, 12)}\`. Revise os arquivos alterados, descreva nesta linha os impactos reais de segurança, módulos/controles afetados e testes executados; não deixe esta nota genérica.\n`;
  content = content.replace(historyHeading, `${historyHeading}${pendingEntry}`);
  console.log('Foi criada uma revisão pendente no histórico. O agente deve substituí-la por um resumo real antes de validar.');
}

content = writeFingerprintMarker(content, fingerprint);
fs.writeFileSync(canonical, content, 'utf8');
fs.mkdirSync(path.dirname(mirror), { recursive: true });
fs.writeFileSync(mirror, content, 'utf8');

console.log('Skill sincronizada: .agents/skills/ksw-security/SKILL.md -> .claude/skills/ksw-security/SKILL.md');
console.log(`SHA-256 do projeto: ${fingerprint}`);
