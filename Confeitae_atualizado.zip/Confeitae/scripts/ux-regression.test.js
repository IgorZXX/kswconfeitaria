'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('public/index.html');
const css = read('public/ksw-home.css');
const scrollEffects = read('public/ksw-scroll-effects.js');
const gestao = read('public/gestao.js');
const productionUi = read('public/production-ui.js');
const productionRoute = read('routes/production.js');
const analytics = read('public/analytics-engine.js');
const costing = read('public/costing.js');
const resources = read('public/recursos.js');
const birthdayEngine = read('public/birthday-engine.js');
const storefrontPublic = read('public/storefront-public.js');
const storefrontRoute = read('routes/storefront.js');

test('menu principal usa grupos e não deixa planos/resultados/mais recursos como entradas soltas', () => {
  const tabsBlock = html.match(/var TABS=\[([\s\S]*?)\n\];/);
  const groupsBlock = html.match(/var NAV_GROUPS=\[([\s\S]*?)\n\];/);
  assert.ok(tabsBlock && groupsBlock);
  assert.match(groupsBlock[1], /DIA A DIA/);
  assert.match(groupsBlock[1], /CADASTROS/);
  assert.match(groupsBlock[1], /DINHEIRO/);
  assert.match(groupsBlock[1], /EMPRESA/);
  assert.doesNotMatch(tabsBlock[1], /\['planos'/);
  assert.doesNotMatch(tabsBlock[1], /\['resultados'/);
  assert.doesNotMatch(tabsBlock[1], /\['recursos'/);
  assert.match(groupsBlock[1], /'tarefas'/);
  assert.match(groupsBlock[1], /'alertas'/);
});

test('Resultados e Orçamentos são subáreas de Financeiro e Pedidos', () => {
  assert.match(html, /if\(t==='resultados'\)[\s\S]{0,160}t='financeiro'/);
  assert.match(gestao, /\['resultados', 'Resultados'\]/);
  assert.match(gestao, /setPedSection\(&quot;orcamentos&quot;\)/);
  assert.match(html, /setClientSection\(&quot;crm&quot;\)/);
  assert.match(html, /setClientSection\(&quot;cupons&quot;\)/);
});

test('navegar para Empresa e equipe redesenha a tela e destaca o módulo selecionado', () => {
  const goFunction = html.slice(html.indexOf('function go(t){'), html.indexOf('function closeAppMenu(){'));
  assert.match(goFunction, /tab = t;[\s\S]*if\(t==='catalogo'&&!demoMode\) loadMenus\(\);[\s\S]*else render\(\);/);
  assert.doesNotMatch(goFunction, /loadTenantWorkspace\(true\)/);
  assert.ok(html.includes("tab===key?'is-active':''"));
  assert.match(html, /if\(demoMode\) return '[\s\S]*Configure sua vitrine online[\s\S]*No modo demonstração/);
});

test('mobile nav tem cinco posições fixas com K central e respeita páginas públicas', () => {
  assert.match(html, /var items=\[\['pedidos','Pedidos'/);
  assert.match(html, /\['agenda','Agenda'/);
  assert.match(html, /mobile-nav-home/);
  assert.match(html, /\['producao','Produção'/);
  assert.match(html, /rightItem/);
  assert.match(html, /class="mobile-nav-logo" aria-hidden="true">K/);
  assert.match(html, /publicRoute\|\|tab==='planos'/);
  assert.match(css, /grid-template-columns:repeat\(5,minmax\(0,1fr\)\)/);
  assert.match(css, /env\(safe-area-inset-bottom/);
  assert.match(css, /overflow-x:hidden/);
});

test('logo K central da navegação inferior abre e fecha o menu principal', () => {
  assert.match(html, /mobile-nav-home" data-app-menu-toggle type="button"/);
  assert.match(html, /aria-label="\s*'\+\(APP_MENU_OPEN\?'Fechar':'Abrir'\)\+' menu principal"/);
  assert.match(html, /aria-controls="app-menu-layer" onclick="toggleAppMenu\(\)"/);
  assert.match(html, /function setAppMenuTriggersExpanded\(expanded\)/);
  assert.match(html, /querySelectorAll\('\[data-app-menu-toggle\]'\)/);
  assert.match(html, /toggle\.setAttribute\('aria-expanded',String\(expanded\)\)/);
});

test('logo K do cabeçalho abre o menu e elimina o botão Menu separado', () => {
  const appHeader = html.slice(html.indexOf("siteHeader.innerHTML = '<button id=\"app-menu-toggle\""), html.indexOf("siteHeader.innerHTML = '<button id=\"app-menu-toggle\"") + 500);
  assert.match(appHeader, /id="app-menu-toggle" data-app-menu-toggle class="app-header-brand app-menu-toggle"/);
  assert.match(appHeader, /aria-label="'\+\(APP_MENU_OPEN\?'Fechar':'Abrir'\)\+' menu principal"/);
  assert.match(appHeader, /commercial-brand-mark" aria-hidden="true">K<\/span>/);
  assert.match(appHeader, /aria-controls="app-menu-layer" onclick="toggleAppMenu\(\)"/);
  assert.doesNotMatch(appHeader, />Menu<\/button>/);
  assert.match(css, /#site-header \.app-menu-toggle:focus-visible/);
});

test('cabeçalho fixo em telas pequenas não captura cabeçalhos internos da tela', () => {
  assert.match(html, /body:not\(\.commerce-mode\) #site-header\{display:block;position:fixed/);
  assert.match(html, /body:not\(\.commerce-mode\) #site-header\{height:58px;display:flex/);
  assert.doesNotMatch(html, /body:not\(\.commerce-mode\) header\{/);
});

test('painel oferece atalhos, visão de estoque, tendências e pedidos da vitrine', () => {
  assert.match(gestao, /Ações rápidas do ateliê/);
  assert.match(gestao, /Pedidos da vitrine/);
  assert.match(gestao, /Nova encomenda/);
  assert.match(gestao, /Lotes de produção/);
  assert.match(gestao, /Cadastrar cliente/);
  assert.match(gestao, /Fichas e receitas/);
  assert.match(gestao, /Lista de compras/);
  assert.match(gestao, /Valor estimado em estoque/);
  assert.match(gestao, /Não inclui .* item\(ns\) com saldo sem custo cadastrado/);
  assert.match(gestao, /KSWAnalytics\.monthlySeries\(db, m, 6\)/);
  assert.match(gestao, /Evolução de custos/);
  assert.match(gestao, /Rentabilidade/);
  assert.match(gestao, /p\.origem === 'loja_virtual'/);
  assert.match(gestao, /function dashboardOpenOnlineOrders\(\)/);
  assert.match(gestao, /go\('pedidos'\)/);
  assert.match(gestao, /go\(&quot;catalogo&quot;\)/);
  assert.match(gestao, /esc\(D\(p\.ent\)\)/);
  assert.match(gestao, /esc\(dateLabel\)/);
});

test('pedidos online filtram pela origem e lista de compras leva ao item a repor', () => {
  assert.match(gestao, /PF\.origem === 'vitrine' && p\.origem !== 'loja_virtual'/);
  assert.match(gestao, /id="ped-origin"/);
  assert.match(gestao, /Vitrine online/);
  assert.match(productionUi, /Lista de compras/);
  assert.match(productionUi, /buildShoppingList/);
  assert.match(productionUi, /Comprar \${row\.quantity\.toLocaleString\('pt-BR'\)}/);
  assert.match(productionUi, /Custo estimado/);
  assert.match(productionUi, /copyShoppingListKSW/);
  assert.match(productionUi, /wa\.me\/\?text=/);
  assert.match(productionUi, /function \(type, itemId, quantity\)/);
  assert.match(productionUi, /input\.focus\(\{ preventScroll: true \}\)/);
});

test('estoque tem busca, categorias e abas para itens cadastrados pela confeiteira', () => {
  assert.match(productionUi, /Meus Itens/);
  assert.match(productionUi, /aria-label="Buscar item pelo nome"/);
  assert.match(productionUi, /Todas as categorias/);
  assert.match(productionUi, /Ingredientes/);
  assert.match(productionUi, /Embalagens/);
  assert.match(productionUi, /Decorações/);
  assert.match(productionUi, /Farinhas & Secos/);
  assert.match(productionUi, /Frutas & Castanhas/);
  assert.match(productionUi, /openInventoryItemKSW/);
  assert.match(productionUi, /window\.db\.ingredientes\.push\(item\)/);
  assert.match(productionUi, /window\.db\.embalagens\.push\(item\)/);
  assert.match(productionUi, /estoque começa vazio/);
});

test('edição do item preserva o saldo e bloqueia exclusão com estoque ou referências', () => {
  assert.match(productionUi, /Estoque atual: \$\{stockOf\(item\)/);
  assert.match(productionUi, /Para ajustar o saldo, use “Entrada ou saída”/);
  assert.match(productionUi, /item\.tipo_item = type/);
  assert.match(productionUi, /const referenced = list\(window\.db\.lotes\)/);
  assert.match(productionUi, /if \(referenced \|\| stockOf\(item\) > 0\)/);
  assert.match(productionUi, /Esta ação não pode ser desfeita/);
});

test('menu drawer oferece seletor de empresa e respeita permissões de navegação', () => {
  assert.match(html, /tenantSwitcher=currentUser&&\(tenantList\|\|\[\]\)\.length>1/);
  assert.match(html, /switchTenant\(this\.value\)/);
  assert.match(html, /tenantHasPermission\('finance\.read'\)/);
  assert.match(html, /tenantHasPermission\('audit\.read'\)/);
  assert.match(html, /tenantHasPermission\('menus\.read'\)/);
  assert.match(html, /function closeAppMenu/);
  assert.match(html, /event\.key==='Escape'/);
});

test('Resultados apresenta quatro KPIs e detalhes expansíveis', () => {
  const resultFn = html.slice(html.indexOf('function vRes(){'), html.indexOf('function exportReportCSV(){'));
  assert.equal((resultFn.match(/class="ksw-report-kpi"/g) || []).length, 4);
  assert.match(resultFn, /<details class="card report-details"><summary>Ver detalhes financeiros e relatórios/);
  assert.match(resultFn, /Resultado de caixa/);
  assert.match(resultFn, /Despesas previstas/);
  assert.match(resultFn, /Valores a receber/);
  assert.match(resultFn, /Perdas registradas/);
});

test('Resumo financeiro e Início usam a mesma fonte de indicadores', () => {
  assert.match(gestao, /function finResumo\(\)[\s\S]*?KSWAnalytics\.summarize\(db, m\)/);
  assert.match(gestao, /function vEnt\(\)[\s\S]*?KSWAnalytics\.summarize\(db, m\)/);
  assert.match(gestao, /function aReceberLista\(\)\s*\{\s*return KSWAnalytics\.openReceivables\(db\);\s*\}/);
  assert.match(gestao, /function pagoDe\(p\) \{ return KSWAnalytics\.orderPaid\(p\); \}/);
  assert.match(gestao, /function saldoDe\(p\) \{ return KSWAnalytics\.orderBalance\(p\); \}/);
  assert.match(gestao, /function vencidas\(\)\s*\{\s*return \(db\.despesas \|\| \[\]\)\.filter\(function \(x\) \{ return !x\.pago && x\.venc && diasAte\(x\.venc\) < 0; \}\);\s*\}/);
  assert.match(gestao, /function soma\(list, pick\)\s*\{\s*return \(Array\.isArray\(list\) \? list : \[\]\)\.reduce/);
  assert.match(gestao, /var base = KSWAnalytics\.cashBalanceAsOf\(mv, t0\)/);
  assert.match(gestao, /var h = financeMonthNav\(\) \+ '<div class="grid">'/);
  assert.match(gestao, /summary\.products\.slice\(\)\.sort\(function \(a, b\) \{ return b\.quantity - a\.quantity; \}\)/);
  assert.match(gestao, /db\.ingredientes \|\| \[\]\)\.map\(function \(item\)/);
  assert.match(gestao, /db\.embalagens \|\| \[\]\)\.map\(function \(item\)/);
  assert.match(html, /function tp\(p\)\{return KSWAnalytics\.orderTotal\(p\)\}/);
  assert.match(html, /function costCalculation\(p\)\{return KSWCosting\.calculateProductCost\(p,db\.ingredientes,db\.embalagens\)\}/);
  assert.match(analytics, /const managerialResult = grossProfit - accruedExpenses - wasteCost/);
  assert.match(analytics, /const cashResult = received - paidExpenses/);
  assert.match(analytics, /orders\.filter\(\(order\) => order && order\.st !== 'cancelado'\)/);
  assert.match(gestao, /Saldo de caixa do mês/);
});

test('página comercial explica corretamente que a loja recebe pedidos, mas não cobra online', () => {
  assert.match(html, /Posso receber encomendas pelo meu cardápio\?/);
  assert.match(html, /O pedido entra no seu painel do KSW/);
  assert.match(html, /não gera PIX nem cobra cartão nesta versão/);
});

test('loja pública aplica a capacidade diária configurada na Agenda', () => {
  assert.match(storefrontRoute, /loadStoreCapacity\(tenant\.id\)/);
  assert.match(storefrontRoute, /storefrontCapacity\.buildUnavailableDates/);
  assert.match(storefrontRoute, /storefrontCapacity\.checkDailyCapacity/);
  assert.match(storefrontRoute, /BEGIN|withTransaction/);
  assert.match(storefrontRoute, /STOREFRONT_CAPACITY_EXCEEDED/);
  assert.match(storefrontRoute, /data_entrega = \?/);
  assert.match(storefrontPublic, /unavailableDates/);
  assert.match(storefrontPublic, /capacityFullMessage/);
  assert.match(storefrontPublic, /data-store-capacity-message/);
  assert.match(storefrontPublic, /dateUnavailable/);
});

test('cadastro de aniversário é opcional, sem ano, e registra autorização promocional separadamente', () => {
  assert.match(html, /Aniversário \(opcional\)<\/label><input id="cb" type="text" inputmode="numeric" maxlength="5" placeholder="DD\/MM"/);
  assert.match(html, /if\(birthInput&&!birthday\)return toast\('Informe um aniversário válido no formato DD\/MM\.'\)/);
  assert.match(html, /nasc:birthday\?birthday\.value:''/);
  assert.match(html, /whatsapp_promocoes:whatsappConsent,whatsapp_promocoes_at:whatsappConsent\?new Date\(\)\.toISOString\(\):''/);
  assert.match(html, /function editClientBirthdayKSW\(clientId\)/);
  assert.ok(html.includes('setBirthdayConsentKSW'));
  assert.ok(html.includes("c.whatsapp_promocoes===true?'false':'true'"));
  assert.match(birthdayEngine, /function parse\(value\)/);
  assert.match(birthdayEngine, /function format\(value\)/);
  assert.match(birthdayEngine, /\\d\{4\}/);
});

test('CRM mostra lembretes, aniversariantes do mês, cupons individuais e WhatsApp consentido', () => {
  assert.match(resources, /Aniversários próximos/);
  assert.match(resources, /KSWBirthdays\.upcoming\(db\.clientes,today,7\)/);
  assert.match(resources, /Aniversariantes do mês/);
  assert.match(resources, /KSWBirthdays\.inMonth\(db\.clientes,month,today\)/);
  assert.match(resources, /generateBirthdayCouponKSW/);
  assert.match(resources, /whatsapp_promocoes!==true/);
  assert.match(resources, /function hasBirthdayPhone\(client\)/);
  assert.match(resources, /Gere o cupom para preparar a mensagem/);
  assert.match(resources, /Revogar autorização/);
  assert.match(resources, /ano_aniversario:cycle/);
  assert.match(resources, /id="coupon-client"/);
  assert.match(resources, /String\(c\.cliente_id\)!==clientId/);
});

test('gráfico informa ausência de movimentações em vez de desenhar valores zerados', () => {
  const chart = html.slice(html.indexOf('function reportTrendHtml'), html.indexOf('function reportCategoriesHtml'));
  assert.match(chart, /if\(!max\)return '<div class="report-empty-state"/);
  assert.match(chart, /toLocaleDateString\('pt-BR'/);
  assert.match(chart, /month:'short',year:'2-digit'/);
});

test('pedidos mostram próxima etapa e ações secundárias identificam WhatsApp', () => {
  assert.match(gestao, /function orderProgressHtml/);
  assert.match(gestao, /Confirmar pedido/);
  assert.match(gestao, /Iniciar produção/);
  assert.match(gestao, /Registrar pagamento/);
  assert.match(gestao, /Cobrar no WhatsApp/);
  assert.match(gestao, /Lembrar no WhatsApp/);
  assert.match(gestao, /Mais ações/);
  assert.match(gestao, /danger-quiet/);
});

test('produção começa pelos pedidos e permite informar unidades boas produzidas', () => {
  assert.match(productionUi, /Planejar produção/);
  assert.match(productionUi, /production-actual-output/);
  assert.match(productionUi, /Unidades boas efetivamente produzidas/);
  assert.match(productionUi, /quantity_produced/);
  assert.match(productionRoute, /validateProducedQuantity/);
  assert.match(productionRoute, /production\.quantidade_produzida = producedResult\.quantity/);
  assert.match(productionRoute, /production\.consumo_aplicado \|\| production\.status === 'concluida'/);
});

test('datas e meses são apresentados em português sem capitalização forçada', () => {
  assert.match(gestao, /toLocaleDateString\('pt-BR', \{ weekday: 'long'/);
  assert.doesNotMatch(css, /text-transform:\s*capitalize/i);
  assert.match(html, /toLocaleDateString\('pt-BR',\{month:'short',year:'2-digit'\}\)/);
});

test('tipografia e controles móveis têm tamanho de leitura e toque adequados', () => {
  assert.match(css, /body\.app-mode main p,[\s\S]*?font-size: 14px/);
  assert.match(css, /min-height:44px/);
  assert.match(css, /grid-template-columns:repeat\(5,minmax\(0,1fr\)\)/);
  assert.match(css, /@media\(max-width:390px\)/);
  assert.match(css, /@media\(max-width:420px\)/);
  assert.match(css, /@media\(max-width:760px\)/);
});

test('aviso de cookies oferece aceitar, rejeitar e personalizar, some após a escolha e pode ser reaberto', () => {
  const cookieJs = read('public/cookie-notice.js');
  const cookieCss = read('public/cookie-notice.css');
  assert.match(cookieJs, /cookie-notice-reject/);
  assert.match(cookieJs, /cookie-notice-accept/);
  assert.match(cookieJs, /cookie-notice-save/);
  assert.match(cookieJs, /function removeNotice\(\)/);
  assert.match(cookieJs, /openPreferences/);
  assert.doesNotMatch(cookieJs, /cookie-notice-toggle/);
  assert.match(cookieCss, /max-height:min\(78vh,620px\)/);
  assert.match(cookieCss, /max-height:82vh/);
  assert.match(cookieCss, /#cookie-notice\{position:fixed/);
});

test('efeitos de rolagem revelam telas inteiras e repetem a entrada dos painéis ao subir', () => {
  assert.match(scrollEffects, /function setupLandingScenes\(scenes\)/);
  assert.match(scrollEffects, /start: 'top 94%'/);
  assert.match(scrollEffects, /end: 'top 34%'/);
  assert.match(scrollEffects, /onEnterBack:\s*function\s*\(batch\)\s*\{\s*show\(batch\);\s*\}/);
  assert.match(scrollEffects, /onLeaveBack:\s*function\s*\(batch\)\s*\{[\s\S]*?hide\(batch\);\s*\}/);
});

test('hero comercial usa parallax em camadas e respeita movimento reduzido', () => {
  const hero = html.slice(html.indexOf("h += '<section class=\"ksw-hero ksw-screen-scene\""), html.indexOf("h += '<section class=\"ksw-trust-strip"));
  assert.match(hero, /ksw-art-glow[^>]+data-ksw-parallax-depth="1"/);
  assert.match(hero, /painel-dashboard\.png[^>]+data-ksw-parallax-depth="2"/);
  assert.equal((hero.match(/data-ksw-parallax-depth="3"/g) || []).length, 3);
  assert.match(hero, /Relacionamento com clientes/);
  assert.match(hero, /Pedidos e encomendas/);
  assert.doesNotMatch(hero, /98%|15\.4K\+/);
  assert.match(scrollEffects, /'\[data-ksw-parallax-depth\], \.ksw-showcase-image img, \.ksw-client-showcase > img'/);
  assert.match(scrollEffects, /Math\.min\(depth \* \(mobile \? 4\.8 : 8\), mobile \? 14 : 24\)/);
  assert.match(scrollEffects, /function setupHeroDepth\(heroes\)/);
  assert.match(scrollEffects, /scrub: mobile \? 0\.5 : 0\.8/);
  assert.match(scrollEffects, /mm\.add\('\(prefers-reduced-motion: no-preference\)'/);
});

test('seções comerciais não criam espaços vazios antes do rodapé e mantêm hero/cabeçalho', () => {
  const landingMarkup = html.slice(html.indexOf('function vPlanos(){'), html.indexOf('function startCheckout'));
  assert.equal((landingMarkup.match(/ksw-screen-scene/g) || []).length, 9);
  assert.match(landingMarkup, /<footer class="ksw-footer">/);
  assert.doesNotMatch(landingMarkup, /<footer class="ksw-footer ksw-screen-scene">/);
  assert.match(css, /\.commerce-mode header\{position:sticky;top:0/);
  assert.match(css, /\.commerce-mode main>\.ksw-screen-scene\{min-height:0/);
  assert.match(css, /\.commerce-mode main>\.ksw-hero\.ksw-screen-scene\{min-height:540px/);
  assert.match(css, /\.ksw-footer\{[^}]*margin-top:8px[^}]*padding:18px 0 22px/);
  assert.match(css, /\.ksw-faq\{[^}]*padding:38px 0 24px/);
  assert.match(css, /@media\(max-width:760px\)[\s\S]*?\.commerce-mode main>\.ksw-screen-scene\{min-height:0/);
  assert.match(scrollEffects, /'\.ksw-footer'/);
  assert.match(scrollEffects, /function setupLandingScenes\(scenes\)/);
  assert.match(scrollEffects, /autoAlpha: 0\.22, y: 90/);
  assert.match(scrollEffects, /start: 'top 94%',[\s\S]*end: 'top 34%',[\s\S]*scrub: 0\.5/);
  assert.match(scrollEffects, /setupLandingScenes\(scenes\)/);
});


test('login e cadastro usam layout KSW responsivo sem alterar handlers e IDs de autenticação', () => {
  const auth = html.slice(html.indexOf("if(step === 'auth')"), html.indexOf("}else if(step === 'review')"));
  assert.match(auth, /ksw-auth-layout/);
  assert.match(auth, /ksw-auth-aside/);
  assert.match(auth, /ksw-auth-content/);
  assert.match(auth, /id=\"checkout-email\"/);
  assert.match(auth, /id=\"checkout-password\"/);
  assert.match(auth, /id=\"checkout-name\"/);
  assert.match(auth, /id=\"checkout-whatsapp\"/);
  assert.match(auth, /onclick=\"doLogin\(\)\"/);
  assert.match(auth, /onclick=\"doRegister\(\)\"/);
  assert.match(auth, /onclick=\"forgotPassModal\(\)\"/);
  assert.match(css, /\.checkout-dialog\.ksw-auth-dialog\{position:relative/);
  assert.match(css, /@media\(max-width:620px\)[\s\S]*?\.ksw-auth-layout\{grid-template-columns:1fr/);
  assert.match(html, /ksw-home\.css\?v=15/);
  assert.match(html, /ksw-scroll-effects\.js\?v=3/);
});


test('precificação avisa sobre perda e não considera taxa desconhecida como zero', () => {
  assert.match(html, /Deixe em branco se não souber/);
  assert.match(html, /Taxas de venda ainda não informadas/);
  assert.match(html, /As taxas ainda não foram informadas/);
  assert.match(html, /Preço inicial \(estimativa parcial\)/);
  assert.match(html, /taxa_venda_informada=this\.value\.trim\(\)/);
  assert.match(costing, /function hasKnownVariableFee/);
  assert.match(costing, /status = 'fees_unknown'/);
});

test('pedido mostra perda por encomenda e pede confirmação antes de registrar prejuízo', () => {
  assert.match(gestao, /estimateOrderProfitability/);
  assert.match(gestao, /perda mínima estimada de/);
  assert.match(gestao, /Deseja registrar mesmo assim/);
  assert.match(gestao, /sobra antes das taxas de/);
  assert.match(gestao, /taxa_venda_informada/);
});

test('relatórios distinguem taxas registradas e linhas com taxa desconhecida', () => {
  assert.match(html, /Taxas de venda não informadas/);
  assert.match(html, /summary\.missing_fee_items/);
  assert.match(html, /Custos diretos \+ taxas variáveis de venda/);
  assert.match(analytics, /missing_fee_items/);
  assert.match(analytics, /zero legado sem confirmação explícita/);
});


test('prejuízo da ficha usa o rendimento real do lote e mostra o principal custo de ingrediente', () => {
  assert.match(html, /quantity:c\.yield/);
  assert.match(html, /ATENÇÃO: este preço gera perda mínima estimada[\s\S]*lote completo/);
  assert.match(html, /Maior custo de ingrediente no lote/);
  assert.match(gestao, /quantity: calculation\.yield/);
  assert.match(gestao, /\/lote/);
});

test('painel e relatório usam contribuição/sobra, sem chamar contribuição de lucro líquido', () => {
  assert.match(gestao, /Sobra após custos cadastrados/);
  assert.match(html, /Contribuição por produto/);
  assert.match(html, /Inclui o rateio fixo somente quando cadastrado e válido/);
  assert.match(html, /Entrega, desperdício, tributos e custos não cadastrados podem ficar fora/);
  assert.match(html, /Você confirmou que não possui despesas fixas mensais/);
});


test('scripts inline do app compilam como scripts reais do navegador', () => {
  const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)]
    .filter((match) => !/\bsrc\s*=/.test(match[1]) && match[2].trim());
  assert.ok(scripts.length > 0, 'deve existir ao menos um script inline');
  scripts.forEach((match, index) => {
    assert.doesNotThrow(() => new vm.Script(match[2], { filename: `public/index.html:inline-${index + 1}` }));
  });
});

test('frontend executa init depois dos módulos externos e protege a tela contra falhas de boot', () => {
  const productionScript = html.indexOf('/production-ui.js');
  const bootScript = html.indexOf('(function startKSWApp()');
  assert.ok(productionScript >= 0 && bootScript > productionScript, 'boot deve ocorrer depois dos módulos usados na renderização');
  assert.match(html, /async function init\(\)/);
  assert.match(html, /if \(typeof init !== 'function'\)/);
  assert.match(html, /init\(\)\.then\(function\(\)/);
  assert.match(html, /Não foi possível carregar o KSW/);
});

test('ficha técnica mantém a função calc e evita return solto no script principal', () => {
  const calcIndex = html.indexOf('function calc(){');
  const resultIndex = html.indexOf("document.getElementById('res')", calcIndex);
  const saveIndex = html.indexOf('function saveP(){', calcIndex);
  assert.ok(calcIndex >= 0 && resultIndex > calcIndex && saveIndex > resultIndex);
  assert.match(html.slice(calcIndex, saveIndex), /costCalculation\(P\)/);
});

test('custos fixos precisam ser explicitamente cadastrados ou confirmados', () => {
  assert.match(gestao, /fixed_costs_confirmed !== true/);
  assert.match(gestao, /settings\.fixed_costs_confirmed = true/);
  assert.match(gestao, /Preencha ou remova a despesa fixa vazia antes de salvar/);
  assert.match(gestao, /Cadastre as despesas fixas ou salve a confirmação/);
  assert.match(gestao, /dashboardFixedAllocation/);
  assert.match(gestao, /Financeiro &gt; Custos fixos/);
  assert.match(gestao, /fixed_costs_informado/);
  assert.match(gestao, /rateio fixo confirmado no momento do pedido foi considerado/);
  assert.match(gestao, /rateio de despesas fixas está incompleto/);
});


test('menu abre em painel central, não como gaveta lateral', () => {
  const tenantUi = read('public/tenant-ui.css');
  assert.match(tenantUi, /#app-menu-layer\{display:grid;place-items:center/);
  assert.match(tenantUi, /\.app-menu-drawer\{position:relative;inset:auto;width:min\(560px/);
  assert.match(tenantUi, /@keyframes ksw-menu-center-in/);
  assert.doesNotMatch(tenantUi, /animation:ksw-drawer-in/);
});

test('Configurações aparece uma única vez na navegação principal', () => {
  const configMenu = html.slice(html.indexOf('var NAV_GROUPS=['), html.indexOf('var CLIENT_SECTION='));
  assert.match(configMenu, /items:\['configuracoes'\]/);
  const renderer = html.slice(html.indexOf('function renderAppMenu(){'), html.indexOf('function renderMobileNav(){'));
  assert.doesNotMatch(renderer, /Configurações da conta|nav-item[^']*Configurações/);
  const desktop = html.slice(html.indexOf("if(appMode&&!commerceMode){"), html.indexOf("}else{", html.indexOf("if(appMode&&!commerceMode){")));
  assert.doesNotMatch(desktop, /Configurações da conta/);
});

test('tema escuro cobre marca, navegação lateral e componentes de trabalho', () => {
  const tenantUi = read('public/tenant-ui.css');
  assert.match(tenantUi, /body\.app-mode #nav \.logo/);
  assert.match(tenantUi, /body\.app-mode #nav \.nav-item/);
  assert.match(tenantUi, /body\.app-mode #site-header \.app-header-brand b/);
  assert.match(tenantUi, /body\.app-mode main \.ksw-dashboard-panel/);
  assert.match(tenantUi, /body\.app-mode main \.order-money-row>span/);
  assert.match(tenantUi, /#app-menu-layer \.app-menu-drawer/);
});

test('pedidos e formulários usam layout fluido em telas móveis estreitas', () => {
  const tenantUi = read('public/tenant-ui.css');
  assert.match(gestao, /class="row order-item-row"/);
  assert.match(gestao, /class="card order-toolbar"><div class="order-toolbar-controls"/);
  assert.match(css, /\.order-item-row\{display:grid!important/);
  assert.match(css, /\.order-progress-steps\{display:flex!important;gap:8px!important;overflow-x:auto/);
  assert.match(css, /\.order-actions\{display:grid!important;grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/);
  assert.match(tenantUi, /@media\(max-width:380px\)/);
  assert.match(tenantUi, /order-form-card \.cols\{grid-template-columns:minmax\(0,1fr\)!important\}/);
});

test('precificação reduz entradas obrigatórias e calcula mão de obra automaticamente', () => {
  assert.match(html, /O KSW faz as contas para você/);
  assert.match(html, /Quantas unidades essa receita rende\?/);
  assert.match(html, /Minutos de trabalho no lote/);
  assert.match(html, /Preço inicial \(estimativa parcial\)/);
  assert.match(html, /calculateLaborCostPerUnit/);
  assert.match(costing, /function calculateLaborCostPerUnit\(/);
  assert.match(html, /Custos extras e ajustes \(opcional\)/);
});

test('configurações centralizam perfil, assinatura, logout, tema, idiomas e precificação', () => {
  assert.match(html, /\['configuracoes','Configurações','⚙'\]/);
  assert.match(html, /function vConfiguracoes\(\)/);
  assert.match(html, /Minha assinatura/);
  assert.match(html, /Sair da conta/);
  assert.match(html, /settings-theme/);
  for (const language of ['pt-BR', 'en-US', 'es-ES', 'fr-FR', 'it-IT']) assert.ok(html.includes(language));
  assert.match(html, /settings-margin/);
  assert.match(html, /settings-labor/);
  assert.match(html, /settings-monthly-pay/);
  assert.match(html, /settings-work-days/);
  assert.match(html, /settings-work-hours/);
  assert.doesNotMatch(html, /id=\"settings-packaging\"/);
  assert.doesNotMatch(html, /id=\"settings-tax\"/);
  assert.doesNotMatch(html, /id=\"settings-units\"/);
  assert.match(html, /function applyKswPreferences\(\)/);
  assert.match(html, /function savePricingPreferences\(\)/);
});

test('alteração de senha exige autenticação, senha atual e hash bcrypt', () => {
  const authRoute = read('routes/auth.js');
  assert.match(authRoute, /router\.post\('\/change-password', authMiddleware, resetLimiter/);
  assert.match(authRoute, /bcrypt\.compare\(currentPassword, user\.senha\)/);
  assert.match(authRoute, /bcrypt\.hash\(newPassword, 12\)/);
  assert.match(authRoute, /UPDATE users SET senha = \?/);
});


test('tema claro usa paleta blush suave em todo o ambiente autenticado', () => {
  const tenantCss = read('public/tenant-ui.css');
  assert.match(tenantCss, /html\[data-theme="light"\] body\.app-mode/);
  assert.match(tenantCss, /--bg:#f2eeec/);
  assert.match(tenantCss, /--card:#fffaf9/);
  assert.match(tenantCss, /--soft:#f2e5e9/);
  assert.match(tenantCss, /#nav,\s*html\[data-theme="light"\] body\.app-mode #site-header/);
  assert.match(tenantCss, /main input,[\s\S]*background:#fffdfc!important/);
  assert.match(html, /ksw-home\.css\?v=15/);
  assert.match(html, /tenant-ui\.css\?v=5/);
});




test('tema escuro mantém agenda e componentes legados legíveis', () => {
  const tenantCss = read('public/tenant-ui.css');
  assert.match(tenantCss, /html\[data-theme="dark"\] body\.app-mode main \.cal-d/);
  assert.match(tenantCss, /\.cal-d\{[\s\S]*?background:var\(--card\)!important/);
  assert.match(tenantCss, /\.ksw-inventory-manager/);
  assert.match(tenantCss, /\.ksw-report-kpi/);
  assert.match(tenantCss, /\[style\*="background" i\]\[style\*="#fff" i\]/);
});


test('tema escuro mantém identidade KSW com textos legíveis e sem cartões brancos residuais', () => {
  const tenantCss = read('public/tenant-ui.css');
  assert.ok(tenantCss.includes('--ksw-ink:var(--ink)'));
  assert.ok(tenantCss.includes('--ksw-muted:var(--mut)'));
  assert.ok(tenantCss.includes('--ksw-plum:var(--pri)'));
  assert.ok(tenantCss.includes('main .ksw-month-label'));
  assert.ok(tenantCss.includes('linear-gradient(112deg,var(--card) 0%,var(--card) 58%,var(--soft) 100%)'));
  assert.ok(tenantCss.includes('main .ksw-inventory-dialog'));
  assert.ok(tenantCss.includes('main .ksw-kpi-symbol'));
  assert.ok(tenantCss.includes('main .ksw-dashboard-panel h3'));
  assert.ok(tenantCss.includes('main .ksw-loss-alert'));
  assert.ok(tenantCss.includes('main .ksw-profit-note'));
  assert.ok(tenantCss.includes('main .ksw-inventory-category'));
  assert.ok(tenantCss.includes('main .account-summary'));
});

test('auditoria demo não é servida como página pública', () => {
  assert.equal(fs.existsSync(path.join(root, 'public', '__audit-demo.html')), false);
  assert.equal(fs.existsSync(path.join(root, 'docs', 'fixtures', '__audit-demo.html')), true);
});

test('configurações não exibem botões de suporte que apenas mostram mensagens sem atendimento', () => {
  const settings = html.slice(html.indexOf('function vConfiguracoes()'), html.indexOf('async function changeAccountPassword'));
  assert.match(settings, /canal de suporte conectado/i);
  assert.doesNotMatch(settings, /Central de ajuda.*onclick|Contato do suporte.*onclick/);
});

test('lista de compras calcula necessidade dos pedidos e abre a aba correta para repor', () => {
  assert.match(productionUi, /calculateDemandShortages/);
  assert.match(productionUi, /O que falta para atender os pedidos/);
  assert.match(productionUi, /demandForecast\.shortages\.map/);
  assert.match(productionUi, /needsViewChange/);
  assert.match(productionUi, /prepareRestockKSW/);
});

test('pedidos mostram o próximo passo e preservam o rascunho ao cadastrar cliente ou produto', () => {
  const form = gestao.slice(gestao.indexOf('function pedForm()'), gestao.indexOf('\nfunction tot()'));
  assert.match(form, /Primeiro, cadastre uma cliente/);
  assert.match(form, /O rascunho ficará guardado/);
  assert.doesNotMatch(form, /O=null;go\('clientes'\)/);
  assert.match(form, /Não há produtos cadastrados para adicionar/);
  assert.match(form, /Cadastrar novo produto/);
  assert.match(form, /Adicionar primeiro item/);
  assert.match(form, /order-save-button/);
  assert.match(gestao, /function addOrderItemKSW\(\)/);
  assert.match(gestao, /Escolha um produto cadastrado em cada item do pedido/);
});

test('orientação contextual de próximo passo aparece nas áreas centrais do aplicativo', () => {
  assert.match(html, /function kswNextStepResolve\(\)/);
  ['pedidos','ingredientes','produtos','clientes','agenda','producao','catalogo','financeiro','entregas','configuracoes'].forEach((tab) => {
    assert.match(html, new RegExp("if\\(tab==='" + tab + "'"));
  });
  assert.match(html, /function kswNextStepAction\(action\)/);
  assert.match(html, /aria-label="Próximo passo recomendado"/);
  assert.match(html, /kswNextStepGuide\(\) \+ \(viewMap\[tab\]/);
  assert.match(css, /\.ksw-next-step/);
  assert.match(css, /\.ksw-form-next-step/);
});

test('cadastro de item converte o preço da embalagem sem a confeiteira fazer conta', () => {
  const production = read('public/production-ui.js');
  assert.match(production, /id="inventory-pack-qty"/);
  assert.match(production, /id="inventory-pack-paid"/);
  assert.match(production, /window\.updatePackPriceKSW = function/);
  assert.match(production, /KSWCosting\.convertQuantity\(quantity, packUnit, target\)/);
});

test('ficha de receita mostra o preço sugerido pronto e pergunta taxa em linguagem simples', () => {
  assert.match(html, /ksw-price-answer/);
  assert.match(html, /como preço de venda/);
  assert.match(html, /function setFeeModeKSW/);
  assert.match(html, /Você paga taxa quando vende\?/);
  // "Não sei" nunca vira zero confirmado.
  assert.match(html, /else\{P\.taxa_venda_pct=null;P\.taxa_venda_informada=false;\}/);
});

test('configurações calculam o valor da hora a partir de quanto ela quer ganhar e do tempo de trabalho', () => {
  assert.match(html, /id="settings-work-days"/);
  assert.match(html, /id="settings-work-hours"/);
  assert.match(html, /function hourlyFromInputsKSW/);
  assert.match(html, /function previewHourlyKSW/);
  assert.match(html, /pay\/\(days\*hours\*\(52\/12\)\)/);
});

test('despesas fixas aceitam valor por semana ou ano, sugestões com um toque e ajuda para estimar o volume', () => {
  assert.match(gestao, /var FIXED_COST_PERIODS = \{ mes: 1, semana: 52 \/ 12, ano: 1 \/ 12 \}/);
  assert.match(gestao, /function addFixedCostSuggestion/);
  assert.match(gestao, /function confirmNoFixedCosts/);
  assert.match(gestao, /function applyVolumeHelperKSW/);
  assert.match(gestao, /Quantas unidades você vende em um mês normal\?/);
  // Dado ausente continua sem virar zero: a confirmação de "sem despesas" é um clique explícito.
  assert.match(gestao, /settings\.fixed_costs_confirmed = true/);
});
