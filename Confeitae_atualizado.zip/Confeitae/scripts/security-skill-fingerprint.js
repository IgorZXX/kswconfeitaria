'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const EXCLUDED_DIRS = new Set([
  '.git', 'node_modules', 'backups', 'coverage', 'dist', 'build', '.next', '.cache',
]);
const EXCLUDED_FILES = new Set([
  '.env', '.DS_Store', 'Thumbs.db',
]);
const SKILL_FILES = new Set([
  '.agents/skills/ksw-security/SKILL.md',
  '.claude/skills/ksw-security/SKILL.md',
]);
const MARKER = /<!-- KSW_PROJECT_FINGERPRINT: sha256:([a-f0-9]{64}) -->/;

function shouldExcludeFile(relativePath, basename) {
  if (SKILL_FILES.has(relativePath)) return true;
  if (EXCLUDED_FILES.has(basename)) return true;
  if (basename.startsWith('.env.') && basename !== '.env.example') return true;
  if (/\.(?:sqlite|sqlite3|db)(?:-(?:shm|wal))?$/i.test(basename)) return true;
  if (/\.log$/i.test(basename)) return true;
  return false;
}

function listProjectFiles(root, current = root, output = []) {
  const entries = fs.readdirSync(current, { withFileTypes: true });
  entries.sort((a, b) => a.name.localeCompare(b.name));

  for (const entry of entries) {
    const absolute = path.join(current, entry.name);
    const relative = path.relative(root, absolute).split(path.sep).join('/');

    if (entry.isDirectory()) {
      if (!EXCLUDED_DIRS.has(entry.name)) listProjectFiles(root, absolute, output);
      continue;
    }

    if (entry.isFile() && !shouldExcludeFile(relative, entry.name)) {
      output.push({ absolute, relative });
    }
  }

  return output;
}

function computeFingerprint(root) {
  const hash = crypto.createHash('sha256');
  const files = listProjectFiles(root);

  for (const file of files) {
    hash.update(file.relative, 'utf8');
    hash.update(Buffer.from([0]));
    hash.update(fs.readFileSync(file.absolute));
    hash.update(Buffer.from([0]));
  }

  return hash.digest('hex');
}

function readFingerprintMarker(markdown) {
  const match = markdown.match(MARKER);
  return match ? match[1] : null;
}

function writeFingerprintMarker(markdown, fingerprint) {
  const marker = `<!-- KSW_PROJECT_FINGERPRINT: sha256:${fingerprint} -->`;
  if (MARKER.test(markdown)) return markdown.replace(MARKER, marker);
  return `${marker}\n\n${markdown}`;
}

module.exports = {
  computeFingerprint,
  readFingerprintMarker,
  writeFingerprintMarker,
};
