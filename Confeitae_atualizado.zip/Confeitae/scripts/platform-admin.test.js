'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const {
  DEFAULT_PLATFORM_PLANS,
  validateSubscriptionChange,
  subscriptionExpiration,
  parsePagination,
  normalizeSearch,
  normalizeTenantStatus,
  isSubscriptionActive,
  subscriptionAccessStatus,
  formatMoneyCents
} = require('../lib/platform-admin');

const NOW = Date.parse('2026-11-05T12:00:00.000Z');

test('catálogo padrão preserva os preços comerciais em centavos', () => {
  assert.deepEqual(DEFAULT_PLATFORM_PLANS.map((plan) => [plan.key, plan.price_cents, plan.interval]), [
    ['mensal', 5999, 'month'],
    ['anual', 0, 'month'],
    ['vitalicio', 111900, 'once'],
    ['teste_gratis', 0, 'month']
  ]);
  assert.equal(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'mensal').max_members, 3);
  assert.ok(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'mensal').features.some((feature) => feature.key === 'team'));
  assert.ok(!DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'mensal').features.some((feature) => feature.key === 'admin_chat'));
  assert.ok(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'vitalicio').features.some((feature) => feature.key === 'admin_chat'));
  assert.ok(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'teste_gratis').features.some((feature) => feature.key === 'admin_chat'));
  assert.equal(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'anual').max_members, 3);
  assert.equal(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'vitalicio').max_members, 0);
  assert.equal(DEFAULT_PLATFORM_PLANS.find((plan) => plan.key === 'teste_gratis').max_members, 0);
});

test('valida alterações de assinatura e rejeita planos/status desconhecidos', () => {
  assert.equal(validateSubscriptionChange({ plano_tipo: 'mensal', status_assinatura: 'ativa', dias_adicionais: 30 }).ok, true);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'vitalicio', status_assinatura: 'ativa' }).ok, true);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'anual', status_assinatura: 'ativa', dias_adicionais: 365 }).ok, true);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'teste_gratis', status_assinatura: 'ativa', dias_adicionais: 7 }).ok, true);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'mensal', status_assinatura: 'ativa', dias_adicionais: 0 }).ok, false);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'mensal', status_assinatura: 'ativa', dias_adicionais: 3651 }).ok, false);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'root', status_assinatura: 'ativa' }).ok, false);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'free', status_assinatura: 'ativa' }).ok, false);
});

test('validação da assinatura não aceita números fracionários ou string vazia como validade', () => {
  assert.equal(validateSubscriptionChange({ plano_tipo: 'teste', status_assinatura: 'ativa', dias_adicionais: 1.5 }).ok, false);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'mensal', status_assinatura: 'ativa', dias_adicionais: '' }).ok, false);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'mensal', status_assinatura: 'inativa' }).ok, true);
});

test('calcula expiração em UTC e não cria vencimento para vitalício/inativo', () => {
  assert.equal(subscriptionExpiration('mensal', 'ativa', 30, NOW), '2026-12-05T12:00:00.000Z');
  assert.equal(subscriptionExpiration('vitalicio', 'ativa', null, NOW), null);
  assert.equal(subscriptionExpiration('mensal', 'inativa', null, NOW), null);
  assert.throws(() => subscriptionExpiration('mensal', 'ativa', null, NOW), /validade/i);
});

test('paginação aplica limites e evita valores não inteiros', () => {
  assert.deepEqual(parsePagination({ limit: '500', offset: '-5' }), { limit: 100, offset: 0 });
  assert.deepEqual(parsePagination({ limit: 'abc', offset: '2.2' }), { limit: 50, offset: 0 });
  assert.deepEqual(parsePagination({}), { limit: 50, offset: 0 });
});

test('normaliza busca e rejeita status de empresa não reconhecidos', () => {
  assert.equal(normalizeSearch('  bolo  ', 4), 'bolo');
  assert.equal(normalizeSearch('x'.repeat(200), 10).length, 10);
  assert.equal(normalizeTenantStatus('suspended'), 'suspended');
  assert.equal(normalizeTenantStatus('deleted'), null);
});

test('assinatura ativa considera plano, estado, vencimento e planos personalizados', () => {
  assert.equal(isSubscriptionActive({ plano_tipo: 'vitalicio', status_assinatura: 'ativa' }, NOW), true);
  assert.equal(isSubscriptionActive({ plano_tipo: 'teste_gratis', billing_interval: 'month', status_assinatura: 'ativa', data_vencimento: '2026-11-12T12:00:00Z' }, NOW), true);
  assert.equal(isSubscriptionActive({ plano_tipo: 'mensal', status_assinatura: 'ativa', data_vencimento: '2026-12-01T00:00:00Z' }, NOW), true);
  assert.equal(isSubscriptionActive({ plano_tipo: 'mensal', status_assinatura: 'ativa', data_vencimento: '2026-10-01T00:00:00Z' }, NOW), false);
  assert.equal(isSubscriptionActive({ plano_tipo: 'teste', status_assinatura: 'inativa', data_vencimento: '2026-12-01T00:00:00Z' }, NOW), false);
  assert.equal(isSubscriptionActive({ plano_tipo: 'free', status_assinatura: 'ativa' }, NOW), false);
  assert.equal(isSubscriptionActive({ plano_tipo: 'profissional', billing_interval: 'month', status_assinatura: 'ativa', data_vencimento: '2026-12-01T00:00:00Z' }, NOW), true);
  assert.equal(isSubscriptionActive({ plano_tipo: 'profissional', billing_interval: 'month', status_assinatura: 'ativa' }, NOW), false);
  assert.equal(isSubscriptionActive({ plano_tipo: 'profissional-anual', billing_interval: 'once', status_assinatura: 'ativa' }, NOW), true);
  assert.equal(validateSubscriptionChange({ plano_tipo: 'profissional', status_assinatura: 'ativa', dias_adicionais: 90 }, new Set(['free', 'profissional']), new Set(['profissional'])).ok, true);
});

test('status administrativo distingue acesso ativo, vencido, cancelado e inativo', () => {
  assert.equal(subscriptionAccessStatus({ plano_tipo: 'mensal', billing_interval: 'month', status_assinatura: 'ativa', data_vencimento: '2026-12-01T00:00:00Z' }, NOW), 'ativa');
  assert.equal(subscriptionAccessStatus({ plano_tipo: 'mensal', billing_interval: 'month', status_assinatura: 'ativa', data_vencimento: '2026-10-01T00:00:00Z' }, NOW), 'vencida');
  assert.equal(subscriptionAccessStatus({ plano_tipo: 'profissional', billing_interval: 'month', status_assinatura: 'ativa' }, NOW), 'vencida');
  assert.equal(subscriptionAccessStatus({ plano_tipo: 'vitalicio', billing_interval: 'once', status_assinatura: 'ativa' }, NOW), 'ativa');
  assert.equal(subscriptionAccessStatus({ plano_tipo: 'mensal', status_assinatura: 'cancelada' }, NOW), 'cancelada');
  assert.equal(subscriptionAccessStatus({ plano_tipo: 'mensal', status_assinatura: 'inativa' }, NOW), 'inativa');
});

test('formata centavos sem aceitar valores monetários inválidos', () => {
  assert.equal(formatMoneyCents(5999), '59.99');
  assert.throws(() => formatMoneyCents(-1), /inválido/i);
  assert.throws(() => formatMoneyCents(1.2), /inválido/i);
});
