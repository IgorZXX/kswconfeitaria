'use strict';

var kswSupportPollTimer = null;
var kswSupportLoading = false;

function vSuporte() {
  return '<section class="page-heading"><div><span class="eyebrow">ATENDIMENTO DIRETO</span><h1>Chat com a administração</h1><p class="mut">Converse diretamente com a equipe do Confeitaê. Suas mensagens ficam privadas para a sua empresa.</p></div><button class="btn ghost sm" type="button" onclick="loadSupportChat(true)">Atualizar conversa</button></section>' +
    '<section class="card ksw-support-card"><div class="ksw-support-head"><div><strong>Suporte Confeitaê</strong><span class="mut">Resposta pelo painel administrativo</span></div><span class="ksw-support-private">Conversa privada</span></div>' +
    '<div id="ksw-support-status" class="ksw-support-status" role="status" aria-live="polite">Carregando conversa...</div>' +
    '<div id="ksw-support-messages" class="ksw-support-messages" aria-live="polite" aria-label="Mensagens da conversa"></div>' +
    '<form id="ksw-support-form" class="ksw-support-form" onsubmit="sendSupportChatMessage(event)"><label class="sr-only" for="ksw-support-input">Sua mensagem</label><textarea id="ksw-support-input" maxlength="4000" rows="3" placeholder="Escreva sua mensagem para a administração..." required></textarea><div class="ksw-support-form-footer"><small>Até 4.000 caracteres. Evite enviar senhas ou dados de pagamento.</small><button class="btn" id="ksw-support-send" type="submit">Enviar mensagem</button></div></form></section>';
}

function stopSupportChatPolling() {
  if (kswSupportPollTimer) clearTimeout(kswSupportPollTimer);
  kswSupportPollTimer = null;
}

function scheduleSupportChatPolling() {
  stopSupportChatPolling();
  if (document.visibilityState !== 'visible' || typeof tab === 'undefined' || tab !== 'suporte') return;
  kswSupportPollTimer = setTimeout(function () {
    loadSupportChat(true);
  }, 15000);
}

function supportChatTime(value) {
  var date = new Date(value);
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
}

async function loadSupportChat(silent) {
  var box = document.getElementById('ksw-support-messages');
  if (!box || kswSupportLoading) return;
  kswSupportLoading = true;
  var input = document.getElementById('ksw-support-input');
  var draft = input ? input.value : '';
  try {
    var data = await apiCall('/support/thread');
    box.innerHTML = (data.messages || []).map(function (message) {
      var own = message.sender_type === 'owner';
      return '<article class="ksw-support-message ' + (own ? 'is-owner' : 'is-admin') + '"><div class="ksw-support-message-meta"><strong>' + (own ? 'Você' : 'Confeitaê Administração') + '</strong><time>' + esc(supportChatTime(message.created_at)) + '</time></div><p>' + esc(message.body).replace(/\r?\n/g, '<br>') + '</p></article>';
    }).join('') || '<div class="ksw-support-empty">Este é o início da conversa. Envie sua primeira mensagem para falar com a administração.</div>';
    box.scrollTop = box.scrollHeight;
    var status = document.getElementById('ksw-support-status');
    if (status) status.textContent = data.thread && data.thread.status === 'closed' ? 'Conversa encerrada. Envie uma nova mensagem para reabri-la.' : 'Conversa aberta · as respostas aparecerão aqui.';
    var restored = document.getElementById('ksw-support-input');
    if (restored && draft && document.activeElement !== restored) restored.value = draft;
  } catch (error) {
    var statusEl = document.getElementById('ksw-support-status');
    if (statusEl && !silent) statusEl.textContent = error.message || 'Não foi possível carregar a conversa.';
  } finally {
    kswSupportLoading = false;
    scheduleSupportChatPolling();
  }
}

async function sendSupportChatMessage(event) {
  event.preventDefault();
  var input = document.getElementById('ksw-support-input');
  var button = document.getElementById('ksw-support-send');
  var body = String(input && input.value || '').trim();
  if (!body || body.length > 4000 || !button) return;
  button.disabled = true;
  try {
    await apiCall('/support/messages', 'POST', { body: body });
    input.value = '';
    await loadSupportChat(true);
    toast('Mensagem enviada para a administração.');
  } catch (error) {
    // apiCall já apresenta a mensagem de erro ao usuário.
  } finally {
    button.disabled = false;
    if (input) input.focus();
  }
}

document.addEventListener('visibilitychange', function () {
  if (document.visibilityState === 'visible' && typeof tab !== 'undefined' && tab === 'suporte') loadSupportChat(true);
  else stopSupportChatPolling();
});
