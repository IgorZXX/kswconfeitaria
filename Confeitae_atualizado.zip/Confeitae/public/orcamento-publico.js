(function () {
  'use strict';
  var panel = document.getElementById('quote-panel');
  var token = window.location.pathname.split('/').filter(Boolean).pop() || '';
  var state = null;

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char];
    });
  }
  function money(value) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(value) || 0);
  }
  function date(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(String(value || '')) ? value.split('-').reverse().join('/') : 'A combinar';
  }
  function notice(message, isError) {
    var node = document.getElementById('quote-notice');
    if (!node) return;
    node.className = 'notice' + (isError ? ' error' : '');
    node.textContent = message;
    node.classList.remove('hidden');
  }
  function render(payload) {
    state = payload;
    var quote = payload.quote || {};
    document.title = 'Orçamento de ' + (payload.business && payload.business.name || 'confeitaria');
    document.getElementById('business-brand').textContent = payload.business && payload.business.name || 'Confeitaria';
    var statusHtml = '';
    if (payload.state === 'accepted') {
      statusHtml = '<div class="notice">Orçamento aprovado. Pedido registrado' + (quote.order_code ? ' com o código ' + esc(quote.order_code) : '') + '.</div>';
    } else if (payload.state === 'rejected') {
      statusHtml = '<div class="notice">Este orçamento foi recusado. A confeitaria foi informada.</div>';
    } else if (payload.state === 'expired') {
      statusHtml = '<div class="notice error">A validade deste orçamento terminou. Entre em contato com a confeitaria para solicitar uma nova proposta.</div>';
    } else if (payload.state === 'unavailable') {
      statusHtml = '<div class="notice error">Esta proposta não está mais disponível para resposta. Entre em contato com a confeitaria.</div>';
    }
    var actions = payload.state === 'pending'
      ? '<label class="confirm"><input id="quote-confirm" type="checkbox"><span>Li a descrição, o valor e a validade e concordo com as condições apresentadas neste orçamento.</span></label><div class="actions"><button class="button primary" id="quote-accept" type="button" disabled>Aprovar orçamento</button><button class="button secondary" id="quote-reject" type="button">Recusar proposta</button></div>'
      : '';
    panel.innerHTML = '<p class="eyebrow">Proposta comercial</p><h1>Olá, ' + esc(payload.client_name || 'tudo bem?') + '!</h1><p class="subtitle">' + esc(payload.business && payload.business.name || 'A confeitaria') + ' preparou este orçamento para você.</p>' +
      '<div class="amount">' + money(quote.total) + ' <small>valor total</small></div>' +
      '<div class="facts"><div class="fact"><span>Válido até</span><strong>' + esc(date(quote.valid_until)) + '</strong></div><div class="fact"><span>Entrega desejada</span><strong>' + esc(date(quote.delivery_date)) + '</strong></div><div class="fact"><span>Unidades estimadas</span><strong>' + esc(quote.quantity || 1) + '</strong></div></div>' +
      '<p class="eyebrow">O que está incluído</p><div class="description">' + esc(quote.description) + '</div><div class="divider"></div>' + statusHtml +
      (payload.state === 'pending' ? '<div id="quote-notice" class="notice hidden" role="status"></div>' + actions : '') +
      '<p class="foot">A aprovação registra a encomenda no sistema da confeitaria. O pagamento e os detalhes finais serão combinados diretamente com ela.</p>';
    var confirmBox = document.getElementById('quote-confirm');
    var acceptButton = document.getElementById('quote-accept');
    var rejectButton = document.getElementById('quote-reject');
    if (confirmBox && acceptButton) confirmBox.addEventListener('change', function () { acceptButton.disabled = !confirmBox.checked; });
    if (acceptButton) acceptButton.addEventListener('click', function () { decide('accept', confirmBox.checked); });
    if (rejectButton) rejectButton.addEventListener('click', function () {
      if (window.confirm('Tem certeza de que deseja recusar este orçamento?')) decide('reject', false);
    });
  }
  async function decide(action, confirmed) {
    var buttons = [document.getElementById('quote-accept'), document.getElementById('quote-reject')].filter(Boolean);
    buttons.forEach(function (button) { button.disabled = true; });
    try {
      var response = await fetch('/api/quotes/public/' + encodeURIComponent(token) + '/decision', {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ action: action, confirmed: confirmed === true })
      });
      var result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Não foi possível registrar sua resposta.');
      if (result.state === 'accepted') {
        state.state = 'accepted';
        state.quote.order_code = result.order_code || null;
      } else if (result.state === 'rejected') state.state = 'rejected';
      render(state);
    } catch (error) {
      notice(error.message || 'Não foi possível registrar sua resposta.', true);
      buttons.forEach(function (button) { button.disabled = false; });
    }
  }
  async function load() {
    if (!/^[A-Za-z0-9_-]{43}$/.test(token)) {
      panel.innerHTML = '<h1>Link inválido</h1><p class="subtitle">Confira o endereço recebido e tente novamente.</p>';
      return;
    }
    try {
      var response = await fetch('/api/quotes/public/' + encodeURIComponent(token), { cache: 'no-store', headers: { 'Accept': 'application/json' } });
      var payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Não foi possível carregar o orçamento.');
      render(payload);
    } catch (error) {
      panel.innerHTML = '<p class="eyebrow">Proposta comercial</p><h1>Não foi possível abrir o orçamento</h1><div class="notice error">' + esc(error.message) + '</div><p class="subtitle">Solicite à confeitaria um novo link de aprovação.</p>';
    }
  }
  load();
}());
