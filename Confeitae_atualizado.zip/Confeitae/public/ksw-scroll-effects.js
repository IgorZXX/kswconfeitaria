/* Confeitaê — animações de rolagem com GSAP + ScrollTrigger.
   - Elementos entram com fade/deslocamento escalonado e voltam ao estado inicial
     ao sair da área visível, repetindo a animação ao subir e descer.
   - A abertura (hero) usa uma timeline; imagens de destaque têm parallax suave.
   - A tela é trocada via innerHTML, então um MutationObserver prepara cada nova tela.
   - Sem GSAP carregado ou com prefers-reduced-motion, tudo permanece visível e estático. */
(function () {
  'use strict';

  var app = document.getElementById('app');
  if (!app || !window.gsap || !window.ScrollTrigger) return;

  var gsap = window.gsap;
  var ScrollTrigger = window.ScrollTrigger;
  gsap.registerPlugin(ScrollTrigger);

  var revealSelector = [
    '.ksw-dashboard-welcome',
    '.ksw-dashboard-section-title',
    '.ksw-kpi',
    '.ksw-alert-panel',
    '.ksw-dashboard-panel',
    '.ksw-delivery-card',
    '.ksw-empty-state',
    '.ksw-footer'
  ].join(',');

  var parallaxSelector = '[data-ksw-parallax-depth], .ksw-showcase-image img, .ksw-client-showcase > img';

  var mm = gsap.matchMedia();

  mm.add('(prefers-reduced-motion: no-preference)', function () {
    var triggers = [];
    var refreshQueued = false;

    function distance() {
      return window.innerWidth <= 760 ? 22 : 34;
    }

    function track(created) {
      if (!created) return;
      (Array.isArray(created) ? created : [created]).forEach(function (item) {
        if (item) triggers.push(item);
      });
    }

    // Descarta triggers de elementos removidos pelas trocas de tela (evita vazamento).
    function prune() {
      triggers = triggers.filter(function (st) {
        var el = st.trigger;
        if (el && !el.isConnected) {
          st.kill();
          return false;
        }
        return true;
      });
    }

    function queueRefresh() {
      if (refreshQueued) return;
      refreshQueued = true;
      requestAnimationFrame(function () {
        refreshQueued = false;
        ScrollTrigger.refresh();
      });
    }

    function hide(targets) {
      gsap.set(targets, { autoAlpha: 0, y: distance(), scale: 0.985, overwrite: true });
    }

    function show(targets) {
      gsap.to(targets, {
        autoAlpha: 1,
        y: 0,
        scale: 1,
        duration: 0.85,
        ease: 'power3.out',
        stagger: 0.08,
        overwrite: true,
        onComplete: function () {
          // Devolve o controle do transform ao CSS (hover dos cartões, etc.).
          gsap.set(targets, { clearProps: 'transform' });
          targets.forEach(function (el) { el.classList.remove('ksw-animating'); });
        }
      });
    }

    function setupReveal(elements) {
      if (!elements.length) return;
      elements.forEach(function (el) { el.classList.add('ksw-scroll-reveal', 'ksw-animating'); });
      hide(elements);
      track(ScrollTrigger.batch(elements, {
        start: 'top 100%',
        end: 'bottom 8%',
        onEnter: function (batch) { show(batch); },
        onEnterBack: function (batch) { show(batch); },
        onLeave: function (batch) {
          batch.forEach(function (el) { el.classList.add('ksw-animating'); });
          hide(batch);
        },
        onLeaveBack: function (batch) {
          batch.forEach(function (el) { el.classList.add('ksw-animating'); });
          hide(batch);
        }
      }));
    }

    // Abertura da página: textos em sequência e imagem entrando pela direita.
    function setupHero(hero) {
      var copy = hero.querySelector('.ksw-hero-copy');
      var art = hero.querySelector('.ksw-hero-art');
      var copyItems = copy ? Array.prototype.slice.call(copy.children) : [];
      var floating = art ? Array.prototype.slice.call(art.querySelectorAll('.ksw-floating-card')) : [];
      var image = art ? art.querySelector(':scope > img') : null;

      gsap.set(copyItems, { autoAlpha: 0, y: 26 });
      if (image) gsap.set(image, { autoAlpha: 0, x: 40, scale: 0.96 });
      gsap.set(floating, { autoAlpha: 0, y: 16, scale: 0.92 });

      var tl = gsap.timeline({
        defaults: { ease: 'power3.out' },
        scrollTrigger: { trigger: hero, start: 'top 85%', once: true },
        onComplete: function () {
          gsap.set(copyItems.concat(image ? [image] : [], floating), { clearProps: 'transform' });
        }
      });
      tl.to(copyItems, { autoAlpha: 1, y: 0, duration: 0.8, stagger: 0.1 }, 0.05);
      if (image) tl.to(image, { autoAlpha: 1, x: 0, scale: 1, duration: 1.1 }, 0.2);
      if (floating.length) {
        tl.to(floating, { autoAlpha: 1, y: 0, scale: 1, duration: 0.7, stagger: 0.14, ease: 'back.out(1.6)' }, 0.75);
      }
      track(tl.scrollTrigger);
    }

    // Camadas próximas se deslocam mais, sem alterar o layout do conteúdo.
    function setupParallax(images) {
      images.forEach(function (img) {
        var depth = Number(img.dataset.kswParallaxDepth);
        var mobile = window.innerWidth <= 760;
        var offset = Number.isFinite(depth) && depth > 0
          ? Math.min(depth * (mobile ? 4.8 : 8), mobile ? 14 : 24)
          : (mobile ? 5 : 9);
        var tween = gsap.fromTo(img,
          { yPercent: -offset, force3D: true },
          {
            yPercent: offset,
            ease: 'none',
            scrollTrigger: {
              trigger: img.parentElement,
              start: 'top bottom',
              end: 'bottom top',
              scrub: mobile ? 0.45 : 0.7
            }
          });
        track(tween.scrollTrigger);
      });
    }

    function setupHeroDepth(heroes) {
      heroes.forEach(function (hero) {
        var art = hero.querySelector('.ksw-hero-art');
        if (!art) return;
        var mobile = window.innerWidth <= 760;
        var tween = gsap.fromTo(art, { y: mobile ? 14 : 34 }, {
          y: mobile ? -14 : -34,
          ease: 'none',
          scrollTrigger: { trigger: hero, start: 'top bottom', end: 'bottom top', scrub: mobile ? 0.5 : 0.8 }
        });
        track(tween.scrollTrigger);
      });
    }

    function setupLandingScenes(scenes) {
      scenes.forEach(function (scene) {
        var tween = gsap.fromTo(scene,
          { autoAlpha: 0.22, y: 90 },
          {
            autoAlpha: 1,
            y: 0,
            ease: 'none',
            scrollTrigger: {
              trigger: scene,
              start: 'top 94%',
              end: 'top 34%',
              scrub: 0.5
            }
          });
        track(tween.scrollTrigger);
      });
    }

    // A montagem dos dispositivos é feita por CSS (@keyframes) e depende da classe
    // ksw-is-visible; o ScrollTrigger liga e desliga essa classe ao entrar/sair da tela.
    function setupDevices(stages) {
      stages.forEach(function (el) {
        track(ScrollTrigger.create({
          trigger: el,
          start: 'top 88%',
          end: 'bottom 6%',
          onToggle: function (self) { el.classList.toggle('ksw-is-visible', self.isActive); }
        }));
      });
    }

    function collect(root, selector) {
      var found = [];
      if (root.nodeType === 1 && root.matches && root.matches(selector)) found.push(root);
      if (root.querySelectorAll) {
        found = found.concat(Array.prototype.slice.call(root.querySelectorAll(selector)));
      }
      return found.filter(function (el) {
        if (el.dataset.kswGsapReady === 'true') return false;
        el.dataset.kswGsapReady = 'true';
        return true;
      });
    }

    function prepare(root) {
      if (!root || root.nodeType !== 1) return;
      prune();
      var heroes = collect(root, '.ksw-hero');
      var reveals = collect(root, revealSelector);
      var images = collect(root, parallaxSelector);
      var devices = collect(root, '.ksw-device-image');
      var scenes = collect(root, '.ksw-screen-scene');
      heroes.forEach(setupHero);
      setupHeroDepth(heroes);
      setupReveal(reveals);
      setupParallax(images);
      setupDevices(devices);
      setupLandingScenes(scenes);
      if (heroes.length || reveals.length || images.length || devices.length || scenes.length) queueRefresh();
    }

    var mutations = new MutationObserver(function (records) {
      records.forEach(function (record) {
        record.addedNodes.forEach(prepare);
      });
    });
    mutations.observe(app, { childList: true, subtree: true });
    prepare(app);

    // Imagens que terminam de carregar mudam a altura da página.
    app.addEventListener('load', queueRefresh, true);

    // Chamado automaticamente quando o usuário ativa "reduzir movimento".
    return function cleanup() {
      mutations.disconnect();
      app.removeEventListener('load', queueRefresh, true);
      triggers.forEach(function (st) { st.kill(); });
      triggers = [];
      var animated = app.querySelectorAll('[data-ksw-gsap-ready]');
      gsap.killTweensOf(animated);
      gsap.set(animated, { clearProps: 'all' });
      Array.prototype.forEach.call(animated, function (el) {
        el.classList.remove('ksw-scroll-reveal', 'ksw-animating', 'ksw-is-visible');
        delete el.dataset.kswGsapReady;
      });
    };
  });
})();
