/* Confeitaê — regras puras de estoque, lotes e produção. */
(function (root, factory) {
  const costing = typeof module === 'object' && module.exports
    ? require('./costing')
    : root.KSWCosting;
  const api = factory(costing);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.KSWProduction = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (costing) {
  'use strict';

  function n(value) {
    if (costing && typeof costing.parseNumber === 'function') return costing.parseNumber(value);
    const parsed = Number(String(value == null ? '' : value).replace(',', '.'));
    return Number.isFinite(parsed) ? parsed : NaN;
  }

  function round(value, places = 6) {
    const factor = Math.pow(10, places);
    return Math.round((Number(value) + Number.EPSILON) * factor) / factor;
  }

  function itemStock(item) {
    return n(item && (item.est != null ? item.est : item.estoque));
  }

  function lotQuantity(lot) {
    const value = lot && (lot.quantidade_disponivel != null
      ? lot.quantidade_disponivel
      : lot.disponivel != null ? lot.disponivel : lot.qtd);
    const parsed = n(value);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : 0;
  }

  function aggregateOrderItems(orderItems) {
    const grouped = new Map();
    (Array.isArray(orderItems) ? orderItems : []).forEach((item) => {
      if (!item || typeof item !== 'object') return;
      const productId = String(item.pid || item.product_id || '').trim();
      const quantity = n(item.q != null ? item.q : item.quantity);
      if (!productId || !(quantity > 0) || quantity > 100000) return;
      const current = grouped.get(productId) || { pid: productId, q: 0 };
      current.q = round(current.q + quantity, 6);
      grouped.set(productId, current);
    });
    return Array.from(grouped.values());
  }

  function estimateConsumptionCost(allocation, lots, legacyUnitCost) {
    if (!allocation || !allocation.valid) return NaN;
    const fallback = n(legacyUnitCost);
    const fallbackCost = Number.isFinite(fallback) && fallback >= 0 ? fallback : 0;
    const lotList = Array.isArray(lots) ? lots : [];
    let total = (Number(allocation.legacy_used) || 0) * fallbackCost;
    (Array.isArray(allocation.lot_updates) ? allocation.lot_updates : []).forEach((update) => {
      const lot = lotList.find((entry) => String(entry.id) === String(update.id));
      const rawCost = lot && lot.custo_unitario != null ? n(lot.custo_unitario) : fallbackCost;
      const unitCost = Number.isFinite(rawCost) && rawCost >= 0 ? rawCost : fallbackCost;
      total += (Number(update.consumed) || 0) * unitCost;
    });
    return round(total, 2);
  }

  function buildProductionPlan(product, requestedQuantity, ingredients, packagings) {
    const requested = n(requestedQuantity);
    const errors = [];
    if (!product || typeof product !== 'object') errors.push('Produto não encontrado.');
    if (!(requested > 0) || requested > 100000) errors.push('Informe uma quantidade entre 0 e 100.000 unidades.');
    if (!errors.length && (!Array.isArray(product.itens) || product.itens.length === 0)) {
      errors.push('O produto não possui ficha técnica de ingredientes.');
    }

    const calculation = !errors.length && costing
      ? costing.calculateRecipe(product, ingredients)
      : { valid: false, errors: ['Não foi possível calcular a ficha técnica.'] };
    if (!calculation.valid) errors.push(...calculation.errors);
    if (errors.length) return { valid: false, errors };

    const batches = Math.ceil(requested / calculation.yield);
    const producedQuantity = round(batches * calculation.yield, 6);
    const materialRequirements = calculation.items.map((entry) => ({
      item_type: 'ingrediente',
      item_id: entry.ingredientId,
      name: entry.name,
      unit: entry.purchaseUnit,
      quantity: round(entry.purchaseQuantity * batches, 6),
      unit_cost: entry.unitPrice
    }));

    let packagingRequirement = null;
    const packagingId = String(product.embalagem_id || product.packaging_id || '').trim();
    const packagingPerUnit = n(product.embalagem_qtd != null ? product.embalagem_qtd : product.packaging_qty);
    if (packagingId || (Number.isFinite(packagingPerUnit) && packagingPerUnit > 0)) {
      if (!packagingId || !(packagingPerUnit > 0)) {
        return { valid: false, errors: ['Selecione uma embalagem e informe a quantidade usada por unidade.'] };
      }
      const list = Array.isArray(packagings) ? packagings : [];
      const packaging = list.find((entry) => String(entry.id) === packagingId);
      if (!packaging) return { valid: false, errors: ['A embalagem selecionada não está cadastrada.'] };
      packagingRequirement = {
        item_type: 'embalagem',
        item_id: packagingId,
        name: String(packaging.nome || packaging.name || 'Embalagem'),
        unit: String(packaging.un || 'un'),
        quantity: round(producedQuantity * packagingPerUnit, 6),
        unit_cost: n(packaging.preco)
      };
    }

    const recipeUnitCost = n(calculation.unitCost);
    const packagingUnitCost = packagingRequirement ? packagingRequirement.unit_cost * packagingPerUnit : 0;
    const unitCost = Number.isFinite(recipeUnitCost) && recipeUnitCost >= 0
      ? round(recipeUnitCost + (Number.isFinite(packagingUnitCost) ? packagingUnitCost : 0), 6)
      : 0;
    return {
      valid: true,
      errors: [],
      requested_quantity: requested,
      produced_quantity: producedQuantity,
      batches,
      yield_per_batch: calculation.yield,
      materials: materialRequirements,
      packaging: packagingRequirement,
      estimated_unit_cost: unitCost,
      estimated_total_cost: round(unitCost * producedQuantity, 2)
    };
  }

  function validateProducedQuantity(value, plannedQuantity) {
    const planned = n(plannedQuantity);
    if (!(planned > 0) || !Number.isFinite(planned)) return { valid: false, error: 'Quantidade planejada inválida.' };
    if (value == null || String(value).trim() === '') return { valid: true, quantity: round(planned, 6), usedDefault: true };
    const actual = n(value);
    if (!Number.isFinite(actual) || !(actual > 0)) return { valid: false, error: 'Informe a quantidade efetivamente produzida.' };
    if (actual > planned + 1e-8) return { valid: false, error: 'A quantidade produzida não pode ultrapassar a capacidade planejada com os materiais desta ordem.' };
    return { valid: true, quantity: round(actual, 6), usedDefault: false };
  }

  function calculateDemandShortages(input = {}, today) {
    const orders = Array.isArray(input.orders) ? input.orders : [];
    const productions = Array.isArray(input.productions) ? input.productions : [];
    const products = Array.isArray(input.products) ? input.products : [];
    const ingredients = Array.isArray(input.ingredients) ? input.ingredients : [];
    const packagings = Array.isArray(input.packagings) ? input.packagings : [];
    const lots = Array.isArray(input.lots) ? input.lots : [];
    const currentDate = String(today || new Date().toISOString().slice(0, 10));
    const productById = new Map(products.map((product) => [String(product.id), product]));
    const productionByOrderProduct = new Set();
    const demands = [];
    const skipped = [];
    const materialTotals = new Map();

    const isCancelled = (value) => ['cancelado', 'cancelada', 'cancelled'].includes(String(value || '').trim().toLowerCase());
    const isFinished = (entry) => Boolean(entry && (entry.consumo_aplicado === true || ['concluida', 'concluido', 'entregue', 'finished'].includes(String(entry.status || entry.st || '').trim().toLowerCase())));
    const isActiveProduction = (entry) => entry && !isCancelled(entry.status) && !isFinished(entry) && ['planejada', 'em_producao', 'planned', 'in_progress', ''].includes(String(entry.status || '').trim().toLowerCase());

    productions.forEach((entry) => {
      if (!entry || !entry.pedido_id || !entry.produto_id || isCancelled(entry.status)) return;
      productionByOrderProduct.add(`${String(entry.pedido_id)}:${String(entry.produto_id)}`);
    });

    orders.forEach((order) => {
      if (!order || isCancelled(order.st) || ['entregue', 'concluida', 'concluido', 'finalizado'].includes(String(order.st || '').trim().toLowerCase())) return;
      (Array.isArray(order.itens) ? order.itens : []).forEach((line) => {
        const productId = String(line && (line.pid || line.product_id) || '').trim();
        const quantity = n(line && (line.q != null ? line.q : line.quantity));
        if (!productId || !(quantity > 0) || quantity > 100000) return;
        if (productionByOrderProduct.has(`${String(order.id)}:${productId}`)) return;
        demands.push({ productId, quantity, source: 'pedido', reference: String(order.id || '') });
      });
    });

    productions.forEach((entry) => {
      if (!isActiveProduction(entry)) return;
      const quantity = n(entry.quantidade != null ? entry.quantidade : entry.quantidade_prevista);
      const productId = String(entry.produto_id || '').trim();
      if (!productId || !(quantity > 0) || quantity > 100000) return;
      demands.push({ productId, quantity, source: 'producao', reference: String(entry.id || '') });
    });

    function addMaterial(material) {
      if (!material || !material.item_id) return;
      const type = material.item_type || 'ingrediente';
      const key = `${type}:${String(material.item_id)}`;
      const previous = materialTotals.get(key) || {
        item_type: type,
        item_id: String(material.item_id),
        name: String(material.name || 'Item'),
        unit: String(material.unit || 'un'),
        required: 0
      };
      previous.required = round(previous.required + n(material.quantity), 6);
      materialTotals.set(key, previous);
    }

    demands.forEach((demand) => {
      const product = productById.get(demand.productId);
      if (!product) {
        skipped.push({ product_id: demand.productId, reason: 'Produto não encontrado na ficha técnica.' });
        return;
      }
      const plan = buildProductionPlan(product, demand.quantity, ingredients, packagings);
      if (!plan.valid) {
        skipped.push({ product_id: demand.productId, product_name: String(product.nome || 'Produto'), reason: plan.errors[0] || 'Ficha técnica incompleta.' });
        return;
      }
      plan.materials.forEach(addMaterial);
      if (plan.packaging) addMaterial({
        item_type: 'embalagem', item_id: plan.packaging.item_id,
        name: plan.packaging.name, unit: plan.packaging.unit,
        quantity: plan.packaging.quantity
      });
    });

    const inventoryItem = (type, id) => (type === 'embalagem' ? packagings : ingredients)
      .find((entry) => String(entry.id) === String(id));

    const items = Array.from(materialTotals.values()).map((entry) => {
      const item = inventoryItem(entry.item_type, entry.item_id);
      if (!item) return { ...entry, available: 0, shortage: entry.required, found_in_inventory: false };
      const stock = n(item.est != null ? item.est : item.estoque);
      const safeStock = Number.isFinite(stock) && stock > 0 ? stock : 0;
      const itemLots = lots.filter((lot) => lot.item_tipo === entry.item_type && String(lot.item_id) === entry.item_id);
      const tracked = itemLots.reduce((sum, lot) => sum + lotQuantity(lot), 0);
      const legacy = Math.max(0, safeStock - tracked);
      const validLots = itemLots.reduce((sum, lot) => {
        const expiry = String(lot.validade || lot.expiry || '');
        return sum + (lotQuantity(lot) > 0 && (!expiry || expiry >= currentDate) ? lotQuantity(lot) : 0);
      }, 0);
      const available = round(legacy + validLots, 6);
      return {
        ...entry,
        available,
        shortage: round(Math.max(0, entry.required - available), 6),
        found_in_inventory: true
      };
    }).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

    return {
      items,
      shortages: items.filter((item) => item.shortage > 1e-8),
      skipped,
      demand_count: demands.length,
      considered_orders: new Set(demands.filter((entry) => entry.source === 'pedido').map((entry) => entry.reference)).size,
      considered_productions: demands.filter((entry) => entry.source === 'producao').length
    };
  }

  // Planeja consumo FEFO (primeiro vence, primeiro sai). Estoque antigo sem lote
  // permanece utilizável como saldo legado; lotes vencidos nunca são consumidos.
  function planLotConsumption(lots, totalStock, requestedQuantity, today) {
    const stock = n(totalStock);
    const requested = n(requestedQuantity);
    const currentDate = String(today || new Date().toISOString().slice(0, 10));
    if (!(stock >= 0)) return { valid: false, error: 'Saldo de estoque inválido.' };
    if (!(requested > 0)) return { valid: false, error: 'Quantidade de saída inválida.' };
    if (requested > stock + 1e-8) return { valid: false, error: 'Estoque insuficiente.' };

    const sourceLots = Array.isArray(lots) ? lots : [];
    const trackedTotal = sourceLots.reduce((sum, lot) => sum + lotQuantity(lot), 0);
    const legacyAvailable = Math.max(0, stock - trackedTotal);
    const eligible = sourceLots
      .map((lot) => ({ lot, available: lotQuantity(lot), expiry: String(lot.validade || lot.expiry || '') }))
      .filter((entry) => entry.available > 0 && (!entry.expiry || entry.expiry >= currentDate))
      .sort((a, b) => {
        if (a.expiry && b.expiry && a.expiry !== b.expiry) return a.expiry.localeCompare(b.expiry);
        if (a.expiry && !b.expiry) return -1;
        if (!a.expiry && b.expiry) return 1;
        return String(a.lot.recebido_em || a.lot.received_at || '').localeCompare(String(b.lot.recebido_em || b.lot.received_at || '')) || String(a.lot.id).localeCompare(String(b.lot.id));
      });

    const eligibleTotal = eligible.reduce((sum, entry) => sum + entry.available, 0) + legacyAvailable;
    if (requested > eligibleTotal + 1e-8) {
      return { valid: false, error: 'Estoque válido insuficiente. Verifique os lotes vencidos e as quantidades cadastradas.' };
    }

    let remaining = requested;
    const updates = [];
    for (const entry of eligible) {
      if (remaining <= 1e-8) break;
      const used = Math.min(entry.available, remaining);
      if (used > 0) {
        const next = round(entry.available - used, 6);
        updates.push({ id: String(entry.lot.id), quantidade_disponivel: next, consumed: round(used, 6) });
        remaining = round(remaining - used, 6);
      }
    }
    const legacyUsed = round(Math.min(legacyAvailable, remaining), 6);
    remaining = round(remaining - legacyUsed, 6);
    if (remaining > 1e-6) return { valid: false, error: 'Não foi possível alocar todo o consumo aos lotes.' };

    return {
      valid: true,
      requested: round(requested, 6),
      lot_updates: updates,
      legacy_used: legacyUsed,
      available_before: round(eligibleTotal, 6),
      stock_after: round(stock - requested, 6)
    };
  }

  // Lista de compras única: junta o que falta para os pedidos/produções em aberto
  // com a reposição até o estoque mínimo, sem contar o mesmo item duas vezes.
  // Quantidade a comprar = necessário + mínimo − disponível (só estoque aproveitável).
  // Preço ausente nunca vira zero: o item fica sem custo e a lista é marcada como parcial.
  function buildShoppingList(input = {}, today) {
    const ingredients = Array.isArray(input.ingredients) ? input.ingredients : [];
    const packagings = Array.isArray(input.packagings) ? input.packagings : [];
    const lots = Array.isArray(input.lots) ? input.lots : [];
    const currentDate = String(today || new Date().toISOString().slice(0, 10));
    const demand = calculateDemandShortages(input, currentDate);
    const requiredByKey = new Map(demand.items.map((entry) => [`${entry.item_type}:${entry.item_id}`, entry.required]));

    function usableStock(item, type) {
      const stock = n(item.est != null ? item.est : item.estoque);
      const safeStock = Number.isFinite(stock) && stock > 0 ? stock : 0;
      const itemLots = lots.filter((lot) => lot.item_tipo === type && String(lot.item_id) === String(item.id));
      const tracked = itemLots.reduce((sum, lot) => sum + lotQuantity(lot), 0);
      const validLots = itemLots.reduce((sum, lot) => {
        const expiry = String(lot.validade || lot.expiry || '');
        return sum + (!expiry || expiry >= currentDate ? lotQuantity(lot) : 0);
      }, 0);
      return round(Math.max(0, safeStock - tracked) + validLots, 6);
    }

    const rows = [];
    const collect = (source, type) => source.forEach((item) => {
      if (!item || item.id == null) return;
      const required = requiredByKey.get(`${type}:${String(item.id)}`) || 0;
      const minimumRaw = n(item.min);
      const minimum = Number.isFinite(minimumRaw) && minimumRaw > 0 ? minimumRaw : 0;
      const available = usableStock(item, type);
      const quantity = round(Math.max(0, required + minimum - available), 6);
      if (quantity <= 1e-8) return;
      const price = n(item.preco);
      const hasPrice = Number.isFinite(price) && price >= 0;
      rows.push({
        item_type: type,
        item_id: String(item.id),
        name: String(item.nome || item.name || 'Item'),
        unit: String(item.un || 'un'),
        required,
        minimum,
        available,
        quantity,
        reason: required > available + 1e-8 ? 'pedidos' : 'minimo',
        unit_price: hasPrice ? price : null,
        estimated_cost: hasPrice ? round(quantity * price, 2) : null
      });
    });
    collect(ingredients, 'ingrediente');
    collect(packagings, 'embalagem');
    rows.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));

    const missingPrice = rows.filter((row) => row.estimated_cost == null).length;
    return {
      items: rows,
      total_estimated: round(rows.reduce((sum, row) => sum + (row.estimated_cost || 0), 0), 2),
      missing_price_count: missingPrice,
      skipped: demand.skipped,
      partial: missingPrice > 0 || demand.skipped.length > 0
    };
  }

  // Texto simples da lista de compras para copiar ou enviar (WhatsApp, anotações).
  function formatShoppingListText(shopping, title) {
    const rows = shopping && Array.isArray(shopping.items) ? shopping.items : [];
    if (!rows.length) return '';
    const num = (value) => Number(value).toLocaleString('pt-BR', { maximumFractionDigits: 3 });
    const money = (value) => Number(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    const lines = [String(title || 'Lista de compras')];
    rows.forEach((row) => {
      const cost = row.estimated_cost == null ? ' (preço não cadastrado)' : ` (≈ ${money(row.estimated_cost)})`;
      lines.push(`• ${row.name}: ${num(row.quantity)} ${row.unit}${cost}`);
    });
    lines.push(`Custo estimado: ${shopping.partial ? 'pelo menos ' : ''}${money(shopping.total_estimated)}`);
    return lines.join('\n');
  }

  return { buildProductionPlan, validateProducedQuantity, planLotConsumption, aggregateOrderItems, estimateConsumptionCost, calculateDemandShortages, buildShoppingList, formatShoppingListText, round, itemStock, lotQuantity };
});
