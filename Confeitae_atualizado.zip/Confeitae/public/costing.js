/* Confeitaê — motor de custos e fichas técnicas (v2)
 * Regras puras, compartilhadas pelo navegador e pelos testes Node.js.
 * Valores de ingredientes são informados por unidade de compra cadastrada.
 * Custos adicionais do produto são valores por unidade produzida, preservando
 * o comportamento das fichas antigas (emb, mo, en e out).
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.KSWCosting = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const UNIT_META = {
    mg: { category: 'mass', factor: 0.001, label: 'mg' },
    g: { category: 'mass', factor: 1, label: 'g' },
    kg: { category: 'mass', factor: 1000, label: 'kg' },
    ml: { category: 'volume', factor: 1, label: 'ml' },
    l: { category: 'volume', factor: 1000, label: 'L' },
    un: { category: 'count', factor: 1, label: 'un' },
    unidade: { category: 'count', factor: 1, label: 'unidade' },
    unidades: { category: 'count', factor: 1, label: 'unidades' },
    und: { category: 'count', factor: 1, label: 'und' },
    dz: { category: 'count', factor: 12, label: 'dúzia' },
    duzia: { category: 'count', factor: 12, label: 'dúzia' },
    dúzia: { category: 'count', factor: 12, label: 'dúzia' }
  };

  function parseNumber(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : NaN;
    let raw = String(value == null ? '' : value).trim().replace(/\s/g, '');
    if (!raw) return NaN;
    // Aceita 1.234,56 (pt-BR), 1234,56 e 1234.56.
    if (raw.includes(',') && raw.includes('.')) raw = raw.replace(/\./g, '').replace(',', '.');
    else if (raw.includes(',')) raw = raw.replace(',', '.');
    const n = Number(raw);
    return Number.isFinite(n) ? n : NaN;
  }

  function normalizeUnit(unit) {
    const raw = String(unit == null ? '' : unit).trim().toLowerCase();
    const key = raw.normalize ? raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : raw;
    const aliases = {
      quilo: 'kg', quilos: 'kg', quilograma: 'kg', quilogramas: 'kg',
      grama: 'g', gramas: 'g', gr: 'g',
      miligrama: 'mg', miligramas: 'mg',
      litro: 'l', litros: 'l', lt: 'l',
      mililitro: 'ml', mililitros: 'ml',
      unidade: 'unidade', unidades: 'unidades', unid: 'und', unidade_s: 'unidades',
      duzia: 'duzia', dozenas: 'duzia'
    };
    return aliases[key] || key;
  }

  function unitMeta(unit) {
    const normalized = normalizeUnit(unit);
    return UNIT_META[normalized] || { category: 'custom:' + normalized, factor: 1, label: String(unit || '').trim() };
  }

  function compatibleUnits(unit) {
    const meta = unitMeta(unit);
    if (meta.category === 'mass') return ['g', 'kg'];
    if (meta.category === 'volume') return ['ml', 'L'];
    if (meta.category === 'count') return ['un', 'dúzia'];
    return [String(unit || 'un').trim() || 'un'];
  }

  function convertQuantity(quantity, fromUnit, toUnit) {
    const qty = parseNumber(quantity);
    if (!Number.isFinite(qty)) return null;
    const from = unitMeta(fromUnit);
    const to = unitMeta(toUnit);
    if (from.category !== to.category) return null;
    if (from.category.indexOf('custom:') === 0 && normalizeUnit(fromUnit) !== normalizeUnit(toUnit)) return null;
    return qty * from.factor / to.factor;
  }

  function roundMoney(value) {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return NaN;
    // Compensa resíduos binários (ex.: 7,90 - 5% - 8,00 = -0,495).
    const epsilon = 1e-9 * Math.max(1, Math.abs(amount));
    return Math.round((amount + Math.sign(amount || 1) * epsilon) * 100) / 100;
  }

  function calculateRecipe(recipe, ingredients) {
    const source = recipe && typeof recipe === 'object' ? recipe : {};
    const yieldQty = parseNumber(source.rend);
    const rows = Array.isArray(source.itens) ? source.itens : [];
    const available = Array.isArray(ingredients) ? ingredients : [];
    const errors = [];
    const details = [];

    if (!(yieldQty > 0)) errors.push('Informe um rendimento maior que zero.');
    if (!rows.length) errors.push('Adicione ao menos um ingrediente à ficha técnica.');

    let ingredientBatchCost = 0;
    rows.forEach((item, index) => {
      const ingredient = available.find((entry) => entry && String(entry.id) === String(item && item.ing));
      if (!ingredient) {
        errors.push('Ingrediente ' + (index + 1) + ': selecione um ingrediente cadastrado.');
        return;
      }

      const qty = parseNumber(item.qtd);
      if (!(qty > 0)) {
        errors.push('Ingrediente ' + ingredient.nome + ': informe uma quantidade maior que zero.');
        return;
      }

      const purchaseUnit = String(ingredient.un || 'un').trim() || 'un';
      const recipeUnit = String((item && (item.un || item.unidade)) || purchaseUnit).trim() || purchaseUnit;
      const convertedQty = convertQuantity(qty, recipeUnit, purchaseUnit);
      if (convertedQty == null) {
        errors.push('Ingrediente ' + ingredient.nome + ': não é possível converter ' + recipeUnit + ' para ' + purchaseUnit + '.');
        return;
      }

      const unitPrice = parseNumber(ingredient.preco);
      if (!(unitPrice >= 0)) {
        errors.push('Ingrediente ' + ingredient.nome + ': preço por ' + purchaseUnit + ' inválido.');
        return;
      }

      const lineCost = convertedQty * unitPrice;
      ingredientBatchCost += lineCost;
      details.push({
        ingredientId: String(ingredient.id),
        name: String(ingredient.nome || 'Ingrediente'),
        quantity: qty,
        recipeUnit,
        purchaseQuantity: convertedQty,
        purchaseUnit,
        unitPrice,
        lineCost
      });
    });

    const additions = {
      packaging: parseNumber(source.emb == null ? 0 : source.emb),
      labor: parseNumber(source.mo == null ? 0 : source.mo),
      utilities: parseNumber(source.en == null ? 0 : source.en),
      other: parseNumber(source.out == null ? 0 : source.out)
    };
    Object.keys(additions).forEach((key) => {
      if (!(additions[key] >= 0)) errors.push('O custo adicional (' + key + ') não pode ser negativo.');
    });

    const additionsPerUnit = Object.values(additions).reduce((sum, value) => sum + (Number.isFinite(value) ? value : 0), 0);
    const ingredientsPerUnit = yieldQty > 0 ? ingredientBatchCost / yieldQty : 0;
    const unitCost = ingredientsPerUnit + additionsPerUnit;
    const batchCost = ingredientBatchCost + additionsPerUnit * (yieldQty > 0 ? yieldQty : 0);

    return {
      valid: errors.length === 0,
      errors,
      yield: yieldQty,
      items: details,
      ingredientsBatch: ingredientBatchCost,
      ingredientsPerUnit,
      additions,
      additionsPerUnit,
      unitCost,
      batchCost,
      rounded: {
        ingredientsBatch: roundMoney(ingredientBatchCost),
        ingredientsPerUnit: roundMoney(ingredientsPerUnit),
        additionsPerUnit: roundMoney(additionsPerUnit),
        unitCost: roundMoney(unitCost),
        batchCost: roundMoney(batchCost)
      }
    };
  }

  function calculateProductCost(product, ingredients, packagings) {
    const source = product && typeof product === 'object' ? Object.assign({}, product) : {};
    const packagingId = String(source.embalagem_id || '').trim();
    const packagingQuantity = parseNumber(source.embalagem_qtd);
    const packaging = (Array.isArray(packagings) ? packagings : [])
      .find((entry) => entry && String(entry.id) === packagingId);

    if (packagingId && !packaging) {
      return { valid: false, errors: ['A embalagem vinculada não está cadastrada.'] };
    }
    if (packagingId && !(packagingQuantity > 0)) {
      return { valid: false, errors: ['Informe uma quantidade de embalagem maior que zero.'] };
    }
    if (packaging) {
      const packagingPrice = parseNumber(packaging.preco);
      if (!(packagingPrice >= 0)) {
        return { valid: false, errors: ['O preço da embalagem vinculada é inválido.'] };
      }
      source.emb = parseNumber(source.emb == null ? 0 : source.emb) + packagingPrice * packagingQuantity;
    }
    return calculateRecipe(source, ingredients);
  }

  function hasKnownVariableFee(source) {
    if (!source || typeof source !== 'object') return false;
    if (source.taxa_venda_informada === true) return true;
    if (source.taxa_venda_informada === false) return false;
    const value = parseNumber(source.taxa_venda_pct);
    // Compatibilidade: percentuais positivos anteriores à flag são dados informados.
    // Zero legado é ambíguo e não deve ser tratado como taxa confirmada.
    return Number.isFinite(value) && value > 0;
  }

  // Converte o tempo ativo de preparo do lote em mão de obra por unidade.
  // A confeiteira informa a remuneração/hora e o tempo do lote; o motor divide
  // pelo rendimento para evitar exigir contas manuais por unidade.
  function calculateLaborCostPerUnit(hourlyRate, activeMinutes, yieldQuantity) {
    const hourly = parseNumber(hourlyRate);
    const minutes = parseNumber(activeMinutes);
    const yieldQty = parseNumber(yieldQuantity);
    const errors = [];
    if (!(hourly > 0)) errors.push('Informe um valor por hora maior que zero.');
    if (!(minutes >= 0)) errors.push('Informe os minutos de trabalho do lote.');
    if (!(yieldQty > 0)) errors.push('Informe o rendimento do lote maior que zero.');
    if (errors.length) return { valid: false, hourlyRate: null, activeMinutes: null, yield: null, batchCost: null, costPerUnit: null, errors };
    const batchCost = hourly * minutes / 60;
    return {
      valid: true,
      hourlyRate: roundMoney(hourly),
      activeMinutes: minutes,
      yield: yieldQty,
      batchCost: roundMoney(batchCost),
      costPerUnit: roundMoney(batchCost / yieldQty),
      errors: []
    };
  }

  function suggestPrice(unitCost, targetMargin, variableFeePercent) {
    const cost = parseNumber(unitCost);
    const margin = parseNumber(targetMargin);
    const feePercent = variableFeePercent == null || variableFeePercent === '' ? 0 : parseNumber(variableFeePercent);
    if (!(cost >= 0) || !Number.isFinite(margin) || !(feePercent >= 0) || feePercent >= 100) return null;
    const safeMargin = Math.min(90, Math.max(0, margin));
    const retainedPercent = 1 - (safeMargin + feePercent) / 100;
    if (!(retainedPercent > 0)) return null;
    return cost / retainedPercent;
  }

  // Rateio gerencial das despesas fixas: divide o total mensal pela previsão
  // de unidades vendáveis no mês. Não cria lançamentos no caixa/contas a pagar.
  function calculateFixedCostAllocation(fixedCosts, expectedMonthlyUnits) {
    const rows = Array.isArray(fixedCosts) ? fixedCosts : [];
    const errors = [];
    let monthlyTotal = 0;
    let activeCount = 0;
    rows.forEach((row, index) => {
      if (!row || row.active === false || row.enabled === false) return;
      const name = String(row.name == null ? row.nome || '' : row.name).trim();
      const rawValue = row.monthly_value != null ? row.monthly_value : row.valor_mensal;
      if (!name && (rawValue == null || String(rawValue).trim() === '')) return;
      const value = parseNumber(rawValue);
      if (!name) errors.push('Despesa fixa ' + (index + 1) + ': informe uma descrição.');
      if (!(value >= 0)) errors.push('Despesa fixa ' + (index + 1) + ': informe um valor mensal válido.');
      if (name && value >= 0) {
        monthlyTotal += value;
        activeCount += 1;
      }
    });
    const expectedUnits = expectedMonthlyUnits == null || expectedMonthlyUnits === '' ? NaN : parseNumber(expectedMonthlyUnits);
    if (monthlyTotal > 0 && !(expectedUnits > 0)) {
      errors.push('Informe quantas unidades você espera vender/produzir por mês para ratear as despesas fixas.');
    }
    if (Number.isFinite(expectedUnits) && expectedUnits < 0) {
      errors.push('A previsão mensal de unidades não pode ser negativa.');
    }
    const valid = errors.length === 0;
    const costPerUnit = valid && monthlyTotal > 0 && expectedUnits > 0 ? monthlyTotal / expectedUnits : valid ? 0 : null;
    return {
      valid,
      configured: activeCount > 0 && monthlyTotal > 0,
      itemCount: activeCount,
      monthlyTotal: roundMoney(monthlyTotal),
      expectedMonthlyUnits: Number.isFinite(expectedUnits) ? expectedUnits : null,
      costPerUnit: costPerUnit == null ? null : roundMoney(costPerUnit),
      errors
    };
  }

  // Calcula a contribuição estimada depois dos custos diretos da ficha e das
  // taxas/impostos percentuais que a confeiteira informar. Não é lucro líquido
  // contábil: despesas fixas só entram quando houver rateio válido confirmado.
  function assessProfitability(unitCost, sellingPrice, options) {
    const config = options && typeof options === 'object' ? options : {};
    const cost = parseNumber(unitCost);
    const price = parseNumber(sellingPrice);
    const quantity = config.quantity == null || config.quantity === '' ? 1 : parseNumber(config.quantity);
    const targetMargin = config.targetMargin == null || config.targetMargin === '' ? 0 : parseNumber(config.targetMargin);
    const feeKnown = config.variableFeeKnown !== false;
    const requestedFeePercent = config.variableFeePercent == null || config.variableFeePercent === '' ? 0 : parseNumber(config.variableFeePercent);
    const feePercent = feeKnown ? requestedFeePercent : 0;
    const fixedCostKnown = config.fixedCostKnown !== false;
    const requestedFixedCost = config.fixedCostPerUnit == null || config.fixedCostPerUnit === '' ? 0 : parseNumber(config.fixedCostPerUnit);
    const fixedCostPerUnit = fixedCostKnown ? requestedFixedCost : 0;
    const invalid = { valid: false, status: 'insufficient_data', profitPerUnit: null, estimatedProfit: null, lossPerUnit: null, estimatedLoss: null, margin: null, feeAmountPerUnit: null, fixedCostPerUnit: null, recommendedPrice: null, variableFeesIncluded: feeKnown, fixedCostsIncluded: fixedCostKnown, errors: [] };

    if (!(cost >= 0)) invalid.errors.push('O custo unitário precisa estar cadastrado e ser maior ou igual a zero.');
    if (!(price >= 0)) invalid.errors.push('O preço de venda precisa ser maior ou igual a zero.');
    if (!(quantity > 0)) invalid.errors.push('A quantidade precisa ser maior que zero.');
    if (!(targetMargin >= 0 && targetMargin <= 90)) invalid.errors.push('A margem desejada deve ficar entre 0% e 90%.');
    if (feeKnown && !(feePercent >= 0 && feePercent < 100)) invalid.errors.push('Taxas e impostos percentuais devem ficar entre 0% e menos de 100%.');
    if (fixedCostKnown && !(fixedCostPerUnit >= 0)) invalid.errors.push('O rateio de despesas fixas por unidade precisa ser maior ou igual a zero.');
    if (invalid.errors.length) return invalid;

    const feeAmountPerUnit = price * feePercent / 100;
    const directProfitPerUnit = price - feeAmountPerUnit - cost;
    const fullyLoadedCostPerUnit = cost + fixedCostPerUnit;
    const profitPerUnit = price - feeAmountPerUnit - fullyLoadedCostPerUnit;
    const estimatedProfit = profitPerUnit * quantity;
    const lossPerUnit = Math.max(0, -profitPerUnit);
    const estimatedLoss = lossPerUnit * quantity;
    const margin = price > 0 ? (profitPerUnit / price) * 100 : null;
    const recommendedPrice = feeKnown && fixedCostKnown ? suggestPrice(fullyLoadedCostPerUnit, targetMargin, feePercent) : null;
    const belowTarget = profitPerUnit > 0 && margin != null && margin + 0.005 < targetMargin;
    let status = 'profitable';
    if (profitPerUnit < -0.005) status = 'loss';
    else if (!feeKnown) status = 'fees_unknown';
    else if (!fixedCostKnown) status = 'fixed_costs_unknown';
    else if (Math.abs(profitPerUnit) <= 0.005) status = 'break_even';
    else if (belowTarget) status = 'below_target';

    let recommendation = 'Mantenha os custos atualizados e revise a margem periodicamente.';
    if (status === 'loss') {
      if (recommendedPrice != null) {
        recommendation = 'Para atingir a contribuição desejada de ' + targetMargin.toLocaleString('pt-BR') + '%, ajuste o preço para pelo menos R$ ' + roundMoney(recommendedPrice).toFixed(2) + '. O valor considera custos diretos, rateio fixo confirmado e taxas informadas. Compare fornecedores, reveja o tamanho da porção e reduza perdas no preparo.';
      } else {
        const missing = [];
        if (!feeKnown) missing.push('as taxas de venda');
        if (!fixedCostKnown) missing.push('o rateio das despesas fixas em Financeiro > Custos fixos');
        recommendation = 'A perda exibida é mínima porque já existe prejuízo antes de ' + (missing.length ? missing.join(' e ') : 'todos os custos') + '. Complete ' + missing.join(' e ') + ' para calcular o prejuízo completo e um preço confiável. Enquanto isso, compare fornecedores, reveja porções e reduza desperdícios.';
      }
    } else if (status === 'fees_unknown') {
      recommendation = 'Informe as taxas de pagamento, marketplace e tributos percentuais. A sobra exibida é antes dessas taxas, pode virar prejuízo e ainda não permite recomendar um preço final confiável.';
    } else if (status === 'fixed_costs_unknown') {
      recommendation = 'Cadastre suas despesas fixas mensais e a previsão de unidades vendidas por mês em Financeiro > Custos fixos. Até completar esse rateio, a sobra pode estar superestimada e não é possível recomendar um preço final confiável.';
    } else if (status === 'break_even') {
      recommendation = 'A venda apenas cobre os custos diretos e taxas cadastradas. Aumente o preço para gerar contribuição e ajudar a pagar despesas fixas e imprevistos.';
    } else if (status === 'below_target') {
      recommendation = recommendedPrice != null
        ? 'A venda ainda deixa uma sobra, mas abaixo da meta. Considere ajustar o preço para R$ ' + roundMoney(recommendedPrice).toFixed(2) + ' para atingir a contribuição desejada sobre os custos informados. Despesas fixas ainda precisam ser consideradas.'
        : 'Revise a margem desejada e as taxas cadastradas para obter um preço recomendado.';
    }

    return {
      valid: true,
      status,
      unitCost: roundMoney(cost),
      sellingPrice: roundMoney(price),
      quantity,
      feePercent,
      variableFeesIncluded: feeKnown,
      feeStatus: feeKnown ? 'known' : 'unknown',
      feeAmountPerUnit: roundMoney(feeAmountPerUnit),
      fixedCostPerUnit: fixedCostKnown ? roundMoney(fixedCostPerUnit) : null,
      fixedCostsIncluded: fixedCostKnown,
      fullyLoadedCostPerUnit: fixedCostKnown ? roundMoney(fullyLoadedCostPerUnit) : null,
      directProfitPerUnit: roundMoney(directProfitPerUnit),
      directEstimatedProfit: roundMoney(directProfitPerUnit * quantity),
      profitPerUnit: roundMoney(profitPerUnit),
      estimatedProfit: roundMoney(estimatedProfit),
      lossPerUnit: roundMoney(lossPerUnit),
      estimatedLoss: roundMoney(estimatedLoss),
      margin: margin == null ? null : margin,
      targetMargin,
      recommendedPrice: recommendedPrice == null ? null : roundMoney(recommendedPrice),
      priceGap: recommendedPrice == null ? null : roundMoney(Math.max(0, recommendedPrice - price)),
      recommendation,
      errors: []
    };
  }

  function analyzePrice(unitCost, sellingPrice, variableFeePercent) {
    const cost = parseNumber(unitCost);
    const price = parseNumber(sellingPrice);
    if (!(cost >= 0) || !(price > 0)) return { valid: false, profit: null, margin: null };
    const feePercent = variableFeePercent == null || variableFeePercent === '' ? 0 : parseNumber(variableFeePercent);
    if (!(feePercent >= 0 && feePercent < 100)) return { valid: false, profit: null, margin: null };
    const feeAmount = price * feePercent / 100;
    const profit = price - feeAmount - cost;
    return { valid: true, profit, margin: (profit / price) * 100, feePercent, feeAmount };
  }

  function makeSnapshot(recipe, calculation, now, fixedCostAllocation) {
    const source = recipe && typeof recipe === 'object' ? recipe : {};
    const feeKnown = hasKnownVariableFee(source);
    const feeValue = feeKnown ? parseNumber(source.taxa_venda_pct) : null;
    return {
      version: 3,
      calculatedAt: now || new Date().toISOString(),
      yield: calculation.yield,
      ingredientsBatch: roundMoney(calculation.ingredientsBatch),
      ingredientsPerUnit: roundMoney(calculation.ingredientsPerUnit),
      additionsPerUnit: roundMoney(calculation.additionsPerUnit),
      unitCost: roundMoney(calculation.unitCost),
      batchCost: roundMoney(calculation.batchCost),
      additions: Object.fromEntries(Object.entries(calculation.additions).map(([key, value]) => [key, roundMoney(value)])),
      sellingPrice: Number.isFinite(parseNumber(source.preco)) ? roundMoney(parseNumber(source.preco)) : null,
      targetMargin: Number.isFinite(parseNumber(source.margem)) ? parseNumber(source.margem) : null,
      variableFeePercent: feeValue,
      variableFeeKnown: feeKnown,
      fixedCostAllocation: fixedCostAllocation && fixedCostAllocation.valid ? {
        monthlyTotal: roundMoney(fixedCostAllocation.monthlyTotal),
        expectedMonthlyUnits: fixedCostAllocation.expectedMonthlyUnits,
        costPerUnit: roundMoney(fixedCostAllocation.costPerUnit),
        itemCount: fixedCostAllocation.itemCount
      } : null,
      items: calculation.items.map((item) => ({
        ingredientId: item.ingredientId,
        name: item.name,
        quantity: item.quantity,
        recipeUnit: item.recipeUnit,
        purchaseQuantity: item.purchaseQuantity,
        purchaseUnit: item.purchaseUnit,
        unitPrice: item.unitPrice,
        lineCost: roundMoney(item.lineCost)
      }))
    };
  }

  return {
    parseNumber,
    normalizeUnit,
    unitMeta,
    compatibleUnits,
    convertQuantity,
    roundMoney,
    calculateRecipe,
    calculateProductCost,
    calculateLaborCostPerUnit,
    suggestPrice,
    calculateFixedCostAllocation,
    hasKnownVariableFee,
    analyzePrice,
    assessProfitability,
    makeSnapshot
  };
});
