(function () {
  'use strict';

  var storageKey = 'ksw_cookie_consent_v2';
  var memoryConsent = null;
  var notice = null;
  var hasStorage = true;

  function readConsent() {
    if (memoryConsent) return memoryConsent;
    try {
      var raw = window.localStorage.getItem(storageKey);
      if (!raw) return null;
      var parsed = JSON.parse(raw);
      if (!parsed || parsed.version !== 2 || !['accepted', 'rejected', 'custom'].includes(parsed.choice)) return null;
      return parsed;
    } catch (error) {
      hasStorage = false;
      return null;
    }
  }

  function hasChoice() {
    return Boolean(readConsent());
  }

  function saveChoice(choice, preferences) {
    var payload = {
      version: 2,
      choice: choice,
      necessary: true,
      analytics: Boolean(preferences && preferences.analytics),
      marketing: Boolean(preferences && preferences.marketing),
      savedAt: new Date().toISOString()
    };
    memoryConsent = payload;
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(payload));
      hasStorage = true;
    } catch (error) {
      hasStorage = false;
      // A escolha vale durante a sessão atual, mas será solicitada novamente
      // em uma visita futura se o navegador bloquear o armazenamento.
    }
    removeNotice();
    // Quando já existe sessão, registra a alteração no servidor também.
    // O site continua funcional se a API estiver temporariamente indisponível.
    if (window.token && typeof window.apiCall === 'function') {
      window.apiCall('/auth/cookie-preferences', 'POST', {
        choice: payload.choice,
        analytics: payload.analytics,
        marketing: payload.marketing
      }).catch(function (error) {
        console.warn('Não foi possível sincronizar as preferências de cookies com a conta:', error && error.message);
      });
    }
    return payload;
  }

  function removeNotice() {
    if (notice && notice.parentNode) notice.parentNode.removeChild(notice);
    notice = null;
  }

  function ensureNotice() {
    if (notice && notice.isConnected) return notice;
    notice = document.createElement('aside');
    notice.id = 'cookie-notice';
    notice.setAttribute('aria-label', 'Preferências de cookies e armazenamento local');
    notice.innerHTML =
      '<section class="cookie-notice-panel" aria-labelledby="cookie-notice-title" role="dialog" aria-modal="false">' +
        '<h2 id="cookie-notice-title">Sua privacidade importa</h2>' +
        '<p>O Confeitaê guarda no seu aparelho só o necessário para manter você conectada e salvar seu trabalho. Não usamos anúncios nem rastreadores de comportamento.</p>' +
        '<details class="cookie-notice-details"><summary>Ver e configurar armazenamento</summary>' +
          '<label class="cookie-option is-required"><input type="checkbox" checked disabled> <span><strong>Necessário — sempre ativo</strong><small>O token de acesso do Confeitaê fica no armazenamento local por até 7 dias. O cache de trabalho pode permanecer neste aparelho para permitir continuidade e evitar perda de alterações ainda não sincronizadas. Ao sair, o token é removido; o cache sincronizado também é removido, enquanto alterações pendentes são preservadas para não perder dados. O painel administrativo usa uma sessão técnica de até 30 minutos.</small></span></label>' +
          '<label class="cookie-option"><input id="cookie-analytics" type="checkbox"> <span><strong>Análise — não utilizada atualmente</strong><small>Preferência para métricas não essenciais, caso uma ferramenta desse tipo venha a ser adicionada. Nada dessa categoria é carregado hoje.</small></span></label>' +
          '<label class="cookie-option"><input id="cookie-marketing" type="checkbox"> <span><strong>Marketing — não utilizado atualmente</strong><small>Preferência para recursos publicitários não essenciais, caso sejam adicionados. Nenhum pixel de publicidade é carregado hoje.</small></span></label>' +
        '<p class="cookie-notice-footnote">Sua escolha fica salva neste navegador e pode ser alterada em Configurações. Você também pode reabrir estas opções pelo link “Preferências de privacidade”. Rejeitar opcionais não impede cadastro nem uso do KSW; sem uma escolha, o cadastro não é enviado.</p>' +
        '</details>' +
        '<div class="cookie-notice-actions">' +
          '<button type="button" class="cookie-notice-reject">Rejeitar opcionais</button>' +
          '<button type="button" class="cookie-notice-save">Salvar escolhas</button>' +
          '<button type="button" class="cookie-notice-accept">Aceitar todos</button>' +
        '</div>' +
      '</section>';
    document.body.appendChild(notice);

    notice.querySelector('.cookie-notice-reject').addEventListener('click', function () {
      saveChoice('rejected', { analytics: false, marketing: false });
    });
    notice.querySelector('.cookie-notice-accept').addEventListener('click', function () {
      saveChoice('accepted', { analytics: true, marketing: true });
    });
    notice.querySelector('.cookie-notice-save').addEventListener('click', function () {
      saveChoice('custom', {
        analytics: Boolean(notice.querySelector('#cookie-analytics').checked),
        marketing: Boolean(notice.querySelector('#cookie-marketing').checked)
      });
    });
    return notice;
  }

  function openPreferences() {
    var root = ensureNotice();
    root.hidden = false;
    var saved = readConsent();
    root.querySelector('#cookie-analytics').checked = Boolean(saved && saved.analytics);
    root.querySelector('#cookie-marketing').checked = Boolean(saved && saved.marketing);
    var details = root.querySelector('details');
    if (saved) details.open = true;
    var focusTarget = root.querySelector('.cookie-notice-reject');
    if (focusTarget) focusTarget.focus();
  }

  window.KSWCookieConsent = {
    hasChoice: hasChoice,
    getPreferences: function () {
      var saved = readConsent();
      return saved ? { necessary: true, analytics: Boolean(saved.analytics), marketing: Boolean(saved.marketing), choice: saved.choice } : null;
    },
    openPreferences: openPreferences
  };

  if (!hasChoice()) openPreferences();
})();
