/* Módulos complementares KSW. Dados sincronizados pelo mecanismo multiusuário já existente. */
(function(){
  window.recTab = 'tarefas';
  window.audit = function(entity, entityId, action){
    db.auditoria = db.auditoria || [];
    db.auditoria.push({id:id(),entidade:entity,entidade_id:String(entityId||''),acao:action,data:new Date().toISOString()});
    if(db.auditoria.length>500) db.auditoria=db.auditoria.slice(-500);
  };
  window.recTabGo = function(t){window.recTab=t;render()};
  window.vRecursos = function(){
    var t=window.recTab||'tarefas', tabs=[['tarefas','Tarefas'],['orcamentos','Orçamentos'],['crm','CRM e fidelidade'],['cupons','Cupons'],['dorinha','Dorinha'],['auditoria','Auditoria']];
    var h='<h2>Mais recursos</h2><div class="row" style="flex-wrap:wrap">'+tabs.map(function(x){return '<button class="btn '+(t===x[0]?'':'ghost')+' sm" onclick="recTabGo(\''+x[0]+'\')">'+x[1]+'</button>'}).join('')+'</div>';
    return h+(t==='tarefas'?tasksView():t==='orcamentos'?quotesView():t==='crm'?crmView():t==='cupons'?couponsView():t==='dorinha'?assistantView():auditView());
  };
  function tasksView(){
    var list=(db.tarefas||[]).slice().sort(function(a,b){return (a.prazo||'').localeCompare(b.prazo||'')});
    return '<div class="card"><b>Nova tarefa</b><div class="cols"><div><label>Descrição</label><input id="task-title" maxlength="160" placeholder="Ex.: preparar recheio"></div><div><label>Prazo</label><input id="task-date" type="date" value="'+hoje()+'"></div><div><label>Responsável</label><input id="task-owner" placeholder="Opcional"></div></div><button class="btn" onclick="addTaskKSW()">Criar tarefa</button></div>'+['pendente','fazendo','concluida'].map(function(st){return '<div class="card"><b>'+({pendente:'A fazer',fazendo:'Em andamento',concluida:'Concluídas'}[st])+'</b>'+(list.filter(function(x){return x.status===st}).map(function(x){return '<div class="kv"><span>'+esc(x.titulo)+'<small class="mut" style="display:block">Prazo: '+(x.prazo?D(x.prazo):'Sem prazo')+(x.responsavel?' · '+esc(x.responsavel):'')+'</small></span><span><select aria-label="Status da tarefa" onchange="taskStatusKSW(\''+x.id+'\',this.value)">'+['pendente','fazendo','concluida'].map(function(v){return '<option '+(v===x.status?'selected':'')+' value="'+v+'">'+v+'</option>'}).join('')+'</select> <button class="btn ghost sm" onclick="deleteResourceKSW(\'tarefas\',\''+x.id+'\')">×</button></span></div>'}).join('')||'<p class="mut">Nenhuma tarefa.</p>')+'</div>'}).join('');
  }
  window.addTaskKSW=function(){var title=document.getElementById('task-title').value.trim(),date=document.getElementById('task-date').value;if(!title)return toast('Descreva a tarefa.');var x={id:id(),titulo:title,prazo:date,status:'pendente',responsavel:document.getElementById('task-owner').value.trim(),criado_em:hoje()};db.tarefas.push(x);audit('tarefa',x.id,'Criou: '+title);saveLocalDB();render()};
  window.taskStatusKSW=function(i,s){var x=by(db.tarefas,i);if(!x)return;x.status=s;audit('tarefa',i,'Status: '+s);saveLocalDB();render()};
  window.deleteResourceKSW=function(k,i){if(!confirm('Excluir este registro?'))return;db[k]=db[k].filter(function(x){return x.id!==i});audit(k,i,'Excluiu registro');saveLocalDB();render()};
  window.quoteShareLinks = window.quoteShareLinks || {};
  function quotesView(){
    var clients=(db.clientes||[]).slice().sort(function(a,b){return String(a.nome||'').localeCompare(String(b.nome||''),'pt-BR')});
    var h='<div class="card"><b>Criar orçamento</b><div class="cols"><div><label>Cliente</label><select id="q-client">'+clients.map(function(c){return '<option value="'+esc(c.id)+'">'+esc(c.nome)+'</option>'}).join('')+'</select></div><div><label>Validade da proposta</label><input id="q-valid" type="date" min="'+hoje()+'" value="'+addDias(hoje(),7)+'"></div><div><label>Entrega desejada (opcional)</label><input id="q-delivery" type="date" min="'+hoje()+'"></div><div><label>Valor total (R$)</label><input id="q-total" type="number" min="0.01" max="10000000" step="0.01" inputmode="decimal"></div><div><label>Unidades estimadas</label><input id="q-quantity" type="number" min="1" max="100000" step="1" value="1" inputmode="numeric"></div></div><label>Descrição/itens</label><textarea id="q-desc" rows="3" maxlength="1000" placeholder="Descreva produtos, quantidades, personalizações e o que está incluído"></textarea><button class="btn" type="button" onclick="addQuoteKSW()">Salvar orçamento</button><p class="mut">Depois de salvar, gere um link individual para a cliente aprovar ou recusar pelo celular. A aprovação cria uma encomenda no KSW.</p></div>';
    var list=(db.orcamentos||[]).slice().reverse();
    return h+(list.length?list.map(function(q){
      var c=by(db.clientes,q.cli),tel=String(c&&c.tel||'').replace(/\D/g,''),url=window.quoteShareLinks[q.id]||'';
      if(tel.length===10||tel.length===11)tel='55'+tel;
      var status=String(q.status||'rascunho'),finalized=status==='aceito'||status==='recusado';
      var whatsapp=url&&/^55\d{10,11}$/.test(tel)?'https://wa.me/'+tel+'?text='+encodeURIComponent('Olá, '+(c?c.nome:'')+'! Preparei seu orçamento no valor de '+R(q.total)+'. Confira os detalhes e responda por este link: '+url):'';
      var actions='<button class="btn ghost sm" type="button" '+(finalized?'disabled':'')+' onclick="shareQuoteKSW(\''+Q(q.id)+'\')">'+(url?'Gerar novo link':'Gerar link de aprovação')+'</button>';
      if(url)actions+='<div class="quote-public-link" style="width:100%;margin-top:10px"><label for="quote-url-'+esc(q.id)+'">Link de aprovação</label><input id="quote-url-'+esc(q.id)+'" readonly value="'+esc(url)+'"><div class="row"><button class="btn ghost sm" type="button" onclick="copyQuoteLinkKSW(\''+Q(q.id)+'\')">Copiar link</button>'+(whatsapp?'<a class="btn ghost sm" target="_blank" rel="noopener noreferrer" href="'+esc(whatsapp)+'">Enviar no WhatsApp</a>':'')+'</div></div>';
      var statusOptions=['rascunho','enviado','aceito','recusado','expirado'].map(function(s){return '<option value="'+s+'" '+(status===s?'selected':'')+((s==='aceito'||s==='recusado')?' disabled':'')+'>'+s+'</option>'}).join('');
      return '<article class="card"><div class="row"><b>'+esc(c?c.nome:'Cliente removido')+'</b><b>'+R(q.total)+'</b></div><p>'+esc(q.descricao)+'</p><div class="mut">Validade: '+D(q.validade)+(q.entrega?' · Entrega desejada: '+D(q.entrega):' · Entrega a combinar')+' · '+esc(status)+'</div>'+(q.pedido_id?'<div class="mut">Pedido gerado: '+esc(String(q.pedido_id).slice(0,8).toUpperCase())+'</div>':'')+'<div class="row" style="flex-wrap:wrap;margin-top:10px"><select aria-label="Status do orçamento" '+(finalized?'disabled':'')+' onchange="quoteStatusKSW(\''+Q(q.id)+'\',this.value)">'+statusOptions+'</select>'+actions+'<button class="btn ghost sm" type="button" '+(finalized?'disabled title=\"Orçamentos respondidos são preservados no histórico\"':'')+' onclick="deleteResourceKSW(\'orcamentos\',\''+Q(q.id)+'\')">Excluir</button></div></article>';
    }).join(''):'<div class="card mut">Nenhum orçamento cadastrado. Crie a primeira proposta acima.</div>');
  }
  window.addQuoteKSW=function(){
    var client=document.getElementById('q-client'),c=client&&client.value,v=num(document.getElementById('q-total').value),quantity=Number(document.getElementById('q-quantity').value),valid=document.getElementById('q-valid').value,delivery=document.getElementById('q-delivery').value,desc=document.getElementById('q-desc').value.trim();
    if(!c)return toast('Cadastre ou selecione uma cliente antes de criar o orçamento.');
    if(!(v>0)||v>10000000||!Number.isSafeInteger(quantity)||quantity<1||quantity>100000||!valid||!desc)return toast('Preencha cliente, valor, quantidade, validade e descrição com dados válidos.');
    if(valid<hoje()||(delivery&&delivery<hoje()))return toast('As datas do orçamento não podem estar no passado.');
    var q={id:id(),cli:c,total:+v.toFixed(2),quantidade:quantity,validade:valid,entrega:delivery,descricao:desc,status:'rascunho',criado_em:hoje()};
    db.orcamentos.push(q);audit('orcamento',q.id,'Criou orçamento');saveLocalDB();render();
  };
  window.shareQuoteKSW=async function(i){
    var q=by(db.orcamentos,i);if(!q)return toast('Orçamento não encontrado.');
    if(q.status==='aceito'||q.status==='recusado')return toast('Este orçamento já recebeu uma resposta.');
    q.status='enviado';q.enviado_em=q.enviado_em||new Date().toISOString();
    saveLocalDB();
    try{
      var result=await apiCall('/quotes/share','POST',{quote:q});
      window.quoteShareLinks[i]=result.url;
      audit('orcamento',i,'Gerou link público de aprovação');saveLocalDB();render();
      toast('Link de aprovação criado. Copie ou envie pelo WhatsApp.');
    }catch(error){/* apiCall já informa a falha na interface; o status enviado pode ser reenviado */}
  };
  window.copyQuoteLinkKSW=async function(i){
    var url=window.quoteShareLinks[i];if(!url)return;
    try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(url);toast('Link copiado.');}else{var field=document.getElementById('quote-url-'+i);if(field){field.focus();field.select();toast('Copie o link selecionado.');}}}
    catch(error){toast('Não foi possível copiar automaticamente. Selecione o link e copie.');}
  };
  window.quoteStatusKSW=function(i,s){
    var q=by(db.orcamentos,i);if(!q)return;
    if(s==='aceito')return toast('A aprovação precisa ser feita pela cliente no link. Assim o pedido é criado automaticamente.');
    q.status=s;audit('orcamento',i,'Status: '+s);saveLocalDB();render();
  };
  function points(c){return (db.fidelidade||[]).filter(function(x){return x.cliente_id===c}).reduce(function(a,x){return a+num(x.pontos)},0)}
  function birthdayCouponFor(clientId,year){return (db.cupons||[]).find(function(c){return c.origem==='aniversario'&&c.cliente_id===clientId&&Number(c.ano_aniversario)===Number(year)})}
  function birthdayWhatsAppUrl(client,coupon){
    if(!client||client.whatsapp_promocoes!==true||!coupon)return '';
    var phone=String(client.tel||'').replace(/\D/g,'');
    if(phone.length===10||phone.length===11)phone='55'+phone;
    if(!/^55\d{10,11}$/.test(phone))return '';
    var discount=coupon.tipo==='percentual'?coupon.valor+'%':'R$ '+Number(coupon.valor).toLocaleString('pt-BR',{minimumFractionDigits:2});
    var message='Feliz aniversário, '+client.nome+'! Preparamos um presente para você: use o cupom '+coupon.codigo+' e ganhe '+discount+' de desconto. Válido até '+D(coupon.validade)+'.';
    return 'https://wa.me/'+phone+'?text='+encodeURIComponent(message);
  }
  function hasBirthdayPhone(client){
    var phone=String(client&&client.tel||'').replace(/\D/g,'');
    if(phone.length===10||phone.length===11)phone='55'+phone;
    return /^55\d{10,11}$/.test(phone);
  }
  function birthdayConsentHtml(client){
    var allowed=client.whatsapp_promocoes===true;
    return '<div class="mut">'+(allowed?'Autorização promocional registrada'+(client.whatsapp_promocoes_at?' em '+D(client.whatsapp_promocoes_at.slice(0,10)):''):'Sem autorização para mensagens promocionais')+'</div><button class="btn ghost sm" type="button" onclick="setBirthdayConsentKSW(\''+client.id+'\','+(allowed?'false':'true')+')">'+(allowed?'Revogar autorização':'Registrar autorização')+'</button>';
  }
  function birthdayClientCard(entry){
    var client=entry.client,coupon=birthdayCouponFor(client.id,entry.year),day=String(entry.day).padStart(2,'0')+'/'+String(entry.month).padStart(2,'0');
    var couponMarkup=coupon
      ? '<div class="mut">Cupom '+esc(coupon.codigo)+' · '+esc(coupon.tipo==='percentual'?coupon.valor+'%':R(coupon.valor))+' · válido até '+esc(D(coupon.validade))+(coupon.ativo?'':' · inativo')+'</div>'
      : '<button class="btn sm" type="button" onclick="generateBirthdayCouponKSW(\''+client.id+'\','+entry.year+')">Gerar cupom de aniversário</button>';
    var url=coupon&&coupon.ativo&&coupon.validade>=hoje()?birthdayWhatsAppUrl(client,coupon):'';
    var whatsappMarkup=url
      ? '<a class="btn ghost sm" target="_blank" rel="noopener" href="'+esc(url)+'">Preparar WhatsApp</a>'
      : client.whatsapp_promocoes!==true
        ? '<small class="mut">A mensagem promocional fica indisponível até a cliente autorizar.</small>'
        : !hasBirthdayPhone(client)
        ? '<small class="mut">Cadastre um WhatsApp válido para preparar a mensagem.</small>'
        : coupon&&!coupon.ativo
          ? '<small class="mut">Este cupom está inativo.</small>'
          : coupon
            ? '<small class="mut">Este cupom expirou.</small>'
            : '<small class="mut">Gere o cupom para preparar a mensagem.</small>';
    return '<article class="card"><div class="row"><div><b>'+esc(client.nome)+'</b><div class="mut">Aniversário: '+day+'</div></div><span class="tag">'+(entry.day===Number(hoje().slice(8,10))?'Hoje':'Este mês')+'</span></div><div class="row" style="margin-top:8px;align-items:center">'+couponMarkup+whatsappMarkup+'</div><div style="margin-top:10px">'+birthdayConsentHtml(client)+'</div></article>';
  }
  function crmView(){
    var today=hoje(),month=Number(today.slice(5,7)),upcoming=KSWBirthdays.upcoming(db.clientes,today,7),monthly=KSWBirthdays.inMonth(db.clientes,month,today);
    var reminders=upcoming.length
      ? upcoming.map(function(entry){var when=entry.daysUntil===0?'Hoje':entry.daysUntil===1?'Amanhã':'em '+entry.daysUntil+' dias';return '<div class="kv"><span><b>'+esc(entry.client.nome)+'</b><small class="mut" style="display:block">'+when+' · '+KSWBirthdays.format(entry.value)+'</small></span><span class="tag'+(entry.daysUntil===0?' now':'')+'">'+when+'</span></div>'}).join('')
      : '<p class="mut">Nenhum aniversário nos próximos 7 dias.</p>';
    return '<div class="card"><b>Adicionar ou resgatar pontos</b><div class="cols"><div><label>Cliente</label><select id="loyal-client">'+db.clientes.map(function(c){return '<option value="'+c.id+'">'+esc(c.nome)+'</option>'}).join('')+'</select></div><div><label>Pontos (+ acumular / - resgatar)</label><input id="loyal-points" type="number" step="1"></div><div><label>Motivo</label><input id="loyal-reason" maxlength="160" placeholder="Compra, resgate..."></div></div><button class="btn" onclick="addPointsKSW()">Registrar movimento</button><p class="mut">Livro-razão: cada movimento fica registrado; o saldo é calculado pelo histórico.</p></div>'+
      '<section class="card"><h3>Aniversários próximos</h3><p class="mut">Lembretes para os próximos 7 dias. As mensagens só são preparadas para clientes com autorização registrada.</p>'+reminders+'</section>'+
      '<section class="card"><h3>Aniversariantes do mês</h3><p class="mut">Ofereça um cupom individual; a prévia não aplica descontos automaticamente aos pedidos. Para 29/02 em anos não bissextos, o lembrete ocorre em 01/03.</p><div class="cols"><div><label>Desconto do cupom</label><select id="birthday-coupon-type"><option value="percentual">Percentual</option><option value="valor">Valor fixo em R$</option></select></div><div><label>Valor</label><input id="birthday-coupon-value" type="number" min="0.01" step="0.01" value="10"></div><div><label>Validade (dias)</label><input id="birthday-coupon-days" type="number" min="1" max="365" step="1" value="30"></div></div><small class="mut">Padrão: 10% por 30 dias. Ajuste antes de gerar cada cupom.</small>'+
      (monthly.length?monthly.map(birthdayClientCard).join(''):'<p class="mut">Nenhuma cliente cadastrada faz aniversário neste mês, ou ainda não há aniversários informados.</p>')+'</section>'+
      db.clientes.map(function(c){var ps=db.pedidos.filter(function(p){return p.cli===c.id&&p.st!=='cancelado'}),spent=ps.reduce(function(a,p){return a+tp(p)},0);return '<div class="card"><div class="row"><b>'+esc(c.nome)+'</b><b>'+points(c.id)+' pontos</b></div><div class="mut">'+ps.length+' pedidos · total histórico '+R(spent)+' · '+(c.nasc?'aniversário '+KSWBirthdays.format(c.nasc):'sem aniversário cadastrado')+'</div></div>'}).join('');
  }
  window.setBirthdayConsentKSW=function(clientId,allowed){
    var client=by(db.clientes,clientId);
    if(!client)return toast('Cliente não encontrado.');
    if(allowed&&!confirm('Confirma que esta cliente autorizou mensagens promocionais por WhatsApp?'))return;
    if(!allowed&&!confirm('Revogar a autorização para mensagens promocionais desta cliente?'))return;
    client.whatsapp_promocoes=Boolean(allowed);
    client.whatsapp_promocoes_at=allowed?new Date().toISOString():'';
    audit('cliente',client.id,allowed?'Registrou autorização promocional WhatsApp':'Revogou autorização promocional WhatsApp');
    saveLocalDB();render();
  };
  window.generateBirthdayCouponKSW=function(clientId,year){
    var client=by(db.clientes,clientId),birthday=client&&KSWBirthdays.parse(client.nasc),cycle=Number(year),currentYear=Number(hoje().slice(0,4));
    if(!client||!birthday)return toast('Cadastre um aniversário válido para esta cliente.');
    if(!Number.isInteger(cycle)||cycle<currentYear||cycle>currentYear+1)return toast('Ano do aniversário inválido.');
    if(birthdayCouponFor(clientId,cycle))return toast('Já existe um cupom para este aniversário.');
    var type=document.getElementById('birthday-coupon-type').value,value=num(document.getElementById('birthday-coupon-value').value),days=Number(document.getElementById('birthday-coupon-days').value);
    if(!['percentual','valor'].includes(type)||!(value>0)||(type==='percentual'&&value>100))return toast('Informe um desconto válido; percentuais podem chegar a 100%.');
    if(!Number.isInteger(days)||days<1||days>365)return toast('A validade deve ficar entre 1 e 365 dias.');
    var code='';
    for(var attempt=0;attempt<5;attempt++){code='ANIV-'+id().slice(-8).toUpperCase();if(!(db.cupons||[]).some(function(c){return String(c.codigo||'').toUpperCase()===code}))break;code=''}
    if(!code)return toast('Não foi possível gerar um código único. Tente novamente.');
    var coupon={id:id(),codigo:code,tipo:type,valor:value,validade:addDias(hoje(),days),ativo:true,usos:0,cliente_id:client.id,origem:'aniversario',ano_aniversario:cycle};
    db.cupons=db.cupons||[];db.cupons.push(coupon);
    audit('cupom',coupon.id,'Criou cupom de aniversário');
    saveLocalDB();render();
  };
  window.addPointsKSW=function(){var c=document.getElementById('loyal-client').value,p=Number(document.getElementById('loyal-points').value),m=document.getElementById('loyal-reason').value.trim();if(!c||!Number.isInteger(p)||!p||!m)return toast('Informe cliente, pontos inteiros e motivo.');if(points(c)+p<0)return toast('Saldo de pontos insuficiente.');var x={id:id(),cliente_id:c,pontos:p,motivo:m,data:new Date().toISOString()};db.fidelidade.push(x);audit('fidelidade',x.id,(p>0?'Acumulou ':'Resgatou ')+Math.abs(p)+' pontos');saveLocalDB();render()};
  function couponsView(){return '<div class="card"><b>Novo cupom</b><div class="cols"><div><label>Código</label><input id="coupon-code" maxlength="40" placeholder="BOASVINDAS"></div><div><label>Tipo</label><select id="coupon-type"><option value="percentual">Desconto %</option><option value="valor">Desconto R$</option></select></div><div><label>Valor</label><input id="coupon-value" type="number" min="0.01" step="0.01"></div><div><label>Validade</label><input id="coupon-date" type="date" value="'+addDias(hoje(),30)+'"></div></div><button class="btn" onclick="addCouponKSW()">Criar cupom</button></div>'+(db.cupons||[]).map(function(c){var client=c.cliente_id&&by(db.clientes,c.cliente_id);return '<div class="card row"><span><b>'+esc(c.codigo)+'</b><small class="mut" style="display:block">'+(c.tipo==='percentual'?c.valor+'%':R(c.valor))+' · até '+D(c.validade)+' · '+(c.ativo?'Ativo':'Inativo')+(client?' · aniversário de '+esc(client.nome):'')+'</small></span><span><button class="btn ghost sm" onclick="toggleCouponKSW(\''+c.id+'\')">'+(c.ativo?'Pausar':'Ativar')+'</button> <button class="btn ghost sm" onclick="deleteResourceKSW(\'cupons\',\''+c.id+'\')">×</button></span></div>'}).join('')+'<div class="card"><b>Validar cupom</b><div class="cols"><div><label>Código</label><input id="coupon-check" placeholder="Código"></div><div><label>Cliente</label><select id="coupon-client"><option value="">Selecione…</option>'+db.clientes.map(function(c){return '<option value="'+esc(c.id)+'">'+esc(c.nome)+'</option>'}).join('')+'</select></div><div><label>Valor do pedido</label><input id="coupon-order" type="number" min="0.01" step="0.01" placeholder="Valor do pedido"></div></div><button class="btn sm" onclick="checkCouponKSW()">Validar</button><div id="coupon-result" class="mut"></div><small class="mut">A validação é uma prévia; o cupom ainda não é aplicado automaticamente ao pedido.</small></div>'}
  window.addCouponKSW=function(){var code=document.getElementById('coupon-code').value.trim().toUpperCase(),type=document.getElementById('coupon-type').value,value=num(document.getElementById('coupon-value').value),date=document.getElementById('coupon-date').value;if(!/^[A-Z0-9_-]{3,40}$/.test(code)||!(value>0)||!date)return toast('Código inválido ou dados incompletos.');if(db.cupons.some(function(c){return c.codigo===code}))return toast('Este código já existe.');if(type==='percentual'&&value>100)return toast('Percentual máximo: 100%.');var c={id:id(),codigo:code,tipo:type,valor:value,validade:date,ativo:true,usos:0};db.cupons.push(c);audit('cupom',c.id,'Criou '+code);saveLocalDB();render()};
  window.toggleCouponKSW=function(i){var c=by(db.cupons,i);if(c){c.ativo=!c.ativo;saveLocalDB();render()}};
  window.checkCouponKSW=function(){var code=document.getElementById('coupon-check').value.trim().toUpperCase(),clientId=document.getElementById('coupon-client').value,total=num(document.getElementById('coupon-order').value),c=db.cupons.find(function(x){return String(x.codigo||'').toUpperCase()===code}),el=document.getElementById('coupon-result');if(!c||!c.ativo||c.validade<hoje()||!(total>0)|| (c.cliente_id&&String(c.cliente_id)!==clientId)){el.textContent='Cupom inválido, inativo, expirado, de outra cliente ou valor de pedido incorreto.';return}var discount=Math.min(total,c.tipo==='percentual'?total*c.valor/100:c.valor);el.textContent='Cupom válido. Desconto calculado: '+R(discount)+'. Prévia: ainda não aplicado ao pedido.'};
  function assistantView(){var alerts=[],open=db.pedidos.filter(function(p){return p.st!=='cancelado'&&p.st!=='entregue'}),balance=open.reduce(function(a,p){return a+saldoDe(p)},0),late=open.filter(function(p){return p.ent&&p.ent<hoje()}),low=db.ingredientes.filter(function(g){return num(g.est)<=num(g.min)}),due=db.despesas.filter(function(d){return !d.pago&&d.venc<hoje()});if(balance>0)alerts.push(open.filter(function(p){return saldoDe(p)>0.01}).length+' pedido(s) com saldo em aberto: '+R(balance)+'.');if(late.length)alerts.push(late.length+' entrega(s) atrasada(s).');if(low.length)alerts.push('Estoque baixo: '+low.map(function(g){return g.nome}).join(', ')+'.');if(due.length)alerts.push(due.length+' conta(s) vencida(s), total '+R(due.reduce(function(a,d){return a+num(d.v)},0))+'.');if(!alerts.length)alerts.push('Nenhum alerta crítico encontrado nos dados atuais.');return '<div class="card"><b>Alertas da confeitaria</b><p class="mut">A KSW reúne avisos automáticos sobre pedidos, saldos, estoque baixo e contas vencidas. Os avisos são regras simples, não uma IA, e não alteram dados sozinhos.</p>'+alerts.map(function(x){return '<div class="kv">'+esc(x)+'</div>'}).join('')+'<button class="btn ghost sm" onclick="go(\'pedidos\')">Ver pedidos</button> <button class="btn ghost sm" onclick="go(\'ingredientes\')">Ver estoque</button></div>'}
  function auditView(){var rows=(db.auditoria||[]).slice().reverse();return '<div class="card"><b>Histórico de alterações</b><p class="mut">Últimos 500 eventos registrados pelos módulos complementares.</p>'+(rows.map(function(x){return '<div class="kv"><span>'+esc(x.acao)+'<small class="mut" style="display:block">'+esc(x.entidade)+' · '+esc(x.entidade_id)+'</small></span><small>'+new Date(x.data).toLocaleString('pt-BR')+'</small></div>'}).join('')||'<p class="mut">Nenhuma alteração registrada.</p>')+'</div>'}
  window.KSWResourceViews={
    tasks:function(){return tasksView();},
    quotes:function(){return quotesView();},
    crm:function(){return crmView();},
    coupons:function(){return couponsView();},
    alerts:function(){return assistantView();},
    audit:function(){return auditView();}
  };
})();
