/* Confeitaê — Fase 3: estoque por lotes, embalagens, produção e perdas.
 * Este arquivo é carregado depois do app principal para substituir as telas iniciais.
 */
(function () {
  'use strict';

  function list(value) { return Array.isArray(value) ? value : []; }
  const inventoryCategories = [
    'Farinhas & Secos', 'Laticínios & Ovos', 'Chocolates & Cacau',
    'Frutas & Castanhas', 'Confeitos & Decorações', 'Embalagens Especiais', 'Outros'
  ];
  const inventoryView = { type: 'ingrediente', query: '', category: 'todas' };

  function numeric(value) {
    const parsed = window.KSWCosting.parseNumber(value);
    return Number.isFinite(parsed) ? parsed : NaN;
  }
  function safeId(value) { return String(value == null ? '' : value).replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 64); }
  function inventoryCollection(type) {
    return type === 'embalagem' ? list(window.db.embalagens) : list(window.db.ingredientes);
  }
  function inventoryType(item, collectionType) {
    if (collectionType === 'embalagem') return 'embalagem';
    return item.tipo_item === 'decoracao' ? 'decoracao' : 'ingrediente';
  }
  function inventoryCategory(item, type) {
    const category = String(item.categoria || '').trim();
    if (inventoryCategories.includes(category)) return category;
    return type === 'embalagem' ? 'Embalagens Especiais' : 'Outros';
  }
  function normalizedSearch(value) {
    return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
  }
  function stockOf(item) {
    const parsed = numeric(item && (item.est != null ? item.est : item.estoque));
    return Number.isFinite(parsed) ? parsed : 0;
  }
  function lotsFor(type, itemId) {
    return list(window.db.lotes).filter((lot) => lot.item_tipo === type && String(lot.item_id) === String(itemId));
  }
  function activeLotsFor(type, itemId) {
    const today = window.hoje();
    return lotsFor(type, itemId).filter((lot) => {
      const quantity = window.KSWProduction.lotQuantity(lot);
      return quantity > 0 && (!lot.validade || String(lot.validade) >= today);
    });
  }
  function nextExpiry(type, itemId) {
    return activeLotsFor(type, itemId)
      .filter((lot) => lot.validade)
      .sort((a, b) => String(a.validade).localeCompare(String(b.validade)))[0] || null;
  }
  function lotSummary(type, itemId) {
    const lots = lotsFor(type, itemId);
    const next = nextExpiry(type, itemId);
    const expired = lots.filter((lot) => lot.validade && lot.validade < window.hoje() && window.KSWProduction.lotQuantity(lot) > 0);
    return { count: lots.filter((lot) => window.KSWProduction.lotQuantity(lot) > 0).length, next, expired: expired.length };
  }
  function itemLabel(type, id) {
    const collection = type === 'ingrediente' ? window.db.ingredientes : window.db.embalagens;
    const item = list(collection).find((entry) => String(entry.id) === String(id));
    return item ? item.nome : 'Item removido';
  }
  function movement(type, id, direction) {
    const item = (type === 'ingrediente' ? window.db.ingredientes : window.db.embalagens)
      .find((entry) => String(entry.id) === String(id));
    if (!item) return window.toast('Item de estoque não encontrado.');
    const suffix = type + '-' + id;
    const quantity = numeric(document.getElementById('stock-qty-' + suffix)?.value);
    if (!(quantity > 0) || quantity > 100000) return window.toast('Informe uma quantidade válida.');
    const unit = String(item.un || 'un');
    const dateInput = document.getElementById('stock-expiry-' + suffix);
    const expiry = dateInput ? dateInput.value : '';
    const costInput = document.getElementById('stock-cost-' + suffix);
    const cost = costInput && costInput.value.trim() ? numeric(costInput.value) : numeric(item.preco);
    if (direction > 0 && costInput && costInput.value.trim() && !(cost >= 0)) return window.toast('Informe um custo por unidade válido.');

    if (direction > 0) {
      item.est = window.KSWProduction.round(stockOf(item) + quantity, 6);
      if (costInput && costInput.value.trim()) item.preco = window.KSWCosting.roundMoney(cost);
      window.db.lotes.push({
        id: window.id(), item_tipo: type, item_id: item.id,
        quantidade_inicial: quantity, quantidade_disponivel: quantity,
        unidade: unit, validade: expiry, custo_unitario: Number.isFinite(cost) ? cost : 0,
        recebido_em: window.hoje(), fornecedor_id: ''
      });
    } else {
      const allocation = window.KSWProduction.planLotConsumption(lotsFor(type, id), stockOf(item), quantity, window.hoje());
      if (!allocation.valid) return window.toast(allocation.error);
      allocation.lot_updates.forEach((update) => {
        const lot = window.db.lotes.find((entry) => String(entry.id) === update.id);
        if (lot) lot.quantidade_disponivel = update.quantidade_disponivel;
      });
      item.est = allocation.stock_after;
    }

    window.db.mov.push({
      id: window.id(), ing: item.nome, ingrediente_id: item.id,
      item_tipo: type, item_id: item.id,
      tipo: direction > 0 ? 'entrada' : 'saida', qtd: quantity,
      data: window.hoje(), motivo: direction > 0 ? 'Entrada de compra / reposição' : 'Saída manual'
    });
    if (typeof window.audit === 'function') window.audit('estoque', item.id, (direction > 0 ? 'Entrada ' : 'Saída ') + quantity + ' ' + unit);
    window.saveLocalDB();
    window.render();
    window.toast(direction > 0 ? 'Entrada registrada e lote criado.' : 'Saída registrada pelo critério FEFO.');
  }

  function inventoryRow(item, type) {
    const id = safeId(item.id);
    const suffix = type + '-' + id;
    const unit = String(item.un || 'un');
    const stock = stockOf(item);
    const minimum = numeric(item.min || 0) || 0;
    const storageType = type === 'embalagem' ? 'embalagem' : 'ingrediente';
    const summary = lotSummary(storageType, item.id);
    const category = inventoryCategory(item, type);
    const low = minimum > 0 && stock <= minimum;
    const icon = type === 'embalagem' ? '▧' : type === 'decoracao' ? '✦' : '✣';
    const nextText = summary.next
      ? `<small class="ksw-inventory-expiry">Próximo vencimento: ${window.esc(window.D(summary.next.validade))}</small>`
      : '';
    return `<tr id="stock-card-${suffix}" class="ksw-inventory-row" data-search="${window.esc(normalizedSearch(item.nome))}" data-category="${window.esc(category)}">
      <td data-label="Item"><div class="ksw-inventory-name"><span class="ksw-inventory-icon ksw-inventory-icon-${type}" aria-hidden="true">${icon}</span><span title="${window.esc(item.nome)}">${window.esc(item.nome)}</span></div>${nextText}${summary.expired ? `<small class="ksw-inventory-expiry is-expired">${summary.expired} lote(s) vencido(s)</small>` : ''}</td>
      <td data-label="Categoria"><span class="ksw-inventory-category">${window.esc(category)}</span></td>
      <td data-label="Preço/Unid"><b>${window.R(item.preco || 0)}/${window.esc(unit)}</b></td>
      <td data-label="Estoque"><span class="${low ? 'ksw-inventory-stock is-low' : 'ksw-inventory-stock'}">${stock.toLocaleString('pt-BR')} ${window.esc(unit)}</span>${low ? '<span class="ksw-inventory-low-tag">Baixo</span>' : ''}<details class="ksw-inventory-movement"><summary>Entrada ou saída</summary><div class="ksw-inventory-movement-fields">
        <label for="stock-qty-${suffix}">Quantidade<input id="stock-qty-${suffix}" type="number" min="0.000001" step="any" inputmode="decimal" placeholder="0"></label>
        <label for="stock-expiry-${suffix}">Validade do lote<input id="stock-expiry-${suffix}" type="date" min="${window.hoje()}"></label>
        <label for="stock-cost-${suffix}">Custo por ${window.esc(unit)}<input id="stock-cost-${suffix}" type="number" min="0" step="0.0001" placeholder="${window.esc(String(item.preco || 0))}"></label>
        <div class="ksw-inventory-movement-buttons"><button class="btn sm" type="button" onclick="moveInventoryKSW('${storageType}','${id}',1)">Entrada</button><button class="btn ghost sm" type="button" onclick="moveInventoryKSW('${storageType}','${id}',-1)">Saída</button></div>
      </div></details></td>
      <td data-label="Alerta mín">${minimum > 0 ? `${minimum.toLocaleString('pt-BR')} ${window.esc(unit)}` : '<span class="ksw-inventory-no-min">Não definido</span>'}</td>
      <td data-label="Ações"><div class="ksw-inventory-actions"><button class="ksw-icon-button" type="button" aria-label="Editar ${window.esc(item.nome)}" title="Editar item" onclick="openInventoryItemKSW('${type}','${id}')">✎</button><button class="ksw-icon-button is-danger" type="button" aria-label="Excluir ${window.esc(item.nome)}" title="Excluir item" onclick="deleteInventoryItemKSW('${type}','${id}')">⌫</button></div></td>
    </tr>`;
  }

  window.moveInventoryKSW = movement;

  window.setInventoryTypeKSW = function (type) {
    if (!['ingrediente', 'embalagem', 'decoracao'].includes(type)) return;
    inventoryView.type = type;
    window.render();
  };
  window.filterInventoryKSW = function () {
    const search = document.getElementById('inventory-search');
    const category = document.getElementById('inventory-category');
    if (search) inventoryView.query = search.value;
    if (category) inventoryView.category = category.value;
    const query = normalizedSearch(inventoryView.query).trim();
    const rows = Array.from(document.querySelectorAll('.ksw-inventory-row'));
    let visible = 0;
    rows.forEach((row) => {
      const matches = (!query || row.dataset.search.includes(query)) &&
        (inventoryView.category === 'todas' || row.dataset.category === inventoryView.category);
      row.hidden = !matches;
      if (matches) visible += 1;
    });
    const table = document.querySelector('.ksw-inventory-table');
    const empty = document.getElementById('inventory-empty');
    const count = document.getElementById('inventory-visible-count');
    if (table) table.hidden = visible === 0;
    if (empty) {
      empty.hidden = visible > 0;
      const total = Number(empty.dataset.total || 0);
      empty.querySelector('b').textContent = total === 0
        ? 'Nenhum item cadastrado nesta seção.'
        : 'Nenhum item encontrado com esses filtros.';
      empty.querySelector('p').textContent = total === 0
        ? 'Adicione os ingredientes, embalagens ou decorações que você usa no ateliê.'
        : 'Tente outro nome ou escolha uma categoria diferente.';
      const action = empty.querySelector('button');
      if (action) action.hidden = total > 0;
    }
    if (count) count.textContent = `${visible} ${visible === 1 ? 'item' : 'itens'}`;
  };
  window.resetInventoryFiltersKSW = function () {
    inventoryView.query = '';
    inventoryView.category = 'todas';
    window.render();
  };
  window.updatePackPriceKSW = function () {
    const dialog = document.getElementById('inventory-item-dialog');
    if (!dialog) return;
    const result = dialog.querySelector('#inventory-pack-result');
    const quantity = numeric(dialog.querySelector('#inventory-pack-qty').value);
    const paid = numeric(dialog.querySelector('#inventory-pack-paid').value);
    const packUnit = dialog.querySelector('#inventory-pack-unit').value;
    if (!(quantity > 0) || !(paid >= 0) || dialog.querySelector('#inventory-pack-paid').value.trim() === '') {
      result.textContent = 'Preencha os três campos e o preço por kg, L ou unidade aparece abaixo.';
      return;
    }
    const target = ['g', 'kg'].includes(packUnit) ? 'kg' : ['ml', 'L'].includes(packUnit) ? 'L' : 'un';
    const baseQuantity = window.KSWCosting.convertQuantity(quantity, packUnit, target);
    if (!(baseQuantity > 0)) { result.textContent = 'Não foi possível converter essa medida.'; return; }
    const unitPrice = window.KSWCosting.roundMoney(paid / baseQuantity);
    dialog.querySelector('#inventory-item-unit').value = target;
    dialog.querySelector('#inventory-item-price').value = String(unitPrice).replace('.', ',');
    result.textContent = `Pronto: ${unitPrice.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} por ${target}. A unidade e o preço abaixo já foram preenchidos.`;
  };
  window.openInventoryItemKSW = function (type, itemId) {
    if (!['ingrediente', 'embalagem', 'decoracao'].includes(type)) return window.toast('Tipo de item inválido.');
    const item = itemId ? inventoryCollection(type).find((entry) => String(entry.id) === String(itemId)) : null;
    if (itemId && !item) return window.toast('Item de estoque não encontrado.');
    const dialog = document.getElementById('inventory-item-dialog');
    if (!dialog) return window.toast('Não foi possível abrir o cadastro de item.');
    const editing = Boolean(item);
    const category = item
      ? inventoryCategory(item, type)
      : (type === 'embalagem' ? 'Embalagens Especiais' : type === 'decoracao' ? 'Confeitos & Decorações' : 'Farinhas & Secos');
    dialog.querySelector('#inventory-item-id').value = item ? item.id : '';
    dialog.querySelector('#inventory-item-type').value = type;
    dialog.querySelector('#inventory-item-name').value = item ? item.nome : '';
    dialog.querySelector('#inventory-item-category').value = category;
    dialog.querySelector('#inventory-item-unit').value = item ? item.un || 'un' : type === 'embalagem' ? 'un' : 'kg';
    dialog.querySelector('#inventory-item-price').value = item ? String(item.preco || 0).replace('.', ',') : '';
    dialog.querySelector('#inventory-item-minimum').value = item ? String(item.min || 0).replace('.', ',') : '';
    dialog.querySelector('#inventory-item-stock').value = '0';
    dialog.querySelector('#inventory-pack-qty').value = '';
    dialog.querySelector('#inventory-pack-paid').value = '';
    dialog.querySelector('#inventory-pack-result').textContent = 'Preencha os três campos e o preço por kg, L ou unidade aparece abaixo.';
    dialog.querySelector('.ksw-pack-helper').hidden = editing;
    dialog.querySelector('#inventory-item-expiry').value = '';
    dialog.querySelector('#inventory-item-create-fields').hidden = editing;
    dialog.querySelector('#inventory-item-create-expiry').hidden = editing;
    dialog.querySelector('#inventory-item-current-stock').textContent = item
      ? `Estoque atual: ${stockOf(item).toLocaleString('pt-BR')} ${item.un || 'un'}. Para ajustar o saldo, use “Entrada ou saída” na lista.`
      : '';
    dialog.querySelector('#inventory-item-title').textContent = editing ? 'Editar item' : 'Novo item';
    dialog.querySelector('#inventory-item-save').textContent = editing ? 'Salvar alterações' : 'Adicionar item';
    dialog.showModal();
    dialog.querySelector('#inventory-item-name').focus();
  };
  window.closeInventoryItemKSW = function () {
    const dialog = document.getElementById('inventory-item-dialog');
    if (dialog && dialog.open) dialog.close();
  };
  window.saveInventoryItemKSW = function (event) {
    event.preventDefault();
    const dialog = document.getElementById('inventory-item-dialog');
    const id = dialog.querySelector('#inventory-item-id').value;
    const type = dialog.querySelector('#inventory-item-type').value;
    const name = dialog.querySelector('#inventory-item-name').value.trim();
    const category = dialog.querySelector('#inventory-item-category').value;
    const unit = dialog.querySelector('#inventory-item-unit').value.trim();
    const priceValue = dialog.querySelector('#inventory-item-price').value.trim();
    const price = numeric(priceValue);
    const minimumValue = dialog.querySelector('#inventory-item-minimum').value.trim();
    const minimum = minimumValue ? numeric(minimumValue) : 0;
    if (!['ingrediente', 'embalagem', 'decoracao'].includes(type)) return window.toast('Tipo de item inválido.');
    if (!name || name.length > 100) return window.toast('Informe um nome com até 100 caracteres.');
    if (!inventoryCategories.includes(category)) return window.toast('Escolha uma categoria válida.');
    if (!unit || unit.length > 20) return window.toast('Informe uma unidade com até 20 caracteres.');
    if (priceValue === '' || !(price >= 0)) return window.toast('Informe um preço por unidade válido.');
    if (!(minimum >= 0) || minimum > 100000000) return window.toast('Informe um alerta mínimo válido.');

    const editing = Boolean(id);
    const collection = inventoryCollection(type);
    let item = editing ? collection.find((entry) => String(entry.id) === String(id)) : null;
    if (editing && !item) return window.toast('Item de estoque não encontrado.');
    if (item) {
      item.nome = name;
      item.un = unit;
      item.preco = window.KSWCosting.roundMoney(price);
      item.min = minimum;
      item.categoria = category;
      if (type !== 'embalagem') item.tipo_item = type;
    } else {
      const stockValue = dialog.querySelector('#inventory-item-stock').value.trim();
      const stock = stockValue ? numeric(stockValue) : 0;
      const expiry = dialog.querySelector('#inventory-item-expiry').value;
      if (!(stock >= 0) || stock > 100000000) return window.toast('Informe um estoque inicial válido.');
      if (expiry && expiry < window.hoje()) return window.toast('A validade inicial não pode estar no passado.');
      item = {
        id: window.id(), nome: name, un: unit,
        preco: window.KSWCosting.roundMoney(price), est: stock,
        min: minimum, categoria: category
      };
      if (type === 'embalagem') {
        window.db.embalagens.push(item);
      } else {
        item.tipo_item = type;
        window.db.ingredientes.push(item);
      }
      if (stock > 0) {
        const storageType = type === 'embalagem' ? 'embalagem' : 'ingrediente';
        window.db.lotes.push({
          id: window.id(), item_tipo: storageType, item_id: item.id,
          quantidade_inicial: stock, quantidade_disponivel: stock,
          unidade: unit, validade: expiry, custo_unitario: price,
          recebido_em: window.hoje(), fornecedor_id: ''
        });
        window.db.mov.push({
          id: window.id(), ing: name, ingrediente_id: item.id,
          item_tipo: storageType, item_id: item.id, tipo: 'entrada_inicial',
          qtd: stock, data: window.hoje(), motivo: 'Saldo inicial cadastrado'
        });
      }
    }
    inventoryView.type = type;
    window.saveLocalDB();
    window.render();
    window.toast(editing ? 'Item atualizado.' : 'Item adicionado ao seu estoque.');
  };
  window.deleteInventoryItemKSW = function (type, itemId) {
    if (!['ingrediente', 'embalagem', 'decoracao'].includes(type)) return window.toast('Tipo de item inválido.');
    const storageType = type === 'embalagem' ? 'embalagem' : 'ingrediente';
    const collection = inventoryCollection(type);
    const item = collection.find((entry) => String(entry.id) === String(itemId));
    if (!item) return window.toast('Item de estoque não encontrado.');
    const referenced = list(window.db.lotes).some((entry) => entry.item_tipo === storageType && String(entry.item_id) === String(itemId)) ||
      list(window.db.mov).some((entry) => (entry.item_tipo === storageType && String(entry.item_id) === String(itemId)) ||
        (storageType === 'ingrediente' && !entry.item_tipo && String(entry.ingrediente_id) === String(itemId))) ||
      list(window.db.perdas).some((entry) => entry.item_tipo === storageType && String(entry.item_id) === String(itemId)) ||
      list(window.db.producao).some((entry) => list(entry.consumos).some((consumption) =>
        (consumption.item_type || consumption.item_tipo) === storageType && String(consumption.item_id) === String(itemId))) ||
      list(window.db.produtos).some((product) => storageType === 'ingrediente'
        ? list(product.itens).some((line) => String(line.ing) === String(itemId))
        : String(product.embalagem_id || '') === String(itemId));
    if (referenced || stockOf(item) > 0) return window.toast('Este item tem estoque ou histórico relacionado e não pode ser excluído. Edite o cadastro ou registre uma saída.');
    if (!window.confirm(`Excluir “${item.nome}”? Esta ação não pode ser desfeita.`)) return;
    collection.splice(collection.indexOf(item), 1);
    window.saveLocalDB();
    window.render();
    window.toast('Item excluído.');
  };

  window.vIng = function vIngPhase3() {
    const ingredients = list(window.db.ingredientes);
    const packagings = list(window.db.embalagens);
    const selectedType = inventoryView.type;
    const selectedItems = (selectedType === 'embalagem' ? packagings : ingredients)
      .filter((item) => inventoryType(item, selectedType === 'embalagem' ? 'embalagem' : 'ingrediente') === selectedType)
      .slice().sort((a, b) => String(a.nome || '').localeCompare(String(b.nome || ''), 'pt-BR'));
    const query = normalizedSearch(inventoryView.query).trim();
    const displayedItems = selectedItems.filter((item) =>
      (!query || normalizedSearch(item.nome).includes(query)) &&
      (inventoryView.category === 'todas' || inventoryCategory(item, selectedType) === inventoryView.category)
    );
    const demandForecast = window.KSWProduction.calculateDemandShortages({
      orders: list(window.db.pedidos), productions: list(window.db.producao),
      products: list(window.db.produtos), ingredients, packagings, lots: list(window.db.lotes)
    }, window.hoje());
    const totalLow = ingredients.filter((item) => numeric(item.min || 0) > 0 && stockOf(item) <= numeric(item.min)).length +
      packagings.filter((item) => numeric(item.min || 0) > 0 && stockOf(item) <= numeric(item.min)).length;
    const ingredientCount = ingredients.filter((item) => inventoryType(item, 'ingrediente') === 'ingrediente').length;
    const decorationCount = ingredients.filter((item) => inventoryType(item, 'ingrediente') === 'decoracao').length;
    const packagingCount = packagings.length;
    const categoryOptions = ['todas', ...inventoryCategories].map((category) =>
      `<option value="${window.esc(category)}" ${inventoryView.category === category ? 'selected' : ''}>${category === 'todas' ? 'Todas as categorias' : window.esc(category)}</option>`
    ).join('');
    let html = `<header class="ksw-inventory-heading"><div><h2>Meus Itens</h2><p>Gerencie seus ingredientes, embalagens e decorações.</p></div><button class="btn ksw-inventory-add" type="button" onclick="openInventoryItemKSW('${selectedType}')"><span aria-hidden="true">＋</span> Novo item</button></header>`;
    html += `<section class="ksw-inventory-manager" aria-label="Gerenciar itens do estoque">
      <div class="ksw-inventory-filters">
        <label class="ksw-inventory-search"><span aria-hidden="true">⌕</span><input id="inventory-search" type="search" aria-label="Buscar item pelo nome" placeholder="Buscar item pelo nome…" value="${window.esc(inventoryView.query)}" oninput="filterInventoryKSW()"></label>
        <label class="ksw-inventory-category-filter"><span aria-hidden="true">◇</span><select id="inventory-category" aria-label="Filtrar por categoria" onchange="filterInventoryKSW()">${categoryOptions}</select></label>
      </div>
      <div class="ksw-inventory-tabs" role="tablist" aria-label="Tipo de item">
        <button type="button" role="tab" aria-selected="${selectedType === 'ingrediente'}" class="${selectedType === 'ingrediente' ? 'is-active' : ''}" onclick="setInventoryTypeKSW('ingrediente')">✣ <span>Ingredientes</span><small>${ingredientCount}</small></button>
        <button type="button" role="tab" aria-selected="${selectedType === 'embalagem'}" class="${selectedType === 'embalagem' ? 'is-active' : ''}" onclick="setInventoryTypeKSW('embalagem')">▧ <span>Embalagens</span><small>${packagingCount}</small></button>
        <button type="button" role="tab" aria-selected="${selectedType === 'decoracao'}" class="${selectedType === 'decoracao' ? 'is-active' : ''}" onclick="setInventoryTypeKSW('decoracao')">✦ <span>Decorações</span><small>${decorationCount}</small></button>
      </div>
      <div class="ksw-inventory-table-wrap">
        <table class="ksw-inventory-table" ${displayedItems.length ? '' : 'hidden'}>
          <thead><tr><th>Item</th><th>Categoria</th><th>Preço/Unid</th><th>Estoque</th><th>Alerta mín</th><th>Ações</th></tr></thead>
          <tbody>${displayedItems.map((item) => inventoryRow(item, selectedType)).join('')}</tbody>
        </table>
      </div>
      <div id="inventory-empty" class="ksw-inventory-empty" data-total="${selectedItems.length}" ${displayedItems.length ? 'hidden' : ''}>
        <span aria-hidden="true">${selectedType === 'embalagem' ? '▧' : selectedType === 'decoracao' ? '✦' : '✣'}</span>
        <b>${selectedItems.length ? 'Nenhum item encontrado com esses filtros.' : 'Nenhum item cadastrado nesta seção.'}</b>
        <p>${selectedItems.length ? 'Tente outro nome ou escolha uma categoria diferente.' : 'Adicione os ingredientes, embalagens ou decorações que você usa no ateliê.'}</p>
        <button class="btn sm" type="button" onclick="openInventoryItemKSW('${selectedType}')" ${selectedItems.length ? 'hidden' : ''}>Adicionar primeiro item</button>
      </div>
      <footer class="ksw-inventory-footer"><span id="inventory-visible-count">${displayedItems.length} ${displayedItems.length === 1 ? 'item' : 'itens'}</span><span>${window.demoMode ? 'Os dados desta demonstração são fictícios e não serão salvos.' : 'Cadastre os itens usados pela sua confeitaria; o estoque começa vazio.'}</span></footer>
    </section>
    <dialog id="inventory-item-dialog" class="ksw-inventory-dialog" onclick="if(event.target===this)closeInventoryItemKSW()">
      <form class="ksw-inventory-form" onsubmit="saveInventoryItemKSW(event)">
        <header><div><span class="ksw-eyebrow">ESTOQUE DO ATELIÊ</span><h2 id="inventory-item-title">Novo item</h2></div><button type="button" class="ksw-icon-button" aria-label="Fechar" onclick="closeInventoryItemKSW()">×</button></header>
        <input id="inventory-item-id" type="hidden"><input id="inventory-item-type" type="hidden">
        <label for="inventory-item-name">Nome do item</label><input id="inventory-item-name" maxlength="100" required placeholder="Ex.: Farinha de trigo">
        <label for="inventory-item-category">Categoria</label><select id="inventory-item-category">${inventoryCategories.map((category) => `<option value="${window.esc(category)}">${window.esc(category)}</option>`).join('')}</select>
        <fieldset class="ksw-pack-helper"><legend>Comprou em embalagem? O KSW faz a conta do preço</legend>
          <div class="ksw-pack-grid">
            <div><label for="inventory-pack-qty">Quanto vem nela</label><input id="inventory-pack-qty" type="text" inputmode="decimal" placeholder="Ex.: 395" oninput="updatePackPriceKSW()"></div>
            <div><label for="inventory-pack-unit">Medida</label><select id="inventory-pack-unit" onchange="updatePackPriceKSW()"><option value="g">g</option><option value="kg">kg</option><option value="ml">ml</option><option value="L">L</option><option value="un">un</option><option value="dúzia">dúzia</option></select></div>
            <div><label for="inventory-pack-paid">Quanto pagou (R$)</label><input id="inventory-pack-paid" type="text" inputmode="decimal" placeholder="Ex.: 6,50" oninput="updatePackPriceKSW()"></div>
          </div>
          <p id="inventory-pack-result" class="ksw-pack-result" aria-live="polite">Preencha os três campos e o preço por kg, L ou unidade aparece abaixo.</p>
        </fieldset>
        <div class="ksw-inventory-form-grid"><div><label for="inventory-item-unit">Unidade de compra</label><input id="inventory-item-unit" maxlength="20" required list="ksw-units" placeholder="kg, g, L ou un"><datalist id="ksw-units"><option value="kg"><option value="g"><option value="L"><option value="ml"><option value="un"><option value="lata"><option value="pacote"><option value="caixa"></datalist></div><div><label for="inventory-item-price">Preço por unidade (R$)</label><input id="inventory-item-price" type="text" inputmode="decimal" required placeholder="Ex.: 38,90"></div></div>
        <div class="ksw-inventory-form-grid"><div><label for="inventory-item-minimum">Alerta mínimo</label><input id="inventory-item-minimum" type="text" inputmode="decimal" placeholder="Opcional · 0 desativa"></div><div id="inventory-item-create-fields"><label for="inventory-item-stock">Estoque inicial</label><input id="inventory-item-stock" type="text" inputmode="decimal" value="0"></div></div>
        <div id="inventory-item-create-expiry" class="ksw-inventory-form-expiry"><label for="inventory-item-expiry">Validade (opcional)</label><input id="inventory-item-expiry" type="date" min="${window.hoje()}"></div>
        <p id="inventory-item-current-stock" class="ksw-inventory-current-stock"></p>
        <p class="ksw-inventory-form-note">O saldo inicial informado será registrado como entrada no estoque. Depois, use Entrada ou saída para manter lotes e movimentações corretos.</p>
        <footer><button class="btn ghost" type="button" onclick="closeInventoryItemKSW()">Cancelar</button><button id="inventory-item-save" class="btn" type="submit">Adicionar item</button></footer>
      </form>
    </dialog>`;
    const shopping = window.KSWProduction.buildShoppingList({
      orders: list(window.db.pedidos), productions: list(window.db.producao),
      products: list(window.db.produtos), ingredients, packagings, lots: list(window.db.lotes)
    }, window.hoje());
    const money = (value) => Number(value || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    html += `<section id="shopping-list" class="card ksw-restock-list"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Compras calculadas automaticamente</span><h3>Lista de compras</h3></div><span class="tag ${shopping.items.length ? 'late' : 'ok'}">${shopping.items.length} item(ns) para comprar</span></div>`;
    if (shopping.items.length) {
      html += `<p class="mut">Cada quantidade soma o que os pedidos e produções em aberto exigem com o estoque mínimo e desconta só o estoque aproveitável (lotes vencidos não contam). A lista não registra compras.</p>`;
      html += shopping.items.map((row) => {
        const itemKind = row.item_type === 'embalagem' ? 'Embalagem' : 'Ingrediente';
        const reason = row.reason === 'pedidos' ? 'pedidos em aberto' : 'estoque mínimo';
        const cost = row.estimated_cost == null ? 'preço não cadastrado' : `≈ ${money(row.estimated_cost)}`;
        return `<div class="ksw-restock-row"><div><b>${window.esc(row.name)}</b><small>${itemKind} · motivo: ${reason} · disponível ${row.available.toLocaleString('pt-BR')} ${window.esc(row.unit)} · ${cost}</small></div><strong>Comprar ${row.quantity.toLocaleString('pt-BR')} ${window.esc(row.unit)}</strong><button class="btn ghost sm" type="button" onclick="prepareRestockKSW('${window.esc(row.item_type)}','${window.esc(safeId(row.item_id))}',${row.quantity})">Preparar entrada</button></div>`;
      }).join('');
      html += `<div class="ksw-restock-actions"><button class="btn ghost sm" type="button" onclick="copyShoppingListKSW()">Copiar lista</button><button class="btn ghost sm" type="button" onclick="shareShoppingListKSW()">Enviar por WhatsApp</button></div>`;
      html += `<div class="ksw-profit-note"><b>Custo estimado: ${shopping.partial ? 'pelo menos ' : ''}${money(shopping.total_estimated)}</b>${shopping.missing_price_count ? `<p>${shopping.missing_price_count} item(ns) sem preço cadastrado ficaram fora do total.</p>` : ''}${shopping.skipped.length ? `<p>${shopping.skipped.length} produto(s) sem ficha técnica completa não entraram no cálculo.</p>` : ''}</div>`;
    } else {
      html += '<p class="ksw-profit-good">Nada a comprar: o estoque aproveitável cobre os pedidos em aberto e os mínimos cadastrados.</p>';
    }
    html += '</section>';
    html += `<section id="order-demand-list" class="card ksw-restock-list"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Compras calculadas automaticamente</span><h3>O que falta para atender os pedidos</h3></div><span class="tag ${demandForecast.shortages.length ? 'late' : 'ok'}">${demandForecast.shortages.length} item(ns) em falta</span></div>`;
    if (!demandForecast.demand_count) {
      html += '<p class="mut">Quando houver pedidos em aberto ou produções planejadas com fichas técnicas completas, o KSW calculará os ingredientes e as embalagens necessários aqui.</p>';
    } else if (demandForecast.shortages.length) {
      html += '<p class="mut">O KSW somou os materiais das encomendas e produções ainda não concluídas, descontou o estoque aproveitável e considerou lotes vencidos como indisponíveis. Esta é uma previsão; nenhuma compra ou movimentação foi registrada.</p>';
      html += demandForecast.shortages.map((entry) => `<div class="ksw-restock-row"><div><b>${window.esc(entry.name)}</b><small>Necessário ${entry.required.toLocaleString('pt-BR')} ${window.esc(entry.unit)} · disponível ${entry.available.toLocaleString('pt-BR')} ${window.esc(entry.unit)}</small></div><strong>Comprar ${entry.shortage.toLocaleString('pt-BR')} ${window.esc(entry.unit)}</strong><button class="btn ghost sm" type="button" onclick="prepareRestockKSW('${window.esc(entry.item_type)}','${window.esc(safeId(entry.item_id))}',${entry.shortage})">Preparar entrada</button></div>`).join('');
    } else {
      html += '<p class="ksw-profit-good">O estoque aproveitável cobre os materiais calculados para os pedidos e produções em aberto.</p>';
    }
    if (demandForecast.skipped.length) {
      html += `<div class="ksw-profit-note"><b>${demandForecast.skipped.length} produto(s) não entraram na previsão.</b><p>Complete a ficha técnica de ${demandForecast.skipped.map((entry) => window.esc(entry.product_name || 'um produto')).join(', ')} para calcular a compra necessária. O KSW não inventou quantidades para esses produtos.</p></div>`;
    }
    html += '</section>';
    const movements = list(window.db.mov).slice().reverse().slice(0, 40);
    html += `<details class="card ksw-inventory-history"><summary>Histórico de movimentações (${movements.length})</summary>${movements.length ? movements.map((entry) => `<div class="kv"><span>${window.esc(entry.ing || itemLabel(entry.item_tipo || 'ingrediente', entry.item_id || entry.ingrediente_id))} · ${window.esc(entry.tipo)}<small class="mut" style="display:block">${window.esc(entry.motivo || 'Movimentação de estoque')}</small></span><span>${numeric(entry.qtd || 0).toLocaleString('pt-BR')} · ${window.D(entry.data || entry.criado_em)}</span></div>`).join('') : '<p class="mut">Ainda não há movimentações.</p>'}</details>`;
    return html;
  };

  function currentShoppingText() {
    const shopping = window.KSWProduction.buildShoppingList({
      orders: list(window.db.pedidos), productions: list(window.db.producao),
      products: list(window.db.produtos), ingredients: list(window.db.ingredientes),
      packagings: list(window.db.embalagens), lots: list(window.db.lotes)
    }, window.hoje());
    return window.KSWProduction.formatShoppingListText(shopping, 'Lista de compras — ' + window.D(window.hoje()));
  }

  window.copyShoppingListKSW = function () {
    const text = currentShoppingText();
    if (!text) return window.toast('Não há itens para comprar.');
    const done = () => window.toast('Lista copiada.');
    const fail = () => window.toast('Não foi possível copiar. Use o envio por WhatsApp.');
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fail);
    else fail();
  };

  window.shareShoppingListKSW = function () {
    const text = currentShoppingText();
    if (!text) return window.toast('Não há itens para comprar.');
    window.open('https://wa.me/?text=' + encodeURIComponent(text), '_blank', 'noopener');
  };

  window.prepareRestockKSW = function (type, itemId, quantity) {
    if (!['ingrediente', 'embalagem', 'decoracao'].includes(type)) return window.toast('Tipo de item inválido.');
    const item = inventoryCollection(type)
      .find((entry) => String(entry.id) === String(itemId));
    if (!item) return window.toast('Item de estoque não encontrado.');
    const needsViewChange = inventoryView.type !== type || inventoryView.query !== '' || inventoryView.category !== 'todas';
    if (needsViewChange) {
      inventoryView.type = type;
      inventoryView.query = '';
      inventoryView.category = 'todas';
      window.render();
    }
    const suffix = `${type}-${safeId(item.id)}`;
    const card = document.getElementById(`stock-card-${suffix}`);
    const input = document.getElementById(`stock-qty-${suffix}`);
    const amount = numeric(quantity);
    if (!card || !input || !(amount > 0)) return window.toast('Não foi possível preparar a reposição deste item.');
    input.value = String(window.KSWProduction.round(amount, 6));
    card.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'center' });
    input.focus({ preventScroll: true });
  };

  window.addIngredientPhase3KSW = function () {
    const name = document.getElementById('in')?.value.trim();
    const unit = document.getElementById('iu')?.value.trim() || 'un';
    const price = numeric(document.getElementById('ip')?.value);
    const stock = numeric(document.getElementById('ie')?.value || 0);
    const minimum = numeric(document.getElementById('im')?.value || 0);
    const expiry = document.getElementById('iv')?.value || '';
    if (!name) return window.toast('Informe o nome do ingrediente.');
    if (!(price >= 0) || !(stock >= 0) || !(minimum >= 0)) return window.toast('Revise preço e quantidades; não podem ser negativos.');
    if (expiry && expiry < window.hoje()) return window.toast('A validade inicial não pode estar no passado.');
    const item = { id: window.id(), nome: name, un: unit, preco: window.KSWCosting.roundMoney(price), est: stock, min: minimum, val: expiry };
    window.db.ingredientes.push(item);
    if (stock > 0) {
      window.db.lotes.push({ id: window.id(), item_tipo: 'ingrediente', item_id: item.id, quantidade_inicial: stock, quantidade_disponivel: stock, unidade: unit, validade: expiry, custo_unitario: price, recebido_em: window.hoje(), fornecedor_id: '' });
      window.db.mov.push({ id: window.id(), ing: name, ingrediente_id: item.id, item_tipo: 'ingrediente', item_id: item.id, tipo: 'entrada_inicial', qtd: stock, data: window.hoje(), motivo: 'Saldo inicial cadastrado' });
    }
    window.saveLocalDB(); window.render(); window.toast('Ingrediente cadastrado.');
  };

  window.addPackagingPhase3KSW = function () {
    const name = document.getElementById('pack-name')?.value.trim();
    const unit = document.getElementById('pack-unit')?.value || 'un';
    const price = numeric(document.getElementById('pack-price')?.value);
    const stock = numeric(document.getElementById('pack-stock')?.value || 0);
    const minimum = numeric(document.getElementById('pack-min')?.value || 0);
    const expiry = document.getElementById('pack-expiry')?.value || '';
    if (!name) return window.toast('Informe o nome da embalagem.');
    if (!(price >= 0) || !(stock >= 0) || !(minimum >= 0)) return window.toast('Revise preço e quantidades; não podem ser negativos.');
    if (expiry && expiry < window.hoje()) return window.toast('A validade não pode estar no passado.');
    const item = { id: window.id(), nome: name, un: unit, preco: window.KSWCosting.roundMoney(price), est: stock, min: minimum, val: expiry };
    window.db.embalagens.push(item);
    if (stock > 0) {
      window.db.lotes.push({ id: window.id(), item_tipo: 'embalagem', item_id: item.id, quantidade_inicial: stock, quantidade_disponivel: stock, unidade: unit, validade: expiry, custo_unitario: price, recebido_em: window.hoje(), fornecedor_id: '' });
      window.db.mov.push({ id: window.id(), ing: name, ingrediente_id: item.id, item_tipo: 'embalagem', item_id: item.id, tipo: 'entrada_inicial', qtd: stock, data: window.hoje(), motivo: 'Saldo inicial cadastrado' });
    }
    window.saveLocalDB(); window.render(); window.toast('Embalagem cadastrada.');
  };

  // Mantém compatibilidade com chamadas antigas addIng()/mov() espalhadas pelo app.
  window.addIng = window.addIngredientPhase3KSW;
  window.mov = function (id, direction) { movement('ingrediente', id, direction); };

  window.createProductionKSW = function (orderId, productId, quantity, dueDate) {
    const product = list(window.db.produtos).find((entry) => String(entry.id) === String(productId));
    if (!product) return window.toast('Produto não encontrado.');
    const plan = window.KSWProduction.buildProductionPlan(product, quantity, window.db.ingredientes, window.db.embalagens);
    if (!plan.valid) return window.toast(plan.errors[0]);
    const order = orderId ? list(window.db.pedidos).find((entry) => String(entry.id) === String(orderId)) : null;
    const duplicate = orderId && list(window.db.producao).some((entry) => entry.pedido_id === orderId && entry.produto_id === productId && entry.status !== 'cancelada');
    if (duplicate) return window.toast('Já existe uma ordem de produção para este produto neste pedido.');
    const record = {
      id: window.id(), pedido_id: orderId || '', produto_id: productId,
      produto_nome: product.nome, pedido_cliente: order ? window.cliNome(order) : '',
      quantidade: plan.requested_quantity, quantidade_prevista: plan.produced_quantity,
      data_prevista: dueDate || (order && order.ent) || window.hoje(),
      status: 'planejada', consumo_aplicado: false, criado_em: new Date().toISOString()
    };
    window.db.producao.push(record);
    window.saveLocalDB(); window.render(); window.toast('Ordem de produção criada.');
  };

  window.createProductionFromOrderKSW = function (orderId, productId, quantity) {
    const order = list(window.db.pedidos).find((entry) => String(entry.id) === String(orderId));
    if (!order) return window.toast('Pedido não encontrado.');
    window.createProductionKSW(orderId, productId, quantity, order.ent);
  };

  window.startProductionKSW = function (productionId) {
    const record = list(window.db.producao).find((entry) => String(entry.id) === String(productionId));
    if (!record || record.consumo_aplicado || record.status === 'cancelada') return;
    record.status = 'em_producao'; record.iniciado_em = new Date().toISOString();
    window.saveLocalDB(); window.render(); window.toast('Produção iniciada.');
  };

  function applyLocalConsumption(type, itemId, quantity, reason, context) {
    const collection = type === 'ingrediente' ? window.db.ingredientes : window.db.embalagens;
    const item = collection.find((entry) => String(entry.id) === String(itemId));
    if (!item) throw new Error('Item de estoque não encontrado.');
    const allocation = window.KSWProduction.planLotConsumption(lotsFor(type, itemId), stockOf(item), quantity, window.hoje());
    if (!allocation.valid) throw new Error(item.nome + ': ' + allocation.error);
    allocation.lot_updates.forEach((update) => {
      const lot = window.db.lotes.find((entry) => String(entry.id) === update.id);
      if (lot) lot.quantidade_disponivel = update.quantidade_disponivel;
    });
    item.est = allocation.stock_after;
    const unitCost = Number.isFinite(numeric(item.preco)) ? numeric(item.preco) : 0;
    const estimatedCost = window.KSWProduction.estimateConsumptionCost(allocation, lotsFor(type, itemId), unitCost);
    window.db.mov.push({
      id: window.id(), ing: item.nome, ingrediente_id: item.id,
      item_tipo: type, item_id: item.id, tipo: context.movementType,
      qtd: allocation.requested, data: window.hoje(), motivo: reason || '',
      custo_total: estimatedCost, lotes_consumidos: allocation.lot_updates
    });
    return { item_type: type, item_id: item.id, name: item.nome, quantity: allocation.requested, unit: item.un || 'un', estimated_cost: estimatedCost };
  }

  async function waitForPendingSync() {
    if (window.demoMode) return;
    if (!window.currentUser || !window.token) throw new Error('Entre na sua conta antes de registrar o consumo.');
    if (typeof window.flushSync === 'function') {
      if (window.syncTimer) clearTimeout(window.syncTimer);
      window.syncTimer = null;
      await window.flushSync();
      const until = Date.now() + 12000;
      while ((window.syncBusy || window.syncDirty || ['pending', 'saving'].includes(window.syncState)) && Date.now() < until) {
        await new Promise((resolve) => setTimeout(resolve, 80));
      }
      if (window.syncState !== 'ok' || window.syncBusy || window.syncDirty) {
        throw new Error('Há alterações locais ainda não sincronizadas. Verifique a conexão e tente novamente.');
      }
    }
  }

  async function refreshFromServer() {
    if (typeof window.loadServerData !== 'function') throw new Error('Não foi possível atualizar os dados do servidor.');
    const loaded = await window.loadServerData();
    if (!loaded) throw new Error('O servidor não confirmou a atualização dos dados.');
  }

  window.consumeProductionKSW = async function (productionId, requestedActualQuantity) {
    const record = list(window.db.producao).find((entry) => String(entry.id) === String(productionId));
    if (!record) return window.toast('Ordem de produção não encontrada.');
    if (record.consumo_aplicado) return window.toast('O consumo desta produção já foi registrado.');
    const actualInput = document.getElementById('production-actual-' + String(productionId).replace(/[^A-Za-z0-9_.-]/g, ''));
    const actualValue = requestedActualQuantity == null ? (actualInput ? actualInput.value : '') : requestedActualQuantity;
    const actualCheck = window.KSWProduction.validateProducedQuantity(actualValue, record.quantidade_prevista || record.quantidade);
    if (!actualCheck.valid) return window.toast(actualCheck.error);
    if (!window.confirm('Registrar o consumo planejado dos materiais e concluir com ' + actualCheck.quantity.toLocaleString('pt-BR') + ' unidade(s) boa(s) produzida(s)? Esta ação movimenta o estoque.')) return;
    try {
      if (window.demoMode) {
        const product = list(window.db.produtos).find((entry) => String(entry.id) === String(record.produto_id));
        const plan = window.KSWProduction.buildProductionPlan(product, record.quantidade, window.db.ingredientes, window.db.embalagens);
        if (!plan.valid) throw new Error(plan.errors[0]);
        const consumed = [];
        plan.materials.forEach((material) => consumed.push(applyLocalConsumption('ingrediente', material.item_id, material.quantity, 'Consumo de produção ' + record.id, { movementType: 'saida_producao' })));
        if (plan.packaging) consumed.push(applyLocalConsumption('embalagem', plan.packaging.item_id, plan.packaging.quantity, 'Embalagens de produção ' + record.id, { movementType: 'saida_producao' }));
        record.status = 'concluida'; record.consumo_aplicado = true; record.quantidade_produzida = actualCheck.quantity; record.quantidade_prevista = plan.produced_quantity;
        record.lotes_producao = plan.batches; record.consumos = consumed; record.consumido_em = window.hoje(); record.concluido_em = new Date().toISOString(); record.custo_estimado = window.KSWCosting.roundMoney(consumed.reduce((sum, entry) => sum + (Number(entry.estimated_cost) || 0), 0));
        window.saveLocalDB(); window.render(); window.toast('Produção concluída e estoque atualizado no modo demonstração.');
        return;
      }
      await waitForPendingSync();
      const response = await fetch('/api/production/' + encodeURIComponent(record.id) + '/consume', {
        method: 'POST', headers: { Authorization: 'Bearer ' + window.token, 'Content-Type': 'application/json', 'X-Tenant-ID': String(window.currentTenant && window.currentTenant.id || localStorage.getItem('ksw_tenant_id') || '') }, body: JSON.stringify({ quantity_produced: actualCheck.quantity })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || 'Não foi possível concluir a produção.');
      await refreshFromServer();
      window.render();
      window.toast(`Produção concluída: ${payload.production.produced_quantity} unidade(s) produzida(s).`);
    } catch (error) {
      window.toast(error.message || 'Falha ao registrar o consumo.');
    }
  };

  window.cancelProductionKSW = function (productionId) {
    const record = list(window.db.producao).find((entry) => String(entry.id) === String(productionId));
    if (!record || record.consumo_aplicado) return window.toast('Uma produção com consumo aplicado não pode ser cancelada por esta tela.');
    if (!window.confirm('Cancelar esta ordem de produção? Nenhum estoque será movimentado.')) return;
    record.status = 'cancelada'; record.cancelada_em = new Date().toISOString();
    window.saveLocalDB(); window.render();
  };

  window.recordWasteKSW = async function () {
    const itemValue = document.getElementById('waste-item')?.value || '';
    const [itemType, itemId] = itemValue.split('|');
    const quantity = numeric(document.getElementById('waste-qty')?.value);
    const reason = document.getElementById('waste-reason')?.value.trim() || '';
    const date = document.getElementById('waste-date')?.value || window.hoje();
    if (!['ingrediente', 'embalagem'].includes(itemType) || !itemId) return window.toast('Selecione o item perdido.');
    if (!(quantity > 0)) return window.toast('Informe uma quantidade válida.');
    if (reason.length < 3) return window.toast('Descreva o motivo da perda.');
    if (date > window.hoje()) return window.toast('A data da perda não pode estar no futuro.');
    try {
      if (window.demoMode) {
        const consumption = applyLocalConsumption(itemType, itemId, quantity, 'Perda registrada: ' + reason, { movementType: 'saida_perda' });
        window.db.perdas.push({ id: window.id(), item_tipo: itemType, item_id: itemId, item_nome: consumption.name, quantidade: quantity, unidade: consumption.unit, motivo: reason, data: date, custo_total: consumption.estimated_cost });
        window.saveLocalDB(); window.render(); window.toast('Perda registrada no modo demonstração.');
        return;
      }
      await waitForPendingSync();
      const response = await fetch('/api/production/waste', {
        method: 'POST', headers: { Authorization: 'Bearer ' + window.token, 'Content-Type': 'application/json', 'X-Tenant-ID': String(window.currentTenant && window.currentTenant.id || localStorage.getItem('ksw_tenant_id') || '') },
        body: JSON.stringify({ item_type: itemType, item_id: itemId, quantity, reason, date })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || 'Não foi possível registrar a perda.');
      await refreshFromServer(); window.render(); window.toast('Perda registrada e saldo de estoque atualizado.');
    } catch (error) {
      window.toast(error.message || 'Falha ao registrar a perda.');
    }
  };

  window.renderProductionKSW = function renderProductionKSW() {
    const orders = list(window.db.pedidos).filter((order) => !['cancelado', 'entregue'].includes(order.st));
    const products = list(window.db.produtos);
    const productions = list(window.db.producao).slice().sort((a, b) => String(a.data_prevista || '').localeCompare(String(b.data_prevista || '')));
    const inventoryItems = list(window.db.ingredientes).map((item) => ({ type: 'ingrediente', ...item }))
      .concat(list(window.db.embalagens).map((item) => ({ type: 'embalagem', ...item })));
    const planned = productions.filter((entry) => entry.status === 'planejada').length;
    const inProgress = productions.filter((entry) => entry.status === 'em_producao').length;
    const completed = productions.filter((entry) => entry.status === 'concluida').length;
    let html = `<header class="production-page-heading"><div><span class="ksw-eyebrow">ROTINA DA CONFEITARIA</span><h2>Produção</h2><p class="mut">Organize o que precisa ser preparado e acompanhe cada etapa.</p></div><div class="production-summary"><span><b>${planned}</b> planejada(s)</span><span><b>${inProgress}</b> em produção</span><span><b>${completed}</b> concluída(s)</span></div></header>`;

    html += '<section class="production-section"><div class="production-section-heading"><div><span class="production-step-number">1</span><div><h3>Planejar a partir de pedidos</h3><p>Escolha os produtos de encomendas abertas para criar ordens de produção.</p></div></div><button class="btn ghost sm" type="button" onclick="go(\'pedidos\')">Abrir pedidos</button></div>';
    const orderRows = [];
    orders.forEach((order) => window.KSWProduction.aggregateOrderItems(order.itens).forEach((item) => {
      const product = products.find((entry) => String(entry.id) === String(item.pid));
      if (!product) return;
      const duplicate = productions.some((entry) => entry.pedido_id === order.id && entry.produto_id === item.pid && entry.status !== 'cancelada');
      orderRows.push(`<div class="production-order-row"><div><b>${window.esc(product.nome)}</b><small>Pedido de ${window.esc(window.cliNome(order))} · entrega ${window.D(order.ent)} · ${numeric(item.q).toLocaleString('pt-BR')} unidade(s)</small></div>${duplicate ? '<span class="tag">Ordem já criada</span>' : `<button class="btn sm" type="button" onclick="createProductionFromOrderKSW('${safeId(order.id)}','${safeId(item.pid)}',${numeric(item.q)})">Planejar produção</button>`}</div>`);
    }));
    if (orderRows.length) html += `<div class="card production-order-list">${orderRows.join('')}</div>`;
    else html += `<div class="card production-empty-state"><span aria-hidden="true">✦</span><b>Você ainda não tem ordens para planejar.</b><p>${orders.length ? 'Os pedidos em aberto ainda não possuem produtos vinculados a fichas de receita.' : 'Quando você registrar uma encomenda, poderá transformar os produtos em uma ordem de produção aqui.'}</p><button class="btn" type="button" onclick="go('pedidos')">Ver pedidos</button></div>`;
    html += '</section>';

    const activeProductions = productions.filter((entry) => ['planejada', 'em_producao'].includes(entry.status));
    html += '<section class="production-section"><div class="production-section-heading"><div><span class="production-step-number">2</span><div><h3>Ordens em andamento</h3><p>Acompanhe o planejamento e a execução da produção.</p></div></div></div>';
    if (!activeProductions.length) html += '<div class="card production-empty-state"><b>Nenhuma produção em andamento.</b><p>As ordens criadas a partir dos pedidos aparecerão aqui.</p></div>';
    else html += activeProductions.map((record) => {
      const order = record.pedido_id ? list(window.db.pedidos).find((entry) => entry.id === record.pedido_id) : null;
      const product = products.find((entry) => String(entry.id) === String(record.produto_id));
      const productName = record.produto_nome || (product && product.nome) || 'Produto removido';
      const isStarted = record.status === 'em_producao';
      const plannedQuantity = numeric(record.quantidade_prevista || record.quantidade);
      const controls = isStarted
        ? `<div class="production-actual-output"><label for="production-actual-${safeId(record.id)}">Unidades boas efetivamente produzidas</label><input id="production-actual-${safeId(record.id)}" type="number" min="0.001" max="${plannedQuantity}" step="any" value="${plannedQuantity}" inputmode="decimal"><small>Materiais serão baixados conforme a ficha planejada. Se o rendimento real for menor, informe somente as unidades boas.</small></div><button class="btn production-primary-action" type="button" onclick="consumeProductionKSW('${safeId(record.id)}')">Registrar consumo e concluir</button>`
        : `<button class="btn production-primary-action" type="button" onclick="startProductionKSW('${safeId(record.id)}')">Iniciar produção</button>`;
      const progress = isStarted ? 66 : 33;
      const consumption = record.consumo_aplicado
        ? `<p class="mut">Produzido: ${numeric(record.quantidade_produzida || 0).toLocaleString('pt-BR')} un. · ${list(record.consumos).length} item(ns) consumido(s) · custo estimado ${window.R(record.custo_estimado || 0)}</p>`
        : '<p class="mut">O estoque será atualizado em uma única operação ao concluir a ordem.</p>';
      return `<article class="card production-order-card"><div class="production-order-top"><div><b>${window.esc(productName)}</b><small>${record.pedido_id ? 'Pedido de ' + window.esc(order ? window.cliNome(order) : 'cliente') : 'Produção manual'} · previsão ${window.D(record.data_prevista)}</small></div><span class="tag ${isStarted ? 'now' : ''}">${isStarted ? 'Em produção' : 'Planejada'}</span></div><div class="production-progress" aria-label="${isStarted ? 'Produção iniciada' : 'Produção planejada'}"><span style="width:${progress}%"></span></div><div class="production-order-meta"><span>Quantidade prevista <b>${plannedQuantity.toLocaleString('pt-BR')} un.</b></span><span>Etapa <b>${isStarted ? '2 de 3' : '1 de 3'}</b></span></div>${consumption}<div class="production-order-actions">${controls}<button class="btn ghost sm" type="button" onclick="cancelProductionKSW('${safeId(record.id)}')">Cancelar ordem</button></div></article>`;
    }).join('');
    html += '</section>';

    const history = productions.filter((entry) => ['concluida', 'cancelada'].includes(entry.status));
    html += `<details class="card production-history"><summary>Histórico de produção (${history.length})</summary>${history.length ? history.slice().reverse().map((record) => `<div class="production-history-row"><span><b>${window.esc(record.produto_nome || 'Produto')}</b><small>${record.status === 'concluida' ? 'Concluída' : 'Cancelada'} · ${window.D(record.data_prevista)}</small></span><b>${numeric(record.quantidade_produzida || record.quantidade).toLocaleString('pt-BR')} un.</b></div>`).join('') : '<p class="mut">As ordens concluídas ou canceladas aparecerão aqui.</p>'}</details>`;

    html += '<details class="card production-manual"><summary>Produção manual <span>Para fabricar sem vincular a um pedido</span></summary><div class="grid"><div><label for="production-product">Produto</label><select id="production-product"><option value="">Selecione…</option>' + products.map((product) => `<option value="${window.esc(product.id)}">${window.esc(product.nome)}</option>`).join('') + '</select></div><div><label for="production-qty">Quantidade solicitada</label><input id="production-qty" type="number" min="0.001" max="100000" step="any" placeholder="Ex.: 50"></div><div><label for="production-date">Previsão</label><input id="production-date" type="date" value="${window.hoje()}"></div></div><button class="btn" type="button" onclick="createManualProductionKSW()">Criar ordem manual</button></details>';

    const wasteOptions = inventoryItems.map((item) => `<option value="${item.type}|${window.esc(item.id)}">${item.type === 'ingrediente' ? 'Ingrediente' : 'Embalagem'} · ${window.esc(item.nome)}</option>`).join('');
    html += `<section class="production-section"><div class="production-section-heading"><div><span class="production-step-number">3</span><div><h3>Registrar consumo e perdas</h3><p>Controle materiais utilizados e desperdícios para manter o estoque atualizado.</p></div></div></div><section class="card"><b>Registrar perda ou desperdício</b><p class="mut">O registro reduz o estoque, consome lotes por vencimento e calcula o custo estimado.</p><div class="cols"><div><label for="waste-item">Item</label><select id="waste-item"><option value="">Selecione…</option>${wasteOptions}</select></div><div><label for="waste-qty">Quantidade perdida</label><input id="waste-qty" type="number" min="0.000001" step="any"></div><div><label for="waste-date">Data</label><input id="waste-date" type="date" max="${window.hoje()}" value="${window.hoje()}"></div><div><label for="waste-reason">Motivo</label><input id="waste-reason" maxlength="160" placeholder="Ex.: quebra, vencimento, erro de produção"></div></div><button class="btn" type="button" onclick="recordWasteKSW()">Registrar perda</button></section></section>`;
    const losses = list(window.db.perdas).slice().sort((a, b) => String(b.data || '').localeCompare(String(a.data || ''))).slice(0, 20);
    html += `<details class="card production-loss-history"><summary>Histórico de perdas (${losses.length})</summary>${losses.length ? losses.map((loss) => `<div class="production-history-row"><span>${window.esc(loss.item_nome || itemLabel(loss.item_tipo, loss.item_id))} · ${numeric(loss.quantidade).toLocaleString('pt-BR')} ${window.esc(loss.unidade || '')}<small>${window.esc(loss.motivo)} · ${window.D(loss.data)}</small></span><b>${window.R(loss.custo_total || 0)}</b></div>`).join('') : '<p class="mut">Nenhuma perda registrada.</p>'}</details>`;
    return html;
  };

  window.createManualProductionKSW = function () {
    const productId = document.getElementById('production-product')?.value || '';
    const quantity = numeric(document.getElementById('production-qty')?.value);
    const date = document.getElementById('production-date')?.value || '';
    if (!productId) return window.toast('Selecione um produto.');
    if (!date) return window.toast('Informe a previsão de produção.');
    if (date < window.hoje()) return window.toast('A previsão não pode estar no passado.');
    window.createProductionKSW('', productId, quantity, date);
  };

  // Inicializa somente depois que as funções da Fase 3 substituírem os placeholders.
  if (typeof window.init === 'function') window.init();
})();
