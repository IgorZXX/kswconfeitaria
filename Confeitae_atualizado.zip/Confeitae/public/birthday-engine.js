(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.KSWBirthdays = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function twoDigits(value) {
    return String(value).padStart(2, '0');
  }

  function validParts(month, day, year) {
    if (!Number.isInteger(month) || month < 1 || month > 12 || !Number.isInteger(day) || day < 1) return false;
    const leapYear = year == null ? 2000 : year;
    const date = new Date(Date.UTC(leapYear, month - 1, day));
    return date.getUTCFullYear() === leapYear && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  }

  function parse(value) {
    const raw = String(value == null ? '' : value).trim();
    if (!raw) return null;

    let month;
    let day;
    let year;
    let match = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (match) {
      year = Number(match[1]);
      month = Number(match[2]);
      day = Number(match[3]);
    } else {
      match = raw.match(/^(\d{2})\/(\d{2})$/);
      if (match) {
        day = Number(match[1]);
        month = Number(match[2]);
      } else {
        match = raw.match(/^(\d{2})-(\d{2})$/);
        if (!match) return null;
        month = Number(match[1]);
        day = Number(match[2]);
      }
    }

    if (!validParts(month, day, year)) return null;
    return { month, day, value: twoDigits(month) + '-' + twoDigits(day) };
  }

  function format(value) {
    const birthday = parse(value);
    return birthday ? twoDigits(birthday.day) + '/' + twoDigits(birthday.month) : '';
  }

  function parseIsoDate(value) {
    const match = String(value == null ? '' : value).match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) return null;
    const year = Number(match[1]);
    const month = Number(match[2]);
    const day = Number(match[3]);
    return validParts(month, day, year) ? { year, month, day } : null;
  }

  function birthdayDate(year, birthday) {
    const day = birthday.month === 2 && birthday.day === 29 && !validParts(2, 29, year)
      ? 1
      : birthday.day;
    const month = birthday.month === 2 && birthday.day === 29 && day === 1 ? 3 : birthday.month;
    return new Date(Date.UTC(year, month - 1, day));
  }

  function nextBirthday(value, today) {
    const birthday = parse(value);
    const current = parseIsoDate(today);
    if (!birthday || !current) return null;
    const todayDate = Date.UTC(current.year, current.month - 1, current.day);
    for (let year = current.year; year <= current.year + 2; year += 1) {
      const date = birthdayDate(year, birthday);
      const daysUntil = Math.round((date.getTime() - todayDate) / 86400000);
      if (daysUntil >= 0) {
        return {
          date: date.toISOString().slice(0, 10),
          daysUntil,
          year
        };
      }
    }
    return null;
  }

  function inMonth(clients, month, today) {
    const selectedMonth = Number(month);
    if (!Number.isInteger(selectedMonth) || selectedMonth < 1 || selectedMonth > 12) return [];
    return (Array.isArray(clients) ? clients : [])
      .map((client) => {
        const birthday = parse(client && client.nasc);
        if (!birthday || birthday.month !== selectedMonth) return null;
        return {
          client,
          day: birthday.day,
          month: birthday.month,
          year: Number(String(today).slice(0, 4))
        };
      })
      .filter(Boolean)
      .sort((a, b) => a.day - b.day || String(a.client.nome || '').localeCompare(String(b.client.nome || ''), 'pt-BR'));
  }

  function upcoming(clients, today, days = 7) {
    const windowDays = Number(days);
    if (!Number.isInteger(windowDays) || windowDays < 0 || windowDays > 366) return [];
    return (Array.isArray(clients) ? clients : [])
      .map((client) => {
        const birthday = parse(client && client.nasc);
        if (!birthday) return null;
        const next = nextBirthday(client.nasc, today);
        if (!next || next.daysUntil > windowDays) return null;
        return { client, ...birthday, ...next };
      })
      .filter(Boolean)
      .sort((a, b) => a.daysUntil - b.daysUntil || a.day - b.day || String(a.client.nome || '').localeCompare(String(b.client.nome || ''), 'pt-BR'));
  }

  function isToday(value, today) {
    const birthday = parse(value);
    const date = parseIsoDate(today);
    return Boolean(birthday && date && birthday.month === date.month && birthday.day === date.day);
  }

  return { parse, format, nextBirthday, inMonth, upcoming, isToday };
});
