'use strict';

(function () {
  const loginView = document.getElementById('login-view');
  const adminView = document.getElementById('admin-view');
  const loginForm = document.getElementById('login-form');
  const keyInput = document.getElementById('admin-key');
  const loginMessage = document.getElementById('login-message');
  const loginButton = document.getElementById('login-submit');
  const logoutButton = document.getElementById('logout');
  const content = document.getElementById('content');
  const globalMessage = document.getElementById('global-message');
  const subscriptionDialog = document.getElementById('subscription-dialog');
  const subscriptionForm = document.getElementById('subscription-form');
  const subscriptionError = document.getElementById('subscription-error');
  const companyDialog = document.getElementById('company-dialog');
  const companyDetails = document.getElementById('company-details');
  const state = { view: 'overview', subscriptionTenantId: null, subscriptionUserId: null, subscriptionTargetName: '', plans: [], featureCatalog: [], editingPlanKey: null, supportThreadId: null };

  // Remove a chave antiga que a versão anterior do painel guardava no localStorage.
  try { localStorage.removeItem('ksw_admin_key'); } catch (_) { /* armazenamento indisponível */ }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[char]));
  }

  function moneyFromCents(value) {
    const amount = Number(value);
    return Number.isFinite(amount) ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount / 100) : '—';
  }

  function money(value) {
    const amount = Number(value);
    return Number.isFinite(amount) ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(amount) : '—';
  }

  function date(value) {
    if (!value) return 'Sem vencimento';
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? '—' : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'medium' }).format(parsed);
  }

  function badge(value, kind) {
    return '<span class="badge ' + escapeHtml(kind || '') + '">' + escapeHtml(value) + '</span>';
  }
  function accessLabel(status) {
    return ({ ativa: 'Acesso liberado', vencida: 'Assinatura vencida', cancelada: 'Cancelada', inativa: 'Sem assinatura' })[status] || 'Sem assinatura';
  }
  function accessBadge(status) {
    const kind = status === 'ativa' ? 'success' : status === 'vencida' ? 'danger' : 'warning';
    return badge(accessLabel(status), kind);
  }

  function setGlobalMessage(message, isError) {
    globalMessage.textContent = message || '';
    globalMessage.className = 'global-message' + (isError ? ' error' : '');
  }

  async function api(path, options) {
    const config = Object.assign({ method: 'GET', credentials: 'same-origin', headers: {} }, options || {});
    config.headers = Object.assign({}, config.headers || {});
    if (config.body && typeof config.body !== 'string') {
      config.headers['Content-Type'] = 'application/json';
      config.body = JSON.stringify(config.body);
    }
    const response = await fetch('/api/admin' + path, config);
    let data = {};
    try { data = await response.json(); } catch (_) { /* resposta sem JSON */ }
    if (response.status === 401) {
      showLogin();
      throw new Error(data.error || 'Sua sessão administrativa expirou. Entre novamente.');
    }
    if (!response.ok) throw new Error(data.error || 'Não foi possível concluir a operação.');
    return data;
  }

  function showLogin() {
    loginView.hidden = false;
    adminView.hidden = true;
    logoutButton.hidden = true;
    keyInput.value = '';
  }

  function showAdmin() {
    loginView.hidden = true;
    adminView.hidden = false;
    logoutButton.hidden = false;
  }

  function setLoading(message) {
    content.innerHTML = '<div class="card empty-state">' + escapeHtml(message || 'Carregando dados...') + '</div>';
  }

  function renderMetric(label, value, foot) {
    return '<article class="metric-card"><div class="metric-label">' + escapeHtml(label) + '</div><div class="metric-value">' + escapeHtml(value) + '</div><div class="metric-foot">' + escapeHtml(foot || '') + '</div></article>';
  }

  async function loadOverview() {
    const result = await api('/overview');
    const m = result.metrics || {};
    const companies = (result.recent_companies || []).map((tenant) => (
      '<tr><td><strong>' + escapeHtml(tenant.nome) + '</strong><small>' + escapeHtml(tenant.owner_name) + ' · ' + escapeHtml(tenant.owner_email) + '</small></td>' +
      '<td>' + escapeHtml(tenant.members_count) + ' membros</td><td>' + (tenant.status === 'active' ? badge('Ativa', 'success') : badge('Suspensa', 'danger')) + '</td><td>' + accessBadge(tenant.subscription_access_status) + '<small>' + escapeHtml(tenant.plan_name || tenant.plano_tipo || 'Sem plano') + ' · vence ' + escapeHtml(date(tenant.data_vencimento)) + '</small></td></tr>'
    )).join('');
    content.innerHTML =
      '<div class="metric-grid">' +
      renderMetric('Empresas cadastradas', m.companies_total || 0, (m.companies_active || 0) + ' ativas · ' + (m.companies_suspended || 0) + ' suspensas') +
      renderMetric('Usuários', m.users_total || 0, 'Contas registradas na plataforma') +
      renderMetric('Assinaturas ativas', m.subscriptions_active || 0, (m.monthly_active || 0) + ' mensais · ' + (m.lifetime_active || 0) + ' vitalícias') +
      renderMetric('MRR estimado', moneyFromCents(m.estimated_mrr_cents || 0), 'Estimativa das cobranças recorrentes ativas') +
      '</div>' +
      '<div class="metric-grid">' +
      renderMetric('Pedidos pagos', m.approved_orders || 0, 'Registros com status aprovado') +
      renderMetric('Receita aprovada', moneyFromCents(m.approved_revenue_cents || 0), 'Soma histórica dos pedidos aprovados') +
      renderMetric('Pedidos pendentes', m.pending_orders || 0, 'Aguardando confirmação do gateway') +
      renderMetric('Contas suspensas', m.companies_suspended || 0, 'Empresas sem acesso operacional') +
      '</div>' +
      '<div class="dashboard-grid"><section class="card"><div class="card-heading"><div><h2>Empresas recentes</h2><p>Últimas empresas criadas na plataforma</p></div><button class="button button-secondary button-small" data-view-link="tenants" type="button">Ver empresas</button></div>' +
      (companies ? '<div class="table-wrap"><table class="data-table"><thead><tr><th>Empresa / responsável</th><th>Equipe</th><th>Empresa</th><th>Acesso / assinatura</th></tr></thead><tbody>' + companies + '</tbody></table></div>' : '<div class="empty-state">Nenhuma empresa cadastrada.</div>') +
      '</section><section class="card"><div class="card-heading"><div><h2>Indicadores</h2><p>Leitura rápida da operação</p></div></div><div class="company-detail-row"><strong>MRR estimado</strong><span>Considera apenas assinaturas mensais ativas multiplicadas pelo valor de referência do plano.</span></div><div class="company-detail-row"><strong>Receita aprovada</strong><span>É calculada a partir dos pedidos registrados como aprovados; não equivale a saldo bancário ou lucro.</span></div><div class="company-detail-row"><strong>Suspensão</strong><span>Bloqueia o acesso operacional da empresa sem excluir dados ou cancelar cobranças no gateway.</span></div></section></div>';
  }

  async function loadTenants() {
    const params = new URLSearchParams();
    const search = document.getElementById('tenant-search');
    const status = document.getElementById('tenant-status');
    const searchValue = search ? search.value.trim() : '';
    const statusValue = status ? status.value : '';
    if (searchValue) params.set('search', searchValue);
    if (statusValue) params.set('status', statusValue);
    params.set('limit', '100');
    const result = await api('/tenants?' + params.toString());
    const rows = (result.tenants || []).map((tenant) => {
      const active = tenant.status === 'active';
      return '<tr><td><strong>' + escapeHtml(tenant.nome) + '</strong><small>' + escapeHtml(tenant.slug) + ' · criada em ' + escapeHtml(date(tenant.created_at)) + '</small></td>' +
        '<td><strong>' + escapeHtml(tenant.owner_name) + '</strong><small>' + escapeHtml(tenant.owner_email) + '</small></td>' +
        '<td>' + escapeHtml(tenant.members_count) + '</td>' +
        '<td>' + (active ? badge('Ativa', 'success') : badge('Suspensa', 'danger')) + '</td>' +
        '<td>' + accessBadge(tenant.subscription_access_status) + '<small>' + escapeHtml(tenant.plan_name || tenant.plano_tipo || 'Sem plano') + ' · ' + escapeHtml(date(tenant.data_vencimento)) + '</small></td>' +
        '<td><div class="actions"><button class="button button-secondary button-small" data-action="company-details" data-id="' + escapeHtml(tenant.id) + '">Detalhes</button>' +
        '<button class="button button-small ' + (active ? 'button-quiet' : 'button-primary') + '" data-action="tenant-status" data-id="' + escapeHtml(tenant.id) + '" data-next="' + (active ? 'suspended' : 'active') + '">' + (active ? 'Suspender' : 'Reativar') + '</button></div></td></tr>';
    }).join('');
    content.innerHTML = '<div class="toolbar"><input id="tenant-search" type="search" placeholder="Buscar empresa, responsável ou e-mail" value="' + escapeHtml(searchValue) + '"><select id="tenant-status"><option value="">Todos os status</option><option value="active"' + (statusValue === 'active' ? ' selected' : '') + '>Ativas</option><option value="suspended"' + (statusValue === 'suspended' ? ' selected' : '') + '>Suspensas</option></select><button id="tenant-search-button" class="button button-secondary" type="button">Buscar</button></div>' +
      '<section class="card"><div class="card-heading"><div><h2>Empresas</h2><p>' + escapeHtml(result.pagination.total) + ' registros encontrados</p></div></div>' +
      (rows ? '<div class="table-wrap"><table class="data-table"><thead><tr><th>Empresa</th><th>Responsável</th><th>Equipe</th><th>Empresa</th><th>Acesso / assinatura</th><th>Ações</th></tr></thead><tbody>' + rows + '</tbody></table></div>' : '<div class="empty-state">Nenhuma empresa encontrada.</div>') + '</section>';
  }

  async function loadUsers() {
    const priorSearch = document.getElementById('user-search');
    const searchValue = priorSearch ? priorSearch.value : '';
    const result = await api('/users?limit=100&search=' + encodeURIComponent(searchValue));
    const rows = (result.users || []).map((user) => '<tr><td><strong>' + escapeHtml(user.nome) + '</strong><small>@' + escapeHtml(user.username || '—') + ' · ' + escapeHtml(user.email) + '</small></td>' +
      '<td>' + escapeHtml(user.company_names || '—') + '</td><td>' + escapeHtml(user.companies_count) + '</td>' +
      '<td>' + badge(user.plano_tipo || 'free', 'info') + '</td><td>' + badge(user.status_assinatura || 'inativa', user.status_assinatura === 'ativa' ? 'success' : 'warning') + '</td></tr>').join('');
    content.innerHTML = '<div class="toolbar"><input id="user-search" type="search" placeholder="Buscar por nome, usuário ou e-mail" value="' + escapeHtml(searchValue) + '"><button id="user-search-button" class="button button-secondary" type="button">Buscar</button></div>' +
      '<section class="card"><div class="card-heading"><div><h2>Usuários cadastrados</h2><p>' + escapeHtml(result.pagination.total) + ' contas · dados de autenticação não são exibidos</p></div></div>' +
      (rows ? '<div class="table-wrap"><table class="data-table"><thead><tr><th>Usuário</th><th>Empresas</th><th>Vínculos</th><th>Plano</th><th>Assinatura</th></tr></thead><tbody>' + rows + '</tbody></table></div>' : '<div class="empty-state">Nenhum usuário encontrado.</div>') + '</section>';
  }

  async function loadSubscriptions() {
    const [result, planResult] = await Promise.all([api('/subscriptions?limit=100'), api('/plans')]);
    state.plans = planResult.plans || [];
    const planSelect = document.getElementById('subscription-plan');
    if (planSelect) planSelect.innerHTML = '<option value="free">Gratuito</option>' + state.plans.map((plan) => '<option value="' + escapeHtml(plan.plan_key) + '" data-interval="' + escapeHtml(plan.billing_interval) + '">' + escapeHtml(plan.name) + '</option>').join('');
    const rows = (result.subscriptions || []).map((item) => {
      const stateLabel = item.subscription_access_status || item.status_assinatura || 'inativa';
      return '<tr><td><strong>' + escapeHtml(item.tenant_name) + '</strong><small>' + escapeHtml(item.owner_name) + ' · ' + escapeHtml(item.owner_email) + '</small></td>' +
        '<td>' + badge(item.plano_tipo || 'free', 'info') + '</td>' +
        '<td>' + accessBadge(stateLabel) + '</td>' +
        '<td>' + escapeHtml(date(item.data_vencimento)) + '</td>' +
        '<td>' + escapeHtml(item.last_gateway || '—') + '</td>' +
        '<td><button class="button button-secondary button-small" data-action="edit-subscription" data-tenant-id="' + escapeHtml(item.tenant_id) + '" data-user-id="' + escapeHtml(item.owner_user_id) + '" data-name="' + escapeHtml(item.tenant_name) + '" data-plan="' + escapeHtml(item.plano_tipo) + '" data-status="' + escapeHtml(item.status_assinatura) + '">Editar acesso</button></td></tr>';
    }).join('');
    content.innerHTML = '<section class="card"><div class="card-heading"><div><h2>Assinaturas por empresa</h2><p>O acesso da empresa está vinculado à conta proprietária.</p></div></div>' +
      '<div class="notice">A alteração manual atualiza o acesso no KSW, mas não altera a recorrência, o cancelamento ou a cobrança diretamente no gateway de pagamento.</div>' +
      (rows ? '<div class="table-wrap" style="margin-top:14px"><table class="data-table"><thead><tr><th>Empresa / responsável</th><th>Plano</th><th>Status</th><th>Validade</th><th>Gateway recente</th><th>Ações</th></tr></thead><tbody>' + rows + '</tbody></table></div>' : '<div class="empty-state">Nenhuma assinatura encontrada.</div>') + '</section>';
  }

  function featureDescription(label) {
    const clean = String(label || '').trim().replace(/[.!?]+$/, '');
    return clean ? 'Organize e acompanhe ' + clean.toLocaleLowerCase('pt-BR') + ' diretamente no KSW, com as informações da sua confeitaria centralizadas e conectadas à rotina do negócio.' : '';
  }

  function featureSlug(label) {
    return String(label || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48);
  }

  function renderFeatureInputs(plan) {
    const selected = new Map((plan && Array.isArray(plan.features) ? plan.features : []).map((feature) => [feature.key, feature]));
    const known = new Set(state.featureCatalog.map((feature) => feature.key));
    const lockedFull = plan && ['vitalicio', 'teste_gratis'].includes(plan.plan_key);
    const catalog = state.featureCatalog.map((feature) => {
      const checked = selected.has(feature.key) || lockedFull;
      return '<label class="plan-feature-option"><input class="plan-feature-check" type="checkbox" data-key="' + escapeHtml(feature.key) + '" data-label="' + escapeHtml(feature.label) + '" data-description="' + escapeHtml(feature.description) + '" ' + (checked ? 'checked' : '') + (lockedFull ? ' disabled' : '') + '><span><strong>' + escapeHtml(feature.label) + '</strong><small>' + escapeHtml(feature.description) + '</small></span></label>';
    }).join('');
    const custom = (plan && Array.isArray(plan.features) ? plan.features : []).filter((feature) => !known.has(feature.key));
    return catalog + custom.map((feature) => '<label class="plan-feature-option custom-plan-feature"><input class="plan-feature-check" type="checkbox" data-key="' + escapeHtml(feature.key) + '" data-label="' + escapeHtml(feature.label) + '" data-description="' + escapeHtml(feature.description) + '" checked ' + (lockedFull ? 'disabled' : '') + '><span><strong>' + escapeHtml(feature.label) + ' <em>Personalizada</em></strong><small>' + escapeHtml(feature.description) + '</small></span></label>').join('');
  }

  async function loadPlans() {
    const result = await api('/plans');
    state.plans = result.plans || [];
    state.featureCatalog = result.feature_catalog || [];
    const stripeConfigured = Boolean(result.stripe_configured);
    const cards = state.plans.map((plan) => {
      const active = Number(plan.is_active) === 1;
      const deleted = Number(plan.is_deleted) === 1;
      const cycle = plan.billing_interval === 'month'
        ? (Number(plan.billing_interval_count) > 1 ? 'a cada ' + Number(plan.billing_interval_count) + ' meses' : 'por mês')
        : 'pagamento único';
      const configured = Number(plan.has_stripe_price) === 1;
      const seats = Number(plan.max_members) === 0 ? 'Acessos ilimitados' : Number(plan.max_members) + ' acesso(s)';
      const features = (plan.features || []).map((feature) => '<li>' + escapeHtml(feature.label) + '</li>').join('');
      const locked = ['vitalicio', 'teste_gratis'].includes(plan.plan_key);
      return '<article class="plan-card ' + (deleted ? 'is-archived' : '') + '"><span class="eyebrow">' + (deleted ? 'PLANO REMOVIDO' : (plan.is_system ? 'PLANO DO SISTEMA' : 'PLANO COMERCIAL')) + '</span><h3>' + escapeHtml(plan.name) + '</h3><div class="plan-price">' + moneyFromCents(plan.price_cents) + '</div><p>' + escapeHtml(plan.description) + '</p><p>' + cycle + ' · ' + escapeHtml(seats) + ' · ' + (configured ? 'Preço Stripe vinculado' : 'Sem preço Stripe') + '</p><details class="plan-card-features"><summary>' + (plan.features || []).length + ' funcionalidade(s) incluída(s)</summary><ul>' + (features || '<li>Nenhuma funcionalidade marcada</li>') + '</ul></details><div class="plan-footer">' + (deleted ? badge('Removido', 'danger') : active ? badge('Disponível para novas compras', 'success') : badge('Rascunho / vendas desativadas', 'warning')) +
        (deleted ? '' : '<div class="plan-admin-actions"><button class="button button-secondary button-small" type="button" data-action="edit-plan" data-key="' + escapeHtml(plan.plan_key) + '">Editar</button>' +
        '<button class="button button-secondary button-small" type="button" data-action="toggle-plan" data-key="' + escapeHtml(plan.plan_key) + '" data-active="' + active + '" ' + (plan.plan_key === 'teste_gratis' ? 'disabled' : '') + '>' + (active ? 'Desativar' : 'Ativar') + '</button>' +
        '<button class="button button-quiet button-small" type="button" data-action="delete-plan" data-key="' + escapeHtml(plan.plan_key) + '" ' + (locked ? 'disabled title="Plano essencial do sistema"' : '') + '>Remover</button></div>') + '</div></article>';
    }).join('');
    const editing = state.plans.find((plan) => plan.plan_key === state.editingPlanKey && !Number(plan.is_deleted)) || null;
    const amount = editing ? (Number(editing.price_cents) / 100).toFixed(2) : '';
    const formTitle = editing ? 'Editar plano: ' + editing.name : 'Adicionar novo plano';
    const formText = editing ? 'Altere o nome, valor, limite de acessos e os recursos disponíveis.' : 'Configure preço, quantidade de pessoas e recursos. Sem Stripe, o plano fica salvo como rascunho.';
    const fullLocked = editing && ['vitalicio', 'teste_gratis'].includes(editing.plan_key);
    content.innerHTML = '<section class="card"><div class="card-heading"><div><h2>' + escapeHtml(formTitle) + '</h2><p>' + escapeHtml(formText) + '</p></div></div>' +
      '<form id="plan-editor-form" class="plan-create-form"><input type="hidden" id="plan-key" value="' + escapeHtml(editing ? editing.plan_key : '') + '"><div class="form-grid"><div><label for="new-plan-name">Nome do plano</label><input id="new-plan-name" maxlength="80" minlength="3" required placeholder="Ex.: Plano Profissional" value="' + escapeHtml(editing ? editing.name : '') + '"></div><div><label for="new-plan-price">Preço em reais</label><input id="new-plan-price" type="number" min="0" max="1000000" step="0.01" required placeholder="79,90" value="' + escapeHtml(amount) + '" ' + (fullLocked ? 'readonly' : '') + '><small>Use R$ 0,00 apenas para um plano gratuito ou rascunho.</small></div></div>' +
      '<div class="form-field"><label for="new-plan-description">Descrição do plano</label><textarea id="new-plan-description" maxlength="500" rows="2" placeholder="O que está incluído neste plano">' + escapeHtml(editing ? editing.description : '') + '</textarea></div>' +
      '<div class="form-grid"><div><label for="new-plan-interval">Cobrança</label><select id="new-plan-interval" ' + (fullLocked ? 'disabled' : '') + '><option value="month" ' + (!editing || editing.billing_interval === 'month' ? 'selected' : '') + '>Recorrente mensal</option><option value="once" ' + (editing && editing.billing_interval === 'once' ? 'selected' : '') + '>Pagamento único</option></select></div><div id="new-plan-count-wrap"><label for="new-plan-count">Cobrar a cada</label><select id="new-plan-count" ' + (fullLocked ? 'disabled' : '') + '>' + [1,2,3,6,12].map((count) => '<option value="' + count + '" ' + (Number(editing && editing.billing_interval_count || 1) === count ? 'selected' : '') + '>' + count + ' ' + (count === 1 ? 'mês' : 'meses') + '</option>').join('') + '</select></div><div><label for="new-plan-members">Limite de pessoas com acesso</label><input id="new-plan-members" type="number" min="0" max="500" step="1" value="' + escapeHtml(editing ? editing.max_members : '1') + '" ' + (fullLocked ? 'readonly' : '') + '><small>Conta o proprietário. Use 1 para uso individual, 3 para proprietário + 2 pessoas, ou 0 para ilimitado.</small></div></div>' +
      '<div class="plan-feature-editor"><div class="card-heading"><div><h3>Funcionalidades incluídas</h3><p>Marque o que estará disponível neste plano. Para cada recurso personalizado, o KSW gera uma descrição automaticamente. Recursos técnicos personalizados exigem desenvolvimento próprio; aqui você configura os módulos já existentes no catálogo.</p></div></div><div class="plan-feature-grid" id="plan-feature-grid">' + renderFeatureInputs(editing) + '</div>' +
      '<div class="custom-feature-form"><label for="new-custom-feature-name">Adicionar funcionalidade personalizada</label><div class="toolbar"><input id="new-custom-feature-name" maxlength="80" placeholder="Ex.: Integração com fornecedores"><button class="button button-secondary" type="button" data-action="add-custom-feature" ' + (fullLocked ? 'disabled' : '') + '>Adicionar funcionalidade</button></div><small id="custom-feature-preview">A descrição será gerada automaticamente a partir do nome.</small></div></div>' +
      '<div class="dialog-actions"><button id="plan-editor-submit" class="button button-primary" type="submit">' + (editing ? 'Salvar alterações' : 'Adicionar plano') + '</button>' + (editing ? '<button class="button button-secondary" type="button" data-action="cancel-edit-plan">Cancelar edição</button>' : '') + '</div><p id="plan-editor-error" class="form-message" role="alert">' + (stripeConfigured ? 'Planos pagos criam um produto e preço Stripe automaticamente. Planos gratuitos são mantidos no KSW.' : 'Stripe não configurada: o plano será salvo como rascunho e ficará indisponível para novas compras até configurar o gateway.') + '</p></form></section>' +
      '<div class="plans-grid" style="margin-top:18px">' + (cards || '<div class="empty-state">Nenhum plano cadastrado.</div>') + '</div>' +
      '<div class="notice" style="margin-top:16px">Remover um plano é uma exclusão lógica: ele deixa de aparecer para novas contratações, mas os dados e o histórico de assinaturas são preservados. O vitalício e o teste grátis são planos essenciais, não removíveis. Alterar preço na Stripe cria um novo preço; cobranças antigas não são reescritas.</div>';
    const intervalSelect = document.getElementById('new-plan-interval');
    const updateCount = () => { document.getElementById('new-plan-count-wrap').hidden = intervalSelect.value !== 'month'; };
    intervalSelect.addEventListener('change', updateCount);
    updateCount();
    const customName = document.getElementById('new-custom-feature-name');
    const preview = document.getElementById('custom-feature-preview');
    customName.addEventListener('input', () => { preview.textContent = featureDescription(customName.value) || 'A descrição será gerada automaticamente a partir do nome.'; });
  }

  function supportMessageTime(value) {
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? '' : new Intl.DateTimeFormat('pt-BR', { dateStyle: 'short', timeStyle: 'short' }).format(parsed);
  }

  async function loadSupport() {
    const result = await api('/support/threads');
    const threads = result.threads || [];
    if (!threads.some((thread) => Number(thread.id) === Number(state.supportThreadId))) {
      state.supportThreadId = threads.length ? Number(threads[0].id) : null;
    }
    let selected = null;
    if (state.supportThreadId) selected = await api('/support/threads/' + encodeURIComponent(state.supportThreadId));
    const threadItems = threads.map((thread) => {
      const active = Number(thread.id) === Number(state.supportThreadId);
      const preview = String(thread.last_message || 'Conversa iniciada').slice(0, 100);
      return '<button class="admin-support-thread ' + (active ? 'is-active' : '') + '" type="button" data-action="open-support-thread" data-id="' + escapeHtml(thread.id) + '">' +
        '<span class="admin-support-thread-head"><strong>' + escapeHtml(thread.tenant_name) + '</strong>' +
        (Number(thread.unread_count) > 0 ? '<b class="admin-support-unread">' + escapeHtml(thread.unread_count) + '</b>' : '') + '</span>' +
        '<small>' + escapeHtml(thread.owner_name) + ' · ' + escapeHtml(thread.owner_email) + '</small>' +
        '<span class="admin-support-preview">' + (thread.last_sender_type === 'admin' ? 'Você: ' : '') + escapeHtml(preview) + '</span>' +
        '<time>' + escapeHtml(supportMessageTime(thread.last_message_at || thread.updated_at)) + '</time></button>';
    }).join('');
    const messages = selected ? (selected.messages || []).map((message) => {
      const isAdmin = message.sender_type === 'admin';
      return '<article class="admin-support-message ' + (isAdmin ? 'is-admin' : 'is-owner') + '"><div><strong>' + (isAdmin ? 'Você · Administração' : escapeHtml(selected.thread.owner_name)) + '</strong><time>' + escapeHtml(supportMessageTime(message.created_at)) + '</time></div><p>' + escapeHtml(message.body).replace(/\r?\n/g, '<br>') + '</p></article>';
    }).join('') : '';
    content.innerHTML = '<section class="card admin-support-shell"><div class="card-heading"><div><h2>Chat de suporte</h2><p>Responda às conversas privadas dos proprietários com chat habilitado.</p></div></div>' +
      '<div class="admin-support-layout"><aside class="admin-support-list" aria-label="Conversas">' + (threadItems || '<div class="empty-state">Ainda não há conversas.</div>') + '</aside>' +
      '<section class="admin-support-conversation">' + (selected ?
        '<header><strong>' + escapeHtml(selected.thread.tenant_name) + '</strong><span>' + escapeHtml(selected.thread.owner_name) + ' · ' + escapeHtml(selected.thread.owner_email) + '</span></header>' +
        '<div class="admin-support-messages">' + (messages || '<div class="empty-state">A conversa está aberta. Aguardando a primeira mensagem.</div>') + '</div>' +
        '<form id="admin-support-reply-form"><label for="admin-support-reply">Sua resposta</label><textarea id="admin-support-reply" maxlength="4000" rows="3" required placeholder="Escreva uma resposta para a empresa..."></textarea><div class="dialog-actions"><small>Até 4.000 caracteres.</small><button class="button button-primary" type="submit">Enviar resposta</button></div></form>' :
        '<div class="empty-state">Selecione uma conversa para visualizar e responder.</div>') + '</section></div></section>';
  }

  async function loadAudit() {
    const result = await api('/audit?limit=100');
    const rows = (result.entries || []).map((entry) => '<article class="audit-item"><strong>' + escapeHtml(entry.action) + '</strong><small>' + escapeHtml(entry.target_type) + ' ' + escapeHtml(entry.target_id || '') + ' · ' + escapeHtml(date(entry.created_at)) + '</small><p>' + escapeHtml(JSON.stringify(entry.metadata || {})) + '</p></article>').join('');
    content.innerHTML = '<section class="card"><div class="card-heading"><div><h2>Auditoria da plataforma</h2><p>' + escapeHtml(result.pagination.total) + ' eventos recentes registrados</p></div></div>' + (rows ? '<div class="audit-list">' + rows + '</div>' : '<div class="empty-state">Ainda não há eventos administrativos.</div>') + '<div class="notice" style="margin-top:14px">A auditoria registra ações administrativas relevantes. Ela não é um armazenamento imutável ou uma trilha WORM; mantenha backups protegidos do banco.</div></section>';
  }

  const loaders = { overview: loadOverview, tenants: loadTenants, users: loadUsers, subscriptions: loadSubscriptions, plans: loadPlans, support: loadSupport, audit: loadAudit };
  async function loadView(view) {
    state.view = loaders[view] ? view : 'overview';
    document.querySelectorAll('[data-view]').forEach((button) => button.classList.toggle('is-active', button.dataset.view === state.view));
    setLoading('Carregando ' + state.view + '...');
    setGlobalMessage('');
    try { await loaders[state.view](); }
    catch (error) { setGlobalMessage(error.message, true); content.innerHTML = '<div class="card empty-state">Não foi possível carregar esta seção. Atualize a página ou entre novamente.</div>'; }
  }

  function openSubscription(button) {
    state.subscriptionTenantId = button.dataset.tenantId;
    state.subscriptionUserId = button.dataset.userId;
    state.subscriptionTargetName = button.dataset.name || 'Empresa';
    document.getElementById('subscription-target').textContent = state.subscriptionTargetName + ' — responsável: conta #' + state.subscriptionUserId;
    document.getElementById('subscription-plan').value = button.dataset.plan || 'free';
    document.getElementById('subscription-status').value = button.dataset.status || 'inativa';
    document.getElementById('subscription-days').value = '30';
    updateSubscriptionDays();
    subscriptionError.textContent = '';
    subscriptionDialog.showModal();
  }

  async function showCompany(id) {
    companyDetails.innerHTML = '<div class="empty-state">Carregando empresa...</div>';
    companyDialog.showModal();
    try {
      const result = await api('/tenants/' + encodeURIComponent(id));
      const tenant = result.tenant;
      const members = (result.members || []).map((member) => '<li><span><strong>' + escapeHtml(member.nome) + '</strong><br><small>' + escapeHtml(member.email) + '</small></span>' + badge(member.role, 'info') + '</li>').join('');
      companyDetails.innerHTML = '<div class="company-detail-row"><strong>' + escapeHtml(tenant.nome) + '</strong><span>' + escapeHtml(tenant.slug) + ' · ' + (tenant.status === 'active' ? 'Ativa' : 'Suspensa') + '</span></div>' +
        '<div class="company-detail-row"><strong>Proprietário</strong><span>' + escapeHtml(tenant.owner_name) + ' · ' + escapeHtml(tenant.owner_email) + '</span></div>' +
        '<div class="company-detail-row"><strong>Acesso / assinatura</strong><span>' + escapeHtml(tenant.plan_name || tenant.plano_tipo || 'Sem plano') + ' · ' + escapeHtml(accessLabel(tenant.subscription_access_status)) + ' · ' + escapeHtml(date(tenant.data_vencimento)) + '</span></div>' +
        '<div class="company-detail-row"><strong>Equipe (' + (result.members || []).length + ')</strong><ul class="member-list">' + (members || '<li>Nenhum membro listado.</li>') + '</ul></div>';
    } catch (error) { companyDetails.textContent = error.message; }
  }

  content.addEventListener('submit', async (event) => {
    if (event.target.id === 'admin-support-reply-form') {
      event.preventDefault();
      const textarea = document.getElementById('admin-support-reply');
      const submit = event.target.querySelector('button[type="submit"]');
      const body = String(textarea && textarea.value || '').trim();
      if (!body || !state.supportThreadId) return;
      submit.disabled = true;
      try {
        await api('/support/threads/' + encodeURIComponent(state.supportThreadId) + '/messages', { method: 'POST', body: { body } });
        setGlobalMessage('Resposta enviada para a empresa.');
        await loadView('support');
      } catch (error) { setGlobalMessage(error.message, true); submit.disabled = false; }
      return;
    }
    if (event.target.id !== 'plan-editor-form') return;
    event.preventDefault();
    const form = event.target;
    const button = document.getElementById('plan-editor-submit');
    const error = document.getElementById('plan-editor-error');
    const price = Number(document.getElementById('new-plan-price').value);
    const maxMembers = Number(document.getElementById('new-plan-members').value);
    if (!Number.isFinite(price) || price < 0) { error.textContent = 'Informe um preço válido ou R$ 0,00 para rascunho/gratuito.'; return; }
    if (!Number.isInteger(maxMembers) || maxMembers < 0 || maxMembers > 500) { error.textContent = 'O limite de pessoas deve ser entre 0 e 500. Use 0 para ilimitado.'; return; }
    if (document.getElementById('plan-key').value === 'mensal' && maxMembers < 3) { error.textContent = 'O plano Mensal precisa permitir pelo menos 3 pessoas com acesso.'; return; }
    const features = Array.from(form.querySelectorAll('.plan-feature-check:checked')).map((input) => ({
      key: input.dataset.key, label: input.dataset.label, description: input.dataset.description
    }));
    button.disabled = true; error.textContent = '';
    const planKey = document.getElementById('plan-key').value;
    const payload = {
      name: document.getElementById('new-plan-name').value.trim(),
      description: document.getElementById('new-plan-description').value.trim(),
      price_cents: Math.round(price * 100),
      billing_interval: document.getElementById('new-plan-interval').value,
      billing_interval_count: Number(document.getElementById('new-plan-count').value),
      max_members: maxMembers,
      features
    };
    try {
      if (planKey) {
        await api('/plans/' + encodeURIComponent(planKey), { method: 'PATCH', body: payload });
        setGlobalMessage('Plano atualizado. O novo limite de acessos e as funcionalidades foram salvos.');
      } else {
        const result = await api('/plans', { method: 'POST', body: payload });
        setGlobalMessage(result.plan && result.plan.is_active ? 'Plano criado e vinculado à Stripe.' : 'Plano salvo como rascunho. Configure a Stripe e um preço antes de ativar vendas.');
      }
      state.editingPlanKey = null;
      await loadView('plans');
    } catch (err) { error.textContent = err.message; button.disabled = false; }
  });

  content.addEventListener('click', async (event) => {
    const viewLink = event.target.closest('[data-view-link]');
    if (viewLink) return loadView(viewLink.dataset.viewLink);
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const action = button.dataset.action;
    try {
      if (action === 'company-details') return showCompany(button.dataset.id);
      if (action === 'open-support-thread') { state.supportThreadId = Number(button.dataset.id); return loadView('support'); }
      if (action === 'edit-subscription') return openSubscription(button);
      if (action === 'edit-plan') { state.editingPlanKey = button.dataset.key; return loadView('plans'); }
      if (action === 'cancel-edit-plan') { state.editingPlanKey = null; return loadView('plans'); }
      if (action === 'delete-plan') {
        const plan = state.plans.find((item) => item.plan_key === button.dataset.key);
        if (!plan || !window.confirm('Remover o plano "' + plan.name + '" das novas contratações? O histórico será preservado.')) return;
        button.disabled = true;
        await api('/plans/' + encodeURIComponent(button.dataset.key), { method: 'DELETE' });
        state.editingPlanKey = null;
        setGlobalMessage('Plano removido das novas contratações. O histórico foi preservado.');
        await loadView('plans');
        return;
      }
      if (action === 'add-custom-feature') {
        const nameInput = document.getElementById('new-custom-feature-name');
        const label = String(nameInput && nameInput.value || '').trim();
        const key = featureSlug(label);
        const error = document.getElementById('plan-editor-error');
        if (label.length < 2 || !key) { error.textContent = 'Informe o nome da funcionalidade.'; return; }
        if (content.querySelector('.plan-feature-check[data-key="' + CSS.escape(key) + '"]')) { error.textContent = 'Essa funcionalidade já foi adicionada.'; return; }
        const description = featureDescription(label);
        const option = document.createElement('label');
        option.className = 'plan-feature-option custom-plan-feature';
        const input = document.createElement('input');
        input.className = 'plan-feature-check'; input.type = 'checkbox'; input.checked = true;
        input.dataset.key = key; input.dataset.label = label; input.dataset.description = description;
        const span = document.createElement('span');
        const strong = document.createElement('strong'); strong.textContent = label + ' · Personalizada';
        const small = document.createElement('small'); small.textContent = description;
        span.append(strong, small); option.append(input, span);
        document.getElementById('plan-feature-grid').append(option);
        nameInput.value = ''; document.getElementById('custom-feature-preview').textContent = 'A descrição será gerada automaticamente a partir do nome.';
        error.textContent = '';
        return;
      }
      if (action === 'tenant-status') {
        const next = button.dataset.next;
        const reason = next === 'suspended' ? window.prompt('Motivo da suspensão (obrigatório):') : '';
        if (next === 'suspended' && (!reason || reason.trim().length < 4)) return;
        button.disabled = true;
        await api('/tenants/' + encodeURIComponent(button.dataset.id) + '/status', { method: 'PATCH', body: { status: next, reason: reason || '' } });
        setGlobalMessage(next === 'suspended' ? 'Empresa suspensa. Os dados foram preservados.' : 'Empresa reativada.');
        await loadView('tenants');
        return;
      }
      if (action === 'toggle-plan') {
        const nextActive = button.dataset.active !== 'true';
        button.disabled = true;
        await api('/plans/' + encodeURIComponent(button.dataset.key), { method: 'PATCH', body: { is_active: nextActive } });
        setGlobalMessage(nextActive ? 'Novas vendas do plano foram ativadas.' : 'Novas vendas do plano foram desativadas.');
        await loadView('plans');
      }
    } catch (error) { setGlobalMessage(error.message, true); button.disabled = false; }
  });

  content.addEventListener('click', (event) => {
    if (event.target.closest('#tenant-search-button')) loadView('tenants');
    if (event.target.closest('#user-search-button')) loadView('users');
  });
  content.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' && (event.target.id === 'tenant-search' || event.target.id === 'user-search')) loadView(state.view);
  });

  document.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => loadView(button.dataset.view)));
  document.getElementById('refresh-view').addEventListener('click', () => loadView(state.view));
  document.querySelectorAll('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => button.closest('dialog').close()));
  [subscriptionDialog, companyDialog].forEach((dialog) => dialog.addEventListener('click', (event) => { if (event.target === dialog) dialog.close(); }));

  function updateSubscriptionDays() {
    const select = document.getElementById('subscription-plan');
    const days = document.getElementById('subscription-days');
    const status = document.getElementById('subscription-status').value;
    const option = select.options[select.selectedIndex];
    const interval = option && option.dataset.interval;
    const recurring = interval === 'month' || ['mensal', 'anual', 'teste', 'teste_gratis'].includes(select.value);
    days.disabled = status !== 'ativa' || !recurring;
    const hint = days.parentElement.querySelector('small');
    if (hint) hint.textContent = recurring ? 'Obrigatório para liberar manualmente uma assinatura recorrente (1 a 3650 dias).' : 'Planos de pagamento único não expiram.';
  }
  document.getElementById('subscription-plan').addEventListener('change', updateSubscriptionDays);
  document.getElementById('subscription-status').addEventListener('change', updateSubscriptionDays);

  subscriptionForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!state.subscriptionTenantId) return;
    const button = document.getElementById('subscription-save');
    const plan = document.getElementById('subscription-plan').value;
    const status = document.getElementById('subscription-status').value;
    const days = Number(document.getElementById('subscription-days').value);
    const selectedOption = document.getElementById('subscription-plan').selectedOptions[0];
    const recurring = (selectedOption && selectedOption.dataset.interval === 'month') || ['mensal', 'anual', 'teste', 'teste_gratis'].includes(plan);
    if (status === 'ativa' && recurring && (!Number.isInteger(days) || days < 1 || days > 3650)) {
      subscriptionError.textContent = 'Informe uma validade entre 1 e 3650 dias.';
      return;
    }
    button.disabled = true;
    subscriptionError.textContent = '';
    try {
      await api('/tenants/' + encodeURIComponent(state.subscriptionTenantId) + '/subscription', {
        method: 'PATCH', body: { plano_tipo: plan, status_assinatura: status, dias_adicionais: days }
      });
      subscriptionDialog.close();
      setGlobalMessage('Acesso atualizado para ' + state.subscriptionTargetName + '. O gateway não foi alterado.');
      await loadView('subscriptions');
    } catch (error) { subscriptionError.textContent = error.message; }
    finally { button.disabled = false; }
  });

  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const key = keyInput.value.trim();
    if (!key) { loginMessage.textContent = 'Informe a chave administrativa.'; return; }
    loginButton.disabled = true;
    loginButton.textContent = 'Validando...';
    loginMessage.textContent = '';
    try {
      await api('/session', { method: 'POST', headers: { 'x-admin-key': key } });
      keyInput.value = '';
      showAdmin();
      await loadView('overview');
    } catch (error) { loginMessage.textContent = error.message; }
    finally { loginButton.disabled = false; loginButton.innerHTML = 'Acessar painel <span aria-hidden="true">→</span>'; }
  });

  logoutButton.addEventListener('click', async () => {
    try { await api('/session', { method: 'DELETE' }); } catch (_) { /* limpa a tela mesmo se a sessão já expirou */ }
    showLogin();
  });

  api('/session').then(() => { showAdmin(); loadView('overview'); }).catch(() => showLogin());
})();
