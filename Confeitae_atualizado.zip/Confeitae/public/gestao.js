/* Confeitaê · Fase 2A
 * Encomendas (sinal e saldo), Agenda com trava de capacidade, Financeiro e Painel.
 * Usa os helpers e o visual do app principal (R, esc, num, by, D, hoje, tp, costOf, db, O...).
 * Carregado antes do script principal; só define funções, então não depende da ordem de execução. */

var FORMAS = ['Pix', 'Dinheiro', 'Cartão de crédito', 'Cartão de débito', 'Transferência', 'Outro'];
var CATS = ['Ingredientes e insumos', 'Embalagens', 'Energia, água e gás', 'Aluguel', 'Salários e pró-labore',
  'Marketing', 'Impostos e taxas', 'Equipamentos', 'Transporte e entrega', 'Outros'];

var PF = { st: 'abertos', q: '', origem: 'todos', pay: null, v: '', forma: 'Pix', data: '' };   // filtro de pedidos e painel de pagamento
var AG = { m: null, d: null };                                                   // agenda: mês e dia selecionados
var FN = { seg: 'resumo', m: null, pf: 'abertas', rf: 'todos', draft: null, sup: null };   // financeiro
var PED_SECTION = 'pedidos';

/* ------------------------------------------------------------------ utilidades */
function fmtISO(x) { return new Date(x - x.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); }
function addDias(d, n) { var x = new Date(d + 'T00:00:00'); x.setDate(x.getDate() + n); return fmtISO(x); }
function addMeses(d, n) {
  var y = +d.slice(0, 4), m = +d.slice(5, 7) - 1 + n, dd = +d.slice(8, 10);
  return fmtISO(new Date(y, m, Math.min(dd, new Date(y, m + 1, 0).getDate())));
}
function diasAte(d) { return Math.round((new Date(d + 'T00:00:00') - new Date(hoje() + 'T00:00:00')) / 864e5); }
function mesAtual() { return hoje().slice(0, 7); }
function nomeMes(m) {
  var s = new Date(+m.slice(0, 4), +m.slice(5, 7) - 1, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return s;
}
function nomeDia(d) {
  var s = new Date(d + 'T00:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  return s;
}
function Q(s) { return String(s == null ? '' : s).replace(/'/g, '').replace(/"/g, ''); }   // ids dentro de onclick
function opts(list, sel) {
  return list.map(function (x) { return '<option' + (x === sel ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('');
}
function soma(list, pick) {
  return (Array.isArray(list) ? list : []).reduce(function (total, item) {
    return total + num(typeof pick === 'function' ? pick(item) : item);
  }, 0);
}
function kvl(a, b) { return '<div class="kv"><span>' + a + '</span><b>' + b + '</b></div>'; }
function kpi(l, v, n) {
  return '<div class="card"><div class="mut">' + l + '</div><div class="big">' + v + '</div>' + (n ? '<div class="mut">' + n + '</div>' : '') + '</div>';
}

/* ------------------------------------------------------------------ regras de pedido */
function cfg() { return by(db.config || [], 'main') || { id: 'main', cap_pedidos: 0, cap_unid: 0 }; }

function mainConfigForEdit() {
  var existing = by(db.config || [], 'main');
  if (existing) return existing;
  var created = { id: 'main', cap_pedidos: 0, cap_unid: 0, fixed_costs: [], expected_monthly_units: 0, fixed_costs_confirmed: false };
  db.config.push(created);
  return created;
}
function estimateMonthlyUnitsFromOrders() {
  var today = hoje();
  var start = addDias(today, -90);
  var todayDate = new Date(today + 'T00:00:00');
  var startDate = null;
  var totalUnits = 0;
  var orderCount = 0;
  (Array.isArray(db.pedidos) ? db.pedidos : []).forEach(function (order) {
    if (!order || order.st === 'cancelado' || !/^\d{4}-\d{2}-\d{2}$/.test(String(order.ent || ''))) return;
    if (order.ent < start || order.ent > today) return;
    var units = (Array.isArray(order.itens) ? order.itens : []).reduce(function (sum, item) {
      return sum + Math.max(0, num(item && item.q));
    }, 0);
    if (!(units > 0)) return;
    totalUnits += units;
    orderCount += 1;
    var date = new Date(order.ent + 'T00:00:00');
    if (!startDate || date < startDate) startDate = date;
  });
  if (!startDate || orderCount < 3) return null;
  var observedDays = Math.floor((todayDate - startDate) / 86400000) + 1;
  // Exige pelo menos duas semanas de histórico para evitar extrapolar um único pico.
  if (observedDays < 14) return null;
  var usedDays = Math.min(90, observedDays);
  return {
    units: Math.max(1, Math.round(totalUnits * 30 / usedDays)),
    days: usedDays,
    orders: orderCount
  };
}
function getFixedCostAllocation() {
  var settings = by(db.config || [], 'main') || {};
  var expectedUnits = settings.expected_monthly_units;
  var estimate = null;
  if (!(KSWCosting.parseNumber(expectedUnits) > 0)) {
    estimate = estimateMonthlyUnitsFromOrders();
    if (estimate) expectedUnits = estimate.units;
  }
  var result = KSWCosting.calculateFixedCostAllocation(settings.fixed_costs || [], expectedUnits);
  if (estimate && result.valid) {
    result.estimatedFromHistory = true;
    result.historyDays = estimate.days;
    result.historyOrderCount = estimate.orders;
  } else {
    result.estimatedFromHistory = settings.expected_monthly_units_source === 'historico';
  }
  // Ausência de cadastro não significa despesa fixa igual a zero. Só aceitar
  // zero quando a confeiteira salvar explicitamente essa confirmação.
  if (result.valid && settings.fixed_costs_confirmed !== true) {
    result.valid = false;
    result.costPerUnit = null;
    result.errors.push('Cadastre as despesas fixas ou salve a confirmação de que não possui despesas fixas mensais.');
  }
  return result;
}
function addFixedCostRow() {
  var settings = mainConfigForEdit();
  if (!Array.isArray(settings.fixed_costs)) settings.fixed_costs = [];
  settings.fixed_costs.push({ id: id(), name: '', monthly_value: '' });
  saveLocalDB(); render();
}
var FIXED_COST_PERIODS = { mes: 1, semana: 52 / 12, ano: 1 / 12 };
function fixedCostMonthlyValue(rawValue, period) {
  var value = KSWCosting.parseNumber(rawValue);
  var factor = FIXED_COST_PERIODS[period] || 1;
  return value >= 0 ? KSWCosting.roundMoney(value * factor) : NaN;
}
function updateFixedCostRow(rowId, field, value) {
  var settings = mainConfigForEdit();
  if (!Array.isArray(settings.fixed_costs)) settings.fixed_costs = [];
  var row = settings.fixed_costs.find(function (entry) { return String(entry.id) === String(rowId); });
  if (!row || ['name', 'monthly_value', 'valor_informado', 'periodo'].indexOf(field) < 0) return;
  if (field === 'name') { row.name = String(value || '').slice(0, 100); return; }
  if (field === 'periodo') row.periodo = FIXED_COST_PERIODS[value] ? value : 'mes';
  else if (field === 'valor_informado') row.valor_informado = value;
  else { row.valor_informado = value; row.periodo = 'mes'; }
  var raw = row.valor_informado != null ? row.valor_informado : row.monthly_value;
  var monthly = fixedCostMonthlyValue(raw, row.periodo || 'mes');
  row.monthly_value = String(raw == null ? '' : raw).trim() === '' ? '' : (Number.isFinite(monthly) ? monthly : raw);
  var hint = document.getElementById('fixed-hint-' + rowId);
  if (hint) hint.textContent = Number.isFinite(monthly) && (row.periodo || 'mes') !== 'mes' ? 'Conta como ' + R(monthly) + ' por mês.' : '';
}
function addFixedCostSuggestion(name) {
  var settings = mainConfigForEdit();
  if (!Array.isArray(settings.fixed_costs)) settings.fixed_costs = [];
  var exists = settings.fixed_costs.some(function (entry) { return String(entry.name || '').trim().toLowerCase() === String(name).toLowerCase(); });
  if (exists) return toast(name + ' já está na lista.');
  settings.fixed_costs.push({ id: id(), name: name, monthly_value: '', periodo: 'mes' });
  saveLocalDB(); render();
  var inputs = document.querySelectorAll('.fixed-cost-row input[type=number]');
  if (inputs.length) inputs[inputs.length - 1].focus();
}
function confirmNoFixedCosts() {
  var settings = mainConfigForEdit();
  settings.fixed_costs = [];
  settings.expected_monthly_units = 0;
  settings.fixed_costs_confirmed = true;
  saveLocalDB(); render(); toast('Combinado: você não tem despesas fixas. O KSW não vai ratear nada.');
}
function volumeFromHelperKSW() {
  var orders = KSWCosting.parseNumber((document.getElementById('fixed-helper-orders') || {}).value);
  var perOrder = KSWCosting.parseNumber((document.getElementById('fixed-helper-units') || {}).value);
  return orders > 0 && perOrder > 0 ? Math.round(orders * perOrder) : null;
}
function previewVolumeHelperKSW() {
  var out = document.getElementById('fixed-helper-preview'); if (!out) return;
  var total = volumeFromHelperKSW();
  out.textContent = total ? 'Dá cerca de ' + total.toLocaleString('pt-BR') + ' unidades por mês.' : 'Preencha os dois campos para ver o volume do mês.';
}
function applyVolumeHelperKSW() {
  var total = volumeFromHelperKSW();
  if (!total) return toast('Informe quantas encomendas faz por mês e quantas unidades leva cada uma.');
  var field = document.getElementById('fixed-month-units');
  if (field) { field.value = String(total); field.dataset.estimated = 'false'; }
  toast('Volume mensal preenchido: ' + total.toLocaleString('pt-BR') + ' unidades. Agora toque em Salvar e recalcular.');
}
function removeFixedCostRow(rowId) {
  var settings = mainConfigForEdit();
  settings.fixed_costs = (settings.fixed_costs || []).filter(function (entry) { return String(entry.id) !== String(rowId); });
  saveLocalDB(); render();
}
function saveFixedCostSettings() {
  var settings = mainConfigForEdit();
  var unitsField = document.getElementById('fixed-month-units');
  var expectedUnits = KSWCosting.parseNumber(unitsField ? unitsField.value : settings.expected_monthly_units);
  var historicalEstimate = null;
  if (!(expectedUnits > 0) && !(unitsField && String(unitsField.value || '').trim())) {
    historicalEstimate = estimateMonthlyUnitsFromOrders();
    if (historicalEstimate) expectedUnits = historicalEstimate.units;
  }
  var savedRows = Array.isArray(settings.fixed_costs) ? settings.fixed_costs : [];
  if (savedRows.some(function (row) { return !String(row.name || '').trim() && !String(row.monthly_value == null ? '' : row.monthly_value).trim(); })) {
    return toast('Preencha ou remova a despesa fixa vazia antes de salvar.');
  }
  var rows = savedRows.filter(function (row) { return String(row.name || '').trim() || String(row.monthly_value == null ? '' : row.monthly_value).trim() !== ''; });
  for (var i = 0; i < rows.length; i++) {
    var value = KSWCosting.parseNumber(rows[i].monthly_value);
    if (!String(rows[i].name || '').trim()) return toast('Informe a descrição da despesa fixa ' + (i + 1) + '.');
    if (!(value >= 0)) return toast('Informe um valor mensal válido para ' + rows[i].name + '.');
    rows[i].name = String(rows[i].name).trim();
    rows[i].monthly_value = KSWCosting.roundMoney(value);
  }
  var total = rows.reduce(function (sum, row) { return sum + KSWCosting.parseNumber(row.monthly_value); }, 0);
  if (total > 0 && !(expectedUnits > 0)) return toast('Ainda não há histórico suficiente para estimar o volume. Informe uma previsão mensal aproximada ou deixe o rateio sem configurar por enquanto.');
  if (String(unitsField ? unitsField.value : '').trim() !== '' && (!(expectedUnits >= 0) || !Number.isFinite(expectedUnits))) return toast('A previsão mensal de unidades precisa ser válida.');
  settings.fixed_costs = rows;
  settings.expected_monthly_units = Number.isFinite(expectedUnits) && expectedUnits >= 0 ? expectedUnits : 0;
  settings.expected_monthly_units_source = historicalEstimate ? 'historico' : (unitsField && unitsField.dataset.estimated === 'true' ? 'historico' : 'manual');
  settings.fixed_costs_confirmed = true;
  saveLocalDB(); render(); toast('Custos fixos salvos e rateio atualizado.');
}
function finFixos() {
  var settings = by(db.config || [], 'main') || {};
  var rows = Array.isArray(settings.fixed_costs) ? settings.fixed_costs : [];
  var allocation = getFixedCostAllocation();
  var estimate = !(KSWCosting.parseNumber(settings.expected_monthly_units) > 0) ? estimateMonthlyUnitsFromOrders() : null;
  var expectedUnitsValue = settings.expected_monthly_units > 0 ? settings.expected_monthly_units : (estimate ? estimate.units : '');
  var h = '<section class="card"><span class="ksw-eyebrow">Preço mais realista</span><h3>Despesas fixas (opcional)</h3><p class="mut">Inclua apenas o que você paga mesmo sem nenhum pedido, como aluguel ou internet. O KSW divide esse total entre os produtos e soma no custo de cada um. Você pode começar sem configurar isso e voltar depois.</p>';
  h += '<label for="fixed-month-units">Quantas unidades você vende em um mês normal?</label><input id="fixed-month-units" type="number" min="0" step="1" value="' + esc(String(expectedUnitsValue)) + '" data-estimated="' + (estimate ? 'true' : 'false') + '" oninput="this.dataset.estimated=&quot;false&quot;" placeholder="O KSW estima quando houver histórico"><small class="mut">' + (estimate ? 'Estimativa automática baseada em ' + estimate.orders + ' pedidos nos últimos ' + estimate.days + ' dias. Você pode ajustar se souber que o próximo mês será diferente.' : 'Quando houver pelo menos 3 pedidos distribuídos por 14 dias, o KSW estima este volume pelo histórico.') + '</small>';
  h += '<details class="ksw-volume-helper"><summary>Não sabe esse número? O KSW calcula</summary><div class="cols"><div><label for="fixed-helper-orders">Quantas encomendas faz por mês</label><input id="fixed-helper-orders" type="number" min="1" step="1" inputmode="numeric" placeholder="Ex.: 20" oninput="previewVolumeHelperKSW()"></div><div><label for="fixed-helper-units">Mais ou menos quantas unidades em cada uma</label><input id="fixed-helper-units" type="number" min="1" step="1" inputmode="numeric" placeholder="Ex.: 30 doces" oninput="previewVolumeHelperKSW()"></div></div><p id="fixed-helper-preview" class="ksw-hour-preview" aria-live="polite">Preencha os dois campos para ver o volume do mês.</p><button class="btn ghost sm" type="button" onclick="applyVolumeHelperKSW()">Usar este volume</button></details></section>';
  h += '<section class="card"><div class="row"><b>Despesas fixas mensais</b><button class="btn ghost sm" type="button" onclick="addFixedCostRow()">+ Adicionar despesa</button></div>';
  var suggestions = ['Aluguel', 'Internet', 'Telefone', 'Contador', 'Imposto fixo (MEI)', 'Seguro'];
  h += '<div class="ksw-fixed-suggestions" role="group" aria-label="Sugestões de despesas fixas"><span class="mut">Toque para adicionar:</span>' + suggestions.map(function (name) {
    return '<button class="btn ghost sm" type="button" onclick="addFixedCostSuggestion(&quot;' + name + '&quot;)">' + esc(name) + '</button>';
  }).join('') + '</div>';
  h += rows.length ? rows.map(function (row) {
    var period = FIXED_COST_PERIODS[row.periodo] ? row.periodo : 'mes';
    var shown = row.valor_informado != null ? row.valor_informado : row.monthly_value;
    var monthly = fixedCostMonthlyValue(shown, period);
    return '<div class="fixed-cost-row"><div class="cols"><div><label>Descrição</label><input maxlength="100" value="' + esc(row.name || '') + '" placeholder="Ex.: Aluguel" oninput="updateFixedCostRow(&quot;' + Q(row.id) + '&quot;,&quot;name&quot;,this.value)"></div><div><label>Quanto paga (R$)</label><input type="number" min="0" step="0.01" inputmode="decimal" value="' + esc(String(shown == null ? '' : shown)) + '" placeholder="0,00" oninput="updateFixedCostRow(&quot;' + Q(row.id) + '&quot;,&quot;valor_informado&quot;,this.value)"></div><div><label>A cada</label><select onchange="updateFixedCostRow(&quot;' + Q(row.id) + '&quot;,&quot;periodo&quot;,this.value)"><option value="mes"' + (period === 'mes' ? ' selected' : '') + '>Mês</option><option value="semana"' + (period === 'semana' ? ' selected' : '') + '>Semana</option><option value="ano"' + (period === 'ano' ? ' selected' : '') + '>Ano</option></select></div></div><small id="fixed-hint-' + esc(row.id) + '" class="mut">' + (period !== 'mes' && Number.isFinite(monthly) ? 'Conta como ' + R(monthly) + ' por mês.' : '') + '</small> <button class="btn ghost sm" type="button" onclick="removeFixedCostRow(&quot;' + Q(row.id) + '&quot;)">Remover</button></div>';
  }).join('') : '<p class="mut">Nenhuma despesa fixa cadastrada. Toque em uma sugestão acima ou em “Adicionar despesa”.</p>';
  h += '<p><button class="btn" type="button" onclick="saveFixedCostSettings()">Salvar e recalcular</button>' + (rows.length ? '' : ' <button class="btn ghost" type="button" onclick="confirmNoFixedCosts()">Não tenho despesas fixas</button>') + '</p></section>';
  if (allocation.valid) {
    h += '<section class="grid"><article class="card"><div class="mut">Total fixo por mês</div><div class="big">' + R(allocation.monthlyTotal) + '</div></article><article class="card"><div class="mut">Rateio estimado por unidade</div><div class="big">' + R(allocation.costPerUnit) + '</div><div class="mut">Base: ' + (allocation.expectedMonthlyUnits == null ? 'sem previsão mensal' : allocation.expectedMonthlyUnits.toLocaleString('pt-BR') + ' unidades') + '</div></article></section>';
    if (allocation.configured) h += '<div class="ksw-profit-note"><b>Como o KSW usa este valor:</b> o rateio será somado ao custo do produto ao avaliar preço, margem e encomendas novas. Exemplo: R$ 600 de custos fixos ÷ 200 unidades previstas = R$ 3,00 por unidade.</div>';
    else h += '<div class="card mut">Você confirmou que não possui despesas fixas mensais cadastradas. Quando tiver aluguel, internet, contador ou manutenção, adicione os valores aqui e informe a previsão mensal de unidades.</div>';
  } else {
    h += '<div class="ksw-profit-note"><b>Falta pouco para o KSW ratear.</b><p>' + allocation.errors.map(esc).join('<br>') + ' Preencha e salve, ou toque em “Não tenho despesas fixas”. Até lá, o resultado completo fica marcado como parcial.</p></div>';
  }
  h += '<div class="card mut"><b>Importante para não contar duas vezes:</b> este cadastro é usado apenas para calcular preço e rentabilidade. Ele não cria contas a pagar nem movimentações de caixa. Continue registrando o pagamento real no Financeiro. Não inclua aqui custos já calculados por unidade na ficha (por exemplo, embalagem, mão de obra direta, energia/água/gás variáveis) para evitar duplicidade.</div>';
  return h;
}
function pagList(p) {
  if (Array.isArray(p.pagamentos)) return p.pagamentos;
  return num(p.pg) > 0 ? [{ id: 'legado', v: num(p.pg), data: p.pd || p.ent || '', forma: 'Outro' }] : [];   // pedidos antigos
}
function pagoDe(p) { return KSWAnalytics.orderPaid(p); }
function saldoDe(p) { return KSWAnalytics.orderBalance(p); }
function aReceberLista() { return KSWAnalytics.openReceivables(db); }
function vencidas() { return (db.despesas || []).filter(function (x) { return !x.pago && x.venc && diasAte(x.venc) < 0; }); }
function custoDe(p) { return p.itens.reduce(function (a, i) { return a + (i.cu || 0) * i.q; }, 0); }
function ativo(p) { return p.st !== 'cancelado'; }
function unidades(p) { return p.itens.reduce(function (a, i) { return a + num(i.q); }, 0); }
function cliNome(p) { var c = by(db.clientes, p.cli); return c ? c.nome : 'Cliente removido'; }
function resumoItens(p) { return p.itens.map(function (i) { return i.q + '× ' + esc(i.nome); }).join(', '); }

function capCheck(d, exId, addU) {
  var c = cfg(), n = 0, u = 0;
  db.pedidos.forEach(function (p) { if (p.ent === d && ativo(p) && p.id !== exId) { n++; u += unidades(p); } });
  var m = [];
  if (c.cap_pedidos > 0 && n + 1 > c.cap_pedidos) m.push('o limite de ' + c.cap_pedidos + ' pedido(s) por dia');
  if (c.cap_unid > 0 && u + addU > c.cap_unid) m.push('o limite de ' + c.cap_unid + ' unidades por dia');
  return { n: n, u: u, msgs: m, c: c };
}
function diaLotado(d) {
  var c = cfg(), n = 0, u = 0;
  db.pedidos.forEach(function (p) { if (p.ent === d && ativo(p)) { n++; u += unidades(p); } });
  return { n: n, u: u, over: (c.cap_pedidos > 0 && n > c.cap_pedidos) || (c.cap_unid > 0 && u > c.cap_unid) };
}

/* ------------------------------------------------------------------ WhatsApp */
function waLink(tel, txt) {
  var n = String(tel || '').replace(/\D/g, '');
  if (n && n.length <= 11) n = '55' + n;
  return 'https://wa.me/' + n + (txt ? '?text=' + encodeURIComponent(txt) : '');
}
function msg(i, kind) {
  var p = by(db.pedidos, i); if (!p) return;
  var c = by(db.clientes, p.cli);
  if (!c || !String(c.tel || '').replace(/\D/g, '')) return toast('Cadastre o WhatsApp desta cliente para enviar mensagens.');
  var nome = c.nome.split(' ')[0], quando = D(p.ent) + (p.hora ? ' às ' + p.hora : ''), t = tp(p), pg = pagoDe(p), sd = saldoDe(p);
  var txt = {
    lem: 'Olá, ' + nome + '! Passando para lembrar da sua encomenda de ' + quando + ': ' + p.itens.map(function (x) { return x.q + '× ' + x.nome; }).join(', ') + '. Qualquer dúvida é só me chamar!',
    cob: 'Olá, ' + nome + '! Sua encomenda de ' + quando + ' está com saldo em aberto de ' + R(sd) + ' (total ' + R(t) + ', já pago ' + R(pg) + '). Posso te passar os dados para o pagamento?',
    conf: 'Olá, ' + nome + '! Confirmando sua encomenda para ' + quando + ': ' + p.itens.map(function (x) { return x.q + '× ' + x.nome; }).join(', ') + '. Total ' + R(t) + (pg ? ', sinal de ' + R(pg) + ' recebido' : '') + (sd ? ', saldo de ' + R(sd) + ' na entrega' : '') + '.'
  }[kind] || '';
  window.open(waLink(c.tel, txt), '_blank', 'noopener');
}

/* ------------------------------------------------------------------ PEDIDOS */
function newO(dia) {
  O = { isNew: true, cli: '', ent: dia || '', hora: '', obs: '', itens: [], sinal: 0, forma: 'Pix', st: 'recebido' };
  tab = 'pedidos'; render();
}
function addOrderItemKSW() {
  if (!O) return;
  if (!db.produtos.length) {
    if (db.ingredientes.length) go('produtos'); else go('ingredientes');
    return;
  }
  O.itens.push({ prod: '', q: 1 });
  render();
  var field = document.getElementById('order-product-' + (O.itens.length - 1));
  if (field) { field.focus(); field.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
}
function editO(i) {
  var p = by(db.pedidos, i); if (!p) return;
  O = { id: p.id, isNew: false, cli: p.cli, ent: p.ent || '', hora: p.hora || '', obs: p.obs || '', st: p.st, sinal: 0, forma: 'Pix',
    itens: p.itens.map(function (x) { return { prod: x.pid, q: x.q, pu: x.pu, cu: x.cu, cfu: x.cfu, fixed_costs_informado: x.fixed_costs_informado, taxa_venda_pct: x.taxa_venda_pct, taxa_venda_informada: x.taxa_venda_informada, nome: x.nome }; }) };
  tab = 'pedidos'; render();
}
function precoItem(i) { if (i.pu != null) return i.pu; var p = by(db.produtos, i.prod); return p ? p.preco : 0; }
function totalDraft() { return O.itens.reduce(function (a, i) { return a + precoItem(i) * num(i.q); }, 0); }

// A perda do pedido usa o custo congelado na linha quando disponível. Para
// pedidos novos, usa a ficha atual. Pedidos antigos sem custo ficam sem estimativa.
function estimateOrderProfitability(items, isNewOrder) {
  var result = { rows: [], loss: 0, lossItems: 0, belowTargetItems: 0, missingCostItems: 0, missingFeeItems: 0, missingFixedCostItems: 0 };
  (Array.isArray(items) ? items : []).forEach(function (item) {
    var product = by(db.produtos, item.prod || item.pid), quantity = num(item.q);
    if (!(quantity > 0)) return;
    var newlySelected = item.pu == null;
    var rawCost = item.cu != null ? item.cu : item.custo_unitario;
    var unitCost = rawCost != null && rawCost !== '' ? KSWCosting.parseNumber(rawCost) : NaN;
    if (!Number.isFinite(unitCost) && (isNewOrder || newlySelected) && product) {
      var currentCost = costCalculation(product);
      if (currentCost.valid) unitCost = currentCost.unitCost;
    }
    var price = item.pu != null ? KSWCosting.parseNumber(item.pu) : product ? KSWCosting.parseNumber(product.preco) : NaN;
    if (!Number.isFinite(unitCost) || !Number.isFinite(price)) {
      result.missingCostItems += 1;
      return;
    }
    var feeKnown = item.taxa_venda_informada === true || (item.taxa_venda_informada !== false && Number.isFinite(KSWCosting.parseNumber(item.taxa_venda_pct)) && KSWCosting.parseNumber(item.taxa_venda_pct) > 0);
    if (!feeKnown && (isNewOrder || newlySelected) && product) feeKnown = KSWCosting.hasKnownVariableFee(product);
    var fee = feeKnown ? KSWCosting.parseNumber(item.taxa_venda_pct != null ? item.taxa_venda_pct : product && product.taxa_venda_pct) : 0;
    if (!Number.isFinite(fee)) fee = 0;
    if (!feeKnown) result.missingFeeItems += 1;
    var prefs = (typeof getKswSettings === 'function') ? getKswSettings() : { targetMargin: 30 };
    var target = product ? KSWCosting.parseNumber(product.margem == null ? prefs.targetMargin : product.margem) : prefs.targetMargin;
    if (!Number.isFinite(target)) target = 0;
    var fixedAllocation = getFixedCostAllocation();
    var fixedCostKnown = item.cfu != null && item.fixed_costs_informado !== false;
    var fixedCostPerUnit = fixedCostKnown ? KSWCosting.parseNumber(item.cfu) : 0;
    if (!fixedCostKnown && (isNewOrder || newlySelected)) {
      fixedCostKnown = fixedAllocation.valid;
      fixedCostPerUnit = fixedCostKnown ? fixedAllocation.costPerUnit : 0;
    }
    if (!fixedCostKnown) result.missingFixedCostItems += 1;
    var assessment = KSWCosting.assessProfitability(unitCost, price, {
      quantity: quantity, targetMargin: target, variableFeePercent: fee, variableFeeKnown: feeKnown,
      fixedCostPerUnit: fixedCostPerUnit, fixedCostKnown: fixedCostKnown
    });
    if (!assessment.valid) {
      if (assessment.errors.some(function (error) { return /taxas e impostos/i.test(error); })) result.missingFeeItems += 1;
      else result.missingCostItems += 1;
      return;
    }
    var row = { name: String(item.nome || (product && product.nome) || 'Produto'), quantity: quantity, assessment: assessment, feeKnown: feeKnown, fixedCostKnown: fixedCostKnown };
    result.rows.push(row);
    if (assessment.status === 'loss') {
      result.loss += assessment.estimatedLoss;
      result.lossItems += 1;
    } else if (assessment.status === 'below_target' || assessment.status === 'break_even') {
      result.belowTargetItems += 1;
    }
  });
  result.loss = KSWCosting.roundMoney(result.loss);
  return result;
}

function pedForm() {
  var h = '<div class="card"><b>' + (O.isNew ? 'Novo pedido' : 'Editar pedido') + '</b>';
  if (!db.clientes.length) h += '<div class="ksw-form-next-step"><div><b>Primeiro, cadastre uma cliente</b><p>O pedido precisa estar vinculado a uma cliente. O rascunho ficará guardado enquanto você faz o cadastro.</p></div><button class="btn ghost sm" type="button" onclick="go(\'clientes\')">Cadastrar cliente →</button></div>';
  h += '<label>Cliente</label><select id="order-client" onchange="O.cli=this.value;kswRefreshNextStepGuide()"><option value="">Selecione…</option>' +
    db.clientes.map(function (c) { return '<option value="' + esc(c.id) + '"' + (c.id === O.cli ? ' selected' : '') + '>' + esc(c.nome) + '</option>'; }).join('') + '</select>';
  h += '<div class="cols"><div><label for="order-delivery-date">Data de entrega</label><input id="order-delivery-date" type="date" value="' + esc(O.ent) + '" onchange="O.ent=this.value;tot()"></div>' +
    '<div><label for="order-delivery-time">Horário</label><input id="order-delivery-time" type="time" value="' + esc(O.hora) + '" onchange="O.hora=this.value"></div></div>';
  h += '<div class="order-items-heading"><label>Itens do pedido</label><small class="mut">Selecione produtos já cadastrados em Preços e receitas.</small></div>';
  if (!db.produtos.length) {
    h += '<div class="ksw-form-next-step"><div><b>Não há produtos cadastrados para adicionar</b><p>' + (db.ingredientes.length ? 'Cadastre uma ficha técnica em Preços e receitas. Depois volte a este pedido para selecionar o produto.' : 'Cadastre primeiro os ingredientes no Estoque. Depois crie a ficha técnica e volte para adicionar o produto ao pedido.') + '</p></div><button class="btn ghost sm" type="button" onclick="O.returnToOrder=true;go(\'' + (db.ingredientes.length ? 'produtos' : 'ingredientes') + '\')">' + (db.ingredientes.length ? 'Cadastrar produto' : 'Cadastrar ingrediente') + ' →</button></div>';
  } else if (!O.itens.length) {
    h += '<div class="ksw-form-next-step"><div><b>O pedido ainda não tem itens</b><p>Adicione um produto cadastrado. A quantidade e o preço serão usados para calcular o total e o saldo.</p></div><button class="btn sm" type="button" onclick="addOrderItemKSW()">Adicionar primeiro item →</button></div>';
  }
  h += O.itens.map(function (i, k) {
    var lista = db.produtos.slice();
    var orfao = i.prod && !by(db.produtos, i.prod) ? '<option value="' + esc(i.prod) + '" selected>' + esc(i.nome) + ' (' + R(i.pu) + ', removido)</option>' : '';
    var empty = !i.prod ? '<option value="" selected>Selecione um produto…</option>' : '';
    return '<div class="row order-item-row" style="margin-bottom:6px"><select id="order-product-' + k + '" style="flex:2;min-width:0" aria-label="Produto do item ' + (k + 1) + '" onchange="O.itens[' + k + '].prod=this.value;delete O.itens[' + k + '].pu;delete O.itens[' + k + '].cu;delete O.itens[' + k + '].taxa_venda_pct;delete O.itens[' + k + '].taxa_venda_informada;delete O.itens[' + k + '].nome;tot()">' + empty + orfao +
      lista.map(function (x) { return '<option value="' + esc(x.id) + '"' + (x.id === i.prod ? ' selected' : '') + '>' + esc(x.nome) + ' (' + R(x.preco) + ')</option>'; }).join('') +
      '</select><input style="flex:1;min-width:64px" inputmode="numeric" value="' + esc(i.q) + '" oninput="O.itens[' + k + '].q=num(this.value);tot()" aria-label="Quantidade"><button class="btn ghost sm" type="button" onclick="O.itens.splice(' + k + ',1);render()" aria-label="Remover item">×</button></div>';
  }).join('');
  h += db.produtos.length
    ? '<button id="order-add-item" class="btn ghost sm" type="button" onclick="addOrderItemKSW()">+ Adicionar outro item</button> <button class="btn ghost sm" type="button" onclick="O.returnToOrder=true;go(\'produtos\')">Cadastrar novo produto</button>'
    : '';
  h += '<label>Observações (tema, dedicatória, restrições, endereço de entrega…)</label><textarea rows="2" oninput="O.obs=this.value">' + esc(O.obs) + '</textarea>';
  if (O.isNew) {
    h += '<div class="cols"><div><label>Sinal recebido (R$)</label><input inputmode="decimal" value="' + (O.sinal || '') + '" placeholder="0,00" oninput="O.sinal=num(this.value);tot()"></div>' +
      '<div><label>Forma do sinal</label><select onchange="O.forma=this.value">' + opts(FORMAS, O.forma) + '</select></div></div>' +
      '<div class="mut" style="margin-top:6px">Com sinal, o pedido entra como confirmado.</div>';
  } else {
    h += '<label>Status</label><select onchange="O.st=this.value">' + opts(ST, O.st) + '</select>' +
      '<div class="mut" style="margin-top:6px">Os pagamentos deste pedido são registrados no cartão dele, em “Receber”.</div>';
  }
  h += '<div class="res" id="tot"></div><p><button id="order-save-button" class="btn" ' + (!O.itens.length ? 'disabled title="Adicione um produto para continuar."' : '') + ' onclick="saveO()">' + (O.isNew ? 'Registrar pedido' : 'Salvar alterações') + '</button> <button class="btn ghost" onclick="O=null;render()">Cancelar</button></p></div>';
  return h;
}
function tot() {
  var e = document.getElementById('tot'); if (!e || !O) return;
  var saveButton = document.getElementById('order-save-button');
  if (saveButton) {
    var incompleteItems = !O.itens.length || O.itens.some(function (item) { return !item.prod || !by(db.produtos, item.prod) || !(num(item.q) > 0); });
    saveButton.disabled = incompleteItems;
    saveButton.title = incompleteItems ? 'Escolha um produto e informe uma quantidade válida em cada item.' : '';
  }
  if (typeof kswRefreshNextStepGuide === 'function') kswRefreshNextStepGuide();
  var t = totalDraft(), h = '<div style="margin-top:10px"><b>Total: ' + R(t) + '</b>';
  if (O.isNew) h += ' · Sinal: ' + R(O.sinal || 0) + ' · <b>Saldo: ' + R(Math.max(0, t - (O.sinal || 0))) + '</b>';
  else { var p = by(db.pedidos, O.id); if (p) h += ' · Já pago: ' + R(pagoDe(p)) + ' · <b>Saldo: ' + R(saldoDe(p)) + '</b>'; }
  h += '</div>';
  var profitability = estimateOrderProfitability(O.itens, O.isNew);
  if (profitability.loss > 0) {
    var fixedCostNote = profitability.missingFixedCostItems > 0
      ? 'O rateio de despesas fixas está incompleto; a perda exibida é mínima e pode aumentar depois de incluir aluguel, internet e outros custos.'
      : 'O rateio fixo confirmado no momento do pedido foi considerado. Outros custos não cadastrados continuam fora da estimativa.';
    h += '<div class="ksw-loss-alert"><strong>Alerta: este pedido tem ' + 'perda mínima estimada de ' + R(profitability.loss) + (profitability.missingFeeItems ? ' antes das taxas não informadas.' : ' considerando os custos e taxas cadastrados.') + '</strong>' +
      '<ul class="ksw-loss-list">' + profitability.rows.filter(function (row) { return row.assessment.status === 'loss'; }).map(function (row) {
        return '<li>' + esc(row.name) + ': ' + row.quantity.toLocaleString('pt-BR') + ' un. · perda ' + (row.feeKnown ? 'estimada' : 'mínima, sem taxas') + ' de ' + R(row.assessment.estimatedLoss) + ' (' + R(row.assessment.lossPerUnit) + '/un.). ' + esc(row.assessment.recommendation) + '</li>';
      }).join('') + '</ul><p>' + fixedCostNote + ' Revise o preço, a porção ou os custos antes de confirmar. O sistema não bloqueia a venda, mas pede confirmação.</p></div>';
  } else if (profitability.missingFeeItems > 0) {
    h += '<div class="ksw-profit-note"><b>Taxas não informadas em ' + profitability.missingFeeItems + ' item(ns).</b> A sobra mostrada antes dessas taxas pode ser menor ou virar prejuízo. ' + profitability.rows.filter(function (row) { return !row.feeKnown; }).map(function (row) { return esc(row.name) + ': sobra antes das taxas de ' + R(row.assessment.profitPerUnit) + '/un. (' + R(row.assessment.estimatedProfit) + ' neste pedido).'; }).join(' ') + ' Cadastre a taxa na ficha do produto para ter uma estimativa completa.</div>';
  } else if (profitability.belowTargetItems > 0) {
    h += '<div class="ksw-profit-note"><b>Atenção à margem:</b> ' + profitability.belowTargetItems + ' item(ns) do pedido estão no ponto de equilíbrio ou abaixo da margem desejada. Revise os preços em Preços e receitas.</div>';
  }
  if (profitability.missingCostItems > 0) h += '<small class="mut">Não foi possível estimar a margem de ' + profitability.missingCostItems + ' linha(s), pois faltam custos registrados.</small>';
  if (profitability.missingFixedCostItems > 0) h += '<div class="ksw-profit-note"><b>Despesas fixas ainda não rateadas.</b> Cadastre o total mensal e a previsão de vendas em Financeiro &gt; Custos fixos para saber se o pedido também cobre aluguel, internet e outros custos fixos.</div>';
  if (O.ent) {
    var un = O.itens.reduce(function (a, i) { return a + num(i.q); }, 0), c = capCheck(O.ent, O.id, un);
    h += '<div class="mut" style="margin-top:6px">Neste dia: ' + c.n + ' pedido(s) e ' + c.u + ' unidade(s) já agendados.</div>';
    if (c.msgs.length) h += '<div style="margin-top:6px"><span class="tag late">Este pedido ultrapassa ' + c.msgs.join(' e ') + '</span></div>';
  }
  e.innerHTML = h;
}

function saveO() {
  if (!O.cli) return toast('Escolha a cliente.');
  if (!O.ent) return toast('Informe a data de entrega.');
  if (!O.itens.length) return toast('Adicione ao menos um item. Use “Adicionar primeiro item” no formulário.');
  if (O.itens.some(function (i) { return !i.prod || !by(db.produtos, i.prod); })) return toast('Escolha um produto cadastrado em cada item do pedido.');
  if (O.itens.some(function (i) { return !(num(i.q) > 0); })) return toast('Informe a quantidade de cada item.');
  var invalidProduct = O.itens.find(function (item) { var product = by(db.produtos, item.prod); return item.pu == null && product && !costCalculation(product).valid; });
  if (invalidProduct) return toast('A ficha técnica de um produto está incompleta. Corrija os custos antes de registrar o pedido.');
  var profitability = estimateOrderProfitability(O.itens, O.isNew);
  var fixedCostConfirmationNote = profitability.missingFixedCostItems > 0
    ? 'O rateio das despesas fixas está incompleto; a perda pode ser maior.'
    : 'O rateio fixo confirmado no momento do pedido foi considerado; custos não cadastrados continuam fora.';
  if (profitability.loss > 0 && !confirm('ATENÇÃO: este pedido tem perda mínima estimada de ' + R(profitability.loss) + (profitability.missingFeeItems ? ' antes das taxas não informadas.' : ' considerando os custos e taxas cadastrados.') + '\n\n' + fixedCostConfirmationNote + ' Revise o preço e os custos antes de confirmar.\n\nDeseja registrar mesmo assim?')) return;
  var un = O.itens.reduce(function (a, i) { return a + num(i.q); }, 0), c = capCheck(O.ent, O.id, un);
  if (c.msgs.length && !confirm('Atenção: este pedido ultrapassa ' + c.msgs.join(' e ') + ' (' + D(O.ent) + ').\n\nAceitar mesmo assim?')) return;
  var itens = O.itens.map(function (i) {
    if (i.pu != null) return { pid: i.prod, nome: i.nome, q: num(i.q), pu: i.pu, cu: i.cu, cfu: i.cfu, fixed_costs_informado: i.fixed_costs_informado, taxa_venda_pct: i.taxa_venda_pct, taxa_venda_informada: i.taxa_venda_informada === true || (i.taxa_venda_informada !== false && KSWCosting.parseNumber(i.taxa_venda_pct) > 0) };
    var p = by(db.produtos, i.prod), feeKnown = KSWCosting.hasKnownVariableFee(p), fixedAllocation = getFixedCostAllocation();
    return { pid: p.id, nome: p.nome, q: num(i.q), pu: p.preco, cu: +costOf(p).toFixed(2), cfu: fixedAllocation.valid ? fixedAllocation.costPerUnit : null, fixed_costs_informado: fixedAllocation.valid, taxa_venda_pct: feeKnown ? KSWCosting.parseNumber(p.taxa_venda_pct) : null, taxa_venda_informada: feeKnown };
  });
  if (O.isNew) {
    var ped = { id: id(), cli: O.cli, ent: O.ent, hora: O.hora, obs: O.obs.trim(), itens: itens, st: O.sinal > 0 ? 'confirmado' : 'recebido', pagamentos: [], pg: 0, pd: '' };
    if (O.sinal > 0) { ped.pagamentos.push({ id: id(), v: O.sinal, data: hoje(), forma: O.forma }); ped.pg = O.sinal; ped.pd = hoje(); }
    db.pedidos.push(ped);
  } else {
    var orig = by(db.pedidos, O.id), i = db.pedidos.indexOf(orig);
    db.pedidos[i] = Object.assign({}, orig, { cli: O.cli, ent: O.ent, hora: O.hora, obs: O.obs.trim(), itens: itens, st: O.st });
  }
  O = null; saveLocalDB(); render(); toast('Pedido salvo.');
}

function upO(i, v) {
  var p = by(db.pedidos, i); if (!p) return;
  if (v === 'entregue' && saldoDe(p) > 0.004 && !confirm('Ainda há ' + R(saldoDe(p)) + ' em aberto neste pedido.\n\nMarcar como entregue mesmo assim?')) return render();
  if (v === 'cancelado' && !confirm('Cancelar este pedido? Ele deixa de contar no faturamento e na agenda. Pagamentos já recebidos continuam no caixa; remova-os no pedido se precisar estornar.')) return render();
  p.st = v; saveLocalDB(); render();
}
function delO(i) {
  if (!confirm('Excluir este pedido definitivamente? Os pagamentos registrados nele também serão apagados do caixa.')) return;
  db.pedidos = db.pedidos.filter(function (x) { return x.id !== i; }); saveLocalDB(); render();
}

/* pagamentos de um pedido */
function openPay(i) {
  var p = by(db.pedidos, i); if (!p) return;
  if (PF.pay === i) { PF.pay = null; return render(); }
  PF.pay = i; PF.v = saldoDe(p) ? String(+saldoDe(p).toFixed(2)).replace('.', ',') : ''; PF.forma = 'Pix'; PF.data = hoje(); render();
}
function addPay(i) {
  var p = by(db.pedidos, i), v = num(PF.v); if (!p) return;
  if (!(v > 0)) return toast('Informe o valor recebido.');
  if (!PF.data) return toast('Informe a data do pagamento.');
  if (v > saldoDe(p) + 0.004 && !confirm('O valor (' + R(v) + ') é maior que o saldo (' + R(saldoDe(p)) + '). Registrar mesmo assim?')) return;
  var lista = pagList(p).map(function (x) { return x.id === 'legado' ? Object.assign({}, x, { id: id() }) : x; });
  lista.push({ id: id(), v: v, data: PF.data, forma: PF.forma });
  p.pagamentos = lista; p.pg = +lista.reduce(function (a, x) { return a + num(x.v); }, 0).toFixed(2); p.pd = PF.data;
  PF.pay = null; saveLocalDB(); render(); toast('Pagamento registrado.');
}
function delPay(i, pid) {
  var p = by(db.pedidos, i); if (!p || !confirm('Remover este pagamento?')) return;
  p.pagamentos = pagList(p).filter(function (x) { return x.id !== pid; });
  p.pg = +p.pagamentos.reduce(function (a, x) { return a + num(x.v); }, 0).toFixed(2);
  p.pd = p.pagamentos.length ? p.pagamentos[p.pagamentos.length - 1].data : '';
  saveLocalDB(); render();
}
function payPanel(p) {
  if (PF.pay !== p.id) return '';
  var h = '<div class="card" style="background:var(--soft);margin:10px 0 0"><b>Registrar pagamento</b> <span class="mut">saldo atual ' + R(saldoDe(p)) + '</span>' +
    '<div class="cols"><div><label>Valor recebido (R$)</label><input inputmode="decimal" value="' + esc(PF.v) + '" oninput="PF.v=this.value"></div>' +
    '<div><label>Forma</label><select onchange="PF.forma=this.value">' + opts(FORMAS, PF.forma) + '</select></div></div>' +
    '<label>Data</label><input type="date" value="' + esc(PF.data) + '" onchange="PF.data=this.value">' +
    '<p><button class="btn sm" onclick="addPay(\'' + Q(p.id) + '\')">Registrar</button> <button class="btn ghost sm" onclick="PF.pay=null;render()">Fechar</button></p>';
  var l = pagList(p);
  if (l.length) h += '<div style="margin-top:6px"><b>Pagamentos já registrados</b>' + l.map(function (g) {
    return '<div class="kv"><span>' + D(g.data) + ' · ' + esc(g.forma || '') + '</span><span><b>' + R(g.v) + '</b> ' +
      (g.id === 'legado' ? '' : '<button class="btn ghost sm" onclick="delPay(\'' + Q(p.id) + '\',\'' + Q(g.id) + '\')" aria-label="Remover pagamento">×</button>') + '</span></div>';
  }).join('') + '</div>';
  return h + '</div>';
}

function nextOrderStatus(order) {
  var steps = ['recebido', 'confirmado', 'em produção', 'pronto', 'entregue'];
  var current = steps.indexOf(order.st);
  return current >= 0 && current < steps.length - 1 ? steps[current + 1] : null;
}
function orderStatusLabel(status) {
  return ({ recebido: 'Recebido', confirmado: 'Confirmado', 'em produção': 'Em produção', pronto: 'Pronto', entregue: 'Entregue', cancelado: 'Cancelado' })[status] || status;
}
function orderProgressHtml(order) {
  if (order.st === 'cancelado') return '<div class="order-progress is-cancelled"><span class="tag late">Pedido cancelado</span></div>';
  var steps = ['recebido', 'confirmado', 'em produção', 'pronto', 'entregue'];
  var current = Math.max(0, steps.indexOf(order.st));
  return '<div class="order-progress" aria-label="Etapa atual: ' + esc(orderStatusLabel(order.st)) + '"><div class="order-progress-track"><span style="width:' + (current / (steps.length - 1) * 100) + '%"></span></div><div class="order-progress-steps">' + steps.map(function (step, index) { return '<span class="' + (index < current ? 'is-done' : index === current ? 'is-current' : '') + '">' + (index < current ? '✓ ' : '') + esc(orderStatusLabel(step)) + '</span>'; }).join('') + '</div></div>';
}
function pedCard(p) {
  var total = tp(p), paid = pagoDe(p), balance = saldoDe(p), open = p.st !== 'entregue' && p.st !== 'cancelado';
  var late = open && p.ent && diasAte(p.ent) < 0;
  var next = nextOrderStatus(p);
  var nextLabel = next ? ({ confirmado: 'Confirmar pedido', 'em produção': 'Iniciar produção', pronto: 'Marcar como pronto', entregue: 'Marcar como entregue' })[next] : '';
  var h = '<article class="card order-card"><div class="row order-card-heading"><div><b>' + esc(cliNome(p)) + '</b> ' + (p.origem === 'loja_virtual' ? '<span class="tag">Vitrine online</span> ' : '') + (open ? urg(p.ent) : '') + '<div class="mut">Entrega ' + D(p.ent) + (p.hora ? ' às ' + esc(p.hora) : '') + '</div></div><span class="tag ' + (p.st === 'cancelado' ? 'late' : p.st === 'entregue' ? 'ok' : '') + '">' + esc(orderStatusLabel(p.st)) + '</span></div>' +
    orderProgressHtml(p) + '<div class="mut order-items">' + resumoItens(p) + '</div>' + (p.obs ? '<div class="mut">Observações: ' + esc(p.obs) + '</div>' : '') +
    '<div class="order-money-row"><span>Total <b>' + R(total) + '</b></span><span>Pago <b>' + R(paid) + '</b></span><span>Saldo <b class="' + (balance > 0.004 ? 'neg' : 'pos') + '">' + R(balance) + '</b></span></div>' +
    '<div class="order-actions">' + (next ? '<button class="btn order-primary-action" type="button" onclick="upO(\'' + Q(p.id) + '\',\'' + next + '\')">' + nextLabel + '</button>' : '') +
    (ativo(p) ? '<button class="btn ghost" type="button" onclick="openPay(\'' + Q(p.id) + '\')">' + (balance > 0.004 ? 'Registrar pagamento' : 'Ver pagamentos') + '</button>' : '') +
    (balance > 0.004 && ativo(p) ? '<button class="btn ghost" type="button" onclick="msg(\'' + Q(p.id) + '\',\'cob\')">Cobrar no WhatsApp</button>' : '') +
    (open ? '<button class="btn ghost" type="button" onclick="msg(\'' + Q(p.id) + '\',\'lem\')">Lembrar no WhatsApp</button>' : '') +
    '</div><details class="order-more-actions"><summary>Mais ações</summary><div><button class="btn ghost sm" type="button" onclick="editO(\'' + Q(p.id) + '\')">Editar pedido</button>' +
    (open ? '<button class="btn danger-quiet sm" type="button" onclick="upO(\'' + Q(p.id) + '\',\'cancelado\')">Cancelar pedido</button>' : '') +
    '<button class="btn danger-quiet sm" type="button" onclick="delO(\'' + Q(p.id) + '\')">Excluir pedido</button></div></details>' + payPanel(p) + '</article>';
  return h;
}

function pedFiltrados() {
  var q = PF.q.trim().toLowerCase();
  var l = db.pedidos.filter(function (p) {
    if (q && cliNome(p).toLowerCase().indexOf(q) < 0) return false;
    if (PF.origem === 'vitrine' && p.origem !== 'loja_virtual') return false;
    if (PF.st === 'abertos') return p.st !== 'entregue' && p.st !== 'cancelado';
    if (PF.st === 'saldo') return ativo(p) && saldoDe(p) > 0.004;
    if (PF.st === 'todos') return true;
    return p.st === PF.st;
  });
  var asc = PF.st === 'abertos' || PF.st === 'saldo';
  return l.sort(function (a, b) { var r = (a.ent || '9').localeCompare(b.ent || '9') || (a.hora || '').localeCompare(b.hora || ''); return asc ? r : -r; });
}
function pedLista() {
  var l = pedFiltrados();
  return l.length ? l.map(pedCard).join('') : '<div class="card mut">' + (PF.origem === 'vitrine' ? 'Nenhum pedido em aberto recebido pela vitrine online.' : db.pedidos.length ? 'Nenhum pedido neste filtro.' : 'Nenhum pedido ainda. Clique em “Novo pedido” para registrar a primeira encomenda.') + '</div>';
}
function pedFiltro() {   // atualiza só a lista (não perde o foco da busca)
  var e = document.getElementById('ped-list'); if (e) e.innerHTML = pedLista();
}
function setPedSection(section) { PED_SECTION = section === 'orcamentos' ? 'orcamentos' : 'pedidos'; render(); }
function pedSectionNav() {
  return '<div class="module-tabs" aria-label="Seções de pedidos"><button type="button" class="' + (PED_SECTION === 'pedidos' ? 'is-active' : '') + '" aria-current="' + (PED_SECTION === 'pedidos' ? 'page' : 'false') + '" onclick="setPedSection(&quot;pedidos&quot;)">Encomendas</button><button type="button" class="' + (PED_SECTION === 'orcamentos' ? 'is-active' : '') + '" aria-current="' + (PED_SECTION === 'orcamentos' ? 'page' : 'false') + '" onclick="setPedSection(&quot;orcamentos&quot;)">Orçamentos</button></div>';
}
function vPed() {
  var h = '<h2>Pedidos</h2>' + pedSectionNav();
  if (PED_SECTION === 'orcamentos') return h + (window.KSWResourceViews ? window.KSWResourceViews.quotes() : '<div class="card mut">Orçamentos indisponíveis.</div>');
  if (O) return h + pedForm();
  var f = [['abertos', 'Em aberto'], ['saldo', 'Com saldo a receber'], ['todos', 'Todos']].concat(ST.map(function (s) { return [s, s.charAt(0).toUpperCase() + s.slice(1)]; }));
  return h + '<div class="card order-toolbar"><div class="order-toolbar-controls"><button class="btn order-new-button" type="button" onclick="newO()">Novo pedido</button>' +
    '<div class="order-filter-field"><label style="margin-top:0" for="ped-origin">Origem</label><select id="ped-origin" onchange="PF.origem=this.value;pedFiltro()"><option value="todos"' + (PF.origem === 'todos' ? ' selected' : '') + '>Todos os canais</option><option value="vitrine"' + (PF.origem === 'vitrine' ? ' selected' : '') + '>Vitrine online</option></select></div>' +
    '<div class="order-filter-field"><label style="margin-top:0">Mostrar</label><select onchange="PF.st=this.value;pedFiltro()">' +
    f.map(function (x) { return '<option value="' + x[0] + '"' + (PF.st === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div>' +
    '<div class="order-filter-field"><label style="margin-top:0">Buscar cliente</label><input value="' + esc(PF.q) + '" oninput="PF.q=this.value;pedFiltro()" placeholder="Nome…"></div></div></div>' +
    '<div id="ped-list">' + pedLista() + '</div>';
}

/* ------------------------------------------------------------------ AGENDA */
function agMes(delta) { AG.m = addMeses((AG.m || mesAtual()) + '-01', delta).slice(0, 7); AG.d = null; render(); }
function agDia(d) { AG.d = d; render(); }
function agHoje() { AG.m = mesAtual(); AG.d = hoje(); render(); }
function saveCap(campo, v) {
  var c = by(db.config, 'main');
  if (!c) { c = { id: 'main', cap_pedidos: 0, cap_unid: 0 }; db.config.push(c); }
  c[campo] = Math.max(0, Math.floor(num(v)));
  saveLocalDB(); render(); toast('Capacidade atualizada.');
}
function vAgenda() {
  var m = AG.m || mesAtual(); AG.m = m;
  var sel = AG.d && AG.d.slice(0, 7) === m ? AG.d : (mesAtual() === m ? hoje() : m + '-01');
  var y = +m.slice(0, 4), mo = +m.slice(5, 7) - 1, off = new Date(y, mo, 1).getDay(), nd = new Date(y, mo + 1, 0).getDate();
  var porDia = {}, venc = {};
  db.pedidos.forEach(function (p) { if (ativo(p) && p.ent && p.ent.slice(0, 7) === m) (porDia[p.ent] = porDia[p.ent] || []).push(p); });
  db.despesas.forEach(function (x) { if (!x.pago && x.venc && x.venc.slice(0, 7) === m) venc[x.venc] = (venc[x.venc] || 0) + 1; });

  var h = '<h2>Agenda</h2><div class="card"><div class="row" style="margin-bottom:12px"><b style="font-size:17px">' + nomeMes(m) + '</b>' +
    '<span><button class="btn ghost sm" onclick="agMes(-1)" aria-label="Mês anterior">‹</button> <button class="btn ghost sm" onclick="agHoje()">Hoje</button> <button class="btn ghost sm" onclick="agMes(1)" aria-label="Próximo mês">›</button></span></div>' +
    '<div class="cal-h">' + ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map(function (x) { return '<span>' + x + '</span>'; }).join('') + '</div><div class="cal">';
  for (var i = 0; i < off; i++) h += '<span class="cal-d out"></span>';
  for (var d = 1; d <= nd; d++) {
    var iso = m + '-' + (d < 10 ? '0' : '') + d, ps = porDia[iso] || [], lot = diaLotado(iso), un = ps.reduce(function (a, p) { return a + unidades(p); }, 0);
    h += '<button type="button" class="cal-d' + (iso === hoje() ? ' today' : '') + (iso === sel ? ' sel' : '') + '" onclick="agDia(\'' + iso + '\')" aria-label="' + nomeDia(iso) + ': ' + ps.length + ' pedido(s)"' + (iso === sel ? ' aria-current="date"' : '') + '>' +
      '<span class="cal-n">' + d + '</span>' + (ps.length ? '<span class="tag' + (lot.over ? ' late' : '') + '">' + ps.length + '</span><span class="cal-u">' + un + ' un.</span>' : '') +
      (venc[iso] ? '<i class="cal-dot" title="Conta a pagar vence neste dia"></i>' : '') + '</button>';
  }
  h += '</div><div class="mut" style="margin-top:10px">O número em cada dia é a quantidade de pedidos; vermelho indica que a capacidade foi ultrapassada. O ponto marca conta a pagar vencendo.</div></div>';

  // dia selecionado
  var ps = (porDia[sel] || []).slice().sort(function (a, b) { return (a.hora || '99').localeCompare(b.hora || '99'); }), lot = diaLotado(sel), c = cfg();
  h += '<div class="card"><div class="row"><div><b>' + nomeDia(sel) + '</b><div class="mut">' + lot.n + ' pedido(s) · ' + lot.u + ' unidade(s)' +
    (c.cap_pedidos > 0 ? ' · limite ' + c.cap_pedidos + ' pedido(s)' : '') + (c.cap_unid > 0 ? ' · limite ' + c.cap_unid + ' un.' : '') + '</div></div>' +
    '<button class="btn sm" onclick="newO(\'' + sel + '\')">Novo pedido neste dia</button></div>' + (lot.over ? '<div style="margin-top:8px"><span class="tag late">Capacidade do dia ultrapassada</span></div>' : '');
  h += ps.length ? ps.map(function (p) {
    var sd = saldoDe(p);
    return '<div class="kv" style="align-items:flex-start"><span><b>' + (p.hora ? esc(p.hora) + ' · ' : '') + esc(cliNome(p)) + '</b><br><span class="mut">' + resumoItens(p) + (p.obs ? ' · ' + esc(p.obs) : '') + '</span></span>' +
      '<span style="text-align:right"><span class="tag">' + p.st + '</span><br>' + (sd > 0.004 ? '<span class="mut">saldo ' + R(sd) + '</span><br>' : '') +
      '<button class="btn ghost sm" style="margin-top:6px" onclick="editO(\'' + Q(p.id) + '\')">Abrir</button></span></div>';
  }).join('') : '<div class="mut" style="margin-top:10px">Nenhum pedido para este dia.</div>';
  var cp = db.despesas.filter(function (x) { return !x.pago && x.venc === sel; });
  if (cp.length) h += '<div style="margin-top:10px"><b>Contas a pagar neste dia</b>' + cp.map(function (x) { return kvl(esc(x.desc || 'Despesa'), R(x.v)); }).join('') + '</div>';
  h += '</div>';

  h += '<div class="card"><b>Capacidade diária de produção</b><div class="mut">A trava avisa quando um novo pedido ultrapassa o que você consegue produzir em um dia. Use 0 para não limitar.</div>' +
    '<div class="cols"><div><label>Máximo de pedidos por dia</label><input inputmode="numeric" value="' + (c.cap_pedidos || 0) + '" onchange="saveCap(\'cap_pedidos\',this.value)"></div>' +
    '<div><label>Máximo de unidades por dia</label><input inputmode="numeric" value="' + (c.cap_unid || 0) + '" onchange="saveCap(\'cap_unid\',this.value)"></div></div></div>';
  return h;
}

/* ------------------------------------------------------------------ FINANCEIRO */
function movimentos() {
  var l = [];
  db.pedidos.forEach(function (p) { pagList(p).forEach(function (g) { if (g.data) l.push({ d: g.data, v: num(g.v), txt: 'Pagamento · ' + cliNome(p), sub: g.forma || '' }); }); });
  db.despesas.forEach(function (x) { if (x.pago) { var d = x.dpg || x.venc; if (d) l.push({ d: d, v: -num(x.v), txt: x.desc || 'Despesa', sub: x.cat || '' }); } });
  return l.sort(function (a, b) { return a.d.localeCompare(b.d); });
}
function finMes() { FN.m = FN.m || (typeof REPORT_MONTH !== 'undefined' && REPORT_MONTH) || mesAtual(); if (typeof REPORT_MONTH !== 'undefined') REPORT_MONTH = FN.m; return FN.m; }
function finSeg(s) { FN.seg = s; FN.draft = null; FN.sup = null; PF.pay = null; render(); }
function irFin(s) { FN.seg = s; FN.draft = null; FN.sup = null; PF.pay = null; go('financeiro'); }
function financeMonthNav() {
  var month = finMes();
  var label = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)) - 1, 1)
    .toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return '<div class="finance-month-nav" aria-label="Selecionar mês">' +
    '<button type="button" class="btn ghost sm" aria-label="Mês anterior" onclick="stepFinanceMonth(-1)">‹</button>' +
    '<strong>' + label + '</strong>' +
    '<button type="button" class="btn ghost sm" aria-label="Próximo mês" onclick="stepFinanceMonth(1)">›</button>' +
    '<label class="finance-month-input-label" for="finance-month-input">Escolher mês</label><input id="finance-month-input" type="month" value="' + month + '" onchange="setFinanceMonth(this.value)">' +
    '</div>';
}
function setFinanceMonth(value) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(String(value || ''))) return toast('Selecione um mês válido.');
  FN.m = value;
  if (typeof REPORT_MONTH !== 'undefined') REPORT_MONTH = value;
  render();
}
function stepFinanceMonth(delta) {
  var month = finMes();
  FN.m = KSWAnalytics.shiftMonth(month, delta);
  if (typeof REPORT_MONTH !== 'undefined') REPORT_MONTH = FN.m;
  render();
}
function vFin() {
  var segs = [['resumo', 'Resumo'], ['receber', 'A receber'], ['pagar', 'A pagar'], ['fixos', 'Custos fixos'], ['caixa', 'Fluxo de caixa'], ['resultados', 'Resultados'], ['forn', 'Fornecedores']];
  if (FN.seg === 'resultados') return '<h2>Financeiro</h2>' +
    '<div class="module-tabs" aria-label="Seções do financeiro">' + segs.map(function (segment) {
      return '<button type="button" class="' + (FN.seg === segment[0] ? 'is-active' : '') + '" aria-current="' + (FN.seg === segment[0] ? 'page' : 'false') + '" onclick="finSeg(\'' + segment[0] + '\')">' + segment[1] + '</button>';
    }).join('') + '</div>' + (typeof vRes === 'function' ? vRes() : '<div class="card">Resultados indisponíveis.</div>');
  var h = '<h2>Financeiro</h2>' + financeMonthNav() + '<div class="module-tabs" aria-label="Seções do financeiro">' + segs.map(function (segment) {
    return '<button type="button" class="' + (FN.seg === segment[0] ? 'is-active' : '') + '" aria-current="' + (FN.seg === segment[0] ? 'page' : 'false') + '" onclick="finSeg(\'' + segment[0] + '\')">' + segment[1] + '</button>';
  }).join('') + '</div>';
  return h + ({ resumo: finResumo, receber: finReceber, pagar: finPagar, fixos: finFixos, caixa: finCaixa, forn: finForn }[FN.seg] || finResumo)();
}
function finResumo() {
  var m = finMes();
  var summary = KSWAnalytics.summarize(db, m);
  var overdue = vencidas();
  var deliveredOpen = db.pedidos.filter(function (order) { return order.st === 'entregue' && saldoDe(order) > 0.004; });
  var resultClass = summary.managerial_result >= 0 ? 'pos' : 'neg';
  var h = '<section class="finance-primary-kpis">' +
    '<article class="finance-primary-kpi"><span>Vendas do mês</span><strong>' + R(summary.revenue) + '</strong><small>Por data de entrega, sem pedidos cancelados</small></article>' +
    '<article class="finance-primary-kpi"><span>Dinheiro que entrou</span><strong>' + R(summary.received) + '</strong><small>Pagamentos registrados neste mês</small></article>' +
    '<article class="finance-primary-kpi"><span>Quanto sobrou</span><strong class="' + resultClass + '">' + R(summary.managerial_result) + '</strong><small>Resultado gerencial estimado</small></article>' +
    '<article class="finance-primary-kpi"><span>Valor médio por pedido</span><strong>' + R(summary.average_ticket) + '</strong><small>' + summary.orders_count + ' pedido(s) com entrega no mês</small></article>' +
    '</section>';
  if (summary.managerial_result < 0) {
    h += '<div class="card finance-negative-explainer" role="status"><b>O resultado ficou negativo neste mês.</b><p>O lucro bruto das vendas não cobriu as despesas previstas e as perdas registradas nesta competência. Revise os custos dos produtos e as contas com vencimento neste mês.</p></div>';
  }
  if (overdue.length || deliveredOpen.length) {
    h += '<div class="card"><b>O que precisa de atenção</b>' +
      (overdue.length ? '<div class="kv"><span>' + overdue.length + ' conta(s) vencida(s) · ' + R(soma(overdue, function (item) { return num(item.v); })) + '</span><button class="btn ghost sm" onclick="FN.pf=\'abertas\';finSeg(\'pagar\')">Ver contas</button></div>' : '') +
      (deliveredOpen.length ? '<div class="kv"><span>' + deliveredOpen.length + ' pedido(s) entregue(s) com saldo aberto · ' + R(soma(deliveredOpen, saldoDe)) + '</span><button class="btn ghost sm" onclick="finSeg(\'receber\')">Ver valores</button></div>' : '') + '</div>';
  }
  h += '<section class="card"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Visão da competência</span><h3>' + nomeMes(m) + '</h3></div><button class="btn ghost sm" onclick="finSeg(\'resultados\')">Ver relatório detalhado</button></div>' +
    kvl('Custo dos produtos', R(summary.cost)) + kvl('Lucro bruto', R(summary.gross_profit)) +
    kvl('Despesas previstas por vencimento', R(summary.accrued_expenses)) + kvl('Despesas pagas no mês', R(summary.paid_expenses)) +
    kvl('Resultado de caixa', '<span class="' + (summary.cash_result >= 0 ? 'pos' : 'neg') + '">' + R(summary.cash_result) + '</span>') +
    kvl('Valores a receber em pedidos ativos', R(summary.receivables)) + kvl('Contas a pagar em aberto', R(summary.payables)) +
    '</section>';
  h += '<div class="cols"><section class="card"><b>Despesas por categoria</b>' + (summary.expense_categories.length ? summary.expense_categories.map(function (entry) { return kvl(esc(entry.category), R(entry.value)); }).join('') : '<p class="mut">Não há contas com vencimento nesta competência.</p>') + '</section>' +
    '<section class="card"><b>Resumo do caixa</b>' + kvl('Dinheiro que entrou', R(summary.received)) + kvl('Contas pagas', R(summary.paid_expenses)) + kvl('Saldo de caixa do mês', '<strong class="' + (summary.cash_result >= 0 ? 'pos' : 'neg') + '">' + R(summary.cash_result) + '</strong>') + '<p class="mut">Saldo de caixa considera apenas pagamentos efetivamente registrados, não vendas ainda não recebidas.</p></section></div>';
  if (summary.missing_cost_items) h += '<div class="card ksw-report-warning"><b>Alguns pedidos não têm custo histórico completo</b><p>' + summary.missing_cost_items + ' linha(s) de pedido não possuem custo unitário congelado. O resultado pode estar superestimado. Revise as fichas e os pedidos antigos.</p></div>';
  return h;
}

function finReceber() {
  var l = aReceberLista(), f = FN.rf;
  if (f === 'atrasados') l = l.filter(function (p) { return p.ent && diasAte(p.ent) < 0; });
  if (f === 'proximos') l = l.filter(function (p) { return p.ent && diasAte(p.ent) >= 0; });
  var h = '<div class="card"><div class="row"><div><div class="mut">Total a receber nesta lista</div><div class="big">' + R(soma(l, saldoDe)) + '</div></div>' +
    '<div style="min-width:180px"><label style="margin-top:0">Mostrar</label><select onchange="FN.rf=this.value;render()">' + [['todos', 'Todos'], ['atrasados', 'Entrega já passou'], ['proximos', 'Entregas futuras']].map(function (x) { return '<option value="' + x[0] + '"' + (f === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div></div></div>';
  if (!l.length) return h + '<div class="card mut">Nenhum saldo a receber neste filtro. Quando um pedido tiver valor em aberto, ele aparece aqui.</div>';
  return h + l.map(function (p) {
    var dd = p.ent ? diasAte(p.ent) : null, tg = p.st === 'entregue' ? '<span class="tag late">Entregue sem quitar</span>' : dd !== null && dd < 0 ? '<span class="tag late">Entrega atrasada</span>' : dd === 0 ? '<span class="tag now">Entrega hoje</span>' : '';
    return '<div class="card"><div class="row"><div><b>' + esc(cliNome(p)) + '</b> ' + tg + '<div class="mut">Entrega ' + D(p.ent) + ' · ' + resumoItens(p) + '</div></div><div style="text-align:right"><div class="big" style="font-size:20px">' + R(saldoDe(p)) + '</div><div class="mut">de ' + R(tp(p)) + '</div></div></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start"><button class="btn sm" onclick="openPay(\'' + Q(p.id) + '\')">Registrar pagamento</button><button class="btn ghost sm" onclick="msg(\'' + Q(p.id) + '\',\'cob\')">Cobrar no WhatsApp</button></div>' + payPanel(p) + '</div>';
  }).join('');
}

/* contas a pagar */
function novaConta() { FN.draft = { desc: '', v: '', venc: hoje(), cat: CATS[0], forn: '', rep: 1 }; render(); }
function editConta(i) { var x = by(db.despesas, i); if (!x) return; FN.draft = { id: x.id, desc: x.desc || '', v: String(x.v).replace('.', ','), venc: x.venc || '', cat: x.cat || CATS[0], forn: x.forn || '', rep: 1 }; render(); }
function saveConta() {
  var d = FN.draft, v = num(d.v);
  if (!d.desc.trim()) return toast('Descreva a conta.');
  if (!(v > 0)) return toast('Informe o valor.');
  if (!d.venc) return toast('Informe o vencimento.');
  if (d.id) {
    var x = by(db.despesas, d.id); Object.assign(x, { desc: d.desc.trim(), v: v, venc: d.venc, cat: d.cat, forn: d.forn });
  } else {
    var n = Math.min(24, Math.max(1, Math.floor(num(d.rep)) || 1));
    for (var k = 0; k < n; k++) db.despesas.push({ id: id(), desc: d.desc.trim() + (n > 1 ? ' (' + (k + 1) + '/' + n + ')' : ''), v: v, venc: addMeses(d.venc, k), cat: d.cat, forn: d.forn, pago: false, dpg: '' });
  }
  FN.draft = null; saveLocalDB(); render(); toast('Conta salva.');
}
function pagarConta(i, desfazer) {
  var x = by(db.despesas, i); if (!x) return;
  x.pago = !desfazer; x.dpg = desfazer ? '' : hoje(); saveLocalDB(); render();
}
function delConta(i) { if (!confirm('Excluir esta conta?')) return; db.despesas = db.despesas.filter(function (x) { return x.id !== i; }); saveLocalDB(); render(); }

function finPagar() {
  var dr = FN.draft, f = FN.pf, h = '';
  if (dr) {
    h += '<div class="card"><b>' + (dr.id ? 'Editar conta' : 'Nova conta a pagar') + '</b><label>Descrição</label><input value="' + esc(dr.desc) + '" oninput="FN.draft.desc=this.value" placeholder="Ex.: Conta de luz, Aluguel, Farinha…">' +
      '<div class="cols"><div><label>Valor (R$)</label><input inputmode="decimal" value="' + esc(dr.v) + '" oninput="FN.draft.v=this.value"></div><div><label>Vencimento</label><input type="date" value="' + esc(dr.venc) + '" onchange="FN.draft.venc=this.value"></div>' +
      '<div><label>Categoria</label><select onchange="FN.draft.cat=this.value">' + opts(CATS, dr.cat) + '</select></div>' +
      '<div><label>Fornecedor (opcional)</label><select onchange="FN.draft.forn=this.value"><option value="">—</option>' + db.fornecedores.map(function (s) { return '<option value="' + s.id + '"' + (s.id === dr.forn ? ' selected' : '') + '>' + esc(s.nome) + '</option>'; }).join('') + '</select></div></div>' +
      (dr.id ? '' : '<label>Repetir por quantos meses? (1 = só esta)</label><input inputmode="numeric" value="' + esc(dr.rep) + '" oninput="FN.draft.rep=this.value" style="max-width:140px">') +
      '<p><button class="btn" onclick="saveConta()">Salvar conta</button> <button class="btn ghost" onclick="FN.draft=null;render()">Cancelar</button></p></div>';
  }
  var todas = db.despesas, ab = todas.filter(function (x) { return !x.pago; }), vc = vencidas();
  h += '<div class="grid">' + kpi('Em aberto', R(soma(ab, function (x) { return num(x.v); })), ab.length + ' conta(s)') + kpi('Vencidas', '<span class="neg">' + R(soma(vc, function (x) { return num(x.v); })) + '</span>', vc.length + ' conta(s)') + '</div>';
  h += '<div class="row" style="margin-bottom:12px">' + (dr ? '<span></span>' : '<button class="btn" onclick="novaConta()">Nova conta a pagar</button>') +
    '<div style="min-width:170px"><select aria-label="Filtro de contas" onchange="FN.pf=this.value;render()">' + [['abertas', 'Em aberto'], ['pagas', 'Pagas'], ['todas', 'Todas']].map(function (x) { return '<option value="' + x[0] + '"' + (f === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div></div>';
  var l = todas.filter(function (x) { return f === 'todas' || (f === 'pagas' ? x.pago : !x.pago); }).sort(function (a, b) { var r = (a.venc || '').localeCompare(b.venc || ''); return f === 'pagas' ? -r : r; });
  if (!l.length) return h + '<div class="card mut">' + (todas.length ? 'Nenhuma conta neste filtro.' : 'Nenhuma conta cadastrada. Lance aluguel, energia, embalagens e compras para ver o fluxo de caixa.') + '</div>';
  return h + l.map(function (x) {
    var dd = x.venc ? diasAte(x.venc) : null, s = by(db.fornecedores, x.forn);
    var tg = x.pago ? '<span class="tag ok">Paga em ' + D(x.dpg || x.venc) + '</span>' : dd !== null && dd < 0 ? '<span class="tag late">Vencida há ' + (-dd) + ' d</span>' : dd === 0 ? '<span class="tag now">Vence hoje</span>' : dd !== null && dd <= 7 ? '<span class="tag">Vence em ' + dd + ' d</span>' : '';
    return '<div class="card"><div class="row"><div><b>' + esc(x.desc || 'Despesa') + '</b> ' + tg + '<div class="mut">Vencimento ' + D(x.venc) + (x.cat ? ' · ' + esc(x.cat) : '') + (s ? ' · ' + esc(s.nome) : '') + '</div></div><div class="big" style="font-size:20px">' + R(x.v) + '</div></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start">' + (x.pago ? '<button class="btn ghost sm" onclick="pagarConta(\'' + Q(x.id) + '\',true)">Desfazer pagamento</button>' : '<button class="btn sm" onclick="pagarConta(\'' + Q(x.id) + '\')">Marcar como paga</button>') +
      '<button class="btn ghost sm" onclick="editConta(\'' + Q(x.id) + '\')">Editar</button><button class="btn ghost sm" onclick="delConta(\'' + Q(x.id) + '\')">Excluir</button></div></div>';
  }).join('');
}

/* fluxo de caixa */
function finCaixa() {
  var m = finMes(), mv = movimentos(), ini = 0, ent = 0, sai = 0, doMes = [];
  mv.forEach(function (x) { if (x.d.slice(0, 7) < m) ini += x.v; else if (x.d.slice(0, 7) === m) { doMes.push(x); if (x.v > 0) ent += x.v; else sai -= x.v; } });
  var h = financeMonthNav() + '<div class="grid">' + kpi('Saldo anterior', R(ini)) + kpi('Entradas', '<span class="pos">' + R(ent) + '</span>') + kpi('Saídas', '<span class="neg">' + R(sai) + '</span>') + kpi('Saldo final', R(ini + ent - sai)) + '</div>';
  var acc = ini;
  h += '<div class="card"><b>Movimentações de ' + nomeMes(m).toLowerCase() + '</b>' + (doMes.length ? doMes.map(function (x) {
    acc += x.v;
    return '<div class="kv" style="align-items:flex-start"><span>' + D(x.d).slice(0, 5) + ' · ' + esc(x.txt) + (x.sub ? '<br><span class="mut">' + esc(x.sub) + '</span>' : '') + '</span><span style="text-align:right"><b class="' + (x.v >= 0 ? 'pos' : 'neg') + '">' + (x.v >= 0 ? '+' : '−') + R(Math.abs(x.v)) + '</b><br><span class="mut">saldo ' + R(acc) + '</span></span></div>';
  }).join('') : '<div class="mut" style="margin-top:6px">Nenhuma movimentação neste mês. Pagamentos de pedidos e contas pagas aparecem aqui.</div>') + '</div>';

  // previsão: próximos 30 dias
  var t0 = hoje(), faixas = [['Em atraso', null, t0], ['Próximos 7 dias', t0, addDias(t0, 7)], ['Dias 8 a 14', addDias(t0, 7), addDias(t0, 14)], ['Dias 15 a 21', addDias(t0, 14), addDias(t0, 21)], ['Dias 22 a 30', addDias(t0, 21), addDias(t0, 30)]];
  var ar = aReceberLista(), ap = db.despesas.filter(function (x) { return !x.pago && x.venc; });
  var base = KSWAnalytics.cashBalanceAsOf(mv, t0);
  var cum = base;
  var linhas = faixas.map(function (f) {
    var dentro = function (d) { if (!d) d = t0; return f[1] === null ? d < f[2] : (d >= f[1] && d < f[2]); };
    var r = soma(ar.filter(function (p) { return dentro(p.ent); }), saldoDe), pg = soma(ap.filter(function (x) { return dentro(x.venc); }), function (x) { return num(x.v); });
    cum += r - pg;
    return '<div class="kv"><span>' + f[0] + '</span><span style="text-align:right"><span class="pos">+' + R(r) + '</span> · <span class="neg">−' + R(pg) + '</span> · <b>' + R(cum) + '</b></span></div>';
  }).join('');
  return h + '<div class="card"><b>Previsão dos próximos 30 dias</b><div class="mut">Saldo atual em caixa: <b>' + R(base) + '</b>. Saldos a receber (por data de entrega) menos contas a pagar (por vencimento); o último valor de cada linha é o saldo projetado.</div>' + linhas + '</div>';
}

/* fornecedores */
function novoForn() { FN.sup = { nome: '', tel: '', obs: '' }; render(); }
function editForn(i) { var s = by(db.fornecedores, i); if (s) { FN.sup = { id: s.id, nome: s.nome, tel: s.tel || '', obs: s.obs || '' }; render(); } }
function saveForn() {
  var s = FN.sup; if (!s.nome.trim()) return toast('Informe o nome do fornecedor.');
  if (s.id) Object.assign(by(db.fornecedores, s.id), { nome: s.nome.trim(), tel: s.tel.trim(), obs: s.obs.trim() });
  else db.fornecedores.push({ id: id(), nome: s.nome.trim(), tel: s.tel.trim(), obs: s.obs.trim() });
  FN.sup = null; saveLocalDB(); render(); toast('Fornecedor salvo.');
}
function delForn(i) {
  if (!confirm('Excluir este fornecedor? As contas já lançadas continuam, mas ficam sem fornecedor.')) return;
  db.fornecedores = db.fornecedores.filter(function (x) { return x.id !== i; });
  db.despesas.forEach(function (x) { if (x.forn === i) x.forn = ''; });
  saveLocalDB(); render();
}
function finForn() {
  var s = FN.sup, h = '';
  if (s) h += '<div class="card"><b>' + (s.id ? 'Editar fornecedor' : 'Novo fornecedor') + '</b><div class="cols"><div><label>Nome</label><input value="' + esc(s.nome) + '" oninput="FN.sup.nome=this.value"></div><div><label>WhatsApp (com DDD)</label><input inputmode="tel" value="' + esc(s.tel) + '" oninput="FN.sup.tel=this.value"></div></div><label>Observações</label><input value="' + esc(s.obs) + '" oninput="FN.sup.obs=this.value" placeholder="Prazo, condições, produtos…"><p><button class="btn" onclick="saveForn()">Salvar fornecedor</button> <button class="btn ghost" onclick="FN.sup=null;render()">Cancelar</button></p></div>';
  else h += '<p><button class="btn" onclick="novoForn()">Novo fornecedor</button></p>';
  if (!db.fornecedores.length) return h + (s ? '' : '<div class="card mut">Cadastre onde você compra seus insumos para ligar cada conta a pagar ao fornecedor e ver quanto gasta com cada um.</div>');
  return h + db.fornecedores.map(function (f) {
    var cs = db.despesas.filter(function (x) { return x.forn === f.id; }), ab = soma(cs.filter(function (x) { return !x.pago; }), function (x) { return num(x.v); }), pg = soma(cs.filter(function (x) { return x.pago; }), function (x) { return num(x.v); });
    return '<div class="card"><div class="row"><div><b>' + esc(f.nome) + '</b><div class="mut">' + (f.tel ? esc(f.tel) : 'sem telefone') + (f.obs ? ' · ' + esc(f.obs) : '') + '</div></div><div style="text-align:right"><div class="mut">Em aberto <b>' + R(ab) + '</b></div><div class="mut">Já pago <b>' + R(pg) + '</b></div></div></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start">' + (f.tel ? '<a class="btn sm" target="_blank" rel="noopener" href="' + waLink(f.tel) + '">WhatsApp</a>' : '') + '<button class="btn ghost sm" onclick="editForn(\'' + Q(f.id) + '\')">Editar</button><button class="btn ghost sm" onclick="delForn(\'' + Q(f.id) + '\')">Excluir</button></div></div>';
  }).join('');
}

/* ------------------------------------------------------------------ PAINEL (início) */
function dashboardQuickAction(icon, title, detail, action, badge) {
  return '<button class="ksw-quick-action" type="button" onclick="' + action + '">' +
    '<span class="ksw-quick-icon" aria-hidden="true">' + icon + '</span><b>' + title + '</b><small>' + detail + '</small>' +
    (badge ? '<span class="ksw-quick-badge">' + badge + '</span>' : '') + '</button>';
}
function dashboardOpenOnlineOrders() {
  PF.origem = 'vitrine';
  PF.st = 'abertos';
  PF.q = '';
  go('pedidos');
}
function dashboardTrendChart(series, mode) {
  var comparison = mode === 'comparison', max = 0;
  series.forEach(function (item) {
    max = Math.max(max, num(item.cost), comparison ? num(item.revenue) : 0);
  });
  if (!max) return '<div class="report-empty-state"><b>Sem custos registrados neste período</b><p>Preencha o custo das fichas e dos pedidos para acompanhar esta evolução.</p></div>';
  var legend = comparison
    ? '<div class="ksw-report-chart-legend"><span><i class="revenue"></i>Vendas</span><span><i class="cost"></i>Custos registrados</span></div>'
    : '<div class="ksw-report-chart-legend"><span><i class="cost"></i>Custos diretos + taxas registradas</span></div>';
  return legend + series.map(function (item) {
    var month = new Date(item.month + '-01T00:00:00').toLocaleDateString('pt-BR', { month: 'short' }).replace(/\./g, '');
    var revenueWidth = Math.min(100, Math.max(0, num(item.revenue) / max * 100));
    var costWidth = Math.min(100, Math.max(0, num(item.cost) / max * 100));
    var bars = comparison
      ? '<span class="revenue" title="Vendas: ' + R(item.revenue) + '" style="width:' + revenueWidth + '%"></span><span class="cost" title="Custos: ' + R(item.cost) + '" style="width:' + costWidth + '%"></span>'
      : '<span class="cost" title="Custos diretos + taxas registradas: ' + R(item.cost) + '" style="width:' + costWidth + '%"></span>';
    var values = comparison
      ? '<span>Vendas: <b>' + R(item.revenue) + '</b></span><span>Custos diretos + taxas registradas: <b>' + R(item.cost) + '</b></span><span>Contribuição estimada: <b>' + R(item.revenue - item.cost) + '</b></span>'
      : '<span>Custos diretos + taxas registradas: <b>' + R(item.cost) + '</b></span>';
    return '<div class="ksw-report-trend-row"><span class="ksw-report-month">' + esc(month) + '</span><div class="ksw-report-bars" role="img" aria-label="' + (comparison ? 'Vendas ' + R(item.revenue) + ', custos ' + R(item.cost) : 'Custos diretos e taxas registradas ' + R(item.cost)) + '">' + bars + '</div><b>' + R(comparison ? item.revenue : item.cost) + '</b></div><div class="ksw-report-trend-values">' + values + '</div>';
  }).join('');
}
function vEnt() {
  var m = mesAtual(), summary = KSWAnalytics.summarize(db, m), series = KSWAnalytics.monthlySeries(db, m, 6), fat = summary.revenue, luc = summary.gross_profit, op = [];
  db.pedidos.forEach(function (p) {
    if (!ativo(p)) return;
    if (p.st !== 'entregue' && p.st !== 'cancelado') op.push(p);
  });
  op.sort(function (a, b) { return (a.ent || '9').localeCompare(b.ent || '9') || (a.hora || '').localeCompare(b.hora || ''); });
  var online = op.filter(function (p) { return p.origem === 'loja_virtual'; });
  var ar = aReceberLista(), rec = summary.received, sai = summary.paid_expenses;
  var tops = summary.products.slice().sort(function (a, b) { return b.quantity - a.quantity; }).slice(0, 4);
  var stockItems = (db.ingredientes || []).map(function (item) { return { item: item, type: 'ingrediente' }; })
    .concat((db.embalagens || []).map(function (item) { return { item: item, type: 'embalagem' }; }));
  var lowItems = stockItems.filter(function (entry) {
    var minimum = KSWCosting.parseNumber(entry.item.min || 0);
    return minimum > 0 && KSWCosting.parseNumber(entry.item.est != null ? entry.item.est : entry.item.estoque || 0) <= minimum;
  });
  var inventoryValue = 0, unpricedStockItems = 0;
  stockItems.forEach(function (entry) {
    var stock = KSWCosting.parseNumber(entry.item.est != null ? entry.item.est : entry.item.estoque || 0);
    var rawPrice = entry.item.preco;
    var price = KSWCosting.parseNumber(rawPrice);
    if (stock > 0 && (rawPrice == null || rawPrice === '' || !Number.isFinite(price) || price < 0)) {
      unpricedStockItems += 1;
      return;
    }
    if (Number.isFinite(stock) && stock > 0 && Number.isFinite(price) && price >= 0) inventoryValue += stock * price;
  });
  var low = lowItems.length;
  var vc = vencidas(), prox = db.despesas.filter(function (x) { return !x.pago && x.venc && diasAte(x.venc) >= 0 && diasAte(x.venc) <= 7; });
  var atras = op.filter(function (p) { return p.ent && diasAte(p.ent) < 0; }), semQ = db.pedidos.filter(function (p) { return p.st === 'entregue' && saldoDe(p) > 0.004; });
  var lot = diaLotado(hoje()), today = db.pedidos.filter(function (p) { return p.ent === hoje() && ativo(p); }).length;
  var now = new Date(), greeting = now.getHours() < 12 ? 'Bom dia' : now.getHours() < 18 ? 'Boa tarde' : 'Boa noite';
  var owner = currentUser && currentUser.nome ? currentUser.nome.split(' ')[0] : 'confeiteira';
  var h = '<section class="ksw-dashboard-welcome"><div><span class="ksw-eyebrow">Visão geral da sua confeitaria</span><h2>'+greeting+', '+esc(owner)+'!</h2><p>Aqui está o resumo da sua confeitaria para hoje.</p><small>'+new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'</small></div><div class="ksw-dashboard-actions"><button class="btn" type="button" onclick="newO(hoje())">＋ Nova encomenda</button><button class="btn ghost" type="button" onclick="go(\'agenda\')">Ver agenda</button></div></section>';
  h += '<section class="ksw-dashboard-quick"><div class="ksw-dashboard-section-title"><div><span class="ksw-eyebrow">Comece por aqui</span><h2>Ações rápidas do ateliê</h2></div></div><div class="ksw-quick-grid">' +
    dashboardQuickAction('▣', 'Pedidos da vitrine', online.length ? online.length + ' em andamento' : 'Acompanhe novas encomendas', 'dashboardOpenOnlineOrders()', online.length || '') +
    dashboardQuickAction('＋', 'Nova encomenda', 'Registrar pedido e entrega', 'newO()', '') +
    dashboardQuickAction('◷', 'Lotes de produção', 'Planejar e acompanhar', 'go(&quot;producao&quot;)', '') +
    dashboardQuickAction('◎', 'Cadastrar cliente', 'Guardar contato e preferências', 'go(&quot;clientes&quot;)', '') +
    dashboardQuickAction('◈', 'Fichas e receitas', 'Revisar custos e preços', 'go(&quot;produtos&quot;)', '') +
    dashboardQuickAction('▥', 'Lista de compras', low ? low + ' item(ns) no mínimo' : 'Estoque dentro dos mínimos', 'go(&quot;ingredientes&quot;)', '') +
    '</div></section>';
  h += '<div class="ksw-dashboard-section-title"><div><span class="ksw-eyebrow">Resumo do negócio</span><h2>Estoque e receitas</h2></div></div><section class="ksw-business-overview">' +
    '<article class="ksw-business-stat"><span>Receitas cadastradas</span><strong>' + db.produtos.length + '</strong><small>Fichas de produtos no catálogo</small></article>' +
    '<article class="ksw-business-stat"><span>Insumos e embalagens</span><strong>' + stockItems.length + '</strong><small>Itens cadastrados no estoque</small></article>' +
    '<article class="ksw-business-stat"><span>Valor estimado em estoque</span><strong>' + R(inventoryValue) + '</strong><small>' + (unpricedStockItems ? 'Não inclui ' + unpricedStockItems + ' item(ns) com saldo sem custo cadastrado.' : 'Estimativa pelo saldo e custo unitário cadastrados.') + '</small></article>' +
    '<button class="ksw-business-stat ksw-business-alert" type="button" onclick="go(&quot;ingredientes&quot;)"><span>Estoque crítico</span><strong>' + low + '</strong><small>Item(ns) no mínimo configurado · ver estoque</small></button></section>';
  h += '<div class="ksw-dashboard-section-title"><div><span class="ksw-eyebrow">Resumo do negócio</span><h2>Seu mês em números</h2></div><span class="ksw-month-label">'+esc(nomeMes(m))+'</span></div>';
  h += '<section class="ksw-kpi-grid">'+
    '<article class="ksw-kpi"><span class="ksw-kpi-label">Vendas do mês</span><strong>'+R(fat)+'</strong><small>Pedidos com entrega neste mês</small><span class="ksw-kpi-symbol">↗</span></article>'+
    '<article class="ksw-kpi"><span class="ksw-kpi-label">Sobra após custos cadastrados</span><strong>'+R(luc)+'</strong><small>Após custos diretos e taxas confirmadas; antes das despesas fixas e taxas ainda não informadas</small><span class="ksw-kpi-symbol">✦</span></article>'+
    '<article class="ksw-kpi"><span class="ksw-kpi-label">Pedidos em aberto</span><strong>'+op.length+'</strong><small>'+today+' com entrega hoje</small><span class="ksw-kpi-symbol">▤</span></article>'+
    '<article class="ksw-kpi"><span class="ksw-kpi-label">A receber</span><strong>'+R(soma(ar, saldoDe))+'</strong><small>'+ar.length+' pedido(s) com saldo</small><span class="ksw-kpi-symbol">R$</span></article>'+
    '</section>';
  var av = [];
  var dashboardFixedAllocation = getFixedCostAllocation();
  var productsAtLoss = (db.produtos || []).map(function (product) {
    var calculation = costCalculation(product);
    if (!calculation.valid) return null;
    var feeKnown = KSWCosting.hasKnownVariableFee(product);
    var analysis = KSWCosting.assessProfitability(calculation.unitCost, product.preco, {
      quantity: calculation.yield, targetMargin: product.margem == null ? 0 : product.margem,
      variableFeePercent: feeKnown ? product.taxa_venda_pct : 0, variableFeeKnown: feeKnown,
      fixedCostPerUnit: dashboardFixedAllocation.valid ? dashboardFixedAllocation.costPerUnit : 0,
      fixedCostKnown: dashboardFixedAllocation.valid
    });
    return analysis.valid && analysis.status === 'loss' ? { product: product, analysis: analysis } : null;
  }).filter(Boolean);
  var pendingLossOrders = db.pedidos.filter(function (order) { return order && order.st !== 'cancelado' && order.st !== 'entregue'; });
  var pendingLossSummary = pendingLossOrders.reduce(function (summary, order) {
    var estimate = estimateOrderProfitability(order.itens, false);
    if (estimate.loss > 0) { summary.loss += estimate.loss; summary.orders += 1; }
    summary.missingFeeItems += estimate.missingFeeItems;
    return summary;
  }, { loss: 0, orders: 0, missingFeeItems: 0 });
  var deliveredLossSummary = db.pedidos.filter(function (order) { return order && order.st === 'entregue' && String(order.ent || '').slice(0, 7) === m; }).reduce(function (summary, order) {
    var estimate = estimateOrderProfitability(order.itens, false);
    if (estimate.loss > 0) { summary.loss += estimate.loss; summary.orders += 1; }
    summary.missingFeeItems += estimate.missingFeeItems;
    return summary;
  }, { loss: 0, orders: 0, missingFeeItems: 0 });
  var productsWithUnknownFees = (db.produtos || []).filter(function (product) { return !KSWCosting.hasKnownVariableFee(product); });
  if (!dashboardFixedAllocation.valid && ((db.produtos || []).length || (db.pedidos || []).length)) {
    av.push(['<span class="tag">Complete Financeiro &gt; Custos fixos para o KSW considerar aluguel, internet e outros custos fixos nos alertas de margem</span>', "FN.seg='fixos';go('financeiro')"]);
  }
  if (productsAtLoss.length) av.push(['<span class="tag late">'+productsAtLoss.length+' produto(s) com perda mínima: '+productsAtLoss.slice(0,3).map(function (entry) { return esc(entry.product.nome)+': '+R(entry.analysis.lossPerUnit)+'/un. · '+R(entry.analysis.estimatedLoss)+'/lote'; }).join(' · ')+'</span>',"go('produtos')"]);
  if (productsWithUnknownFees.length) av.push(['<span class="tag">'+productsWithUnknownFees.length+' produto(s) sem taxas cadastradas; resultado antes de taxas</span>',"go('produtos')"]);
  if (summary.missing_fee_items) av.push(['<span class="tag">'+summary.missing_fee_items+' linha(s) antiga(s) sem taxa de venda registrada; margem pode estar superestimada</span>',"go('pedidos')"]);
  if (pendingLossSummary.loss > 0) av.push(['<span class="tag late">'+'Perda mínima estimada de '+R(pendingLossSummary.loss)+' em '+pendingLossSummary.orders+' encomenda(s) em aberto</span>',"go('pedidos')"]);
  if (deliveredLossSummary.loss > 0) av.push(['<span class="tag late">'+'Perda mínima estimada de '+R(deliveredLossSummary.loss)+' em encomendas entregues neste mês</span>',"go('resultados')"]);
  if (atras.length) av.push(['<span class="tag late">'+atras.length+' entrega(s) atrasada(s)</span>',"go('pedidos')"]);
  if (semQ.length) av.push(['<span class="tag late">'+semQ.length+' entrega(s) com saldo em aberto · '+R(soma(semQ, saldoDe))+'</span>',"irFin('receber')"]);
  if (vc.length) av.push(['<span class="tag late">'+vc.length+' conta(s) vencida(s) · '+R(soma(vc, function (x) { return num(x.v); }))+'</span>',"FN.pf='abertas';irFin('pagar')"]);
  if (prox.length) av.push(['<span class="tag">'+prox.length+' conta(s) vencem nos próximos 7 dias · '+R(soma(prox, function (x) { return num(x.v); }))+'</span>',"FN.pf='abertas';irFin('pagar')"]);
  if (low) av.push(['<span class="tag late">'+low+' item(ns) com estoque baixo</span>',"go('ingredientes')"]);
  if (lot.over) av.push(['<span class="tag late">Capacidade de hoje ultrapassada</span>',"go('agenda')"]);
  if (av.length) h += '<section class="ksw-alert-panel"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Acompanhe</span><h3>Pontos de atenção</h3></div><span class="ksw-alert-count">'+av.length+'</span></div>'+av.map(function (a) { return '<div class="ksw-alert-row"><span>'+a[0]+'</span><button class="btn ghost sm" onclick="'+a[1]+'">Ver detalhes <span aria-hidden="true">→</span></button></div>'; }).join('')+'</section>';
  h += '<section class="ksw-dashboard-columns"><article class="ksw-dashboard-panel"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Movimentação</span><h3>Resumo financeiro</h3></div><button class="ksw-panel-link" type="button" onclick="go(\'financeiro\')">Abrir financeiro →</button></div>'+
    '<div class="ksw-finance-line"><span>Dinheiro que entrou</span><b class="pos">'+R(rec)+'</b></div><div class="ksw-finance-line"><span>Despesas pagas</span><b>'+R(sai)+'</b></div><div class="ksw-finance-line ksw-finance-total"><span>Saldo de caixa do mês</span><b class="'+(rec-sai>=0?'pos':'neg')+'">'+R(rec-sai)+'</b></div></article>'+
    '<article class="ksw-dashboard-panel"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Destaques</span><h3>Doces e bolos mais vendidos</h3></div><button class="ksw-panel-link" type="button" onclick="go(\'resultados\')">Relatórios →</button></div>'+
    (tops.length?'<div class="ksw-top-products">'+tops.map(function(product,i){return '<div class="ksw-top-product"><span class="ksw-top-rank">0'+(i+1)+'</span><span>'+esc(product.name)+'</span><b>'+num(product.quantity).toLocaleString('pt-BR')+' un.</b></div>';}).join('')+'</div>':'<p class="mut">Ainda não há vendas registradas neste mês.</p>')+'</article></section>';
  h += '<section class="ksw-dashboard-columns ksw-dashboard-charts"><article class="ksw-dashboard-panel"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Últimos seis meses</span><h3>Evolução de custos</h3></div><button class="ksw-panel-link" type="button" onclick="go(\'resultados\')">Relatório detalhado →</button></div>' + dashboardTrendChart(series, 'cost') + '<p class="ksw-report-footnote">Custos diretos e taxas variáveis registradas nas vendas; linhas antigas sem custo ou taxa podem ficar fora do total.</p></article>' +
    '<article class="ksw-dashboard-panel"><div class="ksw-panel-head"><div><span class="ksw-eyebrow">Últimos seis meses</span><h3>Rentabilidade</h3></div><button class="ksw-panel-link" type="button" onclick="go(\'resultados\')">Ver resultados →</button></div>' + dashboardTrendChart(series, 'comparison') + '<p class="ksw-report-footnote">Custos ou taxas ausentes podem superestimar o resultado. Despesas fixas e encargos não estão incluídos.</p></article></section>';
  h += '<section class="ksw-upcoming"><div class="ksw-dashboard-section-title"><div><span class="ksw-eyebrow">Vendas pela internet</span><h2>Pedidos da vitrine online</h2></div><button class="btn ghost sm" type="button" onclick="dashboardOpenOnlineOrders()">Ver pedidos da vitrine</button></div>';
  h += online.length ? '<div class="ksw-online-order-list">' + online.slice(0, 4).map(function (p) {
    return '<article class="ksw-online-order"><div><b>' + esc(cliNome(p)) + '</b><small>Entrega ' + esc(D(p.ent)) + (p.hora ? ' · ' + esc(p.hora) : '') + '</small></div><span class="tag">' + esc(orderStatusLabel(p.st)) + '</span><strong>' + R(tp(p)) + '</strong></article>';
  }).join('') + '</div>' : '<div class="ksw-empty-state"><b>Nenhum pedido novo pela vitrine</b><p>As encomendas feitas pelo link da loja aparecerão aqui.</p><button class="btn ghost" type="button" onclick="go(&quot;catalogo&quot;)">Configurar vitrine</button></div>';
  h += '</section>';
  h += '<section class="ksw-upcoming"><div class="ksw-dashboard-section-title"><div><span class="ksw-eyebrow">Organização da produção</span><h2>Próximas entregas</h2></div><button class="btn ghost sm" onclick="go(\'pedidos\')">Ver todos os pedidos</button></div>';
  if (!op.length) return h + '<div class="ksw-empty-state"><span>♡</span><b>Nenhuma entrega pendente</b><p>Quando você registrar uma encomenda, ela aparecerá aqui para facilitar o acompanhamento.</p><button class="btn" onclick="newO(hoje())">Cadastrar primeiro pedido</button>' + (db.produtos.length ? '' : '<button class="btn ghost" onclick="demo()">Carregar dados de exemplo</button>') + '</div></section>';
  h += '<div class="ksw-delivery-list">'+op.slice(0,8).map(function (p) {
    var sd = saldoDe(p), dateLabel = p.ent === hoje() ? 'Hoje' : p.ent === addDias(hoje(),1) ? 'Amanhã' : D(p.ent);
    return '<article class="ksw-delivery-card"><div class="ksw-delivery-date"><b>'+esc(dateLabel)+'</b><small>'+(p.hora?esc(p.hora):'Sem horário')+'</small></div><div class="ksw-delivery-info"><b>'+esc(cliNome(p))+'</b><p>'+resumoItens(p)+'</p>'+(sd>0.004?'<small>Saldo a receber: <b>'+R(sd)+'</b></small>':'<small class="pos">Pagamento concluído</small>')+'</div><div class="ksw-delivery-status"><span class="tag">'+esc(p.st)+'</span><div class="ksw-delivery-actions">'+(sd>0.004?'<button class="btn ghost sm" onclick="msg(\''+Q(p.id)+'\',\'cob\')">Cobrar no WhatsApp</button>':'')+'<button class="btn ghost sm" onclick="msg(\''+Q(p.id)+'\',\'lem\')">Lembrar no WhatsApp</button><button class="btn sm" onclick="upO(\''+Q(p.id)+'\',\'entregue\')">Marcar entregue</button></div></div></article>';
  }).join('')+'</div></section>';
  return h;
}