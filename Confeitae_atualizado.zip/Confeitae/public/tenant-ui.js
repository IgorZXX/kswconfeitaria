'use strict';

var tenantWorkspace = {
  loading: false,
  loaded: false,
  error: '',
  tenant: null,
  members: [],
  invitations: [],
  capabilities: {},
  lastInviteUrl: ''
};

function tenantEsc(value) {
  return String(value == null ? '' : value).replace(/[&<>"']/g, function (character) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character];
  });
}

function tenantRoleLabel(role) {
  return ({ owner: 'Proprietário', admin: 'Administrador', manager: 'Gerente', member: 'Membro', viewer: 'Visualizador' })[role] || role;
}

function tenantRoleOptions(currentRole, actorRole) {
  var options = actorRole === 'owner'
    ? ['admin', 'manager', 'member', 'viewer']
    : ['manager', 'member', 'viewer'];
  if (currentRole === 'owner') return '<option value="owner" selected>Proprietário</option>';
  return options.map(function (role) {
    return '<option value="' + role + '" ' + (role === currentRole ? 'selected' : '') + '>' + tenantRoleLabel(role) + '</option>';
  }).join('');
}

function vEquipe() {
  var tenant = tenantWorkspace.tenant || currentTenant;
  if (tenantWorkspace.loading && !tenant) {
    return '<section class="tenant-workspace"><div class="tenant-card"><p>Carregando empresa e equipe...</p></div></section>';
  }
  if (!tenant && !currentTenant) {
    return '<section class="tenant-workspace"><div class="tenant-card"><h2>Empresa e equipe</h2><p>Não foi possível identificar a empresa desta conta.</p></div></section>';
  }

  var caps = tenantWorkspace.capabilities || {};
  var tenantOptions = (tenantList || []).map(function (entry) {
    return '<option value="' + tenantEsc(entry.id) + '" ' + (Number(entry.id) === Number(currentTenant && currentTenant.id) ? 'selected' : '') + '>' + tenantEsc(entry.nome) + ' · ' + tenantRoleLabel(entry.role) + '</option>';
  }).join('');
  var html = '<section class="tenant-workspace">' +
    '<div class="tenant-heading"><div><span class="tenant-eyebrow">Configurações da conta</span><h2>Empresa e equipe</h2><p>Gerencie o espaço de trabalho e as pessoas que podem acessar os dados da confeitaria.</p></div><span class="tenant-role-pill">' + tenantRoleLabel(currentTenant && currentTenant.role) + '</span></div>';

  var memberLimit=Number(tenant.max_members)||0;
  var membersUsed=Number(caps.members_used||tenantWorkspace.members.length||tenant.members_count||1);
  var seatLabel=memberLimit===0?'Acessos ilimitados':membersUsed+' de '+memberLimit+' acesso(s) utilizados';
  var hasTeamFeature=Array.isArray(tenant.features)?tenant.features.some(function(feature){return feature&&feature.key==='team';}):Boolean(caps.can_invite);
  html += '<div class="tenant-card tenant-switch-card"><div class="tenant-card-heading"><div><h3>Empresa selecionada</h3><p>Uma conta pode participar de mais de uma empresa.</p></div></div>' +
    '<label for="tenant-switch-select">Alternar empresa</label><select id="tenant-switch-select" onchange="switchTenant(this.value)">' + tenantOptions + '</select>' +
    '<div class="tenant-company-summary"><strong>' + tenantEsc(tenant.nome) + '</strong><span>' + membersUsed + ' pessoa(s) no espaço de trabalho · '+tenantEsc(seatLabel)+'</span></div></div>';

  html += '<div class="tenant-grid">';
  html += '<section class="tenant-card"><div class="tenant-card-heading"><div><h3>Dados da empresa</h3><p>Nome exibido nas áreas compartilhadas.</p></div></div>';
  if (caps.can_manage_settings) {
    html += '<form onsubmit="saveTenantName(event)"><label for="tenant-name">Nome da confeitaria</label><input id="tenant-name" name="nome" maxlength="100" required value="' + tenantEsc(tenant.nome) + '"><button class="btn" type="submit">Salvar empresa</button></form>';
  } else {
    html += '<p class="tenant-readonly-name">' + tenantEsc(tenant.nome) + '</p><p class="tenant-help">Somente administradores podem alterar os dados da empresa.</p>';
  }
  html += '</section>';

  html += '<section class="tenant-card"><div class="tenant-card-heading"><div><h3>Assinatura da empresa</h3><p>O acesso dos membros acompanha a assinatura do proprietário.</p></div></div>' +
    '<div class="tenant-subscription"><strong>' + tenantEsc(tenant.plan_name || tenant.plano_tipo || 'free') + '</strong><span>' + tenantEsc(tenant.status_assinatura || 'inativa') + '</span></div>' +
    '<p class="tenant-help">Limite deste plano: '+tenantEsc(seatLabel)+'.</p>' +
    (caps.can_manage_billing ? '<p class="tenant-help">A cobrança e a renovação continuam vinculadas à conta proprietária.</p>' : '<p class="tenant-help">Para tratar de pagamentos, fale com o proprietário da empresa.</p>') + '</section>';
  html += '</div>';

  if (caps.can_read_team) {
    html += '<section class="tenant-card"><div class="tenant-card-heading"><div><h3>Pessoas da equipe</h3><p>Os papéis determinam quais operações cada pessoa pode realizar.</p></div><span class="tenant-count">' + tenantWorkspace.members.length + '</span></div>';
    if (tenantWorkspace.members.length) {
      html += '<div class="tenant-member-list">' + tenantWorkspace.members.map(function (member) {
        var isOwner = member.role === 'owner';
        var canManageThisMember = caps.can_manage_team && !isOwner &&
          (currentTenant.role === 'owner' || (currentTenant.role === 'admin' && member.role !== 'admin'));
        return '<div class="tenant-member-row"><div class="tenant-member-identity"><strong>' + tenantEsc(member.nome) + '</strong><span>' + tenantEsc(member.email) + '</span></div>' +
          (canManageThisMember
            ? '<label class="tenant-role-control"><span>Papel</span><select onchange="updateTenantMemberRole(' + Number(member.user_id) + ',this.value)">' + tenantRoleOptions(member.role, currentTenant.role) + '</select></label><button class="btn tenant-remove-btn" type="button" onclick="removeTenantMember(' + Number(member.user_id) + ')">Remover</button>'
            : '<span class="tenant-role-pill">' + tenantRoleLabel(member.role) + '</span>') +
          '</div>';
      }).join('') + '</div>';
    } else {
      html += '<p class="tenant-help">Ainda não há pessoas adicionais nesta empresa.</p>';
    }
    html += '</section>';
  }

  if (caps.can_manage_team && hasTeamFeature && caps.can_invite) {
    html += '<section class="tenant-card"><div class="tenant-card-heading"><div><h3>Convidar pessoa</h3><p>O convite dura 7 dias e só pode ser aceito pelo e-mail informado.</p></div></div>' +
      '<form class="tenant-invite-form" onsubmit="createTenantInvitation(event)"><div><label for="tenant-invite-email">E-mail da pessoa</label><input id="tenant-invite-email" type="email" maxlength="160" autocomplete="email" placeholder="pessoa@exemplo.com" required></div><div><label for="tenant-invite-role">Papel</label><select id="tenant-invite-role">' +
      (currentTenant.role === 'owner' ? '<option value="admin">Administrador</option>' : '') +
      '<option value="manager">Gerente</option><option value="member" selected>Membro</option><option value="viewer">Visualizador</option></select></div><button class="btn" type="submit">Criar convite</button></form>';
    if (tenantWorkspace.lastInviteUrl) {
      html += '<div class="tenant-invite-result"><label for="tenant-invite-link">Link de convite criado</label><input id="tenant-invite-link" readonly value="' + tenantEsc(tenantWorkspace.lastInviteUrl) + '"><button class="btn ghost" type="button" onclick="copyTenantInvite()">Copiar link</button><p class="tenant-help">A pessoa deve criar uma conta ou entrar usando exatamente o e-mail convidado.</p></div>';
    }
    html += '</section>';
  } else if (caps.can_manage_team && (!hasTeamFeature || (memberLimit > 0 && membersUsed >= memberLimit))) {
    html += '<section class="tenant-card"><div class="tenant-card-heading"><div><h3>Mais pessoas na equipe</h3><p>' + (hasTeamFeature ? 'O limite de acessos deste plano foi atingido.' : 'A gestão de equipe está disponível em planos com acessos adicionais.') + '</p></div></div><p class="tenant-help">Plano atual: '+tenantEsc(tenant.plan_name || tenant.plano_tipo || 'atual')+' · '+tenantEsc(seatLabel)+'. Consulte os planos disponíveis para ampliar o número de pessoas.</p><button class="btn ghost" type="button" onclick="go(\'planos\')">Ver planos</button></section>';
  }

  if (caps.can_read_team && tenantWorkspace.invitations.length) {
    html += '<section class="tenant-card"><div class="tenant-card-heading"><div><h3>Convites pendentes</h3><p>Convites aguardando aceitação.</p></div></div><div class="tenant-invitation-list">' + tenantWorkspace.invitations.map(function (invite) {
      return '<div class="tenant-invitation-row"><div><strong>' + tenantEsc(invite.email) + '</strong><span>' + tenantRoleLabel(invite.role) + ' · expira em ' + tenantEsc(new Date(invite.expires_at).toLocaleDateString('pt-BR')) + '</span></div>' +
        (caps.can_manage_team ? '<button class="btn tenant-remove-btn" type="button" onclick="revokeTenantInvitation(' + Number(invite.id) + ')">Revogar</button>' : '') + '</div>';
    }).join('') + '</div></section>';
  }

  html += '<p class="tenant-security-note">Os dados da empresa são compartilhados entre os membros ativos. Visualizadores têm acesso somente de leitura. Alterações de papel e remoções são verificadas no servidor.</p>';
  if (tenantWorkspace.error) html += '<p class="tenant-error" role="alert">' + tenantEsc(tenantWorkspace.error) + '</p>';
  return html + '</section>';
}

async function loadTenantWorkspace(force) {
  if (!currentUser || !token || tenantWorkspace.loading || (tenantWorkspace.loaded && !force)) return;
  tenantWorkspace.loading = true;
  tenantWorkspace.error = '';
  try {
    var result = await apiCall('/tenants/current');
    tenantWorkspace.tenant = result.tenant;
    tenantWorkspace.members = result.members || [];
    tenantWorkspace.capabilities = result.capabilities || {};
    if (tenantWorkspace.capabilities.can_read_team) {
      var pending = await apiCall('/tenants/invitations');
      tenantWorkspace.invitations = pending.invitations || [];
    } else {
      tenantWorkspace.invitations = [];
    }
    tenantWorkspace.loaded = true;
  } catch (error) {
    tenantWorkspace.error = error.message || 'Não foi possível carregar a equipe.';
  } finally {
    tenantWorkspace.loading = false;
    if (typeof tab !== 'undefined' && tab === 'equipe') {
      var app = document.getElementById('app');
      if (app) app.innerHTML = vEquipe();
    }
  }
}

async function switchTenant(tenantId) {
  var selected = (tenantList || []).find(function (entry) { return String(entry.id) === String(tenantId); });
  if (!selected || Number(selected.id) === Number(currentTenant && currentTenant.id)) return;
  if (typeof diffOps === 'function' && syncedSnap && diffOps(db, syncedSnap).length) {
    await flushSync();
    if (diffOps(db, syncedSnap).length) {
      toast('Há alterações ainda não sincronizadas. Verifique a conexão antes de trocar de empresa.');
      return;
    }
  }
  clearTimeout(syncTimer);
  applyTenantContext({ tenants: tenantList, current_tenant: selected });
  tenantWorkspace = { loading: false, loaded: false, error: '', tenant: null, members: [], invitations: [], capabilities: {}, lastInviteUrl: '' };
  db = emptyDB();
  syncedSnap = null;
  syncBusy = false;
  syncDirty = false;
  await loadServerData();
  render();
}

async function saveTenantName(event) {
  event.preventDefault();
  var input = document.getElementById('tenant-name');
  if (!input) return;
  try {
    var result = await apiCall('/tenants/current', 'PATCH', { nome: input.value.trim() });
    if (currentTenant) currentTenant.nome = result.nome;
    await loadTenantWorkspace(true);
    toast('Nome da empresa atualizado.');
  } catch (_) {}
}

async function createTenantInvitation(event) {
  event.preventDefault();
  var emailInput = document.getElementById('tenant-invite-email');
  var roleInput = document.getElementById('tenant-invite-role');
  if (!emailInput || !roleInput) return;
  try {
    var result = await apiCall('/tenants/invitations', 'POST', { email: emailInput.value.trim(), role: roleInput.value });
    tenantWorkspace.lastInviteUrl = result.invitation.accept_url;
    emailInput.value = '';
    await loadTenantWorkspace(true);
    if (typeof toast === 'function') toast('Convite criado. Copie o link para compartilhar.');
  } catch (_) {}
}

async function copyTenantInvite() {
  if (!tenantWorkspace.lastInviteUrl) return;
  try {
    await navigator.clipboard.writeText(tenantWorkspace.lastInviteUrl);
    toast('Link de convite copiado.');
  } catch (_) {
    window.prompt('Copie o link de convite:', tenantWorkspace.lastInviteUrl);
  }
}

async function updateTenantMemberRole(userId, role) {
  try {
    await apiCall('/tenants/members/' + encodeURIComponent(userId), 'PATCH', { role: role });
    await loadTenantWorkspace(true);
    toast('Papel atualizado.');
  } catch (_) {
    await loadTenantWorkspace(true);
  }
}

async function removeTenantMember(userId) {
  if (!window.confirm('Remover esta pessoa da empresa? O acesso aos dados compartilhados será encerrado.')) return;
  try {
    await apiCall('/tenants/members/' + encodeURIComponent(userId), 'DELETE');
    await loadTenantWorkspace(true);
    toast('Pessoa removida da empresa.');
  } catch (_) {}
}

async function revokeTenantInvitation(invitationId) {
  if (!window.confirm('Revogar este convite?')) return;
  try {
    await apiCall('/tenants/invitations/' + encodeURIComponent(invitationId), 'DELETE');
    await loadTenantWorkspace(true);
    toast('Convite revogado.');
  } catch (_) {}
}

async function acceptPendingTenantInvite() {
  var inviteToken = null;
  try { inviteToken = sessionStorage.getItem('ksw_pending_invite'); } catch (_) {}
  if (!inviteToken || !currentUser || !token) return false;
  try {
    var result = await apiCall('/tenants/invitations/accept', 'POST', { token: inviteToken });
    try { sessionStorage.removeItem('ksw_pending_invite'); } catch (_) {}
    applyTenantContext(result);
    tenantWorkspace = { loading: false, loaded: false, error: '', tenant: null, members: [], invitations: [], capabilities: {}, lastInviteUrl: '' };
    toast('Convite aceito. Você agora participa de ' + (result.tenant && result.tenant.nome ? result.tenant.nome : 'uma empresa') + '.');
    return true;
  } catch (error) {
    // Convite expirado ou e-mail divergente deve ser resolvido pelo usuário, sem trocar de empresa.
    return false;
  }
}
