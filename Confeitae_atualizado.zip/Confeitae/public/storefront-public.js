(function (root) {
  'use strict';

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[char]));
  }

  function money(value) {
    const amount = Number(value);
    return (Number.isFinite(amount) ? amount : 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  function localDateAfter(days) {
    const date = new Date();
    date.setHours(12, 0, 0, 0);
    date.setDate(date.getDate() + Math.max(0, Number(days) || 0));
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function mount(element, store) {
    if (!element || !store || !Array.isArray(store.menus)) return;

    const settings = store.settings || {};
    const cart = new Map();
    let fulfillment = settings.pickup_enabled ? 'retirada' : 'entrega';
    let busy = false;
    let errorMessage = '';
    let confirmation = null;
    let pendingIdempotencyKey = '';
    const leadDate = localDateAfter(settings.lead_time_days || 0);
    const unavailableDates = new Set(Array.isArray(store.capacity && store.capacity.unavailable_dates)
      ? store.capacity.unavailable_dates.map(String) : []);
    const capacityHasLimits = Boolean(store.capacity && store.capacity.has_limits);
    const capacityFullMessage = 'Esta data já atingiu a capacidade diária da confeitaria. Escolha outra data.';

    const products = [];
    store.menus.forEach((menu) => {
      (menu.sections || []).filter((section) => section.visible !== false).forEach((section) => {
        (section.products || []).filter((product) => product.visible !== false).forEach((product) => {
          products.push({
            menu_id: menu.id,
            menu_title: menu.title,
            section_name: section.name,
            id: product.id,
            name: product.name,
            description: product.description || '',
            price: Number(product.price) || 0,
            image_url: product.image_url || '',
            available: product.available !== false
          });
        });
      });
    });

    function cartLines() {
      return Array.from(cart.values()).filter((line) => line.quantity > 0);
    }

    function subtotal() {
      return cartLines().reduce((sum, line) => sum + line.price * line.quantity, 0);
    }

    function deliveryFee() {
      return fulfillment === 'entrega' ? Number(settings.delivery_fee || 0) : 0;
    }

    function productCard(product) {
      const key = `${product.menu_id}:${product.id}`;
      const quantity = cart.has(key) ? cart.get(key).quantity : 0;
      return `<article class="ksw-store-product">
        ${product.image_url ? `<img loading="lazy" src="${escapeHtml(product.image_url)}" alt="${escapeHtml(product.name)}" referrerpolicy="no-referrer">` : '<div class="ksw-store-product-placeholder" aria-hidden="true">K</div>'}
        <div class="ksw-store-product-copy"><span class="ksw-store-category">${escapeHtml(product.section_name)}</span>
          <h3>${escapeHtml(product.name)}</h3>
          ${product.description ? `<p>${escapeHtml(product.description)}</p>` : ''}
          <div class="ksw-store-product-foot"><strong>${money(product.price)}</strong>
          ${product.available ? (quantity > 0
            ? `<div class="ksw-store-qty" aria-label="Quantidade de ${escapeHtml(product.name)}"><button type="button" data-cart-action="decrease" data-key="${escapeHtml(key)}" aria-label="Diminuir quantidade">−</button><b>${quantity}</b><button type="button" data-cart-action="increase" data-key="${escapeHtml(key)}" aria-label="Aumentar quantidade">+</button></div>`
            : `<button class="ksw-store-add" type="button" data-cart-action="add" data-key="${escapeHtml(key)}">Adicionar</button>`)
            : '<span class="ksw-store-unavailable">Indisponível</span>'}
          </div>
        </div>
      </article>`;
    }

    function render() {
      const previousForm = element.querySelector('#ksw-store-order-form');
      const previousValues = {};
      if (previousForm) ['name','phone','email','delivery_date','delivery_time','address','notes','website'].forEach((name) => {
        const field = previousForm.elements.namedItem(name);
        if (field) previousValues[name] = field.value;
      });
      const lines = cartLines();
      const sub = subtotal();
      const fee = deliveryFee();
      const total = sub + fee;
      const minOrder = Number(settings.minimum_order || 0);
      const selectedDeliveryDate = previousValues.delivery_date || '';
      const selectedDateUnavailable = Boolean(selectedDeliveryDate && unavailableDates.has(selectedDeliveryDate));
      const capacityMessage = selectedDateUnavailable
        ? capacityFullMessage
        : (capacityHasLimits ? 'A agenda é conferida automaticamente. Datas que atingirem o limite diário não aceitarão novas encomendas.' : '');
      const methods = [
        settings.pickup_enabled ? '<option value="retirada"' + (fulfillment === 'retirada' ? ' selected' : '') + '>Retirada</option>' : '',
        settings.delivery_enabled ? '<option value="entrega"' + (fulfillment === 'entrega' ? ' selected' : '') + '>Entrega</option>' : ''
      ].join('');

      element.innerHTML = `<div class="ksw-store-shell">
        <header class="ksw-store-header">
          <div class="ksw-store-brand-mark">K</div>
          <p class="ksw-store-eyebrow">Loja oficial</p>
          <h1>${escapeHtml(store.owner_name || 'Confeitaria')}</h1>
          <p class="ksw-store-intro">Escolha seus produtos e envie sua encomenda diretamente para a confeitaria.</p>
          <div class="ksw-store-header-links">
            ${settings.instagram_url ? `<a href="${escapeHtml(settings.instagram_url)}" target="_blank" rel="noopener noreferrer">Instagram</a>` : ''}
            ${settings.address ? `<span>${escapeHtml(settings.address)}</span>` : ''}
          </div>
        </header>

        ${store.menus.length ? store.menus.map((menu) => `<section class="ksw-store-menu">
          <div class="ksw-store-menu-heading"><span class="ksw-store-eyebrow">Cardápio</span><h2>${escapeHtml(menu.title)}</h2>${menu.description ? `<p>${escapeHtml(menu.description)}</p>` : ''}</div>
          ${(menu.sections || []).filter((section) => section.visible !== false).map((section) => {
            const items = (section.products || []).filter((product) => product.visible !== false);
            if (!items.length) return '';
            return `<div class="ksw-store-section"><div class="ksw-store-section-heading"><h3>${escapeHtml(section.name)}</h3>${section.description ? `<p>${escapeHtml(section.description)}</p>` : ''}</div><div class="ksw-store-products">${items.map((item) => productCard({ ...item, menu_id: menu.id, menu_title: menu.title, section_name: section.name })).join('')}</div></div>`;
          }).join('')}
        </section>`).join('') : '<div class="ksw-store-empty">Nenhum produto publicado no momento.</div>'}

        <section class="ksw-store-checkout" id="ksw-store-checkout">
          <div class="ksw-store-checkout-heading"><div><span class="ksw-store-eyebrow">Sua encomenda</span><h2>Resumo do pedido</h2></div><span class="ksw-store-cart-count">${lines.reduce((sum, line) => sum + line.quantity, 0)} item(ns)</span></div>
          ${lines.length ? `<div class="ksw-store-cart-lines">${lines.map((line) => `<div class="ksw-store-cart-line"><div><b>${escapeHtml(line.name)}</b><small>${line.quantity} × ${money(line.price)}</small></div><div class="ksw-store-cart-actions"><strong>${money(line.quantity * line.price)}</strong><button type="button" data-cart-action="remove" data-key="${escapeHtml(line.key)}" aria-label="Remover ${escapeHtml(line.name)}">Remover</button></div></div>`).join('')}</div>` : '<p class="ksw-store-empty-cart">Seu carrinho está vazio. Adicione produtos para montar a encomenda.</p>'}
          <div class="ksw-store-total-row"><span>Subtotal</span><b>${money(sub)}</b></div>
          <div class="ksw-store-total-row"><span>Taxa de entrega</span><b data-store-delivery-fee>${money(fee)}</b></div>
          <div class="ksw-store-total-row ksw-store-grand-total"><span>Total estimado</span><b data-store-grand-total>${money(total)}</b></div>
          ${minOrder > 0 ? `<p class="ksw-store-note">Pedido mínimo: ${money(minOrder)}${sub < minOrder ? ` · faltam ${money(minOrder - sub)}` : ''}</p>` : ''}
          ${settings.instructions ? `<p class="ksw-store-note">${escapeHtml(settings.instructions)}</p>` : ''}
          ${errorMessage ? `<p class="ksw-store-error" role="alert">${escapeHtml(errorMessage)}</p>` : ''}
          ${confirmation ? `<div class="ksw-store-confirmation" role="status"><span class="ksw-store-eyebrow">Pedido recebido</span><h3>Obrigada pelo pedido!</h3><p>Protocolo <b>${escapeHtml(confirmation.code)}</b>. A confeitaria precisa confirmar a disponibilidade e combinar o pagamento.</p>${confirmation.whatsapp_url ? `<a class="ksw-store-submit" href="${escapeHtml(confirmation.whatsapp_url)}" target="_blank" rel="noopener noreferrer">Confirmar pelo WhatsApp</a>` : ''}<button class="ksw-store-secondary" type="button" data-store-action="new-order">Fazer outro pedido</button></div>` : `<form id="ksw-store-order-form" class="ksw-store-form">
            <div class="ksw-store-form-heading"><h3>Seus dados</h3><p>Enviaremos a solicitação para a confeitaria confirmar.</p></div>
            <div class="ksw-store-form-grid"><div><label for="store-customer-name">Nome completo</label><input id="store-customer-name" name="name" autocomplete="name" maxlength="100" required></div><div><label for="store-customer-phone">WhatsApp com DDD</label><input id="store-customer-phone" name="phone" type="tel" inputmode="tel" autocomplete="tel" maxlength="18" placeholder="(11) 99999-9999" required></div></div>
            <label for="store-customer-email">E-mail (opcional)</label><input id="store-customer-email" name="email" type="email" autocomplete="email" maxlength="160">
            <div class="ksw-store-form-grid"><div><label for="store-fulfillment">Como deseja receber?</label><select id="store-fulfillment" name="fulfillment" ${methods ? '' : 'disabled'}>${methods}</select></div><div><label for="store-delivery-date">Data desejada</label><input id="store-delivery-date" name="delivery_date" type="date" min="${leadDate}" required><small class="ksw-store-note" data-store-capacity-message role="status">${escapeHtml(capacityMessage)}</small></div></div>
            <div class="ksw-store-form-grid"><div><label for="store-delivery-time">Horário desejado (opcional)</label><input id="store-delivery-time" name="delivery_time" type="time"></div><div id="store-address-wrap" class="${fulfillment === 'entrega' ? '' : 'ksw-store-hidden'}"><label for="store-delivery-address">Endereço para entrega</label><input id="store-delivery-address" name="address" maxlength="240" ${fulfillment === 'entrega' ? 'required' : ''}></div></div>
            <label for="store-order-notes">Observações (opcional)</label><textarea id="store-order-notes" name="notes" rows="3" maxlength="500" placeholder="Detalhes da encomenda, restrições ou preferências"></textarea>
            <div class="ksw-store-honeypot" aria-hidden="true"><label for="store-website">Não preencher</label><input id="store-website" name="website" tabindex="-1" autocomplete="off"></div>
            <p class="ksw-store-payment-note">O pagamento não é realizado nesta página. A confeitaria confirmará o pedido e combinará a forma de pagamento com você. Seus dados serão usados para organizar e responder a esta encomenda. Não informe dados de cartão nas observações.</p>
            <button class="ksw-store-submit" type="submit" ${!lines.length || sub < minOrder || busy || selectedDateUnavailable ? 'disabled' : ''}>${busy ? 'Enviando…' : 'Enviar encomenda'}</button>
          </form>`}
        </section>
        <footer class="ksw-store-footer">Loja virtual criada com Confeitaê</footer>
      </div>`;
      const nextForm = element.querySelector('#ksw-store-order-form');
      if (nextForm) Object.keys(previousValues).forEach((name) => {
        const field = nextForm.elements.namedItem(name);
        if (field) field.value = previousValues[name];
      });
    }

    function cartChange(action, key) {
      const product = products.find((item) => `${item.menu_id}:${item.id}` === key);
      if (!product || !product.available) return;
      const current = cart.get(key) || { ...product, key, quantity: 0 };
      if (action === 'add' || action === 'increase') current.quantity = Math.min(50, current.quantity + 1);
      if (action === 'decrease') current.quantity = Math.max(0, current.quantity - 1);
      if (action === 'remove') current.quantity = 0;
      if (current.quantity > 0) cart.set(key, current);
      else cart.delete(key);
      errorMessage = '';
      render();
    }

    async function submit(form) {
      if (busy) return;
      const lines = cartLines();
      if (!lines.length) return;
      const formData = new FormData(form);
      const requestedDate = String(formData.get('delivery_date') || '');
      if (unavailableDates.has(requestedDate)) {
        errorMessage = capacityFullMessage;
        render();
        return;
      }
      const phone = String(formData.get('phone') || '').replace(/\D/g, '');
      if (phone.length < 10) {
        errorMessage = 'Informe um telefone com DDD.';
        render();
        return;
      }
      if (!pendingIdempotencyKey) {
        pendingIdempotencyKey = (root.crypto && root.crypto.randomUUID)
          ? root.crypto.randomUUID().replace(/-/g, '')
          : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
      }
      const payload = {
        idempotency_key: pendingIdempotencyKey,
        customer: { name: formData.get('name'), phone, email: formData.get('email') },
        fulfillment: formData.get('fulfillment'),
        delivery_date: formData.get('delivery_date'),
        delivery_time: formData.get('delivery_time'),
        address: formData.get('address'),
        notes: formData.get('notes'),
        website: formData.get('website'),
        items: lines.map((line) => ({ menu_id: line.menu_id, product_id: line.id, quantity: line.quantity }))
      };
      busy = true;
      const button = form.querySelector('button[type="submit"]');
      if (button) { button.disabled = true; button.textContent = 'Enviando…'; }
      errorMessage = '';
      try {
        const response = await fetch(`/api/storefront/public/${encodeURIComponent(store.slug)}/orders`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify(payload)
        });
        const result = await response.json().catch(() => ({}));
        if (!response.ok) {
          if (result.code === 'STOREFRONT_CAPACITY_EXCEEDED' && payload.delivery_date) {
            unavailableDates.add(payload.delivery_date);
          }
          throw new Error(result.error || 'Não foi possível enviar sua encomenda.');
        }
        confirmation = result;
        cart.clear();
        pendingIdempotencyKey = '';
      } catch (error) {
        errorMessage = error.message || 'Não foi possível enviar sua encomenda.';
      } finally {
        busy = false;
        render();
      }
    }

    element.addEventListener('click', (event) => {
      const cartButton = event.target.closest('[data-cart-action]');
      if (cartButton) {
        event.preventDefault();
        cartChange(cartButton.dataset.cartAction, cartButton.dataset.key);
        return;
      }
      const storeButton = event.target.closest('[data-store-action]');
      if (storeButton && storeButton.dataset.storeAction === 'new-order') {
        confirmation = null;
        errorMessage = '';
        render();
      }
    });

    element.addEventListener('change', (event) => {
      if (event.target && event.target.id === 'store-delivery-date') {
        const dateUnavailable = unavailableDates.has(String(event.target.value || ''));
        const note = element.querySelector('[data-store-capacity-message]');
        const submitButton = element.querySelector('#ksw-store-order-form button[type="submit"]');
        if (note) note.textContent = dateUnavailable ? capacityFullMessage
          : (capacityHasLimits ? 'A agenda é conferida automaticamente. Datas que atingirem o limite diário não aceitarão novas encomendas.' : '');
        if (submitButton) submitButton.disabled = !cartLines().length || subtotal() < Number(settings.minimum_order || 0) || busy || dateUnavailable;
        errorMessage = '';
        return;
      }
      if (event.target && event.target.id === 'store-fulfillment') {
        fulfillment = event.target.value;
        const wrapper = element.querySelector('#store-address-wrap');
        const addressInput = element.querySelector('#store-delivery-address');
        if (wrapper && addressInput) {
          const requiresAddress = fulfillment === 'entrega';
          wrapper.classList.toggle('ksw-store-hidden', !requiresAddress);
          addressInput.required = requiresAddress;
        }
        const feeValue = element.querySelector('[data-store-delivery-fee]');
        const totalValue = element.querySelector('[data-store-grand-total]');
        if (feeValue) feeValue.textContent = money(deliveryFee());
        if (totalValue) totalValue.textContent = money(subtotal() + deliveryFee());
      }
    });

    element.addEventListener('submit', (event) => {
      if (event.target && event.target.id === 'ksw-store-order-form') {
        event.preventDefault();
        submit(event.target);
      }
    });

    render();
  }

  root.KSWStorefront = { mount };
}(window));
