(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.KSWAnalytics = api;
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function amount(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : 0;
    const normalized = String(value == null ? '' : value).trim().replace(/\s/g, '').replace(/\.(?=\d{3}(?:\D|$))/g, '').replace(',', '.');
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function isoMonth(value) {
    return /^\d{4}-(0[1-9]|1[0-2])$/.test(String(value || '')) ? String(value) : null;
  }

  function monthOf(value) {
    const match = String(value || '').match(/^(\d{4}-\d{2})/);
    return match && isoMonth(match[1]) ? match[1] : '';
  }

  function orderTotal(order) {
    const items = Array.isArray(order && order.itens) ? order.itens : [];
    return items.reduce((sum, item) => sum + amount(item && item.pu) * Math.max(0, amount(item && item.q)), 0) + Math.max(0, amount(order && order.taxa_entrega));
  }

  function orderCost(order) {
    const items = Array.isArray(order && order.itens) ? order.itens : [];
    let directCost = 0;
    let variableFees = 0;
    let missing = 0;
    let missingFeeItems = 0;
    items.forEach((item) => {
      const quantity = Math.max(0, amount(item && item.q));
      if (!(quantity > 0)) return;
      const raw = item && (item.cu != null ? item.cu : item.custo_unitario);
      if (raw == null || raw === '') missing += 1;
      else directCost += amount(raw) * quantity;

      const rawFeePercent = item && item.taxa_venda_pct;
      const feeKnown = item && item.taxa_venda_informada === true || item && item.taxa_venda_informada !== false && rawFeePercent != null && rawFeePercent !== '' && amount(rawFeePercent) > 0;
      if (!feeKnown) {
        missingFeeItems += 1; // taxa ausente ou zero legado sem confirmação explícita
      } else {
        const feePercent = amount(rawFeePercent);
        if (feePercent >= 0 && feePercent < 100) {
          variableFees += Math.max(0, amount(item && item.pu)) * quantity * feePercent / 100;
        } else {
          missingFeeItems += 1;
        }
      }
    });
    return {
      total: directCost + variableFees,
      direct_cost: directCost,
      variable_fees: variableFees,
      missing_items: missing,
      missing_fee_items: missingFeeItems
    };
  }

  function paymentsFor(order) {
    if (Array.isArray(order && order.pagamentos)) return order.pagamentos;
    const legacy = amount(order && order.pg);
    return legacy > 0 ? [{ v: legacy, data: (order && (order.pd || order.ent)) || '' }] : [];
  }

  function orderPaid(order) {
    return paymentsFor(order).reduce((sum, payment) => sum + Math.max(0, amount(payment && payment.v)), 0);
  }

  function orderBalance(order) {
    return Math.max(0, orderTotal(order) - orderPaid(order));
  }

  function openReceivables(data) {
    const orders = Array.isArray(data) ? data : Array.isArray(data && data.pedidos) ? data.pedidos : [];
    return orders.filter((order) => order && order.st !== 'cancelado' && orderBalance(order) > 0.004);
  }

  function cashBalanceAsOf(entries, date) {
    const cutoff = String(date || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(cutoff)) throw new TypeError('Informe uma data válida para o saldo de caixa.');
    return (Array.isArray(entries) ? entries : []).reduce((balance, entry) => {
      const entryDate = String(entry && (entry.date || entry.d) || '').slice(0, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(entryDate) || entryDate > cutoff) return balance;
      return balance + amount(entry.value != null ? entry.value : entry.v);
    }, 0);
  }

  function summarize(data, month) {
    const selectedMonth = isoMonth(month);
    if (!selectedMonth) throw new TypeError('Informe o mês no formato AAAA-MM.');
    const source = data && typeof data === 'object' ? data : {};
    const orders = Array.isArray(source.pedidos) ? source.pedidos : [];
    const expenses = Array.isArray(source.despesas) ? source.despesas : [];
    const losses = Array.isArray(source.perdas) ? source.perdas : [];
    const validOrders = orders.filter((order) => order && order.st !== 'cancelado');
    const monthOrders = validOrders.filter((order) => monthOf(order.ent) === selectedMonth);

    let revenue = 0;
    let cost = 0;
    let directCost = 0;
    let variableFees = 0;
    let missingCostItems = 0;
    let missingFeeItems = 0;
    let units = 0;
    const productMap = new Map();
    monthOrders.forEach((order) => {
      revenue += orderTotal(order);
      const costInfo = orderCost(order);
      cost += costInfo.total;
      directCost += costInfo.direct_cost;
      variableFees += costInfo.variable_fees;
      missingCostItems += costInfo.missing_items;
      missingFeeItems += costInfo.missing_fee_items;
      (Array.isArray(order.itens) ? order.itens : []).forEach((item) => {
        const key = String(item.pid || item.nome || 'Produto sem identificação');
        const current = productMap.get(key) || {
          id: item.pid || '', name: String(item.nome || 'Produto sem identificação'), quantity: 0,
          revenue: 0, cost: 0, orders: 0, missing_cost_items: 0, missing_fee_items: 0
        };
        const quantity = Math.max(0, amount(item.q));
        current.quantity += quantity;
        current.revenue += amount(item.pu) * quantity;
        const hasCost = item.cu != null && item.cu !== '' || item.custo_unitario != null && item.custo_unitario !== '';
        if (hasCost) current.cost += amount(item.cu != null ? item.cu : item.custo_unitario) * quantity;
        else if (quantity > 0) current.missing_cost_items += 1;
        const feePercent = item.taxa_venda_pct == null || item.taxa_venda_pct === '' ? null : amount(item.taxa_venda_pct);
        const feeKnown = item.taxa_venda_informada === true || item.taxa_venda_informada !== false && feePercent != null && feePercent > 0;
        if (feeKnown && feePercent >= 0 && feePercent < 100) current.cost += Math.max(0, amount(item.pu)) * quantity * feePercent / 100;
        else current.missing_fee_items += 1;
        productMap.set(key, current);
        units += quantity;
      });
    });
    monthOrders.forEach((order) => {
      const seen = new Set((Array.isArray(order.itens) ? order.itens : []).map((item) => String(item.pid || item.nome || 'Produto sem identificação')));
      seen.forEach((key) => { const product = productMap.get(key); if (product) product.orders += 1; });
    });

    let received = 0;
    let paidExpenses = 0;
    const cashEntries = [];
    orders.filter(Boolean).forEach((order) => {
      paymentsFor(order).forEach((payment) => {
        const date = String(payment && payment.data || order.pd || order.ent || '');
        const value = Math.max(0, amount(payment && payment.v));
        if (monthOf(date) === selectedMonth && value > 0) {
          received += value;
          cashEntries.push({ date, type: 'Entrada', description: `Pagamento de pedido ${order.id || ''}`.trim(), value });
        }
      });
    });

    let accruedExpenses = 0;
    const expenseCategories = new Map();
    const openPayables = expenses.filter((expense) => expense && !expense.pago);
    expenses.forEach((expense) => {
      if (!expense) return;
      const value = Math.max(0, amount(expense.v != null ? expense.v : expense.valor));
      const dueDate = String(expense.venc || expense.vencimento || '');
      if (monthOf(dueDate) === selectedMonth) {
        accruedExpenses += value;
        const category = String(expense.cat || expense.categoria || 'Outros');
        expenseCategories.set(category, (expenseCategories.get(category) || 0) + value);
      }
      if (expense.pago) {
        const paidDate = String(expense.dpg || expense.data_pagamento || expense.venc || expense.vencimento || '');
        if (monthOf(paidDate) === selectedMonth && value > 0) {
          paidExpenses += value;
          cashEntries.push({ date: paidDate, type: 'Saída', description: String(expense.desc || expense.descricao || 'Despesa'), value: -value });
        }
      }
    });

    const periodLosses = losses.filter((loss) => monthOf(loss && (loss.data || loss.data_perda)) === selectedMonth);
    const wasteCost = periodLosses.reduce((sum, loss) => sum + Math.max(0, amount(loss && (loss.custo_total != null ? loss.custo_total : loss.cost_total))), 0);
    const totalCost = cost;
    const grossProfit = revenue - totalCost;
    const managerialResult = grossProfit - accruedExpenses - wasteCost;
    const cashResult = received - paidExpenses;
    const receivables = openReceivables(validOrders).reduce((sum, order) => sum + orderBalance(order), 0);
    const payables = openPayables.reduce((sum, expense) => sum + Math.max(0, amount(expense.v != null ? expense.v : expense.valor)), 0);
    const byProduct = Array.from(productMap.values()).map((product) => ({
      ...product,
      contribution: product.revenue - product.cost
    })).sort((a, b) => b.revenue - a.revenue);
    const byCategory = Array.from(expenseCategories.entries()).map(([category, value]) => ({ category, value })).sort((a, b) => b.value - a.value);
    const avgTicket = monthOrders.length ? revenue / monthOrders.length : 0;
    const margin = revenue > 0 ? grossProfit / revenue * 100 : 0;

    cashEntries.sort((a, b) => a.date.localeCompare(b.date));
    return {
      month: selectedMonth,
      orders_count: monthOrders.length,
      units,
      revenue,
      received,
      cost: totalCost,
      direct_cost: directCost,
      variable_fees: variableFees,
      missing_cost_items: missingCostItems,
      missing_fee_items: missingFeeItems,
      gross_profit: grossProfit,
      accrued_expenses: accruedExpenses,
      paid_expenses: paidExpenses,
      managerial_result: managerialResult,
      cash_result: cashResult,
      waste_cost: wasteCost,
      receivables,
      payables,
      average_ticket: avgTicket,
      gross_margin_percent: margin,
      products: byProduct,
      expense_categories: byCategory,
      cash_entries: cashEntries,
      orders: monthOrders
    };
  }

  function shiftMonth(month, delta) {
    const valid = isoMonth(month);
    if (!valid || !Number.isInteger(delta)) throw new TypeError('Mês ou intervalo inválido.');
    const [year, monthNumber] = valid.split('-').map(Number);
    const date = new Date(Date.UTC(year, monthNumber - 1 + delta, 1));
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}`;
  }

  function monthlySeries(data, month, count = 6) {
    if (!Number.isInteger(count) || count < 1 || count > 24) throw new RangeError('A série deve conter entre 1 e 24 meses.');
    const start = count - 1;
    return Array.from({ length: count }, (_, index) => {
      const targetMonth = shiftMonth(month, index - start);
      const summary = summarize(data, targetMonth);
      return {
        month: targetMonth,
        revenue: summary.revenue,
        cost: summary.cost,
        expenses: summary.accrued_expenses,
        result: summary.managerial_result,
        orders: summary.orders_count
      };
    });
  }

  function csvCell(value) {
    if (value == null) return '""';
    let text = String(value);
    if (/^[\s]*[=+@\-]/.test(text)) text = `'${text}`;
    return `"${text.replace(/"/g, '""')}"`;
  }

  return {
    amount, isoMonth, monthOf, orderTotal, orderCost, paymentsFor, orderPaid, orderBalance,
    openReceivables, cashBalanceAsOf, summarize, monthlySeries, csvCell
  };
}));
