# Confeitaê SaaS - Sistema Completo com Checkout & Gestão de Assinaturas

Sistema completo de gestão para confeiteiras com controle de assinaturas, autenticação de usuários, integração com pagamento (Hotmart / Mercado Pago), bloqueio por vencimento e painel administrativo.

---

## Planos suportados
1. **Planos comerciais:** catálogo inicial com Mensal (R$ 59,99/mês) e Vitalício (R$ 1.119,00, pagamento único). O Super Admin pode criar planos adicionais na Stripe e publicar os preços no checkout do KSW.
2. **Acesso de teste legado:** fluxo Hotmart separado, mantido apenas para compatibilidade com o produto de teste anterior.

---

## Tecnologias utilizadas
- **Frontend:** HTML5, CSS3 Moderno (CSS Variables, Flexbox/Grid), JavaScript Vanilla.
- **Backend:** Node.js, Express.js.
- **Banco de Dados:** SQLite3 (Persistência leve, leve e rápida).
- **Autenticação & Segurança:** JWT (JSON Web Tokens), Bcryptjs (Hash seguro de senhas).
- **Pagamentos:** Stripe Checkout hospedado para mensal e vitalício, com webhook assinado para ativar, renovar e encerrar assinaturas. As rotas antigas de Mercado Pago e Hotmart foram mantidas, mas a tela principal de planos agora usa Stripe.

---

## Como instalar e rodar

### 1. Descompactar o arquivo ZIP
Extraia o ZIP inteiro. Ele contém uma única pasta raiz chamada `KSW_Confeitaria/`; abra essa pasta no VS Code. Não arraste arquivos e subpastas individualmente para outra pasta.

### 2. Instalar as dependências
No terminal, dentro da pasta que contém `package.json` e `server.js`:
```bash
npm ci
```

### 3. Configurar variáveis de ambiente
Configure no `.env` um token válido do Mercado Pago em `MP_ACCESS_TOKEN`. Para receber notificações de pagamento, configure também `BASE_URL` com a URL HTTPS pública do servidor. Nunca publique ou compartilhe o token.

Para validar o acesso de teste, configure `HOTMART_HOTTOK` no `.env` com o token secreto gerado pela Hotmart e, se necessário, ajuste `HOTMART_TEST_PRODUCT_ID` (padrão `8862465`). Cadastre `https://SUA-URL-PUBLICA/api/payment/hotmart/webhook` como webhook do produto de teste e habilite o evento de compra aprovada. O checkout de teste fica desabilitado até `HOTMART_HOTTOK` e `BASE_URL` HTTPS estarem configurados. A compra deve usar o mesmo e-mail da conta KSW. O servidor só ativa o acesso após validar o token, o ID do produto, o status aprovado, o valor de R$ 3,90 e a moeda BRL. Não compartilhe o Hottok.

Sem um token válido, o checkout permanece indisponível e nenhum pagamento fictício é criado. A recuperação de senha por e-mail também depende de uma integração de envio de e-mail, ainda não configurada.

### 4. Validar e iniciar o servidor
```bash
npm run security:skill:guard
npm test
npm start
# Ou para desenvolvimento com reload automático:
npm run dev
```
O início do servidor é protegido pelo guard da skill de segurança. Se o código for alterado, revise o impacto e atualize o histórico antes de sincronizar a skill; não desative o guard para contornar o bloqueio.

Acesse no navegador: `http://localhost:3000`

---


## Configurar Stripe (modo de teste)

1. Copie `.env.example` para `.env`.
2. Gere segredos fortes para `JWT_SECRET` e `ADMIN_SECRET_KEY`.
3. No Dashboard Stripe em modo de teste, obtenha uma chave secreta `sk_test_` e coloque em `STRIPE_SECRET_KEY`.
4. Instale as dependências:
   ```bash
   npm install
   ```
5. Crie os produtos e preços automaticamente:
   ```bash
   npm run stripe:products
   ```
   O script cria R$ 59,99/mês e R$ 1.119,00 em pagamento único e grava os dois IDs `price_...` no `.env`. Ele só permite a chave de teste e interrompe a execução se os IDs já estiverem preenchidos, para reduzir o risco de duplicação.
6. Instale a Stripe CLI pelo guia oficial: https://docs.stripe.com/stripe-cli
7. Em outro terminal, autentique e encaminhe os eventos para o servidor local:
   ```bash
   stripe login
   stripe listen --forward-to localhost:3000/api/payment/stripe/webhook
   ```
8. Copie o segredo `whsec_...` mostrado pela CLI para `STRIPE_WEBHOOK_SECRET` no `.env` e reinicie o servidor.
9. Inicie o KSW:
   ```bash
   npm run dev
   ```

A tela de planos redireciona o cliente para o Checkout hospedado da Stripe. A aplicação só libera o plano após confirmação verificada pela assinatura do webhook. Para testar, use os cartões de teste oficiais da Stripe: https://docs.stripe.com/testing

### Webhook em produção

Em produção, cadastre `https://SEU-DOMINIO/api/payment/stripe/webhook` como endpoint de webhook no Dashboard Stripe e configure o segredo `whsec_...` desse endpoint em `STRIPE_WEBHOOK_SECRET`. Use uma `BASE_URL` HTTPS. O segredo obtido pelo `stripe listen` é destinado ao desenvolvimento local e não substitui o segredo do endpoint de produção.

### Cancelamento de assinatura

Para assinaturas Stripe, o KSW agenda o cancelamento no fim do período já pago. O cliente mantém o acesso até a data de vencimento. A confirmação final de encerramento vem do webhook da Stripe.

### Segurança

- Nunca envie o `.env` por chat, e-mail ou repositório.
- Não coloque chaves secretas no HTML ou JavaScript do navegador.
- O `.env` e o banco SQLite estão ignorados pelo `.gitignore`.
- Se uma chave secreta foi compartilhada, revogue-a no Dashboard e gere outra.
- O script `npm run stripe:products` cria recursos somente no modo de teste. Antes de produção, crie os preços da conta live e use IDs e chave live em um processo separado e revisado.

## Dados na nuvem (Fase 1)

Antes, ingredientes, receitas, clientes e pedidos ficavam só no `localStorage` do navegador: trocar de aparelho ou limpar o cache apagava tudo. Agora ficam no servidor, separados por usuária.

- **Tabelas:** `clientes`, `ingredientes`, `embalagens`, `lotes_estoque`, `ordens_producao`, `perdas_estoque`, `produtos`, `pedidos`, `despesas` e `movimentacoes_estoque`. Chave primária `(user_id, id)`: uma conta nunca lê nem sobrescreve registros de outra. Cada linha guarda o JSON completo (`data`) e colunas-chave (status, data de entrega, total, pago, validade, etc.) já prontas para filtros e relatórios.
- **API** (`routes/data.js`): `GET /api/data` (carrega tudo), `POST /api/data/sync` (lista de operações `put`/`del`, gravada numa única transação, máx. 1000 por chamada) e `GET /api/data/export` (backup em JSON). A leitura e a exportação funcionam mesmo com assinatura vencida; a escrita exige assinatura ativa.
- **Front-end:** o app envia só o que mudou (alguns instantes após cada alteração) e mostra o estado no menu ("Dados salvos na nuvem"). O `localStorage` virou cache por usuária (`ksw-db:<id>`): sem internet o app continua funcionando e reenvia ao reconectar. Se a mesma conta alterar dados em dois aparelhos, vale o último envio de cada registro. Ao voltar para a aba, o app busca mudanças do outro aparelho.
- **Migração automática:** no primeiro login após a atualização, se a conta ainda não tem dados na nuvem, os dados antigos do navegador (`ksw-db`) são enviados automaticamente e a chave antiga é removida só depois do envio completo.
- **Sair da conta** envia as pendências e apaga o cache do aparelho; se estiver sem internet, mantém o cache para não perder nada.

### Segurança (Fase 1)

- Sem segredos padrão no código. Em produção (`NODE_ENV=production`) o servidor não inicia sem `JWT_SECRET` e `ADMIN_SECRET_KEY` fortes.
- Limite de tentativas: login (10 por 15 min por IP + e-mail), cadastro, redefinição de senha e chave do painel admin. Se usar proxy/túnel, defina `TRUST_PROXY=1`.
- Senha mínima de 8 caracteres também no servidor; validação de tipo e tamanho nos campos de cadastro e login.
- Chave admin comparada em tempo constante; CORS restrito à `BASE_URL` em produção; cabeçalhos de segurança básicos; HSTS em produção; limite de 200 KB para JSON (5 MB só em `/api/data`).
- SQLite em modo WAL com `busy_timeout`.

### Backup e testes

```bash
npm run backup   # copia consistente do banco para ./backups (mantém os 14 mais recentes)
npm test         # executa testes unitários/regressão e o smoke test HTTP
```
Agende o `npm run backup` (cron/Agendador de Tarefas) e copie a pasta para fora do servidor.

## Fase 2A: encomendas e financeiro

Código em `public/gestao.js` (usa o mesmo visual e os mesmos helpers do `index.html`).

- **Pedidos:** criar e editar (cliente, data e hora de entrega, itens, observações/tema), **sinal e saldo**, vários pagamentos por pedido (valor, forma, data) com histórico, status na própria lista, filtro por status/saldo e busca por cliente. O preço e o custo de cada item ficam congelados no pedido; editar não muda o que já foi vendido. Pedidos antigos (com o campo `pg`) continuam valendo.
- **WhatsApp** (`wa.me`, sem custo): lembrete de entrega, cobrança do saldo e confirmação de encomenda, com a mensagem já preenchida.
- **Agenda:** calendário mensal com pedidos por dia, dia selecionado com a lista de encomendas e contas a vencer, e **trava de capacidade diária** (máximo de pedidos e de unidades por dia). Ao ultrapassar, o sistema avisa e pergunta se aceita mesmo assim.
- **Financeiro:** Resumo (entradas, saídas, saldo de caixa, resultado do mês, despesas por categoria), A receber, A pagar (categorias, fornecedor, repetição mensal de até 24 meses, marcar como paga), Fluxo de caixa (saldo anterior, movimentos do mês com saldo corrente e previsão de 30 dias) e Fornecedores.
- **Painel inicial:** alertas (entregas atrasadas, entregues com saldo, contas vencidas ou a vencer, estoque baixo, capacidade do dia) e próximas entregas com ações.
- **Banco:** novas tabelas `fornecedores` e `configuracoes`, colunas novas em `despesas` e migração automática (`ALTER TABLE`) de bancos criados antes, sem apagar dados.

A camada de estoque por lotes, embalagens, produção e desperdício foi ampliada na Fase 3, descrita abaixo.


## Fase 2B: motor de custos e fichas técnicas

A precificação foi centralizada em `public/costing.js`, compartilhado pelo navegador e pelos testes Node.js. O módulo calcula custos de ingredientes por lote e por unidade, aceita conversões de massa (`mg`, `g`, `kg`), volume (`ml`, `L`) e contagem (`un`, dúzia), e recusa conversões entre grandezas incompatíveis ou unidades personalizadas diferentes.

- **Unidade de compra:** cadastre o preço na unidade em que o ingrediente é comprado. Exemplo: R$ 38,90/kg. A ficha pode usar 250 g, e o cálculo converte para 0,25 kg.
- **Ficha técnica:** rendimento, descrição, ingredientes, quantidade e unidade usada, embalagem, mão de obra, energia/água/gás e outros custos adicionais. Os quatro custos adicionais são informados por unidade produzida.
- **Precificação:** sugestão de preço pela margem sobre o preço de venda (`custo / (1 - margem)`), limitada a 90%; exibe custo do lote, custo unitário, lucro bruto unitário e margem real do preço informado.
- **Compatibilidade:** fichas antigas sem unidade por ingrediente usam a unidade de compra cadastrada. O custo atual é congelado no pedido ao registrar a encomenda; mudanças posteriores nos preços dos insumos não alteram o histórico do pedido.
- **Snapshot:** ao salvar uma ficha válida, o produto recebe `custo_unitario`, `ficha_version` e `cost_snapshot` com composição e valores calculados. O snapshot representa a última gravação da ficha; depois de alterar o preço de um ingrediente, o custo atual é recalculado na tela e o snapshot é atualizado quando a ficha é salva novamente. Novos pedidos capturam o custo calculado no momento do registro. O JSON é salvo pelo mecanismo de dados já existente; nenhuma tabela nova é necessária.

Execute os testes específicos do motor com:

```bash
npm run test:costing
```

**Limite importante:** o cálculo e a validação da ficha acontecem no navegador. O backend atual persiste o JSON enviado pela conta autenticada, sem recalcular a ficha. Portanto, `custo_unitario`, `cost_snapshot` e custos enviados pelo cliente são dados de gestão editáveis, não um livro contábil ou registro financeiro inviolável. Para documentos fiscais, faturamento ou apuração contábil confiável, será necessária validação/recomputação no servidor e trilha de auditoria adequada.

## Painel administrativo
- Acesse a página separada em `http://localhost:3000/admin`.
- Digite a chave mestra configurada no `.env` (`ADMIN_SECRET_KEY`).
- É possível visualizar todos os clientes, alterar planos manualmente, ativar/bloquear contas e cancelar assinaturas.

## Cardápios e loja virtual
- Acesse **Cardápios** para criar vários cardápios, organizar produtos por seções e incluir descrição, preço e imagem. Salve como rascunho, pré-visualize, oculte itens e publique/retire cardápios do ar.
- Cada cardápio publicado tem um link de vitrine (`/menu/<slug>`). O link principal (`/links/<slug>`) reúne os cardápios publicados e pode ser compartilhado na bio.
- Na mesma área, configure a **Loja virtual**: WhatsApp, Instagram, região/endereço, retirada, entrega, taxa, pedido mínimo, antecedência e instruções.
- A loja pública fica em `/loja/<slug>`, usando o slug principal da confeitaria. O visitante pode montar carrinho e enviar uma encomenda com nome, telefone, data desejada, horário e endereço quando houver entrega.
- O servidor confere a publicação/disponibilidade dos produtos, recalcula os preços a partir do cardápio publicado, aplica a taxa de entrega e grava o pedido com origem `loja_virtual` dentro do tenant correto. O pedido aparece no fluxo interno como `recebido`.
- **Nesta fase não há pagamento online de encomendas.** A confeitaria confirma disponibilidade e combina o pagamento diretamente com o cliente, inclusive pelo WhatsApp. O checkout mensal/vitalício do SaaS permanece separado.
- A disponibilidade de produto é configurada manualmente no editor do cardápio. A capacidade diária de pedidos/unidades configurada na Agenda é consultada na vitrine e verificada novamente no servidor antes de gravar a encomenda. Ainda não há reserva por faixa de horário/equipamento nem baixa automática de estoque.

## Políticas legais — pendentes de revisão
- O documento interno `legal/politicas-rascunho.md` reúne textos-base para Termos de Uso, privacidade/LGPD, armazenamento local e condições comerciais.
- As páginas principal e administrativa exibem escolhas de cookies/armazenamento: aceitar opcionais, rejeitar opcionais ou personalizar. O aviso some após a escolha e pode ser reaberto nas preferências. O cadastro exige uma escolha explícita; rejeitar opcionais não bloqueia o cadastro.
- O aviso está integrado ao cadastro e as preferências do usuário são registradas no banco; o documento legal, porém, continua sendo rascunho interno. Não use como documento final ou aceite até preencher os dados pendentes, alinhar os textos à operação real e obter revisão jurídica.

## Complementos adicionados nesta revisão (com base no mapa Appdora/Dora)

A atualização preserva Node/Express, SQLite e o front-end atual. As tabelas novas são criadas automaticamente na inicialização; bancos existentes recebem as tabelas sem apagar os dados antigos. Os novos registros usam `user_id` e o mesmo endpoint de sincronização por conta já utilizado pelas demais coleções.

- **Tarefas:** criação, responsável, prazo e quadro por estado (a fazer, em andamento, concluída).
- **Orçamentos:** registro por cliente, validade, valor, quantidade estimada de unidades, descrição e data desejada; link público individual para a cliente consultar, aprovar ou recusar. A aprovação cria uma encomenda no KSW e mantém o pagamento em aberto para registro posterior.
- **CRM/fidelidade:** visão resumida do histórico de compras e livro-razão de pontos, com bloqueio de resgate acima do saldo.
- **Cupons:** criação de desconto percentual ou em valor fixo, validade, ativação/pausa e prévia de validação.
- **Dorinha inicial:** alertas determinísticos sobre saldos, entregas atrasadas, estoque baixo e despesas vencidas. Não usa LLM e não executa ações.
- **Auditoria inicial:** trilha das ações realizadas pelos novos módulos (até 500 eventos por conta).
- **Estoque:** entradas e saídas geram histórico; saídas acima do saldo válido são bloqueadas; consumo por produção respeita lotes FEFO e não utiliza lotes vencidos.
- **Resultados:** indicadores gerenciais mensais e exportação de pedidos para CSV.
- **Produção e compras:** lista de pedidos ativos ordenada por entrega, criação de ordens de produção, cálculo de materiais pela ficha técnica, consumo por lotes FEFO, lista de reposição por estoque mínimo e previsão de déficit para pedidos/produções em aberto. A previsão não registra uma compra nem movimenta o estoque; a confeiteira confirma a entrada quando recebe os insumos.

### O que continua pendente antes de chamar o KSW de produto completo

O PDF descreve módulos que dependem de integrações externas, homologações ou arquitetura maior. Eles **não foram simulados nem apresentados como prontos** nesta versão:

1. Multi-loja com memberships, papéis por módulo, RLS, login Google/link mágico e auditoria completa com desfazer.
2. Dorinha com LLM/function calling, importação de PDF/foto, voz, streaming, fila e confirmação segura de ações.
3. Loja virtual da Fase 7 já permite configurar contato, retirada/entrega, região, taxa, pedido mínimo, prazo e instruções; recebe encomendas com carrinho, data desejada e integração com pedidos. A capacidade diária de pedidos/unidades é aplicada a novos pedidos. Permanecem pendentes disponibilidade por horário/equipamento, reserva de estoque, checkout e pagamento online/PIX para encomendas.
4. Orçamento público já permite aceite/recusa por link e conversão transacional em pedido; permanecem pendentes assinatura eletrônica com validade jurídica, PDF, cobrança/registro automático de sinal e reserva de capacidade por horário.
5. A baixa por lotes e o planejamento de produção da Fase 3 já existem. A lista de compras calcula reposição por mínimo e déficit estimado por pedidos/produções em aberto, mas não compra automaticamente, não consulta preços de fornecedores e não reserva estoque no momento em que a loja pública recebe uma encomenda.
6. DRE contábil, contas bancárias, conciliação OFX, projeções 30/60/90 dias e lançamentos financeiros automáticos/idempotentes.
7. iFood: OAuth de parceiro, homologação, webhooks/polling, confirmação de pedidos e logística.
8. PIX para pedidos, carteira/saldo/saque e reconciliação de pagamentos de clientes. Stripe atual é para assinatura do SaaS, não para o checkout da confeitaria.
9. Entregas: zonas geográficas, cálculo por CEP/rota, roteirização, app do entregador, prova de entrega e rastreio.
10. CRM avançado: campanhas, consentimento/opt-out e envio oficial pela WhatsApp Business API, carrinhos abandonados e avaliações.
11. Impressão ESC/POS, agente local, etiquetas, comunidade/fórum e central de ajuda.
12. PDV offline, caixa, KDS e emissão fiscal. A parte fiscal exige provedor, credenciais e validação de contador.

**Limites importantes da implementação nova:** o link de orçamento é uma confirmação comercial simples, não uma assinatura eletrônica com validade jurídica; não cobra sinal automaticamente e não processa PIX/cartão. A validação de cupom é uma prévia e ainda não desconta valores do pedido; pontos são lançados manualmente; os alertas da Dorinha são regras locais; a auditoria nova não cobre automaticamente toda alteração antiga do aplicativo. A tela de resultados é gerencial e não substitui contabilidade.

## Revisão de experiência e tema claro (07/11/2026)

- O tema claro do ambiente autenticado usa paleta blush pastel quente (fundo `#f2eeec`, cartões `#fffaf9`, controles `#fffdfc`, destaque `#91566e` e texto `#3d2e35`) em vez de branco puro. O tema escuro continua separado; a paleta não substitui a identidade da vitrine pública.
- A lista de compras calcula, sem exigir contas manuais, os ingredientes e as embalagens necessários para pedidos em aberto e ordens de produção ativas, usando fichas técnicas e rendimentos. Subtrai o estoque aproveitável e exclui lotes vencidos. Itens sem ficha técnica válida aparecem como pendência.
- A previsão é somente leitura: não registra compra, não baixa estoque e não cria lançamento financeiro. A confeiteira confirma a compra e a entrada real dos insumos.
- O pacote de distribuição agora extrai uma única pasta `KSW_Confeitaria/` e contém guia de instalação. O arquivo não inclui `.env`, banco local, `node_modules` nem uploads particulares.

## Atualização e instalação

1. Faça uma cópia de segurança da pasta e do banco atual antes de atualizar.
2. Extraia o ZIP novo sobre uma pasta de projeto limpa.
3. Copie seu `.env` local para a pasta (o ZIP não contém segredos) e confira as variáveis.
4. Execute `npm install` e depois `npm start`.
5. As tabelas complementares são criadas na inicialização. Mantenha seu arquivo SQLite existente se precisar dos dados antigos; não o publique nem o envie junto ao código.

## Página inicial e painel redesenhados

A página inicial pública em `public/index.html` ganhou uma apresentação responsiva do KSW com introdução do produto, áreas de gestão, fluxo de uso, demonstrações visuais, opções de acesso e perguntas frequentes. As imagens em `public/imagens/` são usadas como capturas de referência do próprio projeto.

O painel da aba **Início** foi reorganizado para destacar faturamento, lucro estimado, pedidos em aberto, valores a receber, pontos de atenção, resumo financeiro, produtos mais vendidos e próximas entregas. Os botões continuam ligados às funções existentes do sistema. O texto da página descreve apenas recursos disponíveis no projeto; o cardápio público é apresentado como vitrine, sem anunciar processamento de pedidos ou pagamentos online.

## Efeitos de rolagem

A página inicial e os principais blocos do painel usam animações suaves de entrada conforme aparecem na tela. Os elementos são revelados com deslocamento, desfoque e transparência discretos; ao saírem da área visível, retornam ao estado inicial para que o efeito se repita quando a pessoa subir e descer novamente. A implementação usa `IntersectionObserver`, acompanha as telas renderizadas dinamicamente e respeita a preferência de acessibilidade `prefers-reduced-motion`.


## Animação da seção de dispositivos

A seção “Onde estiver” da página inicial utiliza quatro recortes transparentes em `public/imagens/` (`device-desktop.png`, `device-laptop.png`, `device-tablet.png` e `device-phone.png`). Cada aparelho entra em sequência, com deslocamento e rotação 3D suaves, encaixa-se na composição e depois mantém uma flutuação discreta.

O efeito é acionado pelo observador de rolagem já existente em `public/ksw-scroll-effects.js`. Ao sair da área visível, as animações são reiniciadas; ao retornar, a montagem acontece novamente. Em dispositivos configurados para reduzir movimento, os aparelhos são exibidos parados. Se o navegador não suportar `IntersectionObserver`, a composição também aparece estática como alternativa.

## Atualização automática da skill de segurança por agentes de IA

O repositório agora contém regras obrigatórias para que agentes de programação mantenham a skill `ksw-security` atualizada após **toda** modificação, incluindo mudanças de interface e documentação. Leia `AGENTS.md` antes de usar qualquer agente.

- Fonte canônica: `.agents/skills/ksw-security/SKILL.md`.
- Cópia do Claude Code: `.claude/skills/ksw-security/SKILL.md`.
- Outras instruções: `CLAUDE.md`, `GEMINI.md`, `.github/copilot-instructions.md` e `.cursor/rules/ksw-security.mdc`.
- `npm run security:skill:sync`: atualiza o fingerprint e sincroniza a cópia do Claude Code; quando detecta alterações, cria uma linha de revisão pendente que o agente deve substituir por um resumo real.
- `npm run security:skill:check`: valida fingerprint, igualdade das cópias e se a revisão pendente foi concluída.
- `npm run security:skill:guard`: compara uma impressão digital SHA-256 do projeto e falha quando algum arquivo acompanhado mudou sem atualizar a skill.
- `npm test`, `npm start` e `npm run dev`: executam o guard automaticamente antes dos comandos.
- Pull requests passam pelo workflow `.github/workflows/require-security-skill-update.yml`, que exige alteração e sincronização das duas cópias.

A impressão digital funciona mesmo quando a pasta não possui Git. Ela ignora `.env`, bancos locais, logs, caches, backups e dependências instaladas; acompanha código, testes, configurações, documentação, dependências declaradas e assets. Nenhum desses mecanismos substitui a revisão semântica: o agente precisa registrar os impactos reais e nunca inventar controles ou evidências.


## Fase 3: estoque por lotes, embalagens e produção

- **Novas coleções:** `embalagens`, `lotes`, `producao` e `perdas`; `mov` agora identifica `item_tipo` e `item_id`, mantendo compatibilidade com movimentos antigos de ingredientes. As tabelas são criadas/migradas sem apagar dados existentes.
- **Lotes e validade:** entradas de ingredientes e embalagens criam lotes com quantidade, unidade, custo de compra, data de recebimento e validade opcional. Saídas manuais e produção usam FEFO (vence primeiro, sai primeiro); lotes vencidos não são usados. Saldos antigos sem lote continuam disponíveis como estoque legado. O fuso das validações de data usa `KSW_TIME_ZONE` (padrão `America/Sao_Paulo`).
- **Embalagens:** estoque independente, custo unitário e vínculo opcional com a ficha técnica do produto. O custo da embalagem vinculada é somado ao custo unitário e a produção baixa a quantidade configurada por unidade produzida.
- **Produção:** ordens podem ser criadas a partir de itens de pedidos abertos ou manualmente. O rendimento da ficha técnica determina quantos lotes completos são necessários; o sistema informa a quantidade final produzida quando há arredondamento para cima.
- **Consumo protegido no servidor:** `POST /api/production/:id/consume` exige login e assinatura ativa, obtém o proprietário pelo JWT, calcula materiais no servidor e atualiza estoque, lotes, movimentos e ordem na mesma transação SQLite. Uma ordem não pode aplicar o mesmo consumo duas vezes.
- **Desperdício:** `POST /api/production/waste` registra motivo, data, quantidade e custo estimado, aplica FEFO e reduz estoque na mesma transação. Quantidades negativas, datas impossíveis/futuras, lotes vencidos e saldo insuficiente são rejeitados. As rotas de consumo/perda têm limite de 60 operações por usuário por minuto.
- **Custo real de consumo:** movimentos de produção/perda e desperdício calculam o valor pelos custos unitários dos lotes efetivamente consumidos, usando o preço atual do item apenas para saldo legado sem lote.
- **Pedidos com linhas repetidas:** itens do mesmo produto no mesmo pedido são agrupados antes de criar a ordem, evitando subplanejamento.
- **Compatibilidade:** estoque inicial/manual anterior permanece como saldo legado mesmo sem lote. Novas entradas criam lotes para permitir rastreabilidade progressiva. Não existe migração artificial de saldo antigo para lote porque não há dados históricos confiáveis de validade.

Testes específicos:

```bash
npm run test:costing
npm run test:production
npm test
```

**Limites:** FEFO é aplicado a lotes registrados; estoque legado sem lote não tem rastreabilidade de validade. A agenda não substitui ficha de apontamento de produção real, e quantidades produzidas são estimadas por lotes inteiros. O registro de consumo/perda é transacional no servidor, mas ajustes de entrada/saída feitos pela tela continuam sendo sincronizados pelo endpoint genérico de dados. SQLite não oferece RLS: a proteção depende de filtros `user_id` na aplicação e testes de isolamento entre contas.


## Fase 4 — Dashboard BI e relatórios gerenciais

A aba **Resultados** reúne indicadores por competência mensal, tendência dos últimos seis meses, produtos com maior faturamento, despesas por categoria, resultado de caixa e custo registrado de perdas. O relatório pode ser exportado como CSV UTF-8 compatível com Excel/LibreOffice ou impresso/salvo como PDF pelo navegador.

- Testes específicos: `npm run test:analytics`
- Suíte completa: `npm test`
- Regras e limitações: `docs/FASE_4_DASHBOARD_BI.md`

Os valores são gerenciais estimados. Custos históricos dependem do custo congelado em cada item do pedido; itens sem custo são sinalizados. O CSV é compatível com Excel, mas não é um arquivo XLSX nativo. O PDF é gerado pelo recurso de impressão do navegador.


## Fase 5 — Multiempresa, equipe e permissões

O KSW agora possui espaços de trabalho (tenants) independentes. Cada nova conta cria uma empresa e entra como proprietária. O proprietário ou um administrador pode criar convites por e-mail; o link é compartilhado manualmente e expira em sete dias. O token fica no fragmento `#convite=` e é removido da barra de endereço após ser guardado na sessão do navegador; links antigos com `?convite=` continuam aceitos. A pessoa convidada precisa autenticar-se com o mesmo endereço de e-mail para aceitar. Após o aceite, ela pode alternar entre as empresas das quais participa.

- **Empresas e membros:** tabelas `tenants`, `tenant_memberships`, `tenant_invitations` e `tenant_audit_logs`; lista de empresas em `/api/tenants/mine`, contexto em `/api/tenants/current`, convites e gestão de membros no mesmo router.
- **Seleção de empresa:** o navegador envia `X-Tenant-ID` nas chamadas privadas. Esse identificador é apenas uma seleção; o servidor verifica a associação ativa em `tenant_memberships` a cada rota protegida. A ausência de associação resulta em `403 TENANT_ACCESS_DENIED`.
- **Papéis:** `owner`, `admin`, `manager`, `member` e `viewer`. O proprietário controla a assinatura e pode atribuir administradores; administradores podem gerir equipe sem assumir a cobrança; gerente pode gerir operações e finanças; membro pode operar dados do dia a dia; visualizador tem leitura, sem escrita.
- **Dados financeiros:** `despesas` e `fornecedores` são devolvidos somente a papéis com `finance.read` e aceitam gravação apenas com `finance.write`. O menu Financeiro e a aba Resultados são ocultados no frontend para papéis sem leitura financeira; o backend também filtra leitura/exportação e rejeita escritas não autorizadas.
- **Isolamento no banco:** as coleções de gestão usam `tenant_id` e chave primária `(tenant_id, id)`. Isso permite que o mesmo identificador de registro exista em empresas diferentes, sem colisão. `menus`, `menu_hubs`, pedidos de produção e sincronização também são filtrados pelo tenant.
- **Migração retrocompatível:** cada conta antiga recebe sua própria empresa proprietária; seus registros e cardápios recebem o `tenant_id` correspondente. A migração das tabelas de gestão é transacional. A preparação do schema adiciona `tenant_id` em bancos legados antes de criar índices compostos; a suíte possui teste de regressão dessa ordem. Se encontrar registros órfãos sem usuário/empresa, ela interrompe e faz rollback, em vez de atribuir esses dados a uma empresa arbitrária.
- **Assinatura:** a cobrança continua vinculada ao usuário proprietário. Os membros herdam a situação da assinatura da empresa selecionada; não recebem acesso por serem apenas usuários autenticados.
- **Cache local:** o cache é separado por empresa e usuário. O cache global legado sem identificação não é importado automaticamente, para evitar mistura de dados em computadores compartilhados. O cache individual `ksw-db:<userId>` só é considerado na empresa própria do usuário.

### Papéis e capacidades

| Capacidade | Proprietário | Admin | Gerente | Membro | Visualizador |
|---|---:|---:|---:|---:|---:|
| Ler e gravar dados operacionais | Sim | Sim | Sim | Sim | Leitura |
| Ler e gravar financeiro | Sim | Sim | Sim | Não | Não |
| Gerenciar equipe | Sim | Sim* | Não | Não | Não |
| Ler equipe e convites | Sim | Sim | Sim | Não | Não |
| Alterar nome da empresa | Sim | Sim | Não | Não | Não |
| Gerenciar cobrança | Sim | Não | Não | Não | Não |

\* Administradores não podem atribuir o papel de administrador, alterar/remover o proprietário nem alterar/remover outro administrador. Apenas o proprietário pode atribuir o papel `admin`.

### Rotas principais

- `GET /api/tenants/mine` — empresas das quais a conta participa.
- `GET/PATCH /api/tenants/current` — consultar/alterar o nome da empresa atual.
- `GET/POST /api/tenants/invitations` — listar/criar convites.
- `POST /api/tenants/invitations/accept` — aceitar convite autenticado.
- `GET /api/tenants/members` — listar equipe.
- `PATCH/DELETE /api/tenants/members/:userId` — alterar papel/remover membro.
- `DELETE /api/tenants/invitations/:id` — revogar convite.

### Testes

```bash
npm run test:tenants
npm test
```

`tenants.test.js` valida a migração com as 17 coleções reais, idempotência, rollback de órfãos, chave primária por empresa, IDs iguais em tenants distintos, permissões e validação de associação no middleware. `smoke-test.js` cobre também criação/aceite de convite, negação de tenant alheio e bloqueio de leitura/escrita financeira para membro.

### Limites e segurança residual

- SQLite não possui RLS nativo. O isolamento é feito na aplicação com `tenantContextMiddleware`, filtros `tenant_id` e testes; A01 permanece **PARCIAL** até revisão independente e teste com o driver nativo na plataforma de produção.
- As permissões de coleção são finas para dados financeiros; as demais coleções de operação compartilham a permissão geral `data.read`/`data.write`. Não é ainda uma matriz de permissão por botão/campo/tarefa.
- O convite gera link seguro com token aleatório armazenado apenas em hash, mas o link é exibido para cópia manual; não há envio de e-mail integrado nesta fase.
- A assinatura é do proprietário da empresa. Não há cobrança independente por tenant adicional nem criação de um segundo espaço próprio pela mesma conta nesta tela; a participação em outras empresas ocorre por convite.
- `tenant_audit_logs` registra ações de equipe/empresa, mas a auditoria geral de todas as operações ainda não é imutável nem completa.
- Super Admin global, revisão de pagamentos por empresa e gestão de planos por tenant são fases posteriores.
- Faça backup do SQLite antes da primeira inicialização com esta versão. A migração pode reconstruir as tabelas de gestão para alterar a chave primária, preservando as linhas conhecidas; não substitua o banco original sem cópia.

## Super Admin da plataforma (Fase 6)

A rota `/admin` agora oferece uma central de controle para empresas, usuários, assinaturas, catálogo de planos e auditoria. A chave `ADMIN_SECRET_KEY` é usada somente para iniciar uma sessão curta; o painel não a grava no `localStorage`. O servidor emite cookie `HttpOnly`, `SameSite=Strict`, escopado às rotas administrativas e revogável no logout. Escritas administrativas exigem `Origin` do mesmo host (HTTPS em produção), e as respostas do painel são marcadas como não armazenáveis em cache.

- **Empresas:** busca, detalhes, membros e suspensão/reativação. A suspensão bloqueia o acesso autenticado e oculta cardápios/vitrines públicas, mas preserva os dados e não cancela cobranças.
- **Assinaturas:** o administrador pode ajustar o acesso local do proprietário. Essa operação não altera assinaturas/cobranças em Stripe ou Mercado Pago.
- **Planos:** o painel permite criar planos adicionais por nome, descrição, preço e periodicidade. O backend cria o produto e o preço na Stripe, salva os respectivos IDs e disponibiliza o plano no checkout público. Para alterar o preço, crie um novo plano/preço, preservando as cobranças existentes.
- **Status de acesso:** as listas distinguem status operacional da empresa de situação da assinatura. Planos mensais vencidos ou sem data de validade são mostrados como vencidos; pagamentos únicos não expiram mensalmente.
- **Login:** a entrada é por e-mail e senha. Novos cadastros são concluídos imediatamente, sem confirmação de e-mail (temporariamente desativada); o nome de usuário interno permanece para compatibilidade e organização de registros.
- **Indicadores:** MRR é estimado; receita aprovada soma pedidos registrados com status `approved` e não representa lucro/caixa conciliado.
- **Auditoria:** ações administrativas são registradas em `platform_audit_logs`, tabela SQLite que não é imutável.

A documentação técnica detalhada está em `docs/FASE_6_SUPER_ADMIN.md`. Testes específicos: `npm run test:platform-admin` e `npm run test:platform-admin-schema`; a suíte geral permanece `npm test`.


## Auditoria funcional e roadmap

A lista de funcionalidades existentes, limitações verificadas e prioridades de evolução está em [`docs/AUDITORIA_FUNCIONAL_KSW.md`](docs/AUDITORIA_FUNCIONAL_KSW.md). A auditoria diferencia cálculo automático (feito pelo sistema) de dados reais que precisam ser informados pela confeiteira.

## Loja virtual e encomendas (Fase 7)

- **Configuração:** em **Cardápios → Loja virtual**, o proprietário/admin/gerente com `menus.manage` define ativação, WhatsApp, Instagram, região/endereço, retirada, entrega, taxa, pedido mínimo, prazo mínimo e instruções. A loja nasce desativada.
- **Catálogo:** `/loja/<slug>` carrega somente cardápios publicados da empresa resolvida pelo slug. Seções/produtos ocultos não são exibidos; produtos marcados indisponíveis aparecem sem botão de adicionar.
- **Carrinho:** permite quantidade por produto, resumo, pedido mínimo e taxa de entrega. A data desejada respeita o prazo mínimo configurado.
- **Encomenda:** o endpoint público `POST /api/storefront/public/:slug/orders` valida dados, método, endereço, data, produtos publicados/disponíveis, quantidade e preço no servidor. O preço enviado pelo navegador é ignorado.
- **Integração interna:** o pedido é gravado em `pedidos` e o cliente é criado/atualizado em `clientes`, sempre com `tenant_id` resolvido pelo slug; a origem é `loja_virtual` e o status inicial é `recebido`. Os valores incluem taxa de entrega em `taxa_entrega` e no total.
- **Idempotência:** `storefront_order_requests` tem unicidade por `tenant_id` e chave; `request_hash` distingue uma repetição real de uma mesma chave usada com dados diferentes. O hash não armazena o payload em texto, mas deve ser tratado como metadado relacionado ao pedido.
- **Abuso:** o endpoint aplica honeypot, bloqueia `Sec-Fetch-Site: cross-site`, exige origem do mesmo host (ou `BASE_URL`) e HTTPS em produção, limite de 12 pedidos por IP a cada 10 minutos e expurgo das chaves antigas após 90 dias. Em desenvolvimento, Origin ausente é aceito; em produção é obrigatório. Atrás de proxy TLS, configure `TRUST_PROXY=1`. O rate limiter é em memória por processo; em múltiplas instâncias use um store compartilhado.
- **Limites desta fase:** não há cobrança online/PIX para pedidos de clientes, confirmação automática, capacidade máxima por data, zona por CEP/rota, reserva de estoque, nem baixa automática pela ordem pública. Pagamentos de assinatura do KSW não foram alterados.
- **Dados pessoais:** a loja solicita nome, telefone, e-mail opcional e endereço de entrega. Antes de publicar em produção, revise/publice a política de privacidade e informe finalidade, retenção e canal para solicitações de titulares. Use HTTPS e acesso restrito ao banco/backup.
- **Testes:** `npm run test:storefront` valida regras de configuração, preço calculado no servidor, taxa, data, produtos indisponíveis, limites, mínimo e fingerprint de idempotência; `scripts/storefront-schema.test.js` valida criação, migração retrocompatível e unicidade por tenant.


## Planos, equipe e cadastro

- O plano mensal padrão permite pelo menos 3 acessos no total por empresa (proprietário incluído) e inclui gestão de equipe.
- O plano anual fica inicialmente como rascunho inativo, com limite de 3 acessos, porque o preço anual precisa ser definido no Super Admin.
- O plano vitalício inclui todas as funcionalidades cadastradas, chat privado com a administração e acessos ilimitados.
- O teste gratuito oferece 7 dias com todos os recursos, incluindo equipe e chat administrativo; a contagem começa no momento do cadastro (confirmação de e-mail temporariamente desativada).
- O Super Admin permite criar, editar, ativar/desativar e remover logicamente planos, definir limite de pessoas e selecionar funcionalidades. Funcionalidades personalizadas recebem uma descrição comercial automática, mas isso não cria um módulo técnico novo.
- O limite de pessoas inclui a proprietária. Convites pendentes reservam vagas para impedir que convites simultâneos ultrapassem o limite.

### Confirmação de e-mail (temporariamente desativada)

O cadastro cria imediatamente o usuário e a empresa, inicia o teste gratuito de 7 dias e autentica a pessoa sem depender de envio de e-mail. A coluna `email_verified` é marcada como verdadeira para novos cadastros. O módulo de envio e as rotas antigas de confirmação permanecem no código para uma possível reativação futura, mas não fazem parte do fluxo atual de cadastro/login.

### Observação sobre funcionalidades personalizadas

O catálogo permite liberar os módulos técnicos existentes no KSW por plano. Ao adicionar um rótulo personalizado, o sistema gera automaticamente uma descrição comercial, mas isso não cria código ou um novo módulo: integrações e recursos inéditos precisam ser desenvolvidos e testados separadamente. O limite de pessoas inclui o proprietário da empresa.
