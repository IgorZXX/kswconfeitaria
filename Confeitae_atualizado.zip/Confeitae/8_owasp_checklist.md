# OWASP Checklist - Confeitaria SaaS Foundation

> **Nota sobre o runtime verificado em 2026-11-05:** o KSW desta entrega usa SQLite (`sqlite3`) e JWT Bearer no corpo da resposta, armazenado pelo frontend no `localStorage`. Não usa PostgreSQL/RLS, driver `pg`, nem fluxo de refresh token em cookie HttpOnly. Os itens abaixo são requisitos e estados de conformidade, não declarações genéricas de que todos os controles estejam concluídos.

- [ ] **A01: Broken Access Control** — o runtime agora aplica isolamento multiempresa por `tenant_id` em `routes/data.js`, `routes/production.js` e `routes/menus.js`; `middleware/tenant.js` valida membership ativa e `lib/tenant-permissions.js` aplica papéis no servidor. Não há RLS no SQLite. A proteção depende de filtros em cada rota, operações operacionais ainda usam permissões gerais e a matriz completa de módulos/exportações requer revisão independente. Testes cobrem migração A/B, seleção indevida de tenant e parte dos fluxos HTTP de convite/equipe.
- [ ] **A02: Cryptographic Failures** — senhas usam `bcryptjs`; JWT é assinado pelo segredo central. O access token observado expira em 7 dias e é armazenado em `localStorage`; não há refresh token HttpOnly/rotação/revogação. Rever duração de sessão, XSS/armazenamento e transporte HTTPS antes de declarar conformidade.
- [x] **A03: Injection** — queries SQL usam placeholders; nomes de tabelas/colunas em rotas de gestão são escolhidos por allowlists constantes do servidor; a nova rota de produção usa nomes fixos e valores parametrizados. Há teste de texto semelhante a SQL injection na API de dados e validações de entrada na rota de desperdício/produção.
- [ ] **A04: Insecure Design** — há rate limit nas rotas de autenticação, convite (20/hora por empresa) e limite de 60 movimentações por empresa por minuto nas rotas de produção/perdas; a baixa é transacional/idempotente por ordem e valida quantidade, data e saldo. Os limitadores são em memória por processo, não protegem volume agregado em múltiplas instâncias; aceite de convite e outras superfícies ainda precisam de modelagem de abuso e store compartilhada.
- [ ] **A07: Identification and Authentication Failures** — middleware valida assinatura e expiração JWT. A validade observada de 7 dias excede o requisito de referência de 15 minutos; não há refresh token, rotação ou revogação de sessão.
- [ ] **A09: Security Logging and Monitoring Failures** — existem registros de auditoria de equipe/configuração por `tenant_id` e movimentos de estoque; isso não equivale a trilha append-only inviolável nem cobre todas as alterações sensíveis. A consulta completa, monitoramento e retenção ainda precisam de revisão.

O script `npm run stripe:products` cria recursos somente no modo de teste. Antes de produção, crie os preços da conta live e use IDs e chave live em um processo separado e revisado.

## Dados na nuvem (Fase 1)

Antes, ingredientes, receitas, clientes e pedidos ficavam só no `localStorage` do navegador: trocar de aparelho ou limpar o cache apagava tudo. Agora ficam no servidor, separados por usuária.

- **Tabelas:** `clientes`, `ingredientes`, `embalagens`, `lotes_estoque`, `ordens_producao`, `perdas_estoque`, `produtos`, `pedidos`, `despesas` e `movimentacoes_estoque`, além das coleções restantes de gestão. Chave primária `(user_id, id)`: uma conta não lê nem sobrescreve registros de outra por essas rotas.
- **API** (`routes/data.js`): `GET /api/data`, `POST /api/data/sync` (operações `put`/`del` em transação) e `GET /api/data/export`. A leitura/exportação permanece disponível mesmo com assinatura vencida; a escrita exige assinatura ativa.
- **Front-end:** o app sincroniza apenas registros alterados e usa cache local por usuária. O cache offline segue sujeito ao comportamento de última gravação por registro quando duas sessões alteram o mesmo dado.

## Fase 3: estoque por lotes e produção

- A baixa de consumo de produção e o registro de perda usam `routes/production.js`, middleware de autenticação/assinatura e transação SQLite.
- Cada consulta de ordem, produto, ingrediente, embalagem e lote filtra pelo `req.user.id` validado no JWT. Nenhum `user_id` é aceito do corpo da requisição.
- Identificadores SQL vêm de definições estáticas (`db.DATA_TABLES`); IDs e quantidades são validados; os valores SQL são parametrizados.
- A mesma ordem não pode aplicar consumo duas vezes (`consumo_aplicado`). Se algum ingrediente/embalagem estiver sem saldo válido ou tiver apenas lotes vencidos, a transação inteira é revertida. As rotas aplicam limite de 60 requisições/minuto por usuário autenticado.
- FEFO considera primeiro a validade mais próxima; saldo antigo sem lote permanece como saldo legado e não tem rastreabilidade de validade. O custo de consumo usa o custo unitário de cada lote baixado; para o saldo legado usa o preço atual cadastrado no item.
- **Risco residual:** ajustes manuais de entrada/saída e sincronização genérica ainda são operações por JSON do cliente; a baixa da produção/perda é server-side, mas o endpoint genérico de sincronização ainda permite a um membro autorizado substituir registros operacionais de sua empresa. O isolamento multiempresa e permissões por papel foram introduzidos na Fase 5, mas permanecem dependentes da aplicação/SQLite (sem RLS), com permissões operacionais gerais; os limitadores são por processo e a trilha de auditoria não é inviolável.

## Comandos de validação

```bash
npm run security:skill:check
npm run security:skill:guard
npm run test:costing
npm run test:production
npm test
```


## Loja virtual pública (Fase 7)

- **A01 — PARCIAL:** `routes/storefront.js` resolve o tenant exclusivamente pelo slug de `menu_hubs`, exige tenant ativo e assinatura ativa, e insere clientes/pedidos com `tenant_id` derivado no servidor. Configurações são protegidas por autenticação, `tenantContextMiddleware` e `menus.read`/`menus.manage`. A API pública não aceita `tenant_id` do navegador. Ainda falta teste HTTP de ponta a ponta com o driver `sqlite3` nativo na plataforma alvo.
- **A02 — PARCIAL:** o pedido público guarda nome, telefone, e-mail opcional, endereço, observações e itens no SQLite da empresa. Nenhum dado de cartão ou credencial de pagamento é coletado; não há pagamento online nesta fase. Exija HTTPS em produção, proteja backup/acesso ao arquivo SQLite e publique aviso/política de privacidade apropriados antes de abrir a loja.
- **A03 — PASSOU nos testes de regra/schema, PARCIAL na integração:** a rota usa SQL parametrizado e o preço é sempre lido dos cardápios publicados no servidor; valores de preço enviados pelo cliente não são usados. `lib/storefront-engine.js` valida identificadores e quantidades, e gera fingerprint SHA-256 da intenção normalizada para idempotência. Não há SQL dinâmico construído com campos do pedido.
- **A04 — PARCIAL:** endpoint público limita a 12 pedidos por IP/10 minutos, usa honeypot, nega `Sec-Fetch-Site: cross-site`, exige `Origin` e HTTPS em produção (Origin ausente só é aceito em desenvolvimento), exige chave de idempotência de 16–80 caracteres, unicidade por tenant, hash da intenção e transação para gravar cliente/pedido. Atrás de proxy TLS, `TRUST_PROXY=1` deve estar configurado para Express reconhecer HTTPS. O limiter em memória só cobre uma instância; para escala horizontal use store compartilhado. A loja pública agora aplica limites diários de pedidos/unidades definidos na Agenda. Não há CAPTCHA nem moderação humana automatizada.
- **A05 — PARCIAL:** configurações públicas não incluem tenant ID ou detalhes de assinatura; mensagens públicas não expõem dados internos. A página é servida pelo mesmo SPA e o catálogo usa escaping para texto/atributos. Imagens externas usam URLs HTTP/HTTPS vindas do cardápio; avalie permitir HTTPS apenas em produção para evitar conteúdo misto.
- **A09 — PARCIAL:** a encomenda fica no histórico de pedidos com `origem: loja_virtual`, e a chave/hash de idempotência fica em tabela própria com retenção de 90 dias. Não há evento dedicado na auditoria de plataforma/equipe para cada encomenda pública; desenhar retenção e auditoria de acesso aos dados de clientes continua pendente.

**Testes específicos:** `npm run test:storefront` cobre regras de negócio, validação do pedido, fingerprint e schema (incluindo migração de tabela legada e unicidade por empresa). A execução HTTP com Express/driver nativo deve ser repetida após `npm ci` em Windows/Linux de destino; não marque a integração como PASSOU sem essa execução.


## Orçamento público com aceite online (2026-11-08)

- **A01 — PARCIAL:** `POST /api/quotes/share` exige JWT, membership/tenant resolvido no servidor, assinatura ativa, `data.write` e feature `quotes`; a cliente do orçamento é validada dentro do tenant. As rotas públicas recebem apenas token opaco, fazem hash SHA-256 e buscam a associação `tenant_id + quote_id` no servidor; não aceitam `tenant_id` no corpo. O sincronizador `/api/data/sync` preserva estados públicos finais para evitar que caches antigos revertam aprovação/recusa e protege propostas respondidas contra exclusão. Isolamento depende de filtro na aplicação/SQLite, sem RLS, e a integração HTTP A/B ainda requer homologação.
- **A02 — PARCIAL:** token gerado com `crypto.randomBytes(32)`; apenas o SHA-256 é persistido; validade limitada à data do orçamento e novo link substitui o hash anterior. O link é bearer-capability: qualquer pessoa que possua o endereço pode responder. POST de decisão exige origem same-origin e HTTPS em produção, mas a entrega real depende de `BASE_URL` HTTPS, proxy confiável quando aplicável e configuração TLS correta.
- **A03 — PASSOU nos testes unitários/schema; PARCIAL na integração:** consultas usam placeholders, tabelas/colunas são constantes e campos de texto são limitados/normalizados no backend. `json_extract` consulta apenas o campo fixo `$.cli` no JSON do orçamento. Não há SQL montado com conteúdo de cliente. Ainda falta teste HTTP com o runtime/driver nativo do ambiente de hospedagem.
- **A04 — PARCIAL:** leitura pública limitada a 40 req/10 min por IP; decisões limitadas a 8 req/10 min por IP; POST aceita somente `accept`/`reject`, exige confirmação explícita para aceitar, compara validade e executa atualização do orçamento, criação do pedido e estado do link na mesma transação. Aprovação repetida retorna o pedido existente e não duplica encomendas. Rate limit em memória é por processo; com múltiplas instâncias use store compartilhado.
- **A09 — PARCIAL:** o orçamento recebe status, data de resposta e `pedido_id`; o pedido recebe `origem: orcamento_online` e `orcamento_id`. Não é uma trilha append-only, não registra evento independente de auditoria do servidor nem prova a identidade de quem recebeu o link.

**Testes desta entrega:** `node --test scripts/quote-public.test.js scripts/quote-schema.test.js scripts/quote-ui.test.js` passou 13/13. Sintaxe dos arquivos JS alterados foi verificada por `node --check`. `npm test`, integração HTTP, browser real, HTTPS e homologação multi-instância precisam ser executados no ambiente com dependências/runtime compatíveis.
