# Instruções para Claude Code

Leia `AGENTS.md` e siga todas as regras. Antes de qualquer edição, leia `.agents/skills/ksw-security/SKILL.md`. Depois de toda alteração no projeto, atualize essa fonte canônica, registre a revisão datada mesmo quando não houver impacto de segurança, execute `npm run security:skill:sync` e `npm run security:skill:check`. A verificação compara uma impressão digital SHA-256 do projeto, portanto também funciona em pastas sem Git. Não conclua a tarefa sem essa sincronização. Consulte `AGENTS.md` para os comandos, evidências e restrições obrigatórios.
