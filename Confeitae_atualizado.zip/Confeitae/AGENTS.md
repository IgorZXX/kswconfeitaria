# Instruções obrigatórias para agentes de IA — Confeitaê

Estas regras valem para qualquer agente de programação que altere este repositório.

## Regra permanente: manter a skill de segurança atualizada

**Antes de editar qualquer arquivo do projeto**, leia por completo:

- `.agents/skills/ksw-security/SKILL.md` — fonte canônica da skill;
- as instruções deste arquivo;
- os arquivos e testes relacionados à tarefa.

**Depois de toda modificação no projeto, atualize a skill antes de concluir a tarefa.** Isso se aplica a código, rotas, banco, migrações, dependências, configurações, testes, documentação, HTML/CSS/JavaScript e recursos visuais.

1. Revise o diff e identifique se a mudança alterou fluxos de dados, autenticação, autorização, isolamento de contas, pagamentos, integrações, logs, segredos, dependências ou superfície de ataque.
2. Atualize `.agents/skills/ksw-security/SKILL.md` com os novos padrões, arquivos relevantes, ameaças, controles, comandos de teste e limitações identificados.
3. Mesmo quando a mudança não alterar a postura de segurança, **registre uma revisão datada na seção “Histórico de atualização da skill”**: arquivos/áreas revisados, avaliação de impacto e motivo pelo qual os controles permaneceram iguais. Não invente garantias ou testes.
4. Sincronize a cópia do Claude Code executando `npm run security:skill:sync` (a fonte canônica é a cópia em `.agents`).
5. Valide a igualdade das cópias com `npm run security:skill:check`.
6. Execute `npm run security:skill:guard`, `npm run security:skill:check` e `npm test`, além dos testes específicos relevantes. O guard compara uma impressão digital SHA-256 dos arquivos do projeto (independente de existir Git) e falha se qualquer arquivo acompanhado mudar sem nova sincronização da skill.
7. Na resposta final, informe que a skill foi atualizada, quais seções mudaram e quais testes realmente foram executados. Se não conseguiu atualizar ou testar, declare isso claramente.

Não finalize uma tarefa com alterações no projeto sem atualizar a skill. Não marque controles OWASP como `PASSOU` sem implementação identificada e teste relevante executado. Nunca copie valores de `.env`, tokens, cookies, senhas, chaves ou dados pessoais para a skill, documentação, testes ou logs.

## Regras gerais de implementação

- Preserve a arquitetura e compatibilidade existentes. Não migre SQLite para PostgreSQL nem troque provedores sem pedido explícito.
- Leia o código real antes de confiar na documentação.
- Faça alterações pequenas, com validação de entrada e autorização no backend.
- Proteja os dados de cada conta; não confie em identificadores ou permissões enviados pelo navegador.
- Use credenciais fictícias e banco temporário nos testes. Nunca teste contra produção sem autorização explícita.
- Não enfraqueça controles de segurança para fazer um teste passar.

## Princípio permanente de utilidade para a confeiteira

Toda funcionalidade, conta, alerta ou automação deve ser julgada pelo efeito prático na rotina de uma confeitaria, e não apenas por parecer tecnicamente completa. Ao alterar custos, preços, pedidos, produção, estoque ou financeiro:

- Use exemplos realistas por lote, por unidade e por encomenda; confira conversões de g/kg, ml/L, dúzias e rendimento antes de exibir resultados.
- Diferencie lucro/contribuição após custos diretos de lucro líquido: despesas fixas, tributos, taxas, entrega, desperdício e mão de obra só entram quando houver dados e regra explícita.
- Nunca transforme dado ausente em zero silenciosamente. Mostre o que falta, qual parte da conta ficou de fora e se o valor exibido é mínimo/parcial.
- Quando uma receita ou encomenda tiver contribuição negativa, informe a perda por unidade e no volume daquela encomenda, sinalize antes da confirmação e recomende uma ação concreta (rever preço, porção, rendimento, fornecedor, ingrediente, embalagem ou taxa).
- Quando os dados forem insuficientes para concluir, diga que não é possível determinar o lucro/prejuízo completo; não invente um valor nem recomende um preço como definitivo.
- Prefira fluxo simples: a confeiteira cadastra ingredientes, quantidades, rendimento e preços uma vez; o KSW calcula, acompanha mudanças e explica o próximo passo em linguagem comum. Evite exigir contas manuais ou conhecimento contábil.

## Comandos de manutenção da skill

```bash
npm run security:skill:sync   # atualiza o fingerprint, exige registro de impacto e sincroniza o Claude
npm run security:skill:check  # verifica fingerprint, revisão concluída e cópias idênticas
npm run security:skill:guard  # detecta mudanças em arquivos acompanhados, mesmo sem Git
npm test                      # executa o guard automaticamente antes da suíte existente
```
