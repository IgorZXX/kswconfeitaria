# Instruções para Gemini CLI

Siga `AGENTS.md` em todas as alterações. Leia `.agents/skills/ksw-security/SKILL.md` antes de editar e atualize-a após toda modificação do projeto. Registre uma revisão datada mesmo quando o impacto de segurança for nulo; depois execute `npm run security:skill:sync` e `npm run security:skill:check`. Consulte `AGENTS.md` para o fluxo completo e não declare testes/controles sem evidência.
