---
name: ksw-ux-quality
description: "Use ao criar, corrigir ou revisar telas, navegação, botões, formulários, dashboards e fluxos do KSW; priorize utilidade real para confeiteiras e clareza de uso."
---

# Qualidade de experiência do KSW

## Princípio obrigatório

Antes de cada alteração de interface, pergunte:

1. **Por que isso é útil para nossas usuárias?** Qual tarefa real da confeiteira fica mais simples, rápida ou confiável?
2. **Está fácil de entender e encontrar?** O rótulo descreve a ação, o resultado esperado é previsível e o estado atual fica evidente?
3. **A alteração merece existir?** Ela resolve um problema observado sem acrescentar ruído, etapas ou métricas de pouco valor?
4. **Como vou confirmar que funciona?** Escolha uma interação reproduzível e teste também os estados vazios, de erro e carregamento relevantes.

Se não houver uma resposta concreta para utilidade e validação, não adicione a interface. Prefira remover, simplificar ou esclarecer em vez de acumular controles.

## Aplicação no KSW

- Leia a implementação atual antes de desenhar uma alternativa. Preserve padrões visuais e navegação existentes quando ajudam as usuárias.
- Use referências de concorrentes como inspiração, não como requisito de cópia. Adapte somente recursos que atendam uma tarefa real e use dados que o KSW realmente possui.
- Não invente contagens, estados, datas, disponibilidade, margens ou resultados. Dê nomes precisos aos indicadores e explique estimativas, dados ausentes e limites.
- Para atalhos, escolha um destino existente e útil. Se o destino não estiver implementado, não apresente o botão como se concluísse a tarefa; implemente o fluxo necessário ou deixe a limitação explícita.
- Cada botão deve ter um rótulo claro, ação funcional e feedback adequado. Evite controles que não fazem nada, links sem destino ou ações que falham silenciosamente.
- Mantenha a navegação sincronizada com o conteúdo: item atual, cabeçalho, subárea selecionada e estado móvel devem refletir a mesma rota, inclusive durante carregamento e em falhas.
- Use mensagens curtas em português simples. Informe o que aconteceu e, quando útil, como corrigir; não dependa somente de cor ou ícone.
- Verifique teclado, foco visível, nomes acessíveis, áreas de toque, responsividade e `prefers-reduced-motion`. Não sacrifique clareza ou acessibilidade por decoração.
- Não persista dados de demonstração nem provoque ações destrutivas durante verificações manuais.

## Fluxo de trabalho

1. Descreva a tarefa da usuária e o problema observado com evidência do código ou da interface.
2. Localize o comportamento em todas as telas afetadas; procure estados duplicados ou ações que redirecionam para o módulo errado.
3. Escolha a menor mudança que conclui a tarefa e deixa explícitas as limitações.
4. Acrescente ou ajuste uma regressão para o comportamento esperado, especialmente para navegação, origem dos dados e ações que antes eram inertes.
5. Teste o fluxo completo no navegador quando disponível: iniciar na página anterior, acionar o controle, confirmar destino/estado/feedback e testar retorno.
6. Revise visualmente em largura móvel e desktop; confirme que não há erro no console nem mudança inesperada de contexto.

## Perguntas para a revisão final

- Uma confeiteira que não conhece a implementação entende o que esse controle faz?
- A interface a leva diretamente à tarefa, sem obrigá-la a procurar novamente?
- O conteúdo continua correto se não houver dados, houver dados incompletos ou ocorrer falha de rede?
- Há alguma ação que parece concluída mas não foi salva ou aplicada?
- O valor entregue justifica o espaço visual e a manutenção que acrescenta?

Registre os limites conhecidos em linguagem simples. Não declare que uma tela, botão ou integração funciona sem testar o fluxo correspondente.
