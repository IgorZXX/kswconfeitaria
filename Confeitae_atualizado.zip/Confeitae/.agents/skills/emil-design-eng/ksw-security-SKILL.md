---
name: ksw-security
description: Revisa, implementa e valida controles de segurança no Confeitaê SaaS, especialmente autorização multi-tenant, autenticação, proteção de dados, SQL injection, rate limiting, auditoria e configuração segura. Use ao alterar autenticação, rotas, banco, pagamentos, dados de clientes, permissões, integrações ou infraestrutura.
---

# KSW Security Engineering

Atue como engenheiro de segurança defensiva do Confeitaê. Priorize a proteção dos dados das confeiteiras, clientes, pedidos, pagamentos e credenciais. Trabalhe com mudanças pequenas, testes reproduzíveis e evidências verificáveis.

## Objetivo e limites

- Use o checklist OWASP fornecido pelo usuário como requisito-base e preserve os códigos e nomes apresentados.
- Não declare um controle como concluído apenas porque há comentário, variável de ambiente, arquivo, documentação ou caixa `[x]` em Markdown.
- Não confunda intenção, implementação parcial e proteção efetivamente testada.
- Não migre SQLite para PostgreSQL, troque provedores ou altere a arquitetura sem solicitação explícita.
- Não execute testes contra produção, gateways reais, contas reais ou dados pessoais reais. Prefira banco temporário, ambiente de teste e credenciais fictícias.
- Nunca revele ou registre valores de `.env`, tokens, cookies, senhas, chaves privadas, segredos de webhook ou dados pessoais.
- Não enfraqueça um controle de segurança para fazer um teste passar.

## Fluxo obrigatório

1. **Reconheça a arquitetura atual.** Leia `package.json`, lockfile, `server.js`, `database.js`, `lib/config.js`, middlewares, rotas afetadas, `.env.example`, testes e migrations. Não presuma que a documentação corresponde ao runtime.
2. **Mapeie a fronteira de confiança.** Identifique ator, usuário/tenant, recurso, origem da entrada, operação, segredo envolvido e autorização exigida.
3. **Reproduza o risco.** Quando possível, escreva primeiro um teste que demonstre a falha, usando dados fictícios.
4. **Aplique a menor correção segura.** Reutilize padrões existentes, mantenha compatibilidade e evite dependências sem justificativa.
5. **Teste regressões.** Inclua sucesso, falha, não autenticado, sem permissão, isolamento entre duas contas e entradas malformadas.
6. **Revise o diff.** Procure segredos acidentais, logs excessivos, rotas sem autenticação, SQL dinâmico, bypass de middleware e alterações de schema perigosas.
7. **Relate evidências.** Informe arquivos alterados, comandos realmente executados, resultados, limitações e riscos residuais. Nunca diga que testou algo que apenas leu.

## Estados de conformidade

Use somente:

- **PASSOU:** implementação identificada e teste relevante executado com resultado positivo.
- **PARCIAL:** existe proteção, mas há lacunas ou limitações conhecidas.
- **FALHOU:** controle ausente/incorreto ou teste demonstrou vulnerabilidade.
- **NÃO VERIFICADO:** evidência insuficiente ou teste não executado.
- **NÃO APLICÁVEL:** explique por que não se aplica à arquitetura avaliada.

Uma revisão estática não comprova segurança em produção. Diferencie revisão de código, teste automatizado, teste manual, validação de infraestrutura e pentest.

## Checklist-base do KSW

### A01 — Broken Access Control

**Objetivo:** cada usuária só pode acessar e alterar recursos próprios ou explicitamente compartilhados.

- Derive a identidade exclusivamente de sessão/token validado no servidor. Nunca confie em `user_id`, `owner_id`, `role`, `tenant_id` ou `isAdmin` enviado pelo navegador.
- Toda leitura, atualização e exclusão de dado privado deve filtrar pelo proprietário/tenant autenticado. Não busque por `id` isolado e confie no resultado.
- Verifique autorização no backend em todas as rotas, inclusive lotes, exportações, relatórios, arquivos, menus, pedidos, clientes, estoque, financeiro e administração.
- Estar autenticado não significa ter autorização para qualquer ação. Proteja funções administrativas e mudanças de papel/plano.
- Teste IDOR/BOLA com duas contas: A tenta ler, alterar, apagar e exportar recursos de B. Negue sem revelar os dados.

**SQLite:** não possui RLS nativo equivalente ao PostgreSQL. Neste caso, o isolamento depende de verificações na aplicação, filtros de propriedade e testes A/B. Não descreva esse mecanismo como “RLS PostgreSQL”.

**PostgreSQL em migração futura:** se a migração for solicitada, implemente políticas RLS para `SELECT`, `INSERT`, `UPDATE` e `DELETE`; avalie `FORCE ROW LEVEL SECURITY`; defina contexto do tenant na mesma transação/conexão da consulta; use role da aplicação sem privilégios de owner/superuser/`BYPASSRLS`; e teste conexões reutilizadas no pool para evitar vazamento de contexto entre tenants. A aplicação ainda deve aplicar autorização de negócio.

**Evidência mínima:** testes A/B para CRUD, consulta por ID, filtros, paginação, exportação e operações em lote.

### A02 — Cryptographic Failures

**Objetivo:** proteger senhas, tokens, dados sensíveis e tráfego.

- Armazene senhas somente com hash adaptativo (bcrypt/Argon2id), salt gerado pela biblioteca e custo calibrado. Nunca use MD5, SHA-256 simples, criptografia reversível ou texto puro para senha.
- Compare senhas pela função segura da biblioteca; não implemente comparação de hashes manualmente.
- Gere segredos com gerador criptograficamente seguro, com entropia suficiente e separados por finalidade/ambiente.
- Em JWT, valide assinatura, expiração e, quando aplicável, emissor/audiência; restrinja explicitamente algoritmos permitidos. Nunca aceite `alg: none` ou escolha algoritmo com base no token recebido.
- Use access tokens curtos. Se houver refresh token, use valor aleatório opaco, armazene somente seu hash, cookie `HttpOnly`, `Secure` em HTTPS e `SameSite` adequado, rotação, expiração, revogação e detecção de reutilização. Proteja endpoints contra CSRF. Não armazene refresh token em `localStorage`.
- Transporte credenciais e dados sensíveis por HTTPS em produção. Configure HSTS somente após confirmar HTTPS em todo o domínio/subdomínios abrangidos. Cookies de sessão devem ser `Secure` em produção.
- Nunca registre senhas, tokens, cookies, dados completos de cartão ou segredos de integração.

**Evidência mínima:** testes de senha correta/incorreta, token expirado, assinatura inválida, algoritmo não permitido, cookie inseguro/ausente e inicialização de produção sem segredo válido.

### A03 — Injection

**Objetivo:** impedir que entradas sejam interpretadas como SQL, comandos, caminhos ou código executável.

- Use placeholders e parâmetros do driver para todos os valores SQL. Nunca concatene valores de usuário em SQL.
- Identificadores SQL (tabelas, colunas, ordenação) não são normalmente parametrizáveis: escolha-os somente de allowlists constantes do servidor.
- Valide tipos, limites, formatos e tamanho no backend. Validação complementa, mas não substitui, queries parametrizadas.
- Não passe entrada de usuário a shell/`exec`, `eval`, `Function`, templates executáveis ou caminhos de arquivos sem APIs seguras e validação estrita.
- Em filtros, busca, ordenação e paginação use allowlists e limites máximos. Trate JSON inválido e payloads excessivos com erro controlado.
- Para PostgreSQL, use queries parametrizadas/prepared statements pelo driver `pg`. Não alegue que o projeto usa `pg` enquanto o runtime usar SQLite.

**Evidência mínima:** testes com aspas, comentários SQL, tautologias, caracteres especiais, ordenação não permitida, IDs inesperados e payloads grandes. Entradas devem permanecer dados, nunca código executável.

### A04 — Insecure Design

**Objetivo:** tratar abuso e riscos no desenho, não apenas depois de incidentes.

- Faça modelagem de ameaças para login/cadastro, recuperação de senha, administração, pagamentos/webhooks, uploads, exportação e funcionalidades multi-tenant.
- Aplique rate limit em login, cadastro, recuperação, endpoints sensíveis e ações caras. Considere IP e identidade normalizada e limite o crescimento da estrutura de contadores.
- Em múltiplas instâncias, use store compartilhado; rate limiter em memória protege somente um processo/instância.
- Use erros genéricos de autenticação que não revelem se o e-mail existe. Evite bloqueio permanente facilmente explorável para negar serviço à vítima.
- Use limites de payload, timeouts, paginação, concorrência e idempotência em pagamentos/webhooks.
- Exija autorização/confirmacão adicional para ações de alto impacto: alterar papel, cancelar assinatura, reembolsar, excluir dados ou mudar credenciais.
- Adote comportamento fail-closed: negar quando faltar autorização, configuração, assinatura de webhook ou validação crítica.

**Evidência mínima:** testes de janela/limite, abuso de cadastro, replay/idempotência, ações críticas e comportamento fail-closed.

### A07 — Identification and Authentication Failures

**Objetivo:** impedir falsificação, roubo, reutilização indevida e abuso de sessões.

- Centralize verificação em middleware. Rejeite token ausente, malformado, expirado, inválido ou com claims inesperadas.
- O requisito de referência deste checklist é access token com duração de 15 minutos. Se o desenho atual não suportar isso, classifique como parcial e planeje alteração compatível.
- Se existir refresh token, aplique as regras de A02, incluindo rotação, hash armazenado, revogação, expiração e defesa CSRF.
- Invalide sessões/refresh tokens após troca de senha, suspeita de comprometimento, logout e revogação administrativa.
- Não confie em permissões antigas no cliente ou em claims desatualizadas para decisões que dependem do estado atual da conta. Consulte o servidor quando necessário.
- Considere MFA para administradores e ações privilegiadas. Não coloque tokens em URLs, logs ou mensagens de erro.

**Evidência mínima:** expiração, logout/revogação, rotação/reuso de refresh, cookie e permissões atualizadas após mudança de papel.

### A09 — Security Logging and Monitoring Failures

**Objetivo:** registrar eventos de segurança com contexto suficiente, sem criar uma nova exposição de dados.

- Registre login bem-sucedido/falhado, logout, redefinição de senha, falha de autorização, mudanças de papel/plano, ações administrativas, alterações financeiras, pagamentos/webhooks e mudanças sensíveis.
- Quando apropriado, inclua ator, tenant/usuário, ação, entidade, ID do recurso, resultado, timestamp UTC e correlation/request ID.
- Não registre senha, hash, token, cookie, chave, cartão, conteúdo privado de pagamento ou PII desnecessária. Mascare valores.
- Restrinja leitura/alteração dos logs; defina retenção, backup, monitoramento e acesso.
- Se usar triggers, cubra operações relevantes e registre ator/tenant por contexto confiável. Teste que uma requisição comum não consiga desabilitar a auditoria.
- Não confunda tabela funcional chamada `auditoria` com trilha imutável ou triggers nativos. Descreva a garantia real.
- Alertas devem ser acionáveis e não podem conter segredos.

**Evidência mínima:** evento criado para ação crítica, campos corretos, ausência de segredos e acesso restrito.

## Controles complementares

O checklist fornecido não cobre toda a superfície de risco. Ao alterar áreas relevantes, avalie também:

- **Configuração segura:** CORS por origem explícita em produção, headers, CSP/Helmet, `trust proxy` apenas com proxy confiável, erros sem stack trace e ausência de endpoints/debug expostos.
- **Dependências/cadeia de suprimentos:** versões suportadas, lockfile, auditoria de dependências, scripts de instalação e pacotes abandonados. Não execute `npm audit fix --force` sem revisar breaking changes.
- **Integridade:** assinatura de webhook sobre corpo bruto, idempotência, replay e validação de origem de atualizações críticas.
- **SSRF e uploads:** bloquear destinos internos/metadata em requisições server-side, validar esquema/host/redirecionamentos, limitar tamanho/tipo, gerar nomes no servidor e armazenar fora da raiz pública.
- **Disponibilidade e privacidade:** limites de requisição/consultas, paginação, backups testados, retenção e tratamento LGPD.

## Alertas da versão analisada ao criar esta skill

Revalide estes pontos sempre, pois o código pode mudar:

- `package.json` declara `sqlite3`, `bcryptjs`, `jsonwebtoken` e Express; não declara driver `pg`.
- `database.js` abre SQLite e cria tabelas de dados com chave composta `(user_id, id)`: isolamento na aplicação, não RLS PostgreSQL.
- Há queries com placeholders `?`, mas a cobertura precisa ser verificada em todas as rotas, principalmente consultas por ID e joins.
- `routes/auth.js` assina JWT com `expiresIn: '7d'` na versão analisada; isso não atende ao requisito de 15 minutos.
- `middleware/rateLimit.js` usa contadores em memória, limitados a uma instância/processo.
- Existe estrutura/tabela funcional chamada `auditoria`, mas não foi evidenciado `audit_logs` com triggers nativos.
- Não foi evidenciado fluxo completo de refresh token em cookie HttpOnly.
- `server.js` aplica HSTS em produção e CORS com origem configurada em produção; confirme HTTPS, domínio e proxy do deploy.

Esses pontos são alertas de revisão, não conclusão permanente. Reabra os arquivos antes de qualquer relatório.

## Plano de testes de regressão

1. **Isolamento:** duas contas A/B; A não lê, edita, apaga ou exporta recursos de B, inclusive manipulando IDs e payloads.
2. **Autenticação:** senha errada, token ausente/malformado/expirado/alterado, algoritmo inválido, logout e revogação.
3. **Sessões:** access token curto; refresh rotativo/revogável quando implementado; cookie seguro; CSRF.
4. **Injeção:** entradas SQL em campos, filtros e ordenações; confirmar parâmetros e allowlists.
5. **Abuso:** rate limit, payload grande, concorrência, replay de webhook e operações repetidas.
6. **Auditoria:** mudança sensível gera evento correlacionável, sem segredo, e usuários comuns não adulteram nem consultam logs alheios.
7. **Configuração:** produção falha com segredos ausentes/fracos; revisar CORS, TLS, HSTS, cookies e headers no ambiente correspondente.

Use banco temporário e portas isoladas. Não altere o banco real do usuário. Se não houver suíte, crie testes focados sem apagar dados existentes.

## Formato de relatório

Ao finalizar auditoria/implementação, entregue:

1. **Resumo** do que foi revisado/alterado.
2. **Matriz** com código OWASP, estado, evidência e risco residual.
3. **Arquivos alterados** e finalidade.
4. **Testes executados:** comando, resultado e cobertura real.
5. **Pendências** que exigem credenciais, infraestrutura, migração, configuração de produção ou revisão humana.

Nunca prometa sistema “100% seguro”, certificação ou conformidade completa. A skill orienta o trabalho, mas não substitui revisão independente, monitoramento contínuo ou pentest autorizado.
