# Rascunhos de políticas — Confeitaê

> **USO INTERNO — NÃO PUBLICAR NEM USAR COMO ACEITE.** Este material é um ponto de partida operacional, não parecer jurídico nem garantia de conformidade. Os campos pendentes e as divergências entre a oferta e o código precisam ser resolvidos antes de coletar dados de clientes ou vender o serviço. Solicite revisão de advogado com atuação em direito do consumidor e proteção de dados no Brasil.

## Situação da operação verificada no projeto

- O cadastro solicita nome, e-mail, senha e WhatsApp opcional. A senha é armazenada com hash bcrypt.
- O backend mantém contas, pedidos e tokens de redefinição no SQLite. O token de sessão e dados de gestão da confeitaria também são guardados no `localStorage` do navegador.
- Os dados locais de gestão podem conter clientes, WhatsApp, aniversários, preferências, pedidos, ingredientes e informações financeiras inseridas pela usuária.
- Não foi encontrado carregamento direto de fontes do Google Fonts, ferramenta própria de analytics ou pixel de publicidade no frontend examinado; isso deve ser revalidado no ambiente publicado, em CDN/hospedagem e em futuras integrações.
- O checkout pode usar Mercado Pago quando configurado. Sem configuração válida, o código permite criar pedido simulado e simular aprovação sem cobrança real. Stripe consta nas dependências, mas não há fluxo de pagamento Stripe implementado nas rotas examinadas.
- Embora a oferta chame o plano mensal de recorrente, o fluxo atual não cria uma assinatura com renovação automática. Não anunciar nem cobrar recorrência até implementá-la e revisar os termos.
- Não foi localizado fluxo para a titular excluir a conta nem política implementada de retenção e eliminação de dados.

## 1. Termos de uso — texto-base

**Responsável pelo serviço:** `[NOME CIVIL OU EMPRESARIAL — PENDENTE]`, identificado como `[CPF OU CNPJ — CONFIRMAR E AUTORIZAR A DIVULGAÇÃO]`, com endereço para contato em `[ENDEREÇO COMPLETO — PENDENTE]`, São Paulo/SP. Marca: Confeitaê.

**Contato:** `[E-MAIL DE SUPORTE E PRIVACIDADE — PENDENTE]`.

### Objeto e elegibilidade

A Confeitaê oferece ferramentas digitais de gestão para confeitaria, conforme as funcionalidades efetivamente disponibilizadas em cada versão. O serviço é destinado a pessoas maiores de 18 anos residentes no Brasil. Esta regra deve ser aplicada e informada claramente no cadastro.

### Conta e segurança

A usuária deve fornecer informações corretas, proteger suas credenciais e avisar o canal de suporte se suspeitar de acesso indevido. A senha não deve ser compartilhada. O acesso por equipe é permitido conforme o limite e os papéis definidos no plano contratado; a pessoa proprietária deve administrar convites e permissões.

### Funcionalidades, disponibilidade e dados

As funcionalidades podem evoluir, mas mudanças relevantes de preço, escopo ou condições devem ser comunicadas de forma adequada e respeitar os direitos da consumidora. Não prometer disponibilidade ininterrupta, backups, recuperação de dados ou integrações que ainda não estejam implementados e testados. Definir suporte, manutenção, exportação de dados e recuperação antes da publicação.

### Planos, preço e cobrança

Os preços atualmente exibidos no projeto são R$ 59,99 para o plano mensal e R$ 1.119,00 para o plano chamado vitalício. Confirmar os preços e o escopo antes de qualquer publicação. O código atual não realiza cobrança recorrente automática; o ambiente sem credencial válida pode simular aprovação sem movimentar dinheiro. Portanto, esta oferta e o checkout não devem ser usados para vendas reais até que cobrança, confirmação, recibos, renovação, cancelamento e suporte estejam implementados e testados.

O significado e os limites de “vitalício”, incluindo duração, funcionalidades abrangidas, manutenção e hipóteses de encerramento, precisam ser definidos antes de usar esse nome comercial.

### Cancelamento, arrependimento e reembolso

`[DEFINIR E REVISAR COM ADVOGADO: como solicitar cancelamento; efeito sobre futuras cobranças e acesso; procedimento e prazo de reembolso; tratamento de pagamentos pendentes, duplicados ou contestados.]`

Nenhuma disposição deste texto pretende limitar direitos obrigatórios previstos na legislação brasileira, inclusive no Código de Defesa do Consumidor. Não publicar uma regra de “sem reembolso” ou renúncia geral a direitos.

### Uso aceitável e propriedade intelectual

A usuária não deve usar o serviço para fins ilícitos, tentar comprometer sua segurança ou inserir dados de terceiros sem autorização e fundamento apropriado. Definir titularidade/licenças de marca, conteúdo, modelos e dados exportados; a redação final deve distinguir conteúdo da usuária e componentes do serviço.

### Alterações e encerramento

Definir como avisos serão enviados, tratamento de contas inativas, encerramento do serviço, exportação e eliminação dos dados. Mudanças contratuais não podem retirar direitos já adquiridos nem afastar normas obrigatórias.

## 2. Aviso de privacidade e proteção de dados — texto-base

### Quem decide sobre o tratamento

`[IDENTIFICAR CONTROLADOR: nome civil ou empresarial, CPF/CNPJ conforme orientação jurídica e endereço completo.]`

Canal para assuntos de privacidade e exercício de direitos: `[E-MAIL OU CANAL OPERACIONAL — PENDENTE]`. Encarregado, se aplicável: `[NOME OU CANAL DO ENCARREGADO — AVALIAR E PREENCHER]`.

### Dados observados no código

- Cadastro e conta: nome, e-mail, senha em formato de hash e WhatsApp opcional.
- Autenticação: token de sessão guardado no navegador.
- Recuperação de senha: token e prazo de expiração registrados no banco; a entrega por e-mail deve ser revisada separadamente.
- Verificação de conta: nome, e-mail e link/token de confirmação são enviados ao Resend por chamada server-side; a senha permanece armazenada como hash no KSW e não é enviada ao Resend.
- Pedidos e pagamentos: plano, valor, estado, referência e identificadores do gateway; dados de pagamento são tratados pelo gateway quando a integração real estiver ativa.
- Dados que a usuária inclui no gestor: nomes e contatos de clientes, aniversários (dia e mês, sem exigir ano), preferências e observações, indicador e data de registro da autorização para mensagens promocionais por WhatsApp, cupons, ingredientes, estoque, receitas, pedidos e informações financeiras. Parte disso fica no `localStorage` do dispositivo/navegador.
- Dados técnicos de acesso e registros do servidor: `[INVENTARIAR COM A HOSPEDAGEM ANTES DA PUBLICAÇÃO]`.

Não inserir dados pessoais ou informações sensíveis de clientes finais sem necessidade, aviso apropriado e base legal. A confeiteira que cadastra dados de seus próprios clientes pode ter responsabilidades próprias como agente de tratamento; definir orientação e limites do produto com assessoria jurídica.

### Finalidades e bases legais

Finalidades possíveis, a confirmar operação por operação: criar e manter a conta; autenticar; fornecer as funções contratadas; registrar e atender pedidos de pagamento; responder suporte; proteger o serviço; cumprir obrigações legais.

Mensagens promocionais e lembretes de aniversário por WhatsApp são preparados somente quando a confeiteira registra que a cliente autorizou; essa indicação e sua data ficam no cadastro, podem ser revogadas e não demonstram por si só como a autorização foi obtida. O envio é iniciado manualmente pela confeiteira; não há disparo automático.

`[MAPEAR PARA CADA FINALIDADE A BASE LEGAL APLICÁVEL NA LGPD, NECESSIDADE, PRAZO E DADOS ENVOLVIDOS. NÃO TRATAR “CONSENTIMENTO” COMO BASE UNIVERSAL. DEFINIR COMO COMPROVAR A AUTORIZAÇÃO E OS PRAZOS DE RETENÇÃO.]`

### Compartilhamento e fornecedores

O KSW usa o Resend para enviar mensagens transacionais de confirmação de conta. Para isso, encaminha ao Resend o endereço de e-mail, o nome usado na saudação e o conteúdo/link de verificação. A chamada é feita pelo servidor e a chave de API fica somente no ambiente do servidor. Identificar a hospedagem, banco, e-mail, backups, suporte, gateway efetivamente usados, contratos, suboperadores e eventuais transferências internacionais antes de publicar.

### Armazenamento, segurança e retenção

O projeto usa SQLite no servidor e `localStorage` no navegador. Isso não comprova criptografia de transporte, controle de acesso de hospedagem, backups, segregação de contas ou política de eliminação em produção. Confirmar arquitetura, HTTPS, permissões, cópias de segurança, gestão de incidentes e controles de acesso.

`[DEFINIR PRAZOS DE RETENÇÃO POR CATEGORIA, COMO A TITULAR PEDE ELIMINAÇÃO/EXPORTAÇÃO, EXCEÇÕES DE GUARDA LEGAL, BACKUPS E DESCARTE. IMPLEMENTAR O PROCESSO ANTES DE PROMETER EXCLUSÃO.]`

### Direitos da titular

A titular pode solicitar, nos termos da LGPD e conforme aplicável, confirmação e acesso, correção, informação sobre compartilhamento, anonimização, bloqueio ou eliminação de dados tratados irregularmente, portabilidade quando regulamentada, revisão de decisões automatizadas quando cabível e demais direitos legais. Disponibilizar canal funcional e processo de verificação de identidade, resposta, registro e tratamento de exceções.

### Crianças, adolescentes e incidentes

O produto declara-se destinado a maiores de 18 anos. Definir como essa condição será comunicada e tratada caso haja cadastro de menor. Documentar procedimento de resposta a incidentes e comunicação às pessoas afetadas e à ANPD quando exigido.

## 3. Aviso de cookies e armazenamento local — estado atual do código

O aviso de primeiro acesso é exibido uma vez até a pessoa escolher entre aceitar opcionais, rejeitar opcionais ou salvar uma escolha personalizada. Depois da escolha, o painel é removido da tela. A opção pode ser reaberta por “Preferências de privacidade” no rodapé e em Configurações. O cadastro exige que uma escolha exista e o servidor valida essa informação; rejeitar cookies opcionais não bloqueia o cadastro nem o uso do KSW. Não clicar em nenhuma opção não envia o cadastro.

O KSW não usa cookie de autenticação para a conta comum: o token JWT de acesso fica no `localStorage` e expira em até 7 dias. O `localStorage` também pode manter cache operacional para uso offline; no logout, o token é removido e o cache sincronizado é removido. Alterações ainda não sincronizadas são preservadas no aparelho para evitar perda acidental, devendo ser sincronizadas ou exportadas antes de limpar os dados do navegador. A escolha de privacidade também é armazenada localmente e, após login, é sincronizada com a tabela `user_cookie_preferences`; o histórico de alterações é mantido em `user_cookie_consent_events` (evento de cadastro ou de configurações).

O Super Admin usa um cookie técnico de sessão, `HttpOnly`, `SameSite=Strict`, restrito a `/api/admin` e com duração de 30 minutos; em produção, recebe também `Secure`. Esse cookie é necessário para autenticar a área administrativa e não é um cookie de publicidade.

No código revisado não há ferramenta própria de analytics, pixel de publicidade ou script de rastreamento carregado antecipadamente. O checkout e links de comunicação externos são acessados somente após ação da pessoa. As opções de análise e marketing ficam desativadas por padrão em escolhas personalizadas e não ativam ferramentas atualmente inexistentes. Caso novas tecnologias opcionais sejam introduzidas, revisar finalidade, fornecedor, retenção e bloqueio até uma escolha válida antes de publicar.

Essas descrições refletem o código analisado, não substituem inventário do ambiente de hospedagem, headers, CDN, gateway ou scripts inseridos fora deste repositório. Antes de produção, testar os domínios efetivos e publicar uma política de privacidade/cookies completa com identificação do controlador, contato, finalidades, bases legais, fornecedores, retenção, direitos e processo de revogação. Este rascunho permanece interno e não deve ser apresentado como política final.

## 4. Condições comerciais e pagamentos — texto-base

Os preços, periodicidade, conteúdo do plano, tributos, meios de pagamento, confirmação, emissão de comprovante, renovação, cancelamento e reembolso precisam ser mostrados antes da contratação, em linguagem clara e coerente com o gateway.

**Estado atual:** demonstração. A opção de simulação pode ativar um plano sem pagamento. O fluxo mensal não implementa renovação automática, apesar do texto comercial existente no produto. Não operar cobrança real nem anunciar recorrência até remover/desabilitar a simulação em produção e completar a integração real.

`[PREENCHER APÓS IMPLEMENTAR E TESTAR: gateway efetivo; cobrança única ou recorrente; data e frequência; valor total; como cancelar; quando o acesso termina; processo de estorno/reembolso; canal de suporte.]`

## Pendências obrigatórias antes de publicar

- [ ] Informar nome civil/empresarial do controlador e definir com advogado qual identificador deve ser divulgado. CPF recebido durante a conversa **não foi copiado para este documento** nem está autorizado para publicação.
- [ ] Fornecer endereço completo de contato e e-mail/canal efetivo de suporte e privacidade.
- [ ] Decidir a política comercial de cancelamento/reembolso em conformidade com a legislação; implementar o procedimento real.
- [ ] Corrigir a divergência entre mensalidade automática anunciada e cobrança única/simulação no código.
- [ ] Desativar a simulação de aprovação em produção e testar o fluxo real antes de aceitar pagamentos.
- [ ] Mapear hospedagem, Resend, suboperadores, transferências, logs, backups, retenção e exclusão; implementar solicitações de titulares e fluxo de eliminação de conta.
- [ ] Revisar todos os cookies, tecnologias de armazenamento, scripts e integrações do ambiente de produção; confirmar a retenção e os domínios de terceiros.
- [ ] Definir duração/escopo do plano “vitalício”, suporte, exportação, manutenção, incidentes e canal de reclamação.
- [ ] Submeter os textos finais a advogado brasileiro; publicar versões datadas, manter histórico e obter aceite demonstrável antes de concluir contratação, sem condicionar direitos que não dependem de consentimento.
