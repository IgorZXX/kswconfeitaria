'use strict';

const db = require('../database');
const { hasPermission } = require('../lib/tenant-permissions');

function tenantContextMiddleware(req, res, next) {
  const userId = Number(req.user && req.user.id);
  if (!Number.isSafeInteger(userId) || userId <= 0) {
    return res.status(401).json({ error: 'Sessão inválida.' });
  }

  const requestedTenant = req.get('x-tenant-id');
  const params = [userId];
  let tenantFilter = '';
  if (requestedTenant != null && requestedTenant !== '') {
    if (!/^\d{1,12}$/.test(String(requestedTenant)) || Number(requestedTenant) <= 0) {
      return res.status(400).json({ error: 'Empresa selecionada inválida.' });
    }
    tenantFilter = ' AND t.id = ?';
    params.push(Number(requestedTenant));
  }

  db.get(
    `SELECT t.id AS tenant_id, t.nome AS tenant_nome, t.slug AS tenant_slug,
            t.owner_user_id, t.status AS tenant_status, tm.role AS tenant_role, tm.status AS membership_status
       FROM tenant_memberships tm
       JOIN tenants t ON t.id = tm.tenant_id
      WHERE tm.user_id = ? AND tm.status = 'active'${tenantFilter}
      ORDER BY CASE tm.role WHEN 'owner' THEN 0 ELSE 1 END, tm.created_at, tm.id
      LIMIT 1`,
    params,
    (err, row) => {
      if (err) {
        console.error('Falha ao resolver empresa da sessão:', err);
        return res.status(500).json({ error: 'Não foi possível validar a empresa selecionada.' });
      }
      if (!row) {
        return res.status(403).json({ error: 'Você não possui acesso ativo a esta empresa.', code: 'TENANT_ACCESS_DENIED' });
      }
      if (row.tenant_status && row.tenant_status !== 'active') {
        return res.status(403).json({ error: 'Esta empresa está temporariamente suspensa. Entre em contato com o suporte.', code: 'TENANT_SUSPENDED' });
      }
      req.tenant = {
        id: Number(row.tenant_id),
        nome: row.tenant_nome,
        slug: row.tenant_slug,
        owner_user_id: Number(row.owner_user_id)
      };
      req.tenantRole = row.tenant_role;
      req.tenantMembershipStatus = row.membership_status;
      return next();
    }
  );
}

function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.tenant || !hasPermission(req.tenantRole, permission)) {
      return res.status(403).json({ error: 'Seu perfil não possui permissão para esta ação.', code: 'TENANT_PERMISSION_DENIED' });
    }
    return next();
  };
}

module.exports = { tenantContextMiddleware, requirePermission };
