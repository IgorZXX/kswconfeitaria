const jwt = require('jsonwebtoken');
const db = require('../database');

const { JWT_SECRET } = require('../lib/config');
const { isSubscriptionActive } = require('../lib/platform-admin');

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'Token de acesso não fornecido.' });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || !/^Bearer$/i.test(parts[0])) {
    return res.status(401).json({ error: 'Formato de token inválido.' });
  }

  const token = parts[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    return next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido ou expirado.' });
  }
}

function checkActiveSubscription(req, res, next) {
  // O acesso é herdado do proprietário da empresa e considera o intervalo
  // configurado no plano, inclusive planos comerciais criados no superadmin.
  const billingUserId = req.tenant && req.tenant.owner_user_id
    ? req.tenant.owner_user_id
    : req.user.id;
  db.get(
    `SELECT u.plano_tipo, u.status_assinatura, u.data_vencimento,
            p.billing_interval, p.billing_interval_count
       FROM users u LEFT JOIN platform_plans p ON p.plan_key = u.plano_tipo
      WHERE u.id = ?`,
    [billingUserId],
    (err, user) => {
      if (err) {
        console.error('Erro ao verificar assinatura:', err);
        return res.status(500).json({ error: 'Não foi possível verificar a assinatura.' });
      }
      if (!user) {
        return res.status(403).json({
          error: 'A empresa não possui uma assinatura ativa. Escolha um plano para liberar o sistema.',
          code: 'SUBSCRIPTION_REQUIRED'
        });
      }
      if (isSubscriptionActive(user)) return next();
      const expired = user.status_assinatura === 'vencida' ||
        (user.status_assinatura === 'ativa' && (user.billing_interval === 'month' || ['mensal', 'anual', 'teste', 'teste_gratis'].includes(user.plano_tipo)) &&
          (!user.data_vencimento || !Number.isFinite(new Date(user.data_vencimento).getTime()) || new Date(user.data_vencimento).getTime() <= Date.now()));
      return res.status(403).json({
        error: expired
          ? 'A assinatura da empresa venceu. O proprietário deve renovar o plano.'
          : 'A empresa não possui uma assinatura ativa. O proprietário deve escolher um plano.',
        code: expired ? 'SUBSCRIPTION_EXPIRED' : 'SUBSCRIPTION_REQUIRED'
      });
    }
  );
}

module.exports = { authMiddleware, checkActiveSubscription };
