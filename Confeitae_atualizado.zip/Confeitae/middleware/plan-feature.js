'use strict';

const db = require('../database');
const { parsePlanFeatures, hasPlanFeature } = require('../lib/plan-features');

function getTenantPlan(tenantId) {
  return new Promise((resolve, reject) => {
    db.get(
      `SELECT owner.plano_tipo, owner.status_assinatura, owner.data_vencimento,
              plan.name AS plan_name, plan.max_members, plan.features_json, plan.billing_interval
         FROM tenants t
         JOIN users owner ON owner.id = t.owner_user_id
         LEFT JOIN platform_plans plan ON plan.plan_key = owner.plano_tipo
        WHERE t.id = ?`,
      [tenantId],
      (error, row) => error ? reject(error) : resolve(row || null)
    );
  });
}

function requirePlanFeature(featureKey) {
  return async (req, res, next) => {
    try {
      if (!req.tenant || !req.tenant.id) {
        return res.status(403).json({ error: 'Empresa não identificada para validar os recursos do plano.', code: 'PLAN_FEATURE_DENIED' });
      }
      const plan = await getTenantPlan(req.tenant.id);
      const features = parsePlanFeatures(plan && plan.features_json);
      if (!hasPlanFeature(features, featureKey)) {
        return res.status(403).json({
          error: `O recurso solicitado não está incluído no plano ${plan && plan.plan_name ? plan.plan_name : 'atual'}. Faça upgrade para liberar esta funcionalidade.`,
          code: 'PLAN_FEATURE_REQUIRED', feature: featureKey, plan_key: plan && plan.plano_tipo
        });
      }
      req.plan = plan;
      req.planFeatures = features;
      return next();
    } catch (error) {
      console.error('Falha ao validar recurso do plano:', error);
      return res.status(500).json({ error: 'Não foi possível validar os recursos do plano.' });
    }
  };
}

module.exports = { getTenantPlan, requirePlanFeature };
