'use strict';

// Fail closed: o runtime continua operando exclusivamente em SQLite.
// A camada MySQL incluída nesta entrega prepara conexão, inventário e migração
// para homologação, mas não substitui ainda o acesso SQL usado pelas rotas.
const requestedDatabaseDriver = String(process.env.DB_DRIVER || 'sqlite').trim().toLowerCase();
if (requestedDatabaseDriver !== 'sqlite') {
  throw new Error('DB_DRIVER=mysql ainda não está habilitado no runtime do KSW. A camada MySQL desta versão é destinada à preparação e migração de homologação; mantenha DB_DRIVER=sqlite até concluir a adaptação integral das rotas e aprovar a troca do banco.');
}

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { migrateTenantSchema } = require('./lib/tenant-schema');
const { initializePlatformAdminSchema } = require('./lib/platform-admin-schema');
const { initializeStorefrontSchema } = require('./lib/storefront-schema');
const { initializeQuoteSchema } = require('./lib/quote-schema');
const { initializeAuthSchema } = require('./lib/auth-schema');
const { initializeSupportSchema } = require('./lib/support-schema');
const { initializeSocialSchema } = require('./lib/social-schema');

const dbPath = process.env.DATABASE_PATH
  ? path.resolve(process.env.DATABASE_PATH)
  : path.resolve(__dirname, 'ksw_database.sqlite');

// Definição das tabelas de dados da confeiteira (usada também por routes/data.js).
const { DATA_TABLES, ensureDataTable } = require('./lib/data-tables');

function runOn(database, sql, params = []) {
  return new Promise((resolve, reject) => {
    database.run(sql, params, function onRun(err) {
      if (err) return reject(err);
      return resolve({ changes: this.changes, lastID: this.lastID });
    });
  });
}

function allOn(database, sql, params = []) {
  return new Promise((resolve, reject) => {
    database.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)));
  });
}

async function initializeSchema(database) {
  // WAL permite leituras durante escritas; busy_timeout reduz falhas transitórias SQLITE_BUSY.
  await runOn(database, 'PRAGMA journal_mode = WAL');
  await runOn(database, 'PRAGMA busy_timeout = 5000');

  const baseSchema = [
    `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      senha TEXT NOT NULL,
      whatsapp TEXT,
      role TEXT DEFAULT 'user',
      plano_tipo TEXT DEFAULT 'free',
      status_assinatura TEXT DEFAULT 'inativa',
      data_vencimento DATETIME,
      subscription_id_gateway TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      plano_tipo TEXT NOT NULL,
      valor REAL NOT NULL,
      status TEXT DEFAULT 'pending',
      gateway TEXT NOT NULL,
      external_reference TEXT UNIQUE,
      payment_id TEXT,
      qr_code TEXT,
      qr_code_base64 TEXT,
      ticket_url TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS password_resets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token TEXT NOT NULL,
      expira_em DATETIME NOT NULL,
      usado INTEGER DEFAULT 0,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS menus (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      published INTEGER NOT NULL DEFAULT 0,
      sections_json TEXT NOT NULL DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )`,
    `CREATE TABLE IF NOT EXISTS menu_hubs (
      user_id INTEGER PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )`
  ];

  for (const statement of baseSchema) {
    await runOn(database, statement);
  }

  // Migração aditiva: cria identificador de acesso exclusivo sem remover o e-mail
  // de contato já usado em cobranças, convites e comunicações.
  await initializeAuthSchema(database);

  // Tabelas de gestão: mantém dados existentes e adiciona apenas colunas ausentes.
  for (const tableDefinition of DATA_TABLES) {
    await ensureDataTable(database, tableDefinition);
  }

  // Migração retrocompatível: cada conta antiga recebe uma empresa própria e
  // seus registros passam a carregar tenant_id antes de o servidor aceitar tráfego.
  await migrateTenantSchema(database, DATA_TABLES);
  await initializePlatformAdminSchema(database);
  await initializeStorefrontSchema(database);
  await initializeQuoteSchema(database);
  await initializeSupportSchema(database);
  await initializeSocialSchema(database);
}

let resolvePrimaryReady;
let rejectPrimaryReady;
const primaryReady = new Promise((resolve, reject) => {
  resolvePrimaryReady = resolve;
  rejectPrimaryReady = reject;
});

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    rejectPrimaryReady(new Error(`Não foi possível abrir o banco SQLite: ${err.message}`));
    return;
  }

  initializeSchema(db).then(resolvePrimaryReady).catch((schemaError) => {
    rejectPrimaryReady(new Error(`Não foi possível preparar o banco SQLite: ${schemaError.message}`));
  });
});

let resolveTransactionReady;
let rejectTransactionReady;
const transactionReady = new Promise((resolve, reject) => {
  resolveTransactionReady = resolve;
  rejectTransactionReady = reject;
});

// A conexão exclusiva para transações também precisa estar aberta antes de aceitar tráfego.
const txDb = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    rejectTransactionReady(new Error(`Não foi possível abrir a conexão de transações SQLite: ${err.message}`));
    return;
  }

  runOn(txDb, 'PRAGMA busy_timeout = 5000')
    .then(resolveTransactionReady)
    .catch(rejectTransactionReady);
});

// Contrato de inicialização: server.js aguarda esta promessa antes de abrir a porta HTTP.
db.ready = Promise.all([primaryReady, transactionReady]).then(() => undefined);
db.DATA_TABLES = DATA_TABLES;
db.dbPath = dbPath;

const tx = {
  run: (sql, params = []) => runOn(txDb, sql, params),
  all: (sql, params = []) => allOn(txDb, sql, params),
  get: (sql, params = []) => new Promise((resolve, reject) => {
    txDb.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
  })
};

let txQueue = Promise.resolve();
function withTransaction(fn) {
  const job = txQueue.then(async () => {
    await db.ready;
    await tx.run('BEGIN IMMEDIATE');
    try {
      const result = await fn(tx);
      await tx.run('COMMIT');
      return result;
    } catch (err) {
      try {
        await tx.run('ROLLBACK');
      } catch (_) {
        // A transação pode já ter sido revertida pelo SQLite.
      }
      throw err;
    }
  });

  txQueue = job.catch(() => {});
  return job;
}

db.withTransaction = withTransaction;
db.closeAll = () => new Promise((resolve) => {
  db.close(() => txDb.close(() => resolve()));
});

module.exports = db;
