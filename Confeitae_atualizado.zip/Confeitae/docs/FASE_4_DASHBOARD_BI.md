# Fase 4 — Dashboard BI e relatórios gerenciais

## Escopo

A Fase 4 substitui a visão resumida da aba **Resultados** por um painel gerencial com competência mensal, indicadores financeiros, tendências de seis meses, desempenho por produto, despesas por categoria e movimentações de caixa.

## Arquivos

- `public/analytics-engine.js`: funções puras de agregação e formatação CSV, compartilhadas entre navegador e testes Node.
- `public/index.html`: tela de Resultados, filtros, indicadores e ações de exportação.
- `public/ksw-home.css`: estilo responsivo e regras de impressão A4.
- `scripts/analytics.test.js`: testes de competência, caixa, custos, perdas, rankings, série mensal e CSV.
- `package.json`: inclui a suíte de analytics em `npm test` e o comando `npm run test:analytics`.

## Regras gerenciais

- Faturamento, quantidade e custo dos produtos são agrupados pelo mês da data de entrega (`pedido.ent`). Pedidos cancelados são excluídos.
- O faturamento é calculado pela soma de quantidade vezes preço unitário (`itens[].q * itens[].pu`).
- O custo histórico usa o custo unitário congelado no item do pedido (`itens[].cu`, com compatibilidade para `custo_unitario`). Não recalcula pedidos passados usando preços atuais do cadastro.
- Itens sem custo histórico são contados e sinalizados. O painel alerta que o resultado pode estar superestimado.
- Recebimentos são agrupados pela data de cada pagamento (`pagamentos[].data`), com compatibilidade para pedidos antigos que só possuem `pg`/`pd`. Pagamentos registrados em pedidos posteriormente cancelados continuam no caixa, conforme o comportamento atual do KSW, mas o pedido cancelado não compõe o faturamento nem as contas a receber; não há fluxo de estorno/refund no modelo atual.
- Despesas provisionadas são agrupadas pela data de vencimento; despesas pagas/caixa usam a data de pagamento (`dpg` ou `data_pagamento`) e, para registros antigos, o vencimento como fallback.
- Perdas são agrupadas pela data registrada e somadas pelo custo do registro de perda.
- Resultado gerencial = faturamento por entrega − custos dos produtos − despesas provisionadas por vencimento − custo de perdas registradas. Resultado de caixa = recebimentos no mês − despesas pagas no mês. São métricas gerenciais e não substituem escrituração contábil, conciliação bancária ou apuração fiscal.
- Contas a receber e a pagar representam os saldos em aberto atuais de todos os pedidos/despesas não cancelados ou quitados, não apenas o mês selecionado.

## Exportação

- **Excel (CSV):** arquivo UTF-8 com BOM e separador `;` e números com vírgula decimal, compatível com abertura no Excel/LibreOffice em configuração brasileira. É CSV, não um arquivo `.xlsx` nativo. Campos textuais que possam iniciar fórmulas são prefixados para reduzir risco de CSV formula injection.
- **PDF:** usa a impressão do navegador. Na janela de impressão, escolha “Salvar como PDF”. CSS A4 oculta navegação e botões e ajusta a página.

## Segurança e limitações

- Nenhuma rota, tabela, query, integração, credencial ou dependência de runtime foi adicionada nesta fase. O painel usa os dados já carregados para a conta autenticada pelo fluxo existente.
- Não é um endpoint financeiro autoritativo: a camada de dados atual sincroniza registros JSON e o usuário autenticado consegue alterar seus próprios snapshots de custo. Os resultados são indicativos e não devem ser usados como prova contábil/fiscal.
- O cálculo de caixa é derivado dos pagamentos e despesas cadastrados no KSW; não há integração de conciliação bancária.
- A exportação pode conter nomes de clientes e informações comerciais da própria conta. O usuário deve armazenar o arquivo exportado com cuidado.

## Testes

Execute `npm run test:analytics` para os testes específicos ou `npm test` para a suíte do projeto. O teste cobre exclusão de pedidos cancelados, período de entrega, pagamentos por data, custo congelado, itens sem custo, despesas provisionadas/pagas, contas em aberto, perdas, séries mensais, ranking e proteção CSV.
