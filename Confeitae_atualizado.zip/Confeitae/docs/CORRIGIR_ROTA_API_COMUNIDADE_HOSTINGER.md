# Corrigir “Rota da API não encontrada” na Comunidade KSW

A Comunidade depende do backend Node.js. Publicar somente os arquivos de `public/` não instala as rotas.

## Como verificar a versão ativa

Abra no navegador: `https://SEU-DOMINIO/api/social/health`. A resposta correta é um JSON semelhante a:

```json
{ "ok": true, "module": "ksw-social", "api_version": "2026-11-08-stories2" }
```

Se retornar `Rota da API não encontrada`, a aplicação Node.js ativa não contém o router social atualizado ou a Hostinger está executando outra pasta/versão do projeto.

## Conferir na Hostinger

1. Abra o hPanel e entre na aplicação Node.js correspondente ao domínio.
2. Confira **Application root**: deve apontar para a pasta que contém diretamente `package.json`, `server.js`, `routes/` e `public/`. Não deve apontar para `public/` nem para uma pasta pai que contenha outra subpasta `KSW_Confeitaria1/`.
3. Dentro dessa raiz, confirme a existência de `server.js`, `routes/social.js` e `public/social-ui.js`.
4. Confirme que o comando de inicialização é `npm start` e que o entry point é `server.js`.
5. Instale as dependências com o mecanismo do hPanel ou `npm install`/`npm ci`, conforme o painel permitir.
6. Reinicie a aplicação Node.js pelo hPanel.
7. Abra `/api/social/health` novamente. Só prossiga quando o JSON acima aparecer.
8. Depois, entre no KSW e atualize a página com `Ctrl + F5`.

## Importante

- Não basta substituir apenas `public/`: as rotas são definidas em `routes/social.js` e montadas por `server.js`.
- Não coloque o Application root em `public/`.
- Não use um servidor de hospedagem estática separado para o frontend, a menos que ele encaminhe `/api/*` para o backend Node.js.
- Mantenha `storage/` e o banco SQLite em armazenamento persistente/backups.
