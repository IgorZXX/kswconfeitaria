# Plano e ferramentas — SQLite para MySQL 8.x

## Estado desta versão

**O MySQL está preparado para inventário e migração para homologação, mas ainda NÃO é o banco de execução do KSW.** As rotas e o módulo `database.js` continuam usando SQL SQLite (`sqlite3`). `database.js` bloqueia deliberadamente `DB_DRIVER=mysql` para não iniciar o app silenciosamente com o driver errado.

Não altere `DB_DRIVER=sqlite` nesta versão. Não aponte o app para MySQL ainda.

## Requisitos pretendidos

- MySQL 8.0.16 ou superior (para as CHECK constraints usadas no schema gerado).
- InnoDB.
- `utf8mb4`; DDL gerado usa `utf8mb4_0900_bin` para comparações sensíveis a maiúsculas/minúsculas equivalentes ao comportamento binário padrão.
- Node.js 18 ou superior.
- Driver de migração `mysql2/promise` (instalado somente quando for executar homologação MySQL).
- Um schema de homologação novo e vazio, isolado do banco de produção.

## Variáveis de ambiente para ferramenta de migração

Copie `.env.example` para `.env` somente no ambiente local protegido. Não versione credenciais.

```env
DB_DRIVER=sqlite
DB_HOST=127.0.0.1
DB_PORT=3306
DB_NAME=ksw_homologacao_nova
DB_USER=ksw_migrator
DB_PASSWORD=SEGREDO_FORTE
DB_CONNECTION_LIMIT=10
DB_SSL=false
# DB_SSL_CA_FILE=C:/caminho/ca.pem
DATABASE_PATH=C:/caminho/backup/ksw_database.sqlite
```

O `DB_DRIVER=sqlite` mantém a aplicação no banco atual. As variáveis `DB_*` são lidas exclusivamente pelas ferramentas de preparação MySQL nesta versão.

## Inventário do schema em uso

O ZIP não contém o banco SQLite físico da instalação. Por isso, não foi possível enumerar a versão efetivamente implantada nem contar registros reais. O schema no código define os seguintes grupos:

### Tabelas base de `database.js`

- `users`
- `orders` — tabela de pedidos de assinatura/pagamento de gateway; não é a encomenda da confeitaria.
- `password_resets`
- `menus`
- `menu_hubs`

### Dados operacionais (`lib/data-tables.js`)

- `clientes`
- `ingredientes`
- `produtos`
- `pedidos` — encomendas da confeitaria; distinta da tabela `orders`.
- `despesas`
- `fornecedores`
- `configuracoes`
- `movimentacoes_estoque`
- `embalagens`
- `lotes_estoque`
- `ordens_producao`
- `perdas_estoque`
- `tarefas`
- `orcamentos`
- `cupons`
- `fidelidade`
- `auditoria`

### Multiempresa (`lib/tenant-schema.js`)

- `tenants`
- `tenant_memberships`
- `tenant_invitations`
- `tenant_audit_logs`

### Administração da plataforma (`lib/platform-admin-schema.js`)

- `platform_admin_sessions`
- `platform_audit_logs`
- `platform_plans`

### Loja virtual (`lib/storefront-schema.js`)

- `storefront_settings`
- `storefront_order_requests`

O código declara 31 tabelas nessas migrações. O inventário final deve sempre ser feito no arquivo SQLite real, pois instalações antigas podem ter colunas extras, migrations parciais ou objetos adicionais.

## Instalação do driver para preparação

Na cópia local do projeto, quando houver acesso ao registry npm:

```powershell
npm install mysql2
```

Esse comando atualizará `package.json` e `package-lock.json` corretamente. Esta entrega não adiciona o pacote manualmente ao lockfile, nem inclui `node_modules`.

## 1. Backup e verificação do SQLite

1. Suspenda temporariamente gravações no app durante a cópia consistente.
2. Faça backup com o comando existente (`npm run backup`) ou copie o banco após fechar o servidor.
3. Guarde a cópia em diretório protegido, fora do ZIP e do repositório.
4. Nunca use o banco de produção como origem de testes destrutivos.

Exemplo:

```powershell
$env:DATABASE_PATH = 'C:\KSW\backups\ksw_database.sqlite'
npm run mysql:report
```

O modo `--report` abre o arquivo em somente leitura, executa `PRAGMA integrity_check`, `PRAGMA foreign_key_check` e lista tabelas, colunas, índices, chaves estrangeiras, views e triggers. Também registra tabelas que exijam revisão manual, sem esconder o inventário.

## 2. Gerar e revisar schema MySQL

```powershell
node scripts/migrate-sqlite-to-mysql.js --report --schema-out .\docs\mysql-schema.generated.sql
```

O arquivo gerado contém DDL, não dados. Ele é criado sem sobrescrever um arquivo existente. Revise-o antes de qualquer migração.

A ferramenta bloqueia automaticamente situações que não converte com segurança, como:

- índices parciais SQLite;
- collation `NOCASE` sem uma decisão explícita de equivalência;
- índices com expressões/colunas não reconhecidas;
- checks contendo funções ou operadores específicos sem tradução segura;
- views e triggers que ainda não tenham sido reescritos;
- tabelas virtuais/colunas ocultas ou geradas;
- texto indexado acima do limite conservador de 191 caracteres;
- `SET DEFAULT` em chaves estrangeiras, não suportado por InnoDB.

Não ignore uma mensagem de bloqueio para forçar a migração. Faça a conversão manual e adicione teste de equivalência.

## 3. Dry-run em schema vazio de homologação

Crie um schema novo no MySQL de homologação, com usuário de migração limitado a esse schema. Não use schema que já tenha dados.

```powershell
npm run mysql:dry-run
```

A ferramenta verifica MySQL 8.0.16+, InnoDB, schema vazio, compatibilidade de metadata e ordem de cópia. Nenhuma tabela ou linha é gravada no dry-run.

## 4. Migração de teste para schema vazio

**Somente depois de revisar backup, relatório e DDL**, execute em homologação:

```powershell
$env:CONFIRM_MYSQL_MIGRATION = 'YES'
npm run mysql:migrate
Remove-Item Env:CONFIRM_MYSQL_MIGRATION
```

O script:

1. exige a confirmação explícita `CONFIRM_MYSQL_MIGRATION=YES`;
2. abre a origem SQLite em somente leitura e mantém snapshot de leitura;
3. exige integridade SQLite aprovada e nenhuma FK violada;
4. cria as tabelas InnoDB sem FKs inicialmente;
5. copia os dados para o schema vazio usando uma transação de inserção;
6. adiciona as FKs depois da cópia;
7. valida contagens, somas numéricas, amostra inicial e digest multiconjunto SHA-256 do conteúdo integral de cada tabela;
8. cria índices secundários;
9. mantém o app apontado para SQLite; não altera `.env`, runtime ou tráfego.

Se falhar após criação de tabelas, o schema de homologação pode ficar parcialmente montado para diagnóstico. Não o promova. Após investigação, descarte somente o schema descartável de homologação e crie outro vazio para repetir; nunca rode `DROP` em produção.

## 5. Conversões de dados

| Origem SQLite | Destino preparado | Observação |
|---|---|---|
| `INTEGER` | `BIGINT` | `TINYINT(1)` para flags reconhecidas |
| `REAL` monetário | `DECIMAL(20,6)` | A escala 6 precisa ser validada com o domínio financeiro e exemplos reais |
| `REAL` quantidade | `DECIMAL(20,6)` | Evita ponto flutuante binário no destino |
| `REAL` genérico | `DECIMAL(24,8)` | Conferir precisão/escala do dado real |
| `TEXT` comum | `LONGTEXT` | JSON em texto é preservado como texto nesta primeira migração |
| `TEXT` indexado/chave | `VARCHAR(191)` | Limite conservador; ferramenta verifica tamanho atual |
| `BLOB` | `LONGBLOB` | Conferir volume e armazenamento |
| `DATETIME`/`TIMESTAMP` | `DATETIME` | Validar timezone e convenção dos valores antes do cutover |

Valores `DECIMAL` são mantidos como strings pelo driver (`decimalNumbers=false`) para não perder precisão em conversões para `Number`.

## 6. O que falta antes do MySQL poder ser principal

A camada `lib/mysql-pool.js` e a ferramenta de migração não constituem uma camada completa de acesso a dados para o runtime. Ainda é necessário:

- inventariar todos os SQL executados pelas rotas e serviços;
- remover dependência de `PRAGMA`, `INSERT OR IGNORE`, `ON CONFLICT`, `BEGIN IMMEDIATE`, `datetime()` e sintaxes SQLite;
- criar repositórios/DAO com operações transacionais via conexão MySQL dedicada;
- assegurar filtros de tenant em todas as leituras/escritas;
- adaptar migrations e inicializadores de schema para MySQL;
- testar concorrência/idempotência com MySQL real;
- testar cobrança e webhooks em homologação;
- rodar `npm test` e smoke HTTP com `mysql2` e MySQL real;
- revisar queries, índices e planos `EXPLAIN` com volume representativo.

Há SQL SQLite espalhado em `database.js`, `routes/` e `lib/`; não é seguro ativar MySQL apenas por mudar o driver. `database.js` bloqueia explicitamente `DB_DRIVER=mysql` nesta versão para evitar fallback silencioso ou inicialização inconsistente.

## 7. Conferência antes da promoção

Validar no mínimo:

- contagem de todas as tabelas;
- todas as FKs e unicidades;
- usuários, empresas, memberships e convites;
- tabela `orders` (assinaturas/pagamentos) separada de `pedidos` (encomendas);
- pagamentos e valores monetários;
- clientes, produtos, receitas, ingredientes e embalagens;
- lotes, movimentações, ordens de produção, consumo e perdas;
- contas a pagar/receber e resultados financeiros;
- menus, slugs, configurações e pedidos da loja virtual;
- sessões administrativas, planos e auditoria;
- login, checkout, webhooks, loja pública, produção e isolamento multiempresa;
- digest integral origem/destino para todas as tabelas.

## 8. Cutover e rollback — ainda não executados

A troca de banco exige janela de manutenção aprovada, congelamento de gravações, backup final, migração final, validação completa, configuração de runtime MySQL já implementado e plano de rollback ensaiado. Não existe cutover nesta entrega.

O SQLite deve ser preservado em modo somente leitura após a migração inicial. Se houver escrita no MySQL após cutover, não restaure um arquivo SQLite antigo como se fosse estado atual: isso apagaria operações recentes. O rollback precisa considerar delta de escrita, sincronização reversa ou restauração do backup com indisponibilidade controlada.

## 9. Backup MySQL para produção futura

Esta versão não agenda nem armazena backups MySQL automaticamente. Para uma implantação futura, adote backup externo criptografado diário, retenção definida, cópia fora do host, binlogs para recuperação pontual (PITR), alerta de falhas e teste de restauração periódico. Um exemplo de ferramenta de dump é `mysqldump --single-transaction`; confirme as opções adequadas à versão e aos objetos usados. Não considere o backup bem-sucedido sem testar a restauração.
