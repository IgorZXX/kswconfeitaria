# Auditoria da Comunidade KSW em relação ao Instagram

**Data da revisão:** 8 de novembro de 2026  
**Escopo:** recursos da Comunidade KSW presentes neste repositório. Esta é uma comparação funcional, não uma auditoria independente de segurança nem uma cópia integral da plataforma Instagram.

## Resultado executivo

A Comunidade KSW já cobre uma base social útil para uma rede especializada em confeitarias: perfis por empresa, seguir, feed de fotos e vídeos, Explorar, aba de vídeos, Stories temporários, curtidas, comentários e mensagens privadas de texto.

**Conclusão:** há semelhança na estrutura principal, mas ainda não há paridade com o Instagram. A Comunidade KSW é um MVP vertical, focado em confeitarias. O maior déficit está na profundidade das ferramentas de criação, descoberta e comunicação, e não apenas na aparência.

## Matriz de funcionalidades

| Área | O que existe no KSW | Comparação com Instagram | Situação |
|---|---|---|---|
| Perfis | Perfil público por confeitaria, `@usuário`, bio, link e avatar | Base semelhante, mas sem perfis pessoais, posts fixados completos ou ferramentas avançadas de criador | Parcial |
| Seguir | Seguir e deixar de seguir empresas | Função social básica presente | Presente |
| Feed | Publicar uma foto ou um vídeo com legenda; curtir, comentar, excluir a própria publicação e denunciar | Cobertura básica; faltam carrossel, edição, marcações, colaboração, salvar e repostar | Parcial |
| Explorar | Grade em mosaico, busca de confeitarias e publicações públicas recentes | Não possui recomendação algorítmica personalizada, tendências ou descoberta por hashtags | Parcial |
| Vídeos | Aba exclusiva para publicações que têm arquivo de vídeo | Não equivale a Reels: não há feed vertical recomendado, áudio/trilhas, remix, templates ou ferramentas de edição | Parcial |
| Stories | Foto ou vídeo em fluxo separado, visualizador vertical, navegação, visualizações por confeitaria e expiração em 24 horas | O ciclo básico de Story está presente; faltam arquivo, destaques, respostas, reações, listas de audiência e figurinhas interativas | Parcial |
| Mensagens | Conversa privada 1:1 entre empresas, histórico, contador de não lidas e atualização periódica | Direct é muito mais completo; faltam grupos, mídia, áudio, chamadas, reações, respostas a Stories, recibos detalhados e notificações push | Parcial |
| Moderação | Denúncia de publicações e exclusão de conteúdo próprio | Falta painel administrativo de análise, fila de denúncias, bloqueio e ferramentas de segurança comunitária | Parcial |
| Notificações | Sem central de notificações ou push | Instagram tem mecanismos de notificação mais amplos | Ausente |
| Arquivo e destaques | Stories ativos somem após 24 horas; a mídia e o registro são limpos quando a lista de Stories é consultada depois da expiração | Não existe arquivo privado nem destaques permanentes no perfil | Ausente |
| Transmissões ao vivo | Não existe | Instagram oferece Live | Ausente |
| Hashtags e localização | Não existem | Não há páginas de hashtag, marcação de local ou descoberta por assunto | Ausente |
| Insights | Contagem simples de visualizações de Story por empresa | Não há painel de alcance, engajamento, retenção ou desempenho de conteúdo | Ausente |

## Correção de Stories implementada nesta revisão

- O botão **Seu story** abre o compositor em modo Story.
- Foto e vídeo usam endpoints e diretórios de upload separados dos posts do feed.
- Vídeo publicado por esse fluxo é salvo em `ksw_social_stories`; não cria linha em `ksw_social_posts`.
- O Story tem visualizador próprio e expira após 24 horas.
- A lista de Stories exibe conteúdo do próprio perfil e de empresas seguidas.
- A API registra uma visualização por empresa visitante, sem duplicar a mesma empresa para o mesmo Story.
- A API deixa de servir a mídia após expiração ou remoção. A limpeza física dos arquivos expirados ocorre quando a lista de Stories é consultada novamente.
- **Limitação de privacidade:** a lista e o registro de visualização respeitam a relação de seguir, mas as rotas da mídia aceitam o endereço direto enquanto o Story está ativo. Quem obtiver esse endereço poderá abrir a mídia sem seguir o perfil. Portanto, não tratar Stories atuais como conteúdo confidencial; para privacidade mais forte, implementar URL assinada de curta duração ou controle de acesso compatível com a reprodução de mídia.
- A remoção de Story mantém a navegação do visualizador e reinicia o avanço automático para o próximo item.

## Diferenças que mais importam para o público KSW

A meta não precisa ser copiar todas as funções do Instagram. Para uma rede de confeitarias, é mais útil priorizar recursos que ajudem a mostrar produtos, trocar conhecimento e gerar oportunidades de negócio.

### Próximas melhorias recomendadas

1. **Arquivo de Stories e Destaques:** preservar Stories expirados de forma privada e permitir que a confeitaria selecione coleções permanentes, por exemplo `Bolos`, `Doces`, `Encomendas` e `Bastidores`.
2. **Respostas aos Stories no Direct:** permitir que uma confeiteira responda a um Story e que a conversa abra com referência ao conteúdo original.
3. **Figurinhas úteis para negócios:** enquete, caixa de perguntas e chamada para orçamento, sem tentar reproduzir toda a biblioteca criativa do Instagram.
4. **Carrossel no feed:** permitir várias fotos na mesma publicação para mostrar detalhes, etapas e variações de um produto.
5. **Notificações:** avisar sobre novas mensagens, respostas e interações relevantes, com preferências e controles de privacidade.
6. **Reels simplificados:** só depois, criar um visualizador vertical de vídeos curtos; recomendação algorítmica, música licenciada e remix exigem infraestrutura e decisões adicionais.
7. **Moderação e privacidade:** bloqueio de empresas, controles de quem pode interagir, fila de denúncias e ferramentas administrativas antes de ampliar a comunidade.

## Pontos técnicos antes de liberar para muitas empresas

- Validar em navegador real com duas ou mais contas/empresas, incluindo perfis que não se seguem.
- Testar upload e reprodução em celular, desktop e conexões lentas; verificar MP4/WebM e MOV compatível.
- Planejar limpeza automática agendada dos arquivos de Stories expirados, sem depender apenas de uma nova consulta à lista.
- Restringir também o acesso por URL direta das mídias de Story, sem quebrar a reprodução de vídeo no navegador.
- Configurar armazenamento persistente e backups para fotos e vídeos. Não confiar na pasta efêmera de uma hospedagem.
- Definir cotas e monitorar crescimento de mídia; 30 MB por vídeo pode gerar consumo expressivo.
- Adotar uma estratégia de armazenamento compartilhado e rate limiting persistente antes de executar múltiplas instâncias do servidor.
- Implementar moderação e processo de resposta às denúncias antes de aumentar a exposição pública.

## Referências oficiais do Instagram/Meta consultadas

- Meta — [Introducing Instagram Reels](https://about.fb.com/news/2020/08/introducing-instagram-reels/): descreve a distinção entre publicar um Reel e compartilhá-lo como Story; a publicação compartilhada como Story não se torna Reel nem publicação de perfil e expira após 24 horas.
- Meta — [New Stickers in Instagram Stories](https://about.fb.com/news/2024/05/new-stickers-in-instagram-stories/): exemplos de figurinhas interativas e ferramentas criativas em Stories.
- Meta — [New Instagram Features to Help You Connect](https://about.fb.com/news/2025/08/new-instagram-features-help-you-connect/): reposts, mapa e aba Friends em Reels, mostrando recursos de descoberta/conexão além do feed básico.
- Meta — [Instagram Highlights and Archive](https://about.fb.com/ja/news/2017/12/instagram_highlight_archive/): anúncio oficial sobre arquivo privado e destaques de Stories.
- Meta — [Instagram Plus](https://about.fb.com/br/news/2026/06/apresentando-o-instagram-plus/): exemplos de recursos premium opcionais; não foram tratados como requisitos mínimos de paridade para o KSW.

## Testes

A suíte automatizada do projeto deve ser executada após instalar as dependências, usando `npm test`. Os testes de código não substituem validação visual no navegador, teste HTTP integrado, teste com múltiplas contas ou auditoria de segurança independente.
