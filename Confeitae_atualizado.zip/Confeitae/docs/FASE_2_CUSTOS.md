# Confeitaê — Fase 2: motor de custos e fichas técnicas

## O que foi adicionado

- Motor de cálculo compartilhado entre navegador e Node.js em `public/costing.js`.
- Conversão automática de massa (`mg`, `g`, `kg`) e volume (`ml`, `L`).
- Conversão entre sinônimos de unidade e compatibilidade estrita para unidades personalizadas (por exemplo, lata, pacote e caixa).
- Cálculo do custo total de ingredientes do lote e custo de ingredientes por unidade produzida.
- Custos adicionais por unidade: embalagem, mão de obra, energia/água/gás e outros.
- Sugestão de preço pela margem sobre preço de venda, limitada a 90% para evitar sugestões desproporcionais.
- Exibição de custo por ingrediente, custo por lote, custo unitário, contribuição estimada e margem após taxas conhecidas.
- Validação de rendimento, quantidade, unidade compatível, ingredientes cadastrados e custos não negativos.
- Embalagem vinculada ao estoque entra no custo unitário; a ficha exige embalagem cadastrada, preço válido e quantidade usada maior que zero. O valor manual de embalagem continua sendo somado separadamente.
- Snapshot versionado da ficha técnica salvo em cada produto, mantendo o custo unitário atual registrado.
- Ação de aplicar preço sugerido e salvamento agora bloqueiam margem vazia ou inválida, sem transformar valor ausente em preço zero.
- Compatibilidade com fichas antigas: quando uma linha não possui unidade, é utilizada a unidade do ingrediente cadastrado.

## Regra de cálculo

O preço cadastrado no ingrediente é sempre o preço por unidade de compra (`ingrediente.un`). A quantidade da receita pode usar outra unidade compatível. Exemplo: ingrediente custa R$ 38,90/kg; receita utiliza 250 g; o custo da linha será R$ 9,725.

Os campos antigos `emb`, `mo`, `en` e `out` continuam sendo interpretados como custos por unidade produzida, para manter compatibilidade com os dados existentes.

Custo unitário = (soma dos custos dos ingredientes do lote / rendimento) + embalagem + mão de obra + energia/água/gás + outros.

Preço sugerido = custo unitário / (1 - (margem desejada + taxas variáveis confirmadas) / 100).

A margem aqui é margem sobre o preço de venda, não markup sobre o custo.

## Dados e compatibilidade

Os novos campos são gravados dentro do JSON do produto já sincronizado pela API. Não foi necessário alterar tabelas ou apagar dados existentes. A estrutura de dados antiga continua válida.

Pedidos continuam preservando o custo unitário (`cu`) no momento do registro; mudanças posteriores no preço de ingredientes não recalculam o histórico automaticamente.

## Testes

Executar:

```bash
npm run test:costing
```

A suíte de custos usa apenas módulos nativos do Node.js e cobre conversões, fichas técnicas, snapshots, taxas e alertas de prejuízo. Para a suíte completa (incluindo o teste HTTP/SQLite da Fase 1):

```bash
npm test
```

O segundo comando depende das dependências de produção instaladas (`npm ci`) e do driver SQLite nativo compatível com o sistema operacional.


## Limite de confiança

O motor roda no navegador. A API de sincronização atual grava o JSON enviado pela conta autenticada e não recalcula `custo_unitario` ou `cost_snapshot` no servidor. Esses campos servem como dados de gestão, mas não devem ser tratados como valores contábeis invioláveis nem usados como base fiscal sem uma etapa futura de recomputação e auditoria no backend.


## Margem, taxas desconhecidas e alertas de prejuízo (2026-11-06)

- O motor `public/costing.js` calcula contribuição por unidade, pelo rendimento completo da receita e pela quantidade real de cada encomenda, considerando custo direto da ficha e percentual variável de venda quando informado.
- A taxa percentual é opcional, mas **em branco significa desconhecida**, não zero. Um zero só é considerado confirmado quando a confeiteira informa explicitamente 0%. Valores legados positivos continuam compatíveis; zeros legados sem confirmação são tratados como desconhecidos.
- Se o preço ficar abaixo dos custos cadastrados, o alerta mostra a perda mínima por unidade e o total do lote calculado pelo rendimento real; no pedido, usa a quantidade da encomenda e pede confirmação antes de registrar uma venda com resultado negativo. Quando a taxa não foi informada, o sistema avisa que a perda real pode ser maior e não fornece preço recomendado como definitivo.
- O preço sugerido considera a contribuição desejada sobre o preço de venda e a taxa variável confirmada: `preço = custo unitário / (1 - (margem desejada + taxa variável) / 100)`. A recomendação explica o preço calculado e aponta ações práticas: comparar fornecedores, rever porcionamento/rendimento e reduzir desperdício.
- Pedidos congelam custo e percentual informado no momento do registro. Pedidos antigos sem esse dado são identificados nos relatórios; o KSW não assume taxa zero para eles.
- A ficha destaca o ingrediente com maior participação no custo do lote para ajudar a confeiteira a priorizar a revisão do fornecedor, da quantidade usada e das perdas de preparo. Indicadores do painel e dos relatórios usam os termos “sobra” e “contribuição”, não “lucro líquido”.
- Custos fixos não rateados (aluguel, internet, manutenção), entrega e custos não cadastrados ficam fora da perda/contribuição exibida; uma sobra positiva não garante lucro líquido. Despesas fixas precisam ser consideradas antes de definir preço final. Recomendações são gerenciais e não substituem contabilidade, apuração tributária nem conciliação do gateway.


## Rateio de despesas fixas e correção do início do frontend (2026-11-06)

- A área **Financeiro > Custos fixos** permite cadastrar aluguel, internet, telefone, contador, manutenção e demais despesas recorrentes, além da previsão de unidades mensais vendidas/produzidas. O KSW soma os valores e divide pela previsão para obter um custo fixo médio por unidade.
- O rateio passa a compor a análise de preços, perda por unidade, perda do lote e estimativas de encomendas novas. O painel de produtos também considera o rateio confirmado e mostra um atalho para completá-lo quando estiver ausente.
- A ausência de despesas cadastradas **não é interpretada como R$ 0,00 automaticamente**. A confeiteira precisa cadastrar valores ou salvar explicitamente que não possui despesas fixas mensais. Sem essa confirmação, o KSW marca a rentabilidade completa como incompleta e não apresenta preço final recomendado.
- Pedidos novos congelam o rateio por unidade que estava confirmado no momento do registro. Pedidos antigos sem esse snapshot permanecem sinalizados como históricos incompletos; o KSW não aplica retroativamente a configuração atual a vendas antigas.
- O rateio é gerencial e não gera contas a pagar ou movimentações de caixa. A despesa efetiva continua sendo registrada uma única vez no Financeiro, evitando dupla contagem no resultado. Não repita no cadastro fixo itens já calculados por unidade (embalagem, mão de obra direta ou consumo variável).
- **Limitação do método:** dividir despesas por unidades pressupõe uma unidade média de produto. Em cardápios com produtos muito diferentes em tamanho e tempo de produção, o rateio é uma aproximação; uma futura evolução pode permitir ratear por horas de produção ou por participação no faturamento. A confeiteira deve revisar a previsão mensal quando o mix de produtos mudar.
- A tela branca foi causada por duas falhas no script principal: o bloco de cálculo de preço estava fora de `function calc()` (com `return` em escopo global, inválido no navegador) e `init()` não era chamado após carregar os módulos. Ambos foram corrigidos. A inicialização ocorre depois de `production-ui.js`; falhas de boot geram uma mensagem de erro e opção para tentar novamente. Cache-busting foi atualizado para CSS e scripts externos modificados.
- Testes de regressão compilam scripts inline com `vm.Script`, no contexto real de script do navegador, e verificam a ordem de inicialização, a presença de `calc()`, o rateio e a confirmação explícita de zero.

### Regra de rateio

`custo fixo médio por unidade = soma das despesas fixas mensais / previsão de unidades vendáveis no mês`.

Exemplo: aluguel R$ 500 + internet R$ 100 = R$ 600/mês. Com previsão de 200 unidades, o rateio é R$ 3,00 por unidade. Se a confeiteira prevê apenas 150 unidades, o rateio aumenta para R$ 4,00 por unidade. O preço sugerido soma esse rateio ao custo direto, e aplica margem e taxas variáveis confirmadas.
