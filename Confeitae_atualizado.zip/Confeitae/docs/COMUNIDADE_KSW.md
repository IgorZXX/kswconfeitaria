# Comunidade KSW — primeira versão

## Objetivo

A Comunidade KSW é uma rede social interna para descoberta e divulgação de confeitarias. O feed reúne publicações de perfis públicos de empresas ativas, sem compartilhar pedidos, clientes, receitas, estoque, informações financeiras ou o nome pessoal de quem publicou/comentou (a interface usa o nome público da empresa).

## Funcionalidades desta versão

- Perfil por empresa com `@usuário`, bio e link HTTPS opcional.
- Foto de perfil opcional: o navegador recorta a imagem em quadrado (até 512 px) e converte para PNG; o servidor revalida e reconstrói em `/api/social/upload-avatar`. A URL só é aceita no perfil se pertencer à própria empresa; enviar vazio remove a foto.
- Layout estilo rede social: faixa de Stories ativos no topo e barra inferior com Início, Explorar, Criar, Vídeos, Mensagens e Perfil. Resumo do perfil, "Sugestões para você" e o rodapé ficam na aba Perfil.
- Stories: foto ou vídeo publicados por um fluxo separado do feed; mídia de Story tem armazenamento próprio, visualizador vertical, navegação entre Stories, registro de visualização por confeitaria e expiração após 24 horas. A faixa mostra Stories próprios e de confeitarias seguidas; o conteúdo expirado/removido deixa de ser servido e os arquivos são removidos na próxima consulta à lista de Stories. Vídeos dos Stories usam a mesma validação de contêiner, poster PNG e limite de 90 s/30 MB.
- Vídeos: MP4 ou WebM (e MOV compatível com o navegador) de até 30 MB e 90 s. O compositor aceita foto ou vídeo; ao escolher um vídeo, o navegador gera automaticamente uma capa (PNG) a partir dele; o servidor confere a assinatura do contêiner (`ftyp` ou EBML/webm), guarda com nome aleatório em `storage/social-videos/tenant-<id>` e entrega com Range, `nosniff` e tipo fixo. O vídeo **não é recodificado**; limites: 8 envios/hora, 40 arquivos e 600 MB por empresa. A aba Vídeos lista só publicações com vídeo.
- Perfil começa privado e só aparece na comunidade depois que o proprietário/usuário autorizado marca a opção de perfil público.
- Feed e Explorar mostram todas as publicações públicas (fotos e vídeos); a aba Vídeos mostra somente publicações com arquivo de vídeo.
- Publicações com foto ou vídeo e legenda.
- Envio de foto da publicação em área de arrastar e soltar, com prévia e botão para remover.
- Upload de imagens rasterizado para PNG pelo navegador e novamente validado/reconstruído no servidor.
- Curtidas por usuário, comentários, seguir/deixar de seguir empresas e denúncia por motivo.
- Busca de perfis por nome da confeitaria, `@usuário` e bio.
- Mensagens privadas entre duas confeitarias: o botão **Conversar** aparece nos perfis públicos encontrados em Explorar e nas publicações de outras empresas. As conversas ficam na aba Mensagens, são persistidas no SQLite e usam uma caixa de entrada em duas colunas: lista de confeitarias à esquerda e chat à direita em telas grandes; no celular, a lista e o chat são alternados para preservar o espaço. Exibem histórico, contador de não lidas e atualização automática da conversa aberta. O conteúdo é texto simples, limitado a 2.000 caracteres; o envio tem limite de frequência e requer permissão de escrita. Uma empresa só pode ler conversas das quais participa. Novas conversas exigem que os dois perfis estejam públicos.
- Remoção de publicações da própria empresa e remoção de comentários pelo autor ou pela empresa dona da publicação.

## Como usar

1. No menu principal, entre em **Comunidade**.
2. Em **Meu perfil**, escolha um `@usuário`, escreva uma bio e decida se quer tornar o perfil público.
3. Com o perfil público ativado, no **Início** use **Seu story** para compartilhar uma foto ou vídeo temporário. O vídeo vai para a área de Stories, nunca para o feed de publicações; cada Story expira após 24 horas.
4. Use **Criar** na barra inferior para publicar conteúdo permanente no feed. Para vídeos, o sistema cria uma capa automaticamente.
5. Use **Explorar** para buscar confeitarias e ver todas as publicações recentes, tanto fotos quanto vídeos. A aba **Vídeos** fica reservada exclusivamente às publicações com arquivo de vídeo.
6. Para conversar, encontre uma confeitaria em **Explorar** (ou em uma publicação) e toque em **Conversar**. Depois, acompanhe as respostas pela aba **Mensagens**.

A foto aceita PNG, JPG ou WebP, até 5 MB na seleção. O navegador redimensiona a imagem para no máximo 2.000 px e envia PNG; o servidor sanitiza o arquivo antes de armazenar.

## API e persistência

- Rota: `routes/social.js`, montada em `/api/social`.
- Schema aditivo e idempotente: `lib/social-schema.js`, inicializado em `database.js`.
- Interface: `public/social-ui.js` e `public/social-ui.css`, chamada pelo roteador principal em `public/index.html`.
- Tabelas: `ksw_social_profiles`, `ksw_social_posts`, `ksw_social_likes`, `ksw_social_comments`, `ksw_social_follows`, `ksw_social_reports`, `ksw_social_conversations`, `ksw_social_messages`, `ksw_social_stories` e `ksw_social_story_views`.
- Fotos ficam em `storage/social-posts/tenant-<id>`; a pasta não deve ser publicada por um servidor estático. A entrega ocorre pela rota controlada `/api/social/images/:tenantId/:filename`.
- Mídia temporária de Stories fica separada em `storage/social-story-images/tenant-<id>` e `storage/social-story-videos/tenant-<id>`. As rotas conferem se o Story ainda está ativo antes de servir cada arquivo; a limpeza física ocorre ao carregar novamente a lista de Stories após a expiração. A lista respeita perfis seguidos, mas o endereço direto da mídia pode ser aberto por quem o obtiver enquanto o Story estiver ativo; não tratar esse conteúdo como confidencial até a adoção de URLs assinadas ou controle de acesso compatível com mídia.

## Limites e próximos passos

Esta versão é um MVP, não uma cópia completa do Instagram. Não inclui destaques permanentes/arquivo de Stories, Reels com recomendação vertical, figurinhas interativas nos Stories, notificações push em tempo real, envio de fotos/arquivos no chat, hashtags, recomendação algorítmica, edição de post, perfis de pessoas físicas, página pública indexável para visitantes sem login, painel de moderação ou fila administrativa para tratar denúncias. As mensagens são atualizadas por consulta periódica enquanto a conversa está aberta; não usam WebSocket. A denúncia é armazenada, mas ainda exige processo administrativo/manual fora desta interface.

O feed, explorar, curtidas, comentários e seguir exigem sessão de usuário e assinatura ativa do KSW. A rede identifica empresas/tenants como perfis; curtidas são únicas por usuário e relacionamentos de seguir são por empresa. Perfil privado não aparece no feed ou na busca, mas links de imagem já publicados são recursos públicos por endereço direto. Não publique conteúdo que deva permanecer confidencial.

Os limitadores de publicação/upload e comentários são em memória por processo. Em implantação com múltiplas instâncias, devem usar um armazenamento compartilhado (por exemplo, Redis). Antes de liberar amplamente, testar em homologação isolamento com duas empresas, upload real, denúncias e moderação, retenção/exclusão de imagens e capacidade de armazenamento.

## Testes específicos

```bash
node --test scripts/social-schema.test.js scripts/social-ui.test.js
```

Esses testes verificam criação idempotente do schema, unicidade case-insensitive do `@usuário`, estrutura das rotas, integração da navegação e pontos principais da interface. Não substituem teste HTTP integrado, teste de navegador ou avaliação de segurança independente.
