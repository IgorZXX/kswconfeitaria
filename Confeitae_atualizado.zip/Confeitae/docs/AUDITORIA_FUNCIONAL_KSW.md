# Auditoria funcional e recomendações — Confeitaê

**Escopo:** revisão estática do código, rotas, interfaces e documentação do projeto em 06/11/2026. Esta auditoria descreve o que está implementado no código e os limites documentados; não equivale a um teste operacional com credenciais reais de gateways ou com uma confeitaria em produção.

## Resumo executivo

O KSW já tem uma base ampla para gestão de uma confeitaria pequena ou em crescimento: cadastro de produtos e fichas técnicas, cálculo de custos, pedidos, agenda, estoque por lotes, produção, clientes, financeiro, relatórios, equipe e vitrine digital. O maior ganho de produto não é adicionar dezenas de telas, mas conectar melhor os fluxos existentes para que a confeiteira informe os dados do negócio uma vez e o sistema faça as contas, gere alertas e proponha as próximas ações.

A frase “a confeiteira não deve fazer nenhuma conta” deve ser entendida como **nenhuma conta manual**. O sistema ainda precisa receber dados reais: preço e unidade de compra dos ingredientes, quantidades da receita, rendimento, embalagem, tempo de produção e despesas. Não é seguro inventar custos nem buscar preços de fornecedores sem autorização e integração. Depois que esses dados forem informados, o KSW deve calcular custos, preços, margens, quantidades, saldos e necessidades de compra automaticamente.

## Funcionalidades encontradas

| Área | O que já existe | Avaliação |
|---|---|---|
| Conta e acesso | Cadastro, senha com hash, JWT, login, recuperação de senha ainda não configurada | Base adequada; login por nome de usuário incluído nesta revisão. |
| Multiempresa e equipe | Espaços de trabalho, convites, alternância de empresa, papéis e permissões | Boa base para equipes pequenas; convites ainda são compartilhados manualmente. |
| Produtos e receitas | Produtos, ingredientes, unidades, embalagens e fichas técnicas | Essencial e adequado ao público. |
| Custos e precificação | Conversão de g/kg, ml/L e unidades compatíveis; custo por lote/unidade; embalagem, mão de obra, energia e outros; sugestão de preço por margem | Resolve parte importante das contas, mas o cálculo ainda roda no navegador e depende de dados preenchidos corretamente. |
| Pedidos e orçamentos | Encomendas, clientes, itens, datas, observações, sinal, saldo, pagamentos e aprovação/recusa pública de orçamento com conversão em pedido | Boa cobertura; pagamento do orçamento e assinatura eletrônica ainda não estão integrados. |
| Agenda e capacidade | Calendário mensal e limite configurável por quantidade de pedidos/unidades por dia | Útil; ainda não faz gestão fina de capacidade por horário, equipamento ou etapa de produção. |
| Estoque | Ingredientes, embalagens, lotes, validade, FEFO, movimentos, perdas e alertas de estoque baixo | Forte para controle básico; a lista de compras agora é única (pedidos em aberto + estoque mínimo, com custo estimado e aviso de preço ausente); falta integrar encomendas públicas ao estoque e agrupar a compra por fornecedor. |
| Produção | Ordens de produção, rendimento da ficha, consumo protegido no servidor e registro de desperdício | Boa base; planejamento detalhado por etapa e agenda de capacidade ainda podem evoluir. |
| Clientes | Cadastro, preferências, observações e histórico de compras | Útil para relacionamento; pode evoluir com lembretes e comunicação automática consentida. |
| Fidelidade e cupons | Pontos, cupons e cadastro de preferências | Existem, mas pontos são lançados manualmente e cupom ainda funciona como prévia, sem desconto final automático no pedido. |
| Financeiro | Pagamentos, sinal/saldo, despesas, fornecedores, contas a pagar/receber e fluxo de caixa | Bom painel gerencial; não substitui contabilidade nem conciliação bancária. |
| Relatórios | Indicadores mensais, tendências, produtos, despesas, perdas, CSV e impressão em PDF | Adequado como BI gerencial; valores dependem da qualidade dos lançamentos. |
| Loja virtual | Vitrine pública, carrinho, retirada/entrega, taxa, pedido mínimo, prazo e pedido integrado ao KSW; aplica capacidade diária | Funciona como captação de encomendas; não processa pagamento online/PIX nem reserva estoque/horários/equipamentos. |
| Assistente e alertas | Dorinha com regras determinísticas para entregas, saldos, estoque e despesas | Útil como alertas; não é ainda uma assistente de IA que executa tarefas. |
| Super Admin | Empresas, usuários, assinaturas, planos, auditoria e gestão global | Evoluído nesta revisão com status de acesso correto e criação de planos Stripe pelo painel. |

## Correções desta revisão

1. **Status real da assinatura:** as listas de empresas e assinaturas agora distinguem o estado operacional da empresa (ativa/suspensa) do acesso comercial (ativo/vencido/cancelado/inativo). Um plano recorrente sem vencimento ou com data passada não aparece como acesso ativo. Planos únicos não recebem expiração mensal.
2. **Bloqueio de acesso:** a verificação de assinatura considera também o intervalo do plano personalizado, não apenas os nomes fixos “mensal”, “teste” e “vitalício”.
3. **Cadastro e rolagem:** o diálogo de autenticação permite rolagem vertical em telas pequenas e grandes, respeita a altura disponível e mantém o formulário acessível.
4. **Login por usuário:** o novo cadastro pede um nome de usuário. Contas antigas recebem um nome único derivado do nome cadastrado durante a migração; a autenticação continua aceitando o e-mail antigo como compatibilidade. O nome de usuário é mostrado no painel da conta e no Super Admin.
5. **Planos dinâmicos Stripe:** Super Admin pode criar plano com nome, descrição, preço, cobrança mensal ou pagamento único e intervalo mensal. O servidor cria produto e preço na Stripe, grava os identificadores no KSW e publica o plano no checkout. Desativar vendas bloqueia novas compras no KSW sem desativar o preço na Stripe nem cancelar assinaturas existentes.
6. **Retorno do checkout:** a consulta de status da sessão Stripe agora carrega também os metadados de periodicidade do plano personalizado, para avaliar corretamente o acesso recém-ativado.

## Comparativo competitivo — novembro de 2026

A análise das páginas públicas da Dora, Confeitaria Pro e Confeito está em `docs/ANALISE_COMPETITIVA_E_ROADMAP_2026.md`. A trava de capacidade da Agenda está conectada à loja virtual: pedidos online respeitam limites diários antes de serem gravados, com validação transacional e HTTP 409 quando o dia não comporta a encomenda. Na etapa seguinte, o orçamento ganhou link público individual: a cliente aprova/recusa, e o aceite cria pedido sem pagamento fictício, com transação e proteção contra reenvio. A suíte definida em `package.json` será atualizada com os testes desta etapa; veja os resultados efetivamente executados no histórico de segurança.

## Prioridades recomendadas para o produto

### P0 — confiabilidade do fluxo principal

- Manter uma fonte única de verdade para plano, cobrança e validade. Webhooks assinados devem atualizar a assinatura e o painel deve sempre refletir o estado calculado.
- Configurar e testar Stripe em modo de teste antes de habilitar venda real: chave `sk_test_`, endpoint e segredo `whsec_`, URLs e produtos/preços corretos. Não usar credenciais reais no desenvolvimento.
- Completar recuperação de senha com provedor de e-mail, mensagens neutras e tokens de uso único com expiração.
- Fazer onboarding guiado: cadastrar a primeira receita, adicionar ingredientes/unidades, informar rendimento, registrar primeiro pedido e criar primeiro lote. O sistema deve explicar os campos e validar o que estiver faltando.

### P1 — o sistema faz as contas

- Criar um assistente de ficha técnica que aceite quantidades em g/kg, ml/L, unidade/pacote e converta automaticamente para a unidade de compra.
- Ao atualizar o preço de um ingrediente, recalcular automaticamente custo por receita, custo por unidade e preço sugerido; destacar quais produtos ficaram com margem baixa e pedir confirmação antes de alterar preços publicados.
- Oferecer modelos simples de margem/preço para iniciantes, separando margem sobre venda de markup, sem misturar os dois conceitos.
- Tornar obrigatórios ou explicitamente opcionais os custos que costumam ficar esquecidos: embalagem, mão de obra, energia/gás, perdas, taxa do meio de pagamento, impostos e entrega. Exibir o efeito de cada item no custo final.
- Recalcular no servidor os dados críticos de ficha e de pedido a partir de quantidades/preços persistidos. Hoje o motor de custos funciona no navegador e o backend aceita os snapshots enviados; os números são gerenciais, não invioláveis.
- Produzir automaticamente uma lista de compras com base em pedidos confirmados, fichas técnicas, estoque útil, lotes próximos do vencimento e estoque mínimo. A confeiteira só revisa e confirma a compra.

### P1 — pedido até entrega sem retrabalho

- Conectar pedidos recebidos pela loja ao calendário e à capacidade diária/por horário. Não aceitar automaticamente uma data lotada sem mostrar alternativas.
- Reservar materiais e capacidade após confirmação do pedido; baixar o estoque em momento de produção configurável, evitando baixa duplicada ou consumo de pedidos não confirmados.
- Incluir sinal/parcelas/pagamento do pedido da cliente na própria loja por Pix e cartão, com webhooks e conciliação de status. Stripe atual é para a assinatura do SaaS; não é o checkout das encomendas da confeitaria.
- Evoluir o orçamento público com assinatura eletrônica, cobrança de sinal integrada e PDF; a aprovação/recusa e conversão em pedido já foram implementadas nesta etapa.

### P2 — automação e escala

- Integração de WhatsApp/e-mail para confirmação de encomenda, lembrete de sinal, aviso de produção, pedido pronto e pós-venda, com modelos aprovados e registro do consentimento.
- Leitura/importação assistida de notas e listas de compra, sempre exibindo a extração para conferência antes de gravar.
- Compra e fornecedor: histórico de preço, lead time, lista de reposição, comparativo de cotação e recebimento que cria lotes/validade.
- Financeiro: lançamentos automáticos a partir de pedidos/pagamentos, taxas de gateway, estornos e despesas; depois conciliação bancária. Manter relatório gerencial separado de escrituração fiscal/contábil.
- Evoluir alertas da Dorinha para recomendações com contexto e ações somente após confirmação humana.

## Limites técnicos e de operação a resolver antes de escalar

- O banco entregue usa SQLite. Há preparação/documentação de migração para MySQL, mas o caminho de produção continua SQLite; para maior concorrência e expansão multi-instância, planejar migração real para banco servidor com transações, backups e isolamento por tenant testados.
- A sincronização offline usa estratégia de último envio por registro; edição simultânea do mesmo registro em dois dispositivos pode sobrescrever alteração recente.
- A ficha/custo é calculada no frontend e persistida pela API como JSON. Não usar os números atuais como livro contábil, documento fiscal ou prova inviolável.
- O dashboard financeiro é gerencial e não recebe conciliação bancária automática.
- A auditoria do Super Admin é uma tabela de banco normal; não é imutável e requer backups externos protegidos.
- Convites de equipe são compartilhados manualmente e a recuperação de senha retorna indisponibilidade enquanto o e-mail não estiver configurado.
- O catálogo público capta encomendas, mas não é um e-commerce com pagamento e gestão de capacidade/estoque completos.
- A criação de planos Stripe desta revisão exige `STRIPE_SECRET_KEY` no servidor. O código cria produtos/preços quando o administrador envia o formulário; nenhum produto real foi criado durante esta auditoria e não houve chamada de cobrança. Configurar `STRIPE_WEBHOOK_SECRET` e testar eventos é obrigatório antes de vender.

## Princípio de UX recomendado

A confeiteira não deve precisar saber calcular custo por grama, margem, rendimento, consumo de material, saldo em aberto, quantidade a comprar ou capacidade disponível. A interface deve pedir apenas os dados observáveis que só ela conhece (preço pago, quantidade, rendimento, tempo, data, escolha de produto e preferências). O KSW deve calcular o restante, explicar de onde veio o resultado e destacar exceções para aprovação.
