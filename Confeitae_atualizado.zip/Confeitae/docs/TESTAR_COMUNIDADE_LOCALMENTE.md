# Testar a Comunidade KSW localmente

A Comunidade não exige Hostinger, Railway ou outro serviço de hospedagem para desenvolvimento. O frontend e a API devem ser servidos pelo mesmo processo Node.js do KSW.

## 1. Abrir a pasta correta

No Windows, abra o PowerShell na pasta raiz do projeto. Ela deve conter diretamente:

```text
package.json
server.js
routes\social.js
public\social-ui.js
```

Não execute o projeto a partir de `public/`.

## 2. Instalar dependências e iniciar

Na primeira execução, rode:

```powershell
npm install
npm start
```

Se o servidor já estiver aberto, pare-o com `Ctrl+C` antes de iniciar novamente.

## 3. Verificar a rota social

Abra no navegador:

```text
http://localhost:3000/api/social/health
```

A resposta esperada é um JSON semelhante a:

```json
{
  "ok": true,
  "module": "ksw-social",
  "api_version": "2026-11-08-stories2"
}
```

Se aparecer `Rota da API não encontrada`, confira se o terminal está na cópia correta do projeto e se `server.js` monta `routes/social.js` em `/api/social`. Se o terminal informar que a porta 3000 está ocupada, encerre o processo antigo ou configure outra porta e use a mesma porta no navegador.

## 4. Teste com contas separadas

Use uma janela normal e uma janela anônima do navegador para entrar com duas contas de teste e verificar feed, Stories, comentários, seguidores e mensagens privadas. Não use dados reais de clientes durante os testes.
