# Orçamento público com aceite online

## Jornada

1. Em **Pedidos → Orçamentos**, crie a proposta com cliente, valor, quantidade estimada de unidades, descrição, validade e, opcionalmente, a data desejada de entrega.
2. Use **Gerar link de aprovação**. O KSW cria um endereço individual até a data de validade; gerar outro link substitui o anterior.
3. Copie o endereço ou use **Enviar no WhatsApp**. O endereço é de uso restrito: quem tiver o link poderá responder à proposta.
4. A cliente consulta os detalhes, marca a confirmação de leitura e escolhe aprovar ou recusar.
5. Ao aprovar, o KSW cria uma encomenda com status **recebido**, pagamento zero e referência ao orçamento. A confeitaria combina o pagamento separadamente.

## Regras importantes

- O servidor exige autenticação, empresa ativa, permissão de escrita e o recurso `quotes` do plano para gerar links.
- O token público contém 32 bytes aleatórios; somente seu SHA-256 é armazenado. O token não é gravado no registro comum do orçamento.
- O link expira na data de validade da proposta. O envio de um novo link invalida o token anterior.
- Aceitar/recusar exige POST da mesma origem; há limite de tentativas por IP e transação SQLite.
- Aprovação repetida devolve a referência do mesmo pedido; não gera outra encomenda.
- Propostas respondidas e os pedidos gerados ficam protegidos contra sobrescrita por caches antigos via `/api/data/sync`.
- Se a proposta trouxer data de entrega, a capacidade configurada na Agenda é verificada no aceite usando a quantidade estimada de unidades informada no orçamento. Se não houver data, o pedido entra sem data e a confeitaria deverá combinar/agendar depois.
- Nenhum pagamento é marcado como recebido. A integração PIX/cartão ainda é uma etapa separada.

## Configuração e homologação

- Em produção, configure `BASE_URL` com a origem HTTPS pública do KSW. Se TLS terminar em proxy, configure `TRUST_PROXY=1` para que Express reconheça HTTPS.
- A feature exige que o plano da empresa inclua `quotes`.
- Após atualizar o projeto, execute `npm ci` e `npm test` no host compatível com o driver `sqlite3` instalado.
- Esta versão inclui testes unitários do validador, builder de pedidos, schema, contrato das rotas e UI. Eles não substituem o teste HTTP/browser real em ambiente de homologação.

## Limitações conhecidas

- O link funciona como credencial de posse: qualquer pessoa que receba ou obtenha o endereço pode responder. Encaminhe apenas à cliente pretendida.
- A validade usa a data configurada no orçamento e a zona `KSW_TIME_ZONE` (padrão `America/Sao_Paulo`).
- Rate limit é em memória por processo; para múltiplas instâncias, deve ser movido para store compartilhado.
- A quantidade é uma estimativa informada pela confeiteira e não é extraída automaticamente dos itens descritos em texto. A trilha de auditoria atual do KSW não é append-only/inviolável; o registro de resposta e a referência ao pedido ficam no orçamento e na tabela dedicada de links.
