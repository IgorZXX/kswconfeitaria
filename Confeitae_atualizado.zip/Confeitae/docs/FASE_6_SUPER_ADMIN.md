# Fase 6 — Super Admin da plataforma

## Entrega

O painel `/admin` foi evoluído para uma central de administração da plataforma KSW. A tela antiga armazenava `ADMIN_SECRET_KEY` em `localStorage` e enviava a chave em todas as chamadas administrativas. A nova tela usa a chave somente no endpoint de criação de sessão; as demais rotas exigem um cookie de sessão `HttpOnly`, `SameSite=Strict`, com validade de 30 minutos e identificador revogável no SQLite.

## Funcionalidades

- Visão geral com empresas ativas/suspensas, usuários, assinaturas, MRR estimado, pedidos aprovados, receita aprovada e pedidos pendentes.
- Listagem e busca de empresas, consulta de detalhes e equipe.
- Suspensão/reativação da empresa sem apagar seus dados.
- Listagem de usuários sem expor hash de senha.
- Visão de assinaturas por empresa e alteração manual de acesso.
- Criação de planos comerciais no painel, incluindo nome, descrição, preço, pagamento único ou cobrança recorrente mensal (com intervalo de 1 a 12 meses).
- Ativação/desativação de novas vendas para qualquer plano do catálogo.
- Consulta dos eventos de auditoria administrativa da plataforma.

## Banco de dados

`lib/platform-admin-schema.js` adiciona, de forma idempotente:

- `tenants.status`, `tenants.suspended_at` e `tenants.suspended_reason`;
- `platform_admin_sessions` para sessão com JTI revogável;
- `platform_audit_logs` para registrar ações administrativas;
- `platform_plans` para controlar disponibilidade comercial dos planos.

O catálogo inicia com R$ 59,99/mês e R$ 1.119,00 em pagamento único. Ao criar um plano no painel, o servidor exige `STRIPE_SECRET_KEY`, cria o produto e o preço em BRL na Stripe e grava os IDs `prod_...` e `price_...` em `platform_plans`. O plano passa a ser oferecido no checkout público. Para mudar o preço, crie um novo plano/preço; o preço antigo não é alterado e as assinaturas existentes permanecem ligadas ao preço original. A criação de plano não sincroniza com o Mercado Pago.

## API administrativa

Todas as rotas abaixo, exceto `POST /api/admin/session`, exigem a sessão do Super Admin:

- `POST /api/admin/session` — autentica com `x-admin-key` e cria cookie de sessão.
- `GET /api/admin/session` / `DELETE /api/admin/session` — consulta/encerra a sessão.
- `GET /api/admin/overview` — indicadores globais.
- `GET /api/admin/tenants` e `GET /api/admin/tenants/:id` — empresas e detalhes.
- `PATCH /api/admin/tenants/:id/status` — suspende/reativa empresa.
- `GET /api/admin/users` — contas sem campos de senha.
- `GET /api/admin/subscriptions` — assinaturas associadas às empresas.
- `PATCH /api/admin/tenants/:id/subscription` — altera o acesso local do proprietário.
- `GET /api/admin/plans`, `POST /api/admin/plans` e `PATCH /api/admin/plans/:planKey` — catálogo, criação de produto/preço Stripe e disponibilidade comercial.
- `GET /api/admin/orders` — pedidos sem QR Code ou payload de pagamento.
- `GET /api/admin/audit` — auditoria administrativa.

O endpoint legado `POST /api/admin/users/:id/update-subscription` permanece apenas para compatibilidade e também exige cookie de sessão; a chave mestra isolada não autoriza as chamadas.

## Regras importantes

- Suspender uma empresa bloqueia suas rotas autenticadas via `tenantContextMiddleware` e oculta cardápios/vitrines públicas publicados. Não exclui dados, cancela cobrança nem efetua reembolso.
- Reativar uma empresa restaura o acesso sujeito ao status normal da assinatura.
- Atualização manual de plano/validade ajusta somente o acesso local no KSW. Não altera uma assinatura no Stripe/Mercado Pago e pode ser sobrescrita por webhooks posteriores.
- Desativar vendas bloqueia novas compras no KSW. O preço Stripe permanece ativo para permitir reativação e para não interferir nas assinaturas já existentes; a operação não cancela assinaturas.
- MRR é estimado pelo número de assinaturas mensais consideradas ativas multiplicado pelo preço de referência cadastrado. Não é receita contabilizada.
- Receita aprovada é soma histórica de `orders.valor` com status `approved`; não representa caixa líquido, lucro ou conciliação com o gateway.
- A auditoria é uma tabela comum do SQLite, não uma trilha imutável/WORM.

## Segurança e limitações

- `ADMIN_SECRET_KEY` é usada somente na troca inicial por sessão curta; não é salva no navegador. A página remove a antiga chave `ksw_admin_key` do `localStorage` legado.
- Cookie administrativo é `HttpOnly`, `SameSite=Strict`, escopado a `/api/admin` e `Secure` quando `NODE_ENV=production`.
- JWT administrativo usa HS256 explícito, issuer/audience próprios, tipo de token específico e JTI consultado em `platform_admin_sessions` para revogação no logout.
- Operações administrativas de escrita exigem cabeçalho `Origin` e comparam o host com o host real da requisição; origem ausente, malformada ou cruzada é rejeitada. Em produção, também exige HTTPS.
- Respostas do router administrativo usam `Cache-Control: no-store, private` e `Pragma: no-cache`.
- MRR estima o valor mensal equivalente das contas proprietárias com plano recorrente ativo, considerando o intervalo de cobrança e sem duplicar o responsável. Não representa receita líquida nem recebida.
- Suspensão é verificada na resolução do tenant, não somente na interface.
- Limite de login administrativo é em memória por processo. Em múltiplas instâncias é necessário store compartilhado.
- Ainda não há MFA, cofre externo para o segredo mestre nem segregação de múltiplos operadores administrativos. O modelo atual é uma chave de plataforma compartilhada, com auditoria identificando o ator como `super_admin`.
- A suspensão da empresa não bloqueia eventos de webhook legítimos que atualizam dados de cobrança; isso é separado do acesso à aplicação.
- O banco SQLite não possui RLS. O isolamento de tenants depende dos filtros e middlewares da aplicação.

## Testes

- `scripts/platform-admin.test.js`: valida catálogo, regras de assinatura, validade, paginação, busca, status de acesso e planos personalizados.
- `scripts/auth-schema.test.js`: valida a migração de contas antigas para nomes de usuário únicos e idempotentes.
- `scripts/platform-admin-schema.test.js`: valida migração de coluna de status, seed do catálogo, tabelas de sessão/auditoria e idempotência.
- `scripts/smoke-test.js`: valida login/cookie, negação sem cookie, indicadores, ausência de campo de senha, suspensão/reativação, desligamento/reativação de vendas, edição de assinatura e revogação de sessão.

A integração HTTP exige dependências do `package-lock.json` instaladas e driver `sqlite3` compatível com o sistema operacional.
