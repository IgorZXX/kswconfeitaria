# Análise competitiva do Confeitaê — novembro de 2026

## Escopo e método

Comparação das páginas públicas e da implementação presente no ZIP do KSW recebido em 08/11/2026. O diagnóstico do KSW considera código, rotas, modelos de dados, testes e documentação interna. Recursos anunciados pelos concorrentes são tratados como posicionamento público, não como auditoria de seus sistemas privados.

Referências consultadas:

- Dora: https://appdora.com.br/ e https://appdora.com.br/funcionalidades
- Confeitaria Pro: https://confeitariabr.pro/
- Confeito: https://www.confeitoapp.com.br/

## Resumo executivo

O KSW já entrega amplitude de gestão: multiempresa e permissões, produtos, fichas técnicas, custos, pedidos com pagamentos/sinal/saldo, agenda, produção, estoque por lotes/validade, lista de compras, fornecedores, clientes, fidelidade, cupons, financeiro, relatórios, loja pública, suporte e Super Admin.

A principal diferença dos concorrentes não é apenas quantidade de módulos. É a profundidade dos fluxos que atravessam vários módulos: a venda deve respeitar a capacidade de produção, converter-se em pedido, alimentar agenda e estoque, gerar recebimentos e atualizar indicadores sem redigitação.

## Comparativo de posicionamento

| Capacidade | KSW no ZIP | Dora (site público) | Confeitaria Pro (site público) | Confeito (site público) |
|---|---|---|---|---|
| Pedidos e encomendas | Implementado, com sinal/saldo e origem da loja | Implementado e central | Pedidos, vendas, fiados e entregas anunciados | Pedidos, status e agenda anunciados |
| Precificação e ficha técnica | Implementado, com conversões e custos adicionais | Implementado, com insumos fracionados e reajuste em lote anunciado | Receitas, margem, markup e CMV anunciados | Custo real, hora de trabalho e margem anunciados |
| Estoque e compras | Lotes, validade, FEFO, perdas e lista de compras | Lista automática e previsão de compra anunciadas | Estoque mínimo e compras anunciados | Estoque ligado a pedidos/integração anunciados |
| Capacidade de produção | Limite diário existe na agenda; inicialmente era somente alerta interno | Trava de capacidade pública anunciada | Não detalhada no site consultado | Agenda de produção anunciada |
| Loja/cardápio público | Vitrine e pedido integrado implementados; sem pagamento | Cardápios, orçamento e pagamentos integrados no plano On | Cardápio, orçamento e pedidos online anunciados | Cardápio com personalização anunciado |
| Orçamento com aceite online | Orçamento interno e envio por WhatsApp; sem aceite público no código auditado | Aprovação em link e conversão automática em encomenda anunciadas | Orçamentos anunciados | PDF de pedido anunciado |
| Pagamento online de encomendas | Não implementado no ZIP; gateways atuais são para assinatura do SaaS | PIX/cartão e links anunciados | Checkout é anunciado como pagamento seguro dos planos | Política de preços/assinatura anunciada |
| Canais externos | Sem conectores iFood/InstaDelivery no ZIP | iFood/99Food anunciados | PDV, vendas e canais destacados | InstaDelivery anunciado |
| IA executora | Alertas determinísticos, sem LLM ou execução aprovada | Assistente conversacional/voz e ações com confirmação anunciados | IA anunciada entre ferramentas | Não é o foco principal da página |
| PDV e caixa de balcão | Sem fluxo dedicado de PDV no ZIP | PDV e KDS anunciados como plano futuro | PDV e fiados anunciados | Não destacado |
| Equipe e multiempresa | Multiempresa, papéis e permissões implementados | Equipe em plano superior | Colaboradores anunciados | Não detalhado |
| Mobile/desktop | Interface responsiva no navegador | App/painel responsivo anunciado | Qualquer dispositivo anunciado | Celular e computador anunciados |

## Vantagens reais do KSW

1. **Amplitude de gestão sem depender de uma única tela:** compras, fornecedores, lotes, perdas, produção, contas e relatórios estão representados no modelo operacional.
2. **Multiempresa e controle de acesso:** a arquitetura já possui tenants, seleção de empresa e papéis/permissões, ponto relevante para equipes.
3. **Transparência de indicadores:** o motor separa vendas, dinheiro recebido, despesas previstas/pagas, custos conhecidos e resultado gerencial estimado. Isso evita prometer lucro líquido quando os dados não sustentam essa conclusão.
4. **Loja pública com proteções:** o servidor deriva a empresa pelo slug, recalcula os preços com o catálogo publicado, valida prazo/mínimo e utiliza idempotência.
5. **Controle de estoque mais profundo:** lotes, validade, consumo FEFO, perdas e custo de estoque fornecem uma base forte para crescer.

## Lacunas prioritárias

### P0 — fechar os fluxos já existentes

- Fazer a loja respeitar a capacidade diária configurada na Agenda. **Implementado nesta revisão:** a API pública consulta limites de pedidos/unidades dentro da transação antes de criar o pedido, desconsidera pedidos cancelados e retorna erro específico quando o dia está cheio. A vitrine recebe as datas já esgotadas e impede seu envio no navegador. A validação do servidor é sempre a autoridade.
- Manter os estados de pedido, pagamento, assinatura e produção coerentes, com operações idempotentes e logs.
- Fazer QA de ponta a ponta em navegador e mobile, além dos testes de regras.

### P1 — conversão e venda sem redigitação

- Orçamento com página/link público, aceite ou recusa, validade e conversão para pedido preservando itens e valores.
- Checkout da encomenda com PIX dinâmico e, depois, cartão; webhook assinado, idempotência, estorno e conciliação. Separar claramente do checkout de assinatura do SaaS.
- Personalizações do produto no cardápio: massa, tamanho, recheios, adicionais, observações e preço por combinação.
- Disponibilidade por data e horário, com capacidade por tipo de produto/etapa e sugestão de datas alternativas.

### P2 — canais e automação

- Conector oficial de WhatsApp para notificações transacionais consentidas, com templates aprovados e registro de opt-in.
- Integração por API/webhook com InstaDelivery, iFood e 99Food, começando por um parceiro e fluxo homologado; não simular integração via scraping.
- IA com provedor configurável, contexto limitado aos dados do tenant, ferramentas de leitura e propostas de ação. Escritas sempre exigem resumo e confirmação; registrar auditoria e limites por plano.
- Importação de cardápio por imagem/PDF com extração para conferência humana antes de gravar.

### P3 — profissionalização

- PDV rápido para balcão, fiado/crediário com limite, recebimentos e fechamento de caixa.
- Rotas e entregadores, zonas de entrega e preço por CEP/bairro.
- Metas, planejamento financeiro e previsão de compras baseada em consumo, lead time e sazonalidade.
- App instalável/PWA e notificações push somente após estabelecer estratégia de suporte e privacidade.

## Passos recomendados de execução

| Etapa | Entrega | Critério de aceite |
|---|---|---|
| 1 | Capacidade da loja conectada à Agenda | Dia lotado bloqueia pedido no servidor; cancelado libera capacidade; reenvio idempotente não duplica pedido |
| 2 | Orçamento público com aceite | Token não enumerável, validade, aceite auditável e conversão sem redigitação |
| 3 | Pagamento PIX de encomendas | QR dinâmico com valor exato, webhook assinado, estados idempotentes e teste de estorno |
| 4 | Variações de produtos no cardápio | Preço final calculado no servidor e opções refletidas no pedido |
| 5 | Notificações e integração de canal | Eventos assinados, consentimento, tentativas/retry e painel de falhas |
| 6 | IA com ações confirmadas | Sem acesso cruzado entre tenants, confirmação explícita e trilha de auditoria |
| 7 | PDV e metas | Venda rápida alimenta caixa, estoque e relatório sem lançar duas vezes |

## O que não deve ser anunciado como pronto ainda

- PIX/cartão para encomendas feitas no cardápio público;
- integração efetiva com iFood, 99Food ou InstaDelivery;
- assistente de IA conversacional que edita o sistema;
- aprovação de orçamento em página pública;
- PDV, emissão fiscal, conciliação bancária ou contabilidade formal.

## Validação desta revisão

- Adicionado módulo puro `lib/storefront-capacity.js` com normalização de limites, soma de unidades, exclusão de cancelados, bloqueio e cálculo de datas indisponíveis.
- Integrado ao `GET /api/storefront/public/:slug` para informar datas já esgotadas nos próximos 60 dias.
- Integrado ao `POST /api/storefront/public/:slug/orders` dentro da transação SQLite para impedir corrida entre pedidos concorrentes e evitar ultrapassar o limite configurado em Agenda.
- Atualizada a vitrine pública para informar a regra, bloquear datas conhecidas como cheias e tratar a resposta de capacidade do servidor.
- Testes de unidade adicionados em `scripts/storefront-capacity.test.js`.

Validação desta revisão: os testes da suíte definidos no `package.json` (sem o smoke HTTP final) passaram com **242/242**; o subconjunto de capacidade e regressões da vitrine passou com **57/57**. `node --check` passou nos arquivos JavaScript alterados. O comando `npm test` foi executado: o guard passou e os 242 testes passaram; o smoke `scripts/smoke-test.js` foi tentado, mas o servidor não iniciou porque `dotenv` não está instalado (`node_modules` ausente). O teste HTTP real e a inspeção visual em navegador permanecem NÃO VERIFICADOS. Não há credenciais de gateway nem integrações externas neste ZIP para homologar pagamentos/canais. A trava implementada cobre capacidade diária por pedidos/unidades, não reserva horário, estoque ou etapa de produção.
