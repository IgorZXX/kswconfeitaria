# Upload seguro de imagens dos cardápios

## Experiência da confeiteira

Na criação/edição de cada produto, o editor oferece upload de arquivos JPG, PNG e WebP, com prévia da imagem. O navegador decodifica a foto e rasteriza uma versão PNG de até 1600 px no maior lado. O nome original do arquivo não é utilizado.

## Controles no servidor

- O endpoint `/api/menus/upload-image` exige sessão autenticada, empresa ativa, assinatura válida e permissão `menus.manage`.
- O endpoint recebe somente o corpo binário `application/octet-stream`, com limite rígido de 5 MB.
- O servidor não confia na extensão, nome ou MIME original. Aceita apenas o PNG rasterizado e valida assinatura, estrutura dos chunks, CRC, sequência IDAT, dimensões, número de pixels, descompressão zlib, tamanho dos pixels e filtros PNG.
- PNGs inválidos, truncados, com conteúdo anexado após IEND, dados inconsistentes, dimensões excessivas ou payloads disfarçados são rejeitados.
- A imagem é reconstruída a partir dos pixels. Chunks auxiliares/metadados (incluindo EXIF, texto e perfis de cor) são descartados.
- Os arquivos ficam em `storage/menu-products/tenant-{id}`, fora da raiz pública, com nome aleatório de 128 bits, criação exclusiva (`wx`) e permissões restritas.
- O upload tem limite de frequência, 5 MB por arquivo, até 500 imagens e 250 MB por empresa.
- A entrega pública usa uma rota controlada, MIME fixo `image/png`, `X-Content-Type-Options: nosniff` e validação adicional do arquivo. O nome/ID é aleatório e a URL contém a empresa proprietária.
- A gravação exige que o caminho final permaneça dentro do diretório de uploads da empresa; o cadastro do produto também só aceita referências de imagem da própria empresa (além de URLs antigas permitidas para compatibilidade).

## Operação e backups

Inclua a pasta `storage/menu-products` nos backups do ambiente de produção, com os mesmos controles de acesso do banco de dados. Não publique essa pasta como diretório estático e não altere o endpoint para servir arquivos por caminho informado pelo usuário.

## Limitações conhecidas

As fotos JPG/WebP são convertidas no navegador usando o decodificador do navegador para PNG antes do upload; o servidor só armazena a versão rasterizada e validada. SVG, GIF, PDF, ZIP, executáveis e outros formatos não são aceitos. A exclusão automática de imagens órfãs não foi implementada nesta versão; o limite por empresa reduz o risco de consumo ilimitado, mas a limpeza/gestão de imagens antigas deve ser adicionada antes de escalar o volume.
