# Confeitaê — revisão de experiência, tema e automação prática

Data da revisão: 07/11/2026

## Objetivo

Reduzir o trabalho operacional da confeiteira. O produto deve pedir dados que ela conhece (o que comprou, quanto pagou, qual receita usa, quantas unidades precisa entregar) e fazer automaticamente as conversões, somas, alertas e recomendações. Campos avançados não devem bloquear a rotina quando forem opcionais.

## Tema claro blush

O tema claro do ambiente autenticado deixa de usar branco puro como fundo geral. A paleta agora usa:

| Uso | Cor |
|---|---|
| Fundo da aplicação | `#f2eeec` |
| Superfícies/cartões | `#fffaf9` |
| Campos de entrada | `#fffdfc` |
| Rosa de destaque | `#91566e` |
| Rosa suave de seleção | `#f2e5e9` |
| Texto principal | `#3d2e35` |
| Texto auxiliar | `#74656b` |
| Bordas | `#e5d6dc` |

A paleta é aplicada ao painel autenticado, incluindo navegação, cabeçalho, cartões, formulários e componentes do menu. A vitrine pública mantém a própria identidade visual e o tema escuro continua independente. As combinações centrais foram conferidas por contraste estático; isso não substitui teste visual de legibilidade em dispositivos.

## Melhorias desta revisão

### 1. ZIP com uma pasta raiz

O arquivo de distribuição agora contém todos os arquivos dentro de `KSW_Confeitaria/`. Ao extrair no Windows, a pessoa abre uma única pasta no VS Code em vez de receber arquivos e diretórios espalhados na raiz do destino.

O pacote exclui `.env`, `node_modules`, bancos locais e uploads de clientes. Mantém `.env.example`, `package-lock.json`, código, documentação, testes e skills de segurança. A instalação pede backup e preservação do `.env`, banco e `storage/` da instalação existente.

### 2. Lista de compras baseada na demanda real

O módulo de estoque continua mostrando itens abaixo do mínimo definido. Foi acrescentada uma previsão separada para as encomendas e ordens de produção ainda não concluídas:

- lê os pedidos não cancelados/não entregues e as produções ainda ativas;
- usa as fichas técnicas existentes e o rendimento de cada receita;
- calcula lotes completos quando a quantidade solicitada excede o rendimento por receita;
- soma ingredientes e embalagens necessários;
- desconta o saldo antigo sem lote e os lotes ainda válidos;
- não considera lotes vencidos como estoque disponível;
- evita somar novamente um pedido quando já existe uma ordem de produção ligada a ele;
- avisa quando não existe uma ficha técnica válida, sem inventar quantidade;
- apresenta a diferença que falta e permite preparar a entrada no item correto.

A previsão é somente leitura. Não gera compra, não registra recebimento e não altera saldo. A confeiteira confirma a compra e registra a entrada quando o material realmente chega.

### 3. Reposição com navegação correta

Ao escolher "Preparar entrada" na lista de mínimos ou na previsão dos pedidos, o KSW muda para a categoria certa do estoque e remove filtros que poderiam esconder o item antes de preencher a quantidade sugerida.

### 4. Precificação sem perguntas desnecessárias

O fluxo principal pede os dados operacionais indispensáveis: nome, rendimento, ingredientes, quantidade utilizada e preço de venda. O KSW faz conversões compatíveis entre g/kg e ml/L, calcula custo por lote e unidade, estima a mão de obra quando o tempo e o valor/hora estão disponíveis e sugere preço pela margem configurada.

Embalagem, tempo, taxas e outros ajustes ficam como opcionais/avançados. Uma taxa em branco não é tratada como taxa zero. A ausência de despesas fixas não é presumida como custo zero sem confirmação. Quando faltam dados, o resultado é identificado como parcial e não como lucro líquido garantido.

## Mapa de recursos existentes no KSW

| Área | O que já existe | Observação de uso |
|---|---|---|
| Pedidos | Cadastro de encomendas, itens, cliente, data, valores, pagamentos e saldo | Deve continuar sendo a origem do planejamento de produção. |
| Receitas e preços | Ficha técnica, conversão de unidades, custo de lote/unidade, preço sugerido e alertas de perda | A precisão depende de preços e quantidades atualizados. |
| Estoque | Ingredientes, embalagens, movimentos, lotes, validade e mínimo | Lotes vencidos são excluídos do consumo FEFO e da previsão de demanda. |
| Produção | Ordens vinculadas a pedidos, etapas, baixa de materiais e registro de perdas | A confeiteira confirma início/conclusão; o sistema calcula a quantidade de materiais. |
| Compras | Reposição por mínimo e previsão de falta para pedidos/produção | Ainda não faz pedido automático a fornecedor nem registra compra sem confirmação. |
| Cardápios | Cardápios sazonais, vitrine pública, edição/exclusão inclusive de rascunhos vazios e upload seguro de imagens | Pagamento da loja pode continuar combinado diretamente com a confeitaria nesta versão. |
| Clientes | Contatos, histórico, preferências e autorização separada para mensagens promocionais | Mensagens promocionais dependem de autorização. |
| Financeiro | Entradas, despesas, saldos, resultados e relatórios | Custos não cadastrados não podem ser presumidos como zero. |
| Configurações | Perfil, segurança/senha, tema, idioma, parâmetros de preço e assinatura | O seletor de idiomas não significa tradução integral de todas as telas. |
| Super Admin e assinaturas | Gestão de empresas, usuários, planos e gateways | Requer credenciais, webhooks e validação no ambiente de produção. |

## Prioridades recomendadas para próximas fases

1. **Conferência de compra por fornecedor:** transformar a lista de falta em uma lista agrupada por fornecedor, mantendo confirmação manual da compra e registro da nota/valor real.
2. **Produção por lote consolidado:** sugerir juntar itens iguais de pedidos com datas compatíveis para evitar produzir a mesma receita em lotes pequenos desnecessários.
3. **Rendimento real e desperdício:** comparar quantidade prevista e quantidade boa efetivamente produzida, atualizando indicadores de perda e custo real sem duplicar baixas.
4. **Conciliação de pagamentos da loja:** integrar checkout e confirmação de pagamento somente depois de validar webhook, estorno e idempotência no servidor.
5. **Tradução completa:** manter o seletor de idioma como preferência, mas concluir tradução de todos os módulos antes de anunciar suporte multilíngue integral.

## Segurança e limites da validação

- O cálculo de necessidade de materiais é uma previsão de leitura no frontend. A baixa efetiva continua sendo feita pelo endpoint autenticado de produção, que verifica tenant, permissão, saldo e lote em transação.
- O upload de cardápios continua exigindo validação e reconstrução de imagem no servidor; este pacote não altera a política de upload.
- Não foram incluídas chaves, `.env`, banco local, `node_modules` ou uploads privados.
- Os testes de Node podem validar cálculos e regressões, mas não provam a renderização visual real nem substituem teste HTTP integrado com sessão, banco e gateways.

## Testes executados nesta revisão

- `node --test scripts/*.test.js`: 211/211 aprovados.
- `node --check` em 68 arquivos JavaScript: aprovado.
- Compilação dos 3 scripts inline de `public/index.html`: aprovada.
- Parsing CSS com `tinycss2`: sem erros nos CSS principais.
- `npm run security:skill:guard`: aprovado após atualizar o histórico real da skill.
- Não foi executado teste HTTP com servidor, login real, gateways ou navegação visual via Chromium neste ambiente.
