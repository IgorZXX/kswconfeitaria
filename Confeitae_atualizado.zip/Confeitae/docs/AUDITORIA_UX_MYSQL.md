# Confeitaê — Auditoria de UX, fluxos e arquitetura

**Base analisada:** pacote `KSW_Confeitaria_Fase_7_Loja_Virtual.zip` recebido nesta conversa.  
**Tipo de auditoria:** inspeção estática do código, rotas, esquemas, regras de negócio e testes automatizados. Não equivale a teste manual em navegador nem a pentest independente.

## 1. Resumo executivo

O projeto possui uma aplicação Node.js/Express com frontend servido em `public/`, SQLite como banco em execução, autenticação por token, dados operacionais separados por empresa (`tenant_id`), módulos de produção/estoque, painel de plataforma e loja pública. A aplicação ainda não está pronta para trocar o runtime por MySQL: há SQL específico de SQLite diretamente em `database.js`, `routes/` e `lib/`.

A melhoria desta entrega organiza a navegação e torna mais explícita a semântica das telas financeiras e operacionais, sem remover as rotas nem substituir os mecanismos de autorização do servidor.

## 2. Auditoria por tela/módulo

| Tela / módulo | Evidência no código | Estado da auditoria | Observação |
|---|---|---|---|
| Início | `public/gestao.js`, `public/analytics-engine.js` | Confirmado pelo código | Usa o motor de indicadores compartilhado; próximas entregas excluem cancelados. |
| Pedidos | `public/gestao.js`, `routes/data.js` | Confirmado pelo código | Ações renomeadas e hierarquizadas; pagamentos permanecem separados da mudança de status. |
| Agenda | `public/gestao.js` | Confirmado pelo código | Acesso mantido pelo módulo de pedidos/entregas; validação visual manual pendente. |
| Financeiro | `public/gestao.js`, `public/analytics-engine.js` | Confirmado pelo código | Resumo, contas, caixa, resultados e fornecedores são subáreas. Indicadores de resumo usam a mesma fonte. |
| Resultados | `public/index.html`, `public/analytics-engine.js` | Confirmado pelo código | Quatro indicadores no início; métricas detalhadas em `<details>`. Não é uma DRE contábil. |
| Produção | `public/production-ui.js`, `public/production-engine.js`, `routes/production.js` | Confirmado pelo código | Fluxo por pedido precede produção manual; consumo permanece atômico/FEFO/idempotente; quantidade boa pode ser informada. |
| Preços e receitas | `public/index.html`, `public/costing.js` | Confirmado pelo código | Fichas e cálculo de custo/preço; custos antigos ausentes são sinalizados no relatório. |
| Estoque | `public/index.html`, `routes/data.js`, `routes/production.js` | Confirmado pelo código | Ingredientes, embalagens, lotes, movimentações e consumo estão presentes. Teste de concorrência HTTP no host final pendente. |
| Clientes | `public/index.html`, `public/recursos.js`, `public/birthday-engine.js` | Confirmado pelo código | Aniversário opcional só com dia/mês; CRM lista aniversariantes e próximos lembretes, gera cupom individual e só prepara mensagem promocional no WhatsApp após autorização registrada. |
| Cardápios | `public/index.html`, `routes/menus.js` | Confirmado pelo código | Editor de cardápios e publicação mantidos. |
| Mais recursos | `public/recursos.js` | Confirmado pelo código | Orçamentos, CRM/fidelidade, cupons, tarefas, auditoria e alertas foram reposicionados por finalidade. |
| Empresa e equipe | `routes/tenants.js`, `middleware/tenant.js`, `public/tenant-ui.js` | Confirmado pelo código | Seleção de empresa, associação, papéis e convites; servidor continua responsável pelas permissões. |
| Minha assinatura / planos | `public/index.html`, `routes/payment.js`, `routes/stripe.js` | Parcialmente confirmado | Interface e rotas existem; não foi possível executar chamadas externas de pagamento nesta sessão. |
| Login / cadastro | `public/index.html`, `routes/auth.js` | Confirmado pelo código | Fluxos e validações no frontend/backend identificados; teste de ponta a ponta depende das dependências e ambiente. |
| Recuperação de senha | `routes/auth.js` | Parcialmente confirmado | Rota de recuperação existe, mas entrega de e-mail depende de provedor/configuração; resposta 503 quando não configurada. |
| Checkout | `public/index.html`, `routes/payment.js`, `routes/stripe.js` | Parcialmente confirmado | Mantido fora da nova barra mobile; pagamentos reais exigem credenciais de teste e webhooks em homologação. |
| Loja virtual pública | `public/storefront-public.js`, `routes/storefront.js` | Confirmado pelo código | Servidor recalcula preço, deriva tenant pelo slug, limita pedidos e usa idempotência. Não inclui pagamento online de encomendas. |
| Cardápios públicos | `routes/menus.js`, `public/index.html` | Confirmado pelo código | Publicação e rotas públicas existem; teste visual manual pendente. |
| Super Admin | `public/admin.html`, `routes/admin.js`, `lib/platform-admin.js` | Confirmado pelo código | Sessão administrativa própria e logs; MFA/operadores independentes ainda são melhorias pendentes. |

## 3. Navegação aplicada

### Desktop

- Grupos: Dia a dia, Cadastros, Dinheiro e Empresa.
- Planos não ficam mais como item de navegação principal.
- Resultados está dentro de Financeiro.
- Orçamentos está dentro de Pedidos.
- CRM/fidelidade e cupons estão dentro de Clientes.
- Tarefas e alertas ficam em Dia a dia.
- Auditoria e equipe ficam em Empresa.
- Minha assinatura e sair ficam na área da conta.

### Mobile

- Barra inferior de cinco posições fixas: Pedidos, Agenda, marca K central, Produção e Financeiro.
- Quando `finance.read` não está disponível, o último atalho aponta para Clientes; Financeiro não aparece como opção sem permissão.
- A marca central retorna a Início.
- O menu complementar apresenta os demais módulos por grupo.
- A barra é ocultada em páginas públicas e na página de planos/checkout.
- CSS usa `env(safe-area-inset-bottom)` e grade de cinco colunas sem rolagem horizontal.

**Limitação de QA:** foram feitos testes estáticos das regras e breakpoints 360/375/390/420/760 CSS; não houve captura manual em aparelho físico. Recomenda-se conferir os quatro viewports solicitados em navegador/dispositivo antes de publicar.

## 4. Regras financeiras: significado dos indicadores

O motor `public/analytics-engine.js` é a fonte compartilhada por Início e Financeiro/Resultados.

- **Vendas do mês:** soma de itens e taxa de entrega de pedidos não cancelados cuja data `ent` cai no mês selecionado. No modelo atual, `ent` representa a data de entrega informada para o pedido; isso não substitui uma conciliação fiscal.
- **Dinheiro que entrou:** soma dos pagamentos registrados com data de pagamento no mês. O modelo legado pode usar `pd`/`ent` quando não existe array de pagamentos.
- **Custos dos produtos:** custo unitário congelado em cada item do pedido multiplicado pela quantidade. Itens sem custo histórico são contabilizados como faltantes e exibem alerta; não se presume custo zero como dado completo.
- **Lucro bruto estimado:** vendas menos custos de produto conhecidos.
- **Despesas previstas:** despesas agrupadas pela data de vencimento (`venc`/`vencimento`) no mês.
- **Despesas pagas:** despesas pagas agrupadas por data de pagamento (`dpg`/`data_pagamento`), com fallback para vencimento no legado.
- **Perdas:** custos de perdas registradas por data da perda no mês.
- **Quanto sobrou:** resultado gerencial estimado = lucro bruto estimado − despesas previstas − perdas registradas.
- **Resultado de caixa:** pagamentos recebidos no mês − despesas pagas no mês. Não é o mesmo que resultado gerencial.
- **Valor médio por pedido:** vendas do mês divididas pelo número de pedidos não cancelados com data de entrega no mês.
- **Valores a receber:** saldo ainda não pago dos pedidos não cancelados, calculado para o conjunto de pedidos ativo (não apenas a competência mostrada).
- **Contas a pagar:** soma de despesas em aberto, também não limitada somente ao mês da tela.

### Casos especiais

- Pedidos cancelados não entram em Vendas do mês nem no ticket médio.
- Pagamentos já recebidos de pedidos cancelados continuam no caixa, porque dinheiro recebido não deixa de existir quando o pedido é cancelado. O estorno precisa ser registrado como saída/ajuste se ocorrer.
- Não se somam pagamentos de pedido ao faturamento: faturamento e recebimento são indicadores separados.
- `Quanto sobrou` é uma visão gerencial estimada, não contabilidade formal. As despesas são agrupadas por vencimento para o resultado gerencial, não por competência contábil completa.
- Se itens antigos não tiverem custo unitário congelado, a margem pode ficar superestimada; a tela avisa e informa a quantidade faltante.

## 5. Fluxo de pedidos e produção

- Os botões de pagamento, cobrança WhatsApp, lembrete WhatsApp, edição e exclusão têm rótulos mais explícitos.
- A próxima etapa do pedido recebe o destaque principal; pagamentos não alteram status por acidente.
- Exclusão/cancelamento estão visualmente separados e exigem confirmação.
- A produção começa pelo planejamento a partir de pedidos; produção manual fica como alternativa secundária.
- Ao concluir, o servidor usa transação e controle de idempotência para não consumir duas vezes. O consumo de materiais segue a estratégia FEFO, respeitando validade.
- A quantidade efetivamente produzida é validada contra a quantidade planejada e armazenada separadamente; o consumo planejado continua a ser aplicado conforme a ficha/lote definido. Revisar diferenças de rendimento e perdas registradas é essencial para análise posterior.

## 6. Riscos e melhorias pendentes

| Risco / pendência | Estado |
|---|---|
| Teste visual manual nos viewports | Não executado nesta sessão |
| Teste HTTP completo no Windows com `sqlite3` nativo | Pendente de `npm ci` no host do projeto |
| Pagamento real Stripe/Mercado Pago e webhooks | Pendente de credenciais de teste e ambiente de homologação |
| Recuperação de senha com e-mail real | Pendente de provedor de e-mail configurado |
| MFA para Super Admin | Melhoria recomendada |
| Rate limiting distribuído da loja em múltiplas instâncias | Melhoria recomendada (atual é por processo) |
| Pentest independente / revisão LGPD jurídica | Não realizado |
| Runtime MySQL para todas as rotas | Não implementado nesta entrega; SQLite permanece ativo |
| Migração de produção SQLite→MySQL | Não executada; requer arquivo de DB atual e MySQL de homologação |

## 7. Arquivos de UX mais relevantes

- `public/index.html` — TABS, grupos de navegação, menu complementar, mobile nav e Resultados.
- `public/ksw-home.css` — navegação desktop/mobile, tipografia, cards, formulários e responsividade.
- `public/gestao.js` — Financeiro, pedidos, calendário, ações de pedido e navegação interna.
- `public/analytics-engine.js` — fonte única dos cálculos gerenciais.
- `public/production-ui.js` — novo fluxo visual da produção.
- `routes/production.js` e `public/production-engine.js` — validação da quantidade realmente produzida e consumo.
- `public/cookie-notice.css` — aviso compacto e posicionado conforme app/página pública.
- `scripts/ux-regression.test.js` — regressões estáticas de navegação e layout.

## 8. Arquivos MySQL mais relevantes

- `lib/mysql-pool.js` — pool `mysql2/promise`, SSL validado, transações por conexão e verificação MySQL 8/InnoDB.
- `lib/mysql-migration.js` — conversão do metadata SQLite, DDL MySQL, verificações e digest integral de linhas.
- `scripts/migrate-sqlite-to-mysql.js` — inventário, geração de DDL, dry-run e importação para schema MySQL de homologação.
- `scripts/mysql-prep.test.js` — testes da camada preparada.
- `docs/MYSQL_MIGRATION.md` — procedimento de inventário, migração, validação e rollback.

## 9. Validação executada nesta revisão

- `npm run security:skill:sync`: concluído.
- `npm run security:skill:check`: aprovado.
- `npm run security:skill:guard`: aprovado.
- `npm test`: **123 testes unitários/regressão aprovados** (0 falhas). A etapa final `scripts/smoke-test.js` não conseguiu iniciar o servidor porque `dotenv` não está instalado neste ambiente (`Cannot find module 'dotenv'`).
- Os testes MySQL são testes de unidade da configuração, pool, transações, conversão de metadata e regras do migrador. **Não houve conexão com um servidor MySQL real**, portanto compatibilidade operacional e importação real ainda não estão aprovadas.
- Teste visual manual em navegador/dispositivo nos tamanhos 360, 375, 390 e 430 px não foi executado nesta sessão; os testes de UX são regressões automatizadas sobre a estrutura/CSS.
- Não foi possível auditar dados reais, comparar saldos ou gerar inventário da instalação implantada porque o ZIP não contém o arquivo SQLite físico. O migrador precisa receber uma cópia consistente da base real em `DATABASE_PATH`.

## 10. Estado da entrega

A entrega é uma **versão UX melhorada com preparação e ferramentas de migração MySQL para homologação**. Não é uma versão já operando em MySQL. A aplicação permanece em SQLite; a troca do runtime exigirá refatoração de `database.js` e das rotas para a camada de repositório MySQL, testes de integração com MySQL real, migração validada da base atual e autorização explícita para a janela de corte.
