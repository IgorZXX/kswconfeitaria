# Fase 5 — Multiempresa, equipe e permissões

## Objetivo

Permitir que várias contas compartilhem o espaço de trabalho de uma confeitaria, com seleção explícita de empresa, papéis e autorização aplicada no servidor.

## Entidades

- `tenants`: empresa e usuário proprietário (cobrança).
- `tenant_memberships`: usuário, empresa, papel e estado da associação.
- `tenant_invitations`: e-mail convidado, papel, hash do token, validade e aceite.
- `tenant_audit_logs`: ações de equipe e configurações da empresa.
- Coleções de gestão e cardápios: `tenant_id`; tabelas de gestão: chave primária `(tenant_id, id)`.

## Fluxo de identidade e autorização

1. JWT identifica a conta autenticada; não carrega papel de tenant como fonte de autoridade.
2. `X-Tenant-ID` indica apenas a empresa desejada.
3. `tenantContextMiddleware` consulta a associação ativa para o par usuário/empresa.
4. `requirePermission` verifica o papel armazenado no banco.
5. Cada consulta de registros privados usa `tenant_id` obtido do middleware, nunca do corpo enviado pelo navegador.

## Migração

`database.js` cria o schema base e chama `migrateTenantSchema` antes de `db.ready` resolver. A migração cria uma empresa proprietária para cada conta anterior, atribui `tenant_id` aos registros existentes e aos cardápios, reconstrói as tabelas de gestão cuja chave antiga era `(user_id, id)` para `(tenant_id, id)`, e cria índices tenant-aware. O processo usa uma transação `BEGIN IMMEDIATE`/`COMMIT`; qualquer erro causa `ROLLBACK`. Registro sem usuário correspondente interrompe a inicialização, preservando dados para investigação, em vez de adotar uma associação arbitrária.

## Papéis

- `owner`: empresa, equipe, financeiro e cobrança; único papel que atribui `admin`.
- `admin`: empresa, equipe, operações e financeiro; sem cobrança e sem administração de outro admin/proprietário.
- `manager`: operações, equipe em leitura e financeiro.
- `member`: leitura/escrita operacional, sem leitura ou escrita financeira e sem administração da equipe.
- `viewer`: somente leitura operacional, sem financeiro ou gestão de equipe.

A proteção financeira cobre `despesas` e `fornecedores` no endpoint genérico de dados e na exportação. O frontend oculta Financeiro/Resultados para os papéis sem `finance.read`.

## Convites

O proprietário/admin cria um convite com e-mail e papel. O sistema gera token aleatório de 256 bits; somente SHA-256 é armazenado. A validade é de sete dias. A pessoa convidada precisa estar autenticada com exatamente o e-mail informado. O link guarda o token no fragmento (`#convite=`), evitando enviá-lo na requisição HTTP inicial; o frontend mantém compatibilidade com links legados via query string. O link é compartilhado manualmente; não há envio transacional de e-mail.

## Cache local

A chave atual é por usuário e empresa (`ksw-db:tenant:<tenantId>:user:<userId>`). Cache de outro usuário não é reaproveitado. O cache antigo `ksw-db:<userId>` é lido apenas no tenant próprio do usuário. O cache global não identificado `ksw-db` não é importado automaticamente.

## Verificação executada

- `node --test scripts/tenants.test.js`: migração, isolamento SQL, idempotência, rollback de órfão, PK por tenant, permissões, validade de data e validação de membership por middleware.
- `node --check` nos arquivos JavaScript e scripts inline do `public/index.html`.
- A suíte HTTP `npm test` exige dependências instaladas e o driver nativo `sqlite3`. Neste ambiente sem `node_modules`, a suíte de integração não será declarada como aprovada. Execute-a no Windows após `npm ci`.

## Limites

SQLite não fornece Row Level Security. A01 está PARCIAL; todas as rotas privadas precisam manter filtros por tenant e passar por revisão independente. `lib/data-tables.js` prepara a coluna `tenant_id` antes de criar índices em bancos antigos; o teste de regressão cobre essa ordem. As permissões nas coleções operacionais ainda são gerais (`data.read`/`data.write`); apenas os conjuntos financeiros `despesas`/`fornecedores` têm controle de coleção. A assinatura continua atrelada ao proprietário e os convites são copiados manualmente. Não há criação de empresa adicional pelo mesmo usuário na interface nem cobrança por tenant nesta fase.
