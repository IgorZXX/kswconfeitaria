# Fase 7 — Loja virtual e encomendas

## Escopo entregue

A Fase 7 adiciona uma loja pública por confeitaria, sem substituir o checkout de assinatura do KSW. O visitante monta um carrinho e envia uma solicitação de encomenda; a confeitaria confirma disponibilidade e combina o pagamento fora da loja.

## Configuração administrativa

Na aba **Cardápios**, a área **Loja virtual** permite configurar:

- Ativação da loja (desativada por padrão);
- WhatsApp e link de Instagram;
- endereço/região informada ao público;
- retirada e/ou entrega;
- taxa de entrega e pedido mínimo;
- prazo mínimo em dias para encomendar;
- instruções ao visitante.

A alteração das configurações exige sessão ativa, empresa resolvida pelo middleware e permissão `menus.manage`. A leitura exige `menus.read`.

## Rotas

- `GET /api/storefront/settings` — configuração da loja da empresa atual.
- `PUT /api/storefront/settings` — salva configuração validada.
- `GET /api/storefront/public/:slug` — catálogo público da empresa associada ao slug.
- `POST /api/storefront/public/:slug/orders` — recebe encomenda pública.
- `/loja/:slug` — página pública SPA.

O slug é resolvido no servidor por `menu_hubs`; o cliente não pode escolher `tenant_id`. O servidor também verifica que a empresa está ativa e que o proprietário possui assinatura considerada ativa.

## Validações do pedido

O servidor, e não o navegador, calcula o pedido com base nos cardápios publicados:

- loja ativada;
- seções e produtos publicados/visíveis;
- disponibilidade explícita do produto;
- preço atual do cardápio publicado;
- quantidade inteira de 1 a 50 por item e até 30 linhas;
- mínimo do pedido;
- retirada/entrega habilitada;
- endereço obrigatório para entrega;
- data real de calendário respeitando o prazo mínimo;
- horário, telefone e e-mail válidos;
- taxa de entrega calculada no servidor.

Produtos indisponíveis aparecem na vitrine sem permitir adição ao carrinho. Preço e total enviados pelo navegador são ignorados.

## Persistência e fluxo interno

- `storefront_settings`: configuração por tenant.
- `storefront_order_requests`: idempotência por tenant e chave, com hash SHA-256 da intenção normalizada; suporta migração de instalações sem a coluna `request_hash`.
- `clientes`: cliente localizado por telefone dentro do tenant atual ou novo cliente criado.
- `pedidos`: encomenda criada com status `recebido`, origem `loja_virtual`, itens, data/hora, endereço, subtotal, taxa e total. O `tenant_id` é derivado no servidor.

A gravação do cliente, pedido e registro de idempotência ocorre dentro de uma transação. Se o navegador repetir a mesma chave e a mesma intenção, recebe a confirmação original; se reutilizar a chave com outra intenção, recebe conflito HTTP 409. A intenção é normalizada e o fingerprint não inclui preço, para que uma alteração posterior no catálogo não transforme um reenvio idêntico em um pedido diferente.

## Proteções e limites

- Rate limit: 12 pedidos por IP a cada 10 minutos, por processo. A estrutura é em memória e tem limite de eficácia em múltiplas instâncias.
- Honeypot: campo oculto `website` deve permanecer vazio.
- Proteção de origem: nega `Sec-Fetch-Site: cross-site`; exige HTTPS e `Origin` presente em produção; compara o host com o host da requisição ou `BASE_URL`. Em desenvolvimento, Origin ausente é permitido. Atrás de proxy TLS, configure `TRUST_PROXY=1` para que Express reconheça a conexão segura.
- Chave de idempotência com 16–80 caracteres válidos e unicidade por tenant.
- Chaves com mais de 90 dias são removidas durante novos pedidos.
- Queries usam placeholders e filtros por tenant.
- O limiter em memória não é suficiente para múltiplas instâncias; use store compartilhado ao escalar.

## Limitações explícitas

Esta fase não implementa pagamento online/PIX para encomendas, confirmação automática, capacidade diária por horário, zonas por CEP/rota, entrega por aplicativo, reserva/baixa automática de estoque nem integração automática com lotes de produção. O checkout de assinatura mensal/vitalícia do SaaS não foi alterado.

A loja grava dados pessoais (nome, telefone, e-mail opcional, endereço e observações) no banco operacional da empresa. Antes de publicar em produção, revise a política de privacidade, finalidade, retenção e canal de atendimento a titulares. Use HTTPS e controle de acesso ao banco e backups.

## Testes

- `npm run test:storefront` — valida regras puras do motor de encomendas e o schema SQLite.
- `scripts/storefront.test.js` — preço vindo do servidor, taxa, mínimo, produto indisponível/oculto, prazo de antecedência, limites e idempotência.
- `scripts/storefront-schema.test.js` — criação idempotente, migração da coluna `request_hash` em tabela legada e unicidade por tenant.
- A suíte isolada completa do projeto foi executada com `node --test` e passou com 91/91 testes; `node --check` passou em todos os arquivos JavaScript e os dois scripts inline de `public/index.html` foram compilados com sucesso. `npm test` executou o guard e os 91 testes, mas a etapa final `scripts/smoke-test.js` não conseguiu iniciar o servidor neste ambiente porque `dotenv` não estava instalado (`Cannot find module 'dotenv'`). A API HTTP ainda deve ser testada após `npm ci` com o driver `sqlite3` nativo do sistema operacional de destino.

## Gerenciamento de cardápios vazios

- Um cardápio pode ser criado e salvo como rascunho mesmo sem seções ou produtos; isso permite preparar nome/descrição e completar o conteúdo depois.
- A lista de cardápios exibe a quantidade de seções e produtos e mantém as ações **Editar** e **Excluir** mesmo quando o total de produtos é zero. Essas ações e a criação só aparecem para papéis com `menus.manage`; papéis de leitura podem abrir e copiar links publicados.
- Ao editar, a interface leva a pessoa até o formulário. Cardápios sem seções exibem a ação para criar a primeira seção; se a seção estiver vazia, há ação para adicionar o primeiro produto.
- A exclusão pode ser iniciada diretamente pela lista ou pelo editor, sempre com confirmação. Se publicado, o aviso informa que o link público deixará de funcionar.
- O endpoint de exclusão permanece atrás de autenticação, assinatura ativa e `menus.manage`; o `DELETE` filtra simultaneamente pelo ID e pelo tenant derivado da sessão. A interface não é a fronteira de autorização.
- As imagens enviadas não são apagadas automaticamente junto com o cardápio porque uma referência de imagem pode ter sido reutilizada em outro menu; a coleta segura de arquivos órfãos exige verificação de referências e permanece como melhoria futura.

### Testes de gerenciamento

- `npm run test:menus` — verifica as ações de edição/exclusão na lista, o fluxo de rascunho sem produtos, as chamadas da API e as garantias tenant-scoped do endpoint.
- A suíte UX também compila os scripts inline do HTML com `vm.Script`. Esses testes são de regressão estrutural; não substituem o teste HTTP com sessão e banco SQLite nativo nem um teste visual no navegador.
