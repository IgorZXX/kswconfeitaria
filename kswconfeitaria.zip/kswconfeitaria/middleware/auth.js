const jwt = require('jsonwebtoken');
const db = require('../database');

const { JWT_SECRET } = require('../lib/config');

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'Token de acesso não fornecido.' });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || !/^Bearer$/i.test(parts[0])) {
    return res.status(401).json({ error: 'Formato de token inválido.' });
  }

  const token = parts[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    return next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido ou expirado.' });
  }
}

function checkActiveSubscription(req, res, next) {
  db.get(
    'SELECT plano_tipo, status_assinatura, data_vencimento FROM users WHERE id = ?',
    [req.user.id],
    (err, user) => {
      if (err) {
        console.error('Erro ao verificar assinatura:', err);
        return res.status(500).json({ error: 'Não foi possível verificar a assinatura.' });
      }
      if (!user) {
        return res.status(403).json({
          error: 'Você não possui uma assinatura ativa. Escolha um plano para liberar o sistema.',
          code: 'SUBSCRIPTION_REQUIRED'
        });
      }

      const activePlan = ['mensal', 'vitalicio', 'teste'].includes(user.plano_tipo);
      const expired = user.plano_tipo !== 'vitalicio' &&
        user.data_vencimento && new Date(user.data_vencimento) < new Date();
      if (user.status_assinatura === 'ativa' && activePlan && !expired) return next();

      return res.status(403).json({
        error: expired
          ? 'Sua assinatura venceu. Por favor, renove seu plano para continuar acessando os recursos.'
          : 'Você não possui uma assinatura ativa. Escolha um plano para liberar o sistema.',
        code: expired ? 'SUBSCRIPTION_EXPIRED' : 'SUBSCRIPTION_REQUIRED'
      });
    }
  );
}

module.exports = { authMiddleware, checkActiveSubscription };
