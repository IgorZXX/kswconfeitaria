// Limitador de tentativas em memória, sem dependências externas.
// Suficiente para uma instância única; com várias instâncias use um store compartilhado (ex.: Redis).
function rateLimit({ windowMs, max, key, message }) {
  const hits = new Map();

  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset <= now) hits.delete(k);
  }, Math.min(windowMs, 60000));
  sweep.unref();

  return function limiter(req, res, next) {
    const id = key ? key(req) : req.ip;
    const now = Date.now();
    let entry = hits.get(id);
    if (!entry || entry.reset <= now) {
      entry = { count: 0, reset: now + windowMs };
      hits.set(id, entry);
    }
    entry.count += 1;
    if (entry.count > max) {
      res.set('Retry-After', String(Math.ceil((entry.reset - now) / 1000)));
      return res.status(429).json({ error: message || 'Muitas tentativas. Aguarde alguns minutos e tente novamente.' });
    }
    next();
  };
}

module.exports = rateLimit;
