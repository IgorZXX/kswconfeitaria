# KSW Confeitaria SaaS - Sistema Completo com Checkout & Gestão de Assinaturas

Sistema completo de gestão para confeiteiras com controle de assinaturas, autenticação de usuários, integração com pagamento (Hotmart / Mercado Pago), bloqueio por vencimento e painel administrativo.

---

## Planos suportados
1. **Plano Mensal:** R$ 59,99 por mês, com assinatura recorrente pela Stripe.
2. **Plano Vitalício:** R$ 1.119,00 em pagamento único pela Stripe.
3. **Acesso de teste:** fluxo legado Hotmart de R$ 3,90 por 1 dia, mantido separado dos planos comerciais.

---

## Tecnologias utilizadas
- **Frontend:** HTML5, CSS3 Moderno (CSS Variables, Flexbox/Grid), JavaScript Vanilla.
- **Backend:** Node.js, Express.js.
- **Banco de Dados:** SQLite3 (Persistência leve, leve e rápida).
- **Autenticação & Segurança:** JWT (JSON Web Tokens), Bcryptjs (Hash seguro de senhas).
- **Pagamentos:** Stripe Checkout hospedado para mensal e vitalício, com webhook assinado para ativar, renovar e encerrar assinaturas. As rotas antigas de Mercado Pago e Hotmart foram mantidas, mas a tela principal de planos agora usa Stripe.

---

## Como instalar e rodar

### 1. Descompactar o arquivo ZIP
Extraia os arquivos em uma pasta de sua escolha.

### 2. Instalar as dependências
No terminal, dentro do diretório do projeto:
```bash
npm install
```

### 3. Configurar variáveis de ambiente
Configure no `.env` um token válido do Mercado Pago em `MP_ACCESS_TOKEN`. Para receber notificações de pagamento, configure também `BASE_URL` com a URL HTTPS pública do servidor. Nunca publique ou compartilhe o token.

Para validar o acesso de teste, configure `HOTMART_HOTTOK` no `.env` com o token secreto gerado pela Hotmart e, se necessário, ajuste `HOTMART_TEST_PRODUCT_ID` (padrão `8862465`). Cadastre `https://SUA-URL-PUBLICA/api/payment/hotmart/webhook` como webhook do produto de teste e habilite o evento de compra aprovada. O checkout de teste fica desabilitado até `HOTMART_HOTTOK` e `BASE_URL` HTTPS estarem configurados. A compra deve usar o mesmo e-mail da conta KSW. O servidor só ativa o acesso após validar o token, o ID do produto, o status aprovado, o valor de R$ 3,90 e a moeda BRL. Não compartilhe o Hottok.

Sem um token válido, o checkout permanece indisponível e nenhum pagamento fictício é criado. A recuperação de senha por e-mail também depende de uma integração de envio de e-mail, ainda não configurada.

### 4. Iniciar o servidor
```bash
npm start
# Ou para desenvolvimento com reload automático:
npm run dev
```

Acesse no navegador: `http://localhost:3000`

---


## Configurar Stripe (modo de teste)

1. Copie `.env.example` para `.env`.
2. Gere segredos fortes para `JWT_SECRET` e `ADMIN_SECRET_KEY`.
3. No Dashboard Stripe em modo de teste, obtenha uma chave secreta `sk_test_` e coloque em `STRIPE_SECRET_KEY`.
4. Instale as dependências:
   ```bash
   npm install
   ```
5. Crie os produtos e preços automaticamente:
   ```bash
   npm run stripe:products
   ```
   O script cria R$ 59,99/mês e R$ 1.119,00 em pagamento único e grava os dois IDs `price_...` no `.env`. Ele só permite a chave de teste e interrompe a execução se os IDs já estiverem preenchidos, para reduzir o risco de duplicação.
6. Instale a Stripe CLI pelo guia oficial: https://docs.stripe.com/stripe-cli
7. Em outro terminal, autentique e encaminhe os eventos para o servidor local:
   ```bash
   stripe login
   stripe listen --forward-to localhost:3000/api/payment/stripe/webhook
   ```
8. Copie o segredo `whsec_...` mostrado pela CLI para `STRIPE_WEBHOOK_SECRET` no `.env` e reinicie o servidor.
9. Inicie o KSW:
   ```bash
   npm run dev
   ```

A tela de planos redireciona o cliente para o Checkout hospedado da Stripe. A aplicação só libera o plano após confirmação verificada pela assinatura do webhook. Para testar, use os cartões de teste oficiais da Stripe: https://docs.stripe.com/testing

### Webhook em produção

Em produção, cadastre `https://SEU-DOMINIO/api/payment/stripe/webhook` como endpoint de webhook no Dashboard Stripe e configure o segredo `whsec_...` desse endpoint em `STRIPE_WEBHOOK_SECRET`. Use uma `BASE_URL` HTTPS. O segredo obtido pelo `stripe listen` é destinado ao desenvolvimento local e não substitui o segredo do endpoint de produção.

### Cancelamento de assinatura

Para assinaturas Stripe, o KSW agenda o cancelamento no fim do período já pago. O cliente mantém o acesso até a data de vencimento. A confirmação final de encerramento vem do webhook da Stripe.

### Segurança

- Nunca envie o `.env` por chat, e-mail ou repositório.
- Não coloque chaves secretas no HTML ou JavaScript do navegador.
- O `.env` e o banco SQLite estão ignorados pelo `.gitignore`.
- Se uma chave secreta foi compartilhada, revogue-a no Dashboard e gere outra.
- O script `npm run stripe:products` cria recursos somente no modo de teste. Antes de produção, crie os preços da conta live e use IDs e chave live em um processo separado e revisado.

## Dados na nuvem (Fase 1)

Antes, ingredientes, receitas, clientes e pedidos ficavam só no `localStorage` do navegador: trocar de aparelho ou limpar o cache apagava tudo. Agora ficam no servidor, separados por usuária.

- **Tabelas:** `clientes`, `ingredientes`, `produtos`, `pedidos`, `despesas` e `movimentacoes_estoque`. Chave primária `(user_id, id)`: uma conta nunca lê nem sobrescreve registros de outra. Cada linha guarda o JSON completo (`data`) e colunas-chave (status, data de entrega, total, pago, validade, etc.) já prontas para filtros e relatórios.
- **API** (`routes/data.js`): `GET /api/data` (carrega tudo), `POST /api/data/sync` (lista de operações `put`/`del`, gravada numa única transação, máx. 1000 por chamada) e `GET /api/data/export` (backup em JSON). A leitura e a exportação funcionam mesmo com assinatura vencida; a escrita exige assinatura ativa.
- **Front-end:** o app envia só o que mudou (alguns instantes após cada alteração) e mostra o estado no menu ("Dados salvos na nuvem"). O `localStorage` virou cache por usuária (`ksw-db:<id>`): sem internet o app continua funcionando e reenvia ao reconectar. Se a mesma conta alterar dados em dois aparelhos, vale o último envio de cada registro. Ao voltar para a aba, o app busca mudanças do outro aparelho.
- **Migração automática:** no primeiro login após a atualização, se a conta ainda não tem dados na nuvem, os dados antigos do navegador (`ksw-db`) são enviados automaticamente e a chave antiga é removida só depois do envio completo.
- **Sair da conta** envia as pendências e apaga o cache do aparelho; se estiver sem internet, mantém o cache para não perder nada.

### Segurança (Fase 1)

- Sem segredos padrão no código. Em produção (`NODE_ENV=production`) o servidor não inicia sem `JWT_SECRET` e `ADMIN_SECRET_KEY` fortes.
- Limite de tentativas: login (10 por 15 min por IP + e-mail), cadastro, redefinição de senha e chave do painel admin. Se usar proxy/túnel, defina `TRUST_PROXY=1`.
- Senha mínima de 8 caracteres também no servidor; validação de tipo e tamanho nos campos de cadastro e login.
- Chave admin comparada em tempo constante; CORS restrito à `BASE_URL` em produção; cabeçalhos de segurança básicos; HSTS em produção; limite de 200 KB para JSON (5 MB só em `/api/data`).
- SQLite em modo WAL com `busy_timeout`.

### Backup e testes

```bash
npm run backup   # copia consistente do banco para ./backups (mantém os 14 mais recentes)
npm test         # sobe o servidor com banco temporário e roda 20 verificações da API
```
Agende o `npm run backup` (cron/Agendador de Tarefas) e copie a pasta para fora do servidor.

## Fase 2A: encomendas e financeiro

Código em `public/gestao.js` (usa o mesmo visual e os mesmos helpers do `index.html`).

- **Pedidos:** criar e editar (cliente, data e hora de entrega, itens, observações/tema), **sinal e saldo**, vários pagamentos por pedido (valor, forma, data) com histórico, status na própria lista, filtro por status/saldo e busca por cliente. O preço e o custo de cada item ficam congelados no pedido; editar não muda o que já foi vendido. Pedidos antigos (com o campo `pg`) continuam valendo.
- **WhatsApp** (`wa.me`, sem custo): lembrete de entrega, cobrança do saldo e confirmação de encomenda, com a mensagem já preenchida.
- **Agenda:** calendário mensal com pedidos por dia, dia selecionado com a lista de encomendas e contas a vencer, e **trava de capacidade diária** (máximo de pedidos e de unidades por dia). Ao ultrapassar, o sistema avisa e pergunta se aceita mesmo assim.
- **Financeiro:** Resumo (entradas, saídas, saldo de caixa, resultado do mês, despesas por categoria), A receber, A pagar (categorias, fornecedor, repetição mensal de até 24 meses, marcar como paga), Fluxo de caixa (saldo anterior, movimentos do mês com saldo corrente e previsão de 30 dias) e Fornecedores.
- **Painel inicial:** alertas (entregas atrasadas, entregues com saldo, contas vencidas ou a vencer, estoque baixo, capacidade do dia) e próximas entregas com ações.
- **Banco:** novas tabelas `fornecedores` e `configuracoes`, colunas novas em `despesas` e migração automática (`ALTER TABLE`) de bancos criados antes, sem apagar dados.

Fora desta fase: estoque com histórico e conferência, lista de compras, lotes de produção, relatórios com gráficos, pedidos online, cupons, orçamento por link e a assistente de IA.

## Painel administrativo
- Acesse a página separada em `http://localhost:3000/admin`.
- Digite a chave mestra configurada no `.env` (`ADMIN_SECRET_KEY`).
- É possível visualizar todos os clientes, alterar planos manualmente, ativar/bloquear contas e cancelar assinaturas.

## Catálogo digital
- Acesse **Cardápios** no sistema para criar vários cardápios, organizar produtos por seções e incluir descrição, preço e imagem.
- Salve como rascunho, pré-visualize, oculte itens individualmente e publique ou retire cada cardápio do ar.
- Cada cardápio publicado recebe um link público (`/menu/<slug>`). A vitrine (`/links/<slug>`) reúne os cardápios publicados e pode ser compartilhada na bio.
- Cardápios e vitrine ficam salvos no SQLite e só podem ser editados por uma conta autenticada com assinatura ativa. Os visitantes não precisam entrar na conta para abrir os links.
- O catálogo exibe produtos e preços; não processa pedidos nem pagamentos.

## Políticas legais — pendentes de revisão
- O documento interno `legal/politicas-rascunho.md` reúne textos-base para Termos de Uso, privacidade/LGPD, armazenamento local e condições comerciais.
- As páginas principal e administrativa exibem um aviso sobre cookies e armazenamento local. A confirmação apenas fecha o aviso; não representa consentimento para cookies opcionais.
- Não é publicado nem integrado ao cadastro. Não use como documento final ou aceite até preencher os dados pendentes, alinhar os textos à operação real e obter revisão jurídica.
