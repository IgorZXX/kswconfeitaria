const express = require('express');
const crypto = require('crypto');
const db = require('../database');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');

const router = express.Router();
const slugPattern = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

function slugify(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 48) || 'cardapio';
}

function parseMenu(row) {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    description: row.description,
    published: Boolean(row.published),
    sections: JSON.parse(row.sections_json),
    created_at: row.created_at,
    updated_at: row.updated_at
  };
}

function hasJsonObjectBody(req, res) {
  if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body)) {
    res.status(400).json({ error: 'Envie os dados do cardápio em um objeto JSON.' });
    return false;
  }
  return true;
}

function normalizeSections(value) {
  if (!Array.isArray(value) || value.length > 40) {
    return { error: 'Adicione até 40 seções ao cardápio.' };
  }

  const sections = [];
  for (const section of value) {
    if (!section || typeof section !== 'object' ||
        typeof section.name !== 'string' || !section.name.trim() ||
        section.name.trim().length > 70 ||
        !Array.isArray(section.products) || section.products.length > 100) {
      return { error: 'Revise os nomes e os produtos das seções.' };
    }

    const products = [];
    for (const product of section.products) {
      const rawPrice = product && product.price;
      const price = Number(rawPrice);
      if (!product || typeof product !== 'object' ||
          typeof product.name !== 'string' || !product.name.trim() ||
          product.name.trim().length > 100 ||
          (typeof rawPrice !== 'number' && typeof rawPrice !== 'string') ||
          (typeof rawPrice === 'string' && !rawPrice.trim()) ||
          !Number.isFinite(price) || price < 0 || price > 1000000 ||
          (product.description != null && String(product.description).length > 500) ||
          (product.image_url && !isHttpUrl(product.image_url))) {
        return { error: 'Revise o nome, o preço, a descrição e a imagem dos produtos.' };
      }

      products.push({
        id: String(product.id || crypto.randomBytes(8).toString('hex')).slice(0, 40),
        name: product.name.trim(),
        description: String(product.description || '').trim(),
        price,
        image_url: String(product.image_url || '').trim(),
        visible: product.visible !== false
      });
    }

    sections.push({
      id: String(section.id || crypto.randomBytes(8).toString('hex')).slice(0, 40),
      name: section.name.trim(),
      description: String(section.description || '').trim().slice(0, 180),
      visible: section.visible !== false,
      products
    });
  }

  return { sections };
}

function isHttpUrl(value) {
  if (typeof value !== 'string' || value.length > 2000) return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch (error) {
    return false;
  }
}

function ensureHub(userId, callback) {
  const slug = `confeitaria-${userId}`;
  db.run(
    'INSERT OR IGNORE INTO menu_hubs (user_id, slug) VALUES (?, ?)',
    [userId, slug],
    (err) => {
      if (err) return callback(err);
      db.get('SELECT slug FROM menu_hubs WHERE user_id = ?', [userId], callback);
    }
  );
}

router.get('/', authMiddleware, checkActiveSubscription, (req, res) => {
  db.all(
    'SELECT * FROM menus WHERE user_id = ? ORDER BY updated_at DESC, title COLLATE NOCASE',
    [req.user.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Não foi possível carregar os cardápios.' });
      ensureHub(req.user.id, (hubErr, hub) => {
        if (hubErr) return res.status(500).json({ error: 'Não foi possível carregar o link da vitrine.' });
        res.json({ menus: rows.map(parseMenu), hub_slug: hub.slug });
      });
    }
  );
});

router.get('/public/menus/:slug', (req, res) => {
  db.get(
    `SELECT menus.*, users.nome AS owner_name
     FROM menus JOIN users ON users.id = menus.user_id
     WHERE menus.slug = ? AND menus.published = 1`,
    [req.params.slug],
    (err, row) => {
      if (err) return res.status(500).json({ error: 'Não foi possível carregar este cardápio.' });
      if (!row) return res.status(404).json({ error: 'Este cardápio não foi encontrado ou não está publicado.' });
      const menu = parseMenu(row);
      menu.owner_name = row.owner_name;
      res.json({ menu });
    }
  );
});

router.get('/public/links/:slug', (req, res) => {
  db.get('SELECT user_id FROM menu_hubs WHERE slug = ?', [req.params.slug], (hubErr, hub) => {
    if (hubErr) return res.status(500).json({ error: 'Não foi possível carregar esta vitrine.' });
    if (!hub) return res.status(404).json({ error: 'Esta vitrine não foi encontrada.' });
    db.get('SELECT nome FROM users WHERE id = ?', [hub.user_id], (userErr, user) => {
      if (userErr) return res.status(500).json({ error: 'Não foi possível carregar esta vitrine.' });
      if (!user) return res.status(404).json({ error: 'Esta vitrine não foi encontrada.' });
      db.all(
        'SELECT id, slug, title, description FROM menus WHERE user_id = ? AND published = 1 ORDER BY updated_at DESC',
        [hub.user_id],
        (menusErr, menus) => {
          if (menusErr) return res.status(500).json({ error: 'Não foi possível carregar os cardápios publicados.' });
          res.json({ owner_name: user.nome, menus });
        }
      );
    });
  });
});

router.use(authMiddleware, checkActiveSubscription);

router.post('/', (req, res) => {
  if (!hasJsonObjectBody(req, res)) return;
  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim();
  const normalized = normalizeSections(req.body.sections);
  if (!title || title.length > 100 || description.length > 500) {
    return res.status(400).json({ error: 'Informe um título de até 100 caracteres e uma descrição de até 500 caracteres.' });
  }
  if (normalized.error) return res.status(400).json({ error: normalized.error });

  const id = crypto.randomBytes(12).toString('hex');
  const slug = `${slugify(title)}-${crypto.randomBytes(3).toString('hex')}`;
  db.run(
    `INSERT INTO menus (id, user_id, slug, title, description, sections_json)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [id, req.user.id, slug, title, description, JSON.stringify(normalized.sections)],
    (err) => {
      if (err) return res.status(500).json({ error: 'Não foi possível criar o cardápio.' });
      db.get('SELECT * FROM menus WHERE id = ?', [id], (readErr, row) => {
        if (readErr || !row) return res.status(500).json({ error: 'O cardápio foi criado, mas não pôde ser carregado.' });
        res.status(201).json({ menu: parseMenu(row) });
      });
    }
  );
});

router.put('/:id', (req, res) => {
  if (!hasJsonObjectBody(req, res)) return;
  const title = String(req.body.title || '').trim();
  const description = String(req.body.description || '').trim();
  const normalized = normalizeSections(req.body.sections);
  if (!title || title.length > 100 || description.length > 500) {
    return res.status(400).json({ error: 'Informe um título de até 100 caracteres e uma descrição de até 500 caracteres.' });
  }
  if (normalized.error) return res.status(400).json({ error: normalized.error });
  if (typeof req.body.published !== 'boolean') {
    return res.status(400).json({ error: 'Informe se o cardápio deve estar publicado.' });
  }
  if (req.body.published && !normalized.sections.some((section) =>
    section.visible && section.products.some((product) => product.visible)
  )) {
    return res.status(400).json({ error: 'Adicione ao menos um produto visível antes de publicar.' });
  }

  db.run(
    `UPDATE menus SET title = ?, description = ?, sections_json = ?, published = ?,
     updated_at = CURRENT_TIMESTAMP WHERE id = ? AND user_id = ?`,
    [title, description, JSON.stringify(normalized.sections), req.body.published ? 1 : 0, req.params.id, req.user.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Não foi possível salvar o cardápio.' });
      if (!this.changes) return res.status(404).json({ error: 'Cardápio não encontrado.' });
      db.get('SELECT * FROM menus WHERE id = ?', [req.params.id], (readErr, row) => {
        if (readErr || !row) return res.status(500).json({ error: 'O cardápio foi salvo, mas não pôde ser carregado.' });
        res.json({ menu: parseMenu(row) });
      });
    }
  );
});

router.delete('/:id', (req, res) => {
  db.run('DELETE FROM menus WHERE id = ? AND user_id = ?', [req.params.id, req.user.id], function (err) {
    if (err) return res.status(500).json({ error: 'Não foi possível remover o cardápio.' });
    if (!this.changes) return res.status(404).json({ error: 'Cardápio não encontrado.' });
    res.json({ message: 'Cardápio removido.' });
  });
});

router.put('/hub/slug', (req, res) => {
  if (!hasJsonObjectBody(req, res)) return;
  const slug = String(req.body.slug || '').trim().toLowerCase();
  if (!slugPattern.test(slug) || slug.length < 3 || slug.length > 48) {
    return res.status(400).json({ error: 'Use de 3 a 48 caracteres: letras minúsculas, números e hífens.' });
  }

  ensureHub(req.user.id, (ensureErr) => {
    if (ensureErr) return res.status(500).json({ error: 'Não foi possível atualizar o link da vitrine.' });
    db.run('UPDATE menu_hubs SET slug = ? WHERE user_id = ?', [slug, req.user.id], function (err) {
      if (err && err.code === 'SQLITE_CONSTRAINT') {
        return res.status(409).json({ error: 'Este link já está sendo usado. Escolha outro.' });
      }
      if (err) return res.status(500).json({ error: 'Não foi possível atualizar o link da vitrine.' });
      res.json({ hub_slug: slug });
    });
  });
});

module.exports = router;
