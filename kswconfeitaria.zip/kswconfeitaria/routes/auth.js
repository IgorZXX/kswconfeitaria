const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');

const rateLimit = require('../middleware/rateLimit');
const { JWT_SECRET } = require('../lib/config');

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const isText = (value, max) => typeof value === 'string' && value.length <= max;

// Freio contra força bruta: por IP + e-mail no login, por IP no cadastro e na redefinição.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  key: (req) => `${req.ip}|${String((req.body && req.body.email) || '').toLowerCase().slice(0, 120)}`,
  message: 'Muitas tentativas de login. Aguarde 15 minutos e tente novamente.'
});
const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 15,
  message: 'Muitos cadastros a partir desta conexão. Tente novamente mais tarde.'
});
const resetLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'Muitas tentativas. Aguarde alguns minutos e tente novamente.'
});

// Register Confeiteira
router.post('/register', registerLimiter, async (req, res) => {
  const { nome, email, senha, whatsapp } = req.body || {};

  if (!nome || !email || !senha) {
    return res.status(400).json({ error: 'Nome, e-mail e senha são obrigatórios.' });
  }
  if (!isText(nome, 120) || !isText(email, 160) || !isText(senha, 200) || (whatsapp != null && !isText(whatsapp, 30))) {
    return res.status(400).json({ error: 'Dados de cadastro inválidos.' });
  }
  if (!EMAIL_PATTERN.test(email.trim())) {
    return res.status(400).json({ error: 'Informe um e-mail válido.' });
  }
  if (senha.length < 8) {
    return res.status(400).json({ error: 'A senha deve ter pelo menos 8 caracteres.' });
  }

  db.get('SELECT id FROM users WHERE email = ?', [email.toLowerCase().trim()], async (err, row) => {
    if (err) return res.status(500).json({ error: 'Erro no banco de dados.' });
    if (row) return res.status(400).json({ error: 'E-mail já cadastrado.' });

    const hashSenha = await bcrypt.hash(senha, 10);

    db.run(
      `INSERT INTO users (nome, email, senha, whatsapp, plano_tipo, status_assinatura) VALUES (?, ?, ?, ?, 'free', 'inativa')`,
      [nome.trim(), email.toLowerCase().trim(), hashSenha, whatsapp || ''],
      function (err2) {
        if (err2) return res.status(500).json({ error: 'Erro ao cadastrar usuária.' });

        const userId = this.lastID;
        const token = jwt.sign(
          { id: userId, email, nome, role: 'user', plano_tipo: 'free', status_assinatura: 'inativa' },
          JWT_SECRET,
          { expiresIn: '7d' }
        );

        return res.json({
          message: 'Conta criada com sucesso!',
          token,
          user: { id: userId, nome, email, plano_tipo: 'free', status_assinatura: 'inativa' }
        });
      }
    );
  });
});

// Login
router.post('/login', loginLimiter, (req, res) => {
  const { email, senha } = req.body || {};

  if (!email || !senha) {
    return res.status(400).json({ error: 'Informe e-mail e senha.' });
  }
  if (!isText(email, 160) || !isText(senha, 200)) {
    return res.status(400).json({ error: 'Dados de login inválidos.' });
  }

  db.get('SELECT * FROM users WHERE email = ?', [email.toLowerCase().trim()], async (err, user) => {
    if (err || !user) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }

    const val = await bcrypt.compare(senha, user.senha);
    if (!val) {
      return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
    }

    // Verificar se a assinatura mensal venceu
    let statusFinal = user.status_assinatura;
    if (['mensal', 'teste'].includes(user.plano_tipo) && user.data_vencimento) {
      if (new Date(user.data_vencimento) < new Date()) {
        statusFinal = 'vencida';
        db.run('UPDATE users SET status_assinatura = "vencida" WHERE id = ?', [user.id]);
      }
    }

    const token = jwt.sign(
      {
        id: user.id,
        email: user.email,
        nome: user.nome,
        role: user.role,
        plano_tipo: user.plano_tipo,
        status_assinatura: statusFinal,
        data_vencimento: user.data_vencimento
      },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.json({
      message: 'Login realizado com sucesso!',
      token,
      user: {
        id: user.id,
        nome: user.nome,
        email: user.email,
        role: user.role,
        plano_tipo: user.plano_tipo,
        status_assinatura: statusFinal,
        data_vencimento: user.data_vencimento
      }
    });
  });
});

// Get Current Profile
router.get('/me', authMiddleware, (req, res) => {
  db.get('SELECT id, nome, email, whatsapp, role, plano_tipo, status_assinatura, data_vencimento, created_at FROM users WHERE id = ?', [req.user.id], (err, user) => {
    if (err || !user) return res.status(404).json({ error: 'Usuária não encontrada.' });

    // Atualizar se venceu
    if (['mensal', 'teste'].includes(user.plano_tipo) && user.data_vencimento && new Date(user.data_vencimento) < new Date()) {
      user.status_assinatura = 'vencida';
      db.run('UPDATE users SET status_assinatura = "vencida" WHERE id = ?', [user.id]);
    }

    res.json({ user });
  });
});

// Solicitar Recuperação de Senha
router.post('/forgot-password', resetLimiter, (req, res) => {
  return res.status(503).json({
    error: 'A recuperação de senha por e-mail ainda não está configurada neste servidor.'
  });
});

// Redefinir Senha
router.post('/reset-password', resetLimiter, async (req, res) => {
  const { token, novaSenha } = req.body || {};
  if (!token || !novaSenha) {
    return res.status(400).json({ error: 'Token e nova senha são obrigatórios.' });
  }
  if (!isText(token, 200) || !isText(novaSenha, 200)) {
    return res.status(400).json({ error: 'Dados inválidos.' });
  }
  if (novaSenha.length < 8) {
    return res.status(400).json({ error: 'A senha deve ter pelo menos 8 caracteres.' });
  }

  db.get(
    'SELECT * FROM password_resets WHERE token = ? AND usado = 0 AND expira_em > CURRENT_TIMESTAMP',
    [token],
    async (err, reset) => {
      if (err || !reset) {
        return res.status(400).json({ error: 'Token de recuperação inválido ou expirado.' });
      }

      const hash = await bcrypt.hash(novaSenha, 10);

      db.run('UPDATE users SET senha = ? WHERE id = ?', [hash, reset.user_id], (err2) => {
        if (err2) return res.status(500).json({ error: 'Erro ao atualizar senha.' });

        db.run('UPDATE password_resets SET usado = 1 WHERE id = ?', [reset.id]);
        return res.json({ message: 'Senha redefinida com sucesso! Faça login com sua nova senha.' });
      });
    }
  );
});

module.exports = router;
