const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const db = require('../database');
const rateLimit = require('../middleware/rateLimit');
const { ADMIN_SECRET_KEY } = require('../lib/config');

// Limita tentativas de adivinhar a chave mestra.
router.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200, message: 'Muitas requisições ao painel. Aguarde alguns minutos.' }));
const failedAdminAttempts = rateLimit({ windowMs: 15 * 60 * 1000, max: 10, message: 'Muitas tentativas de acesso. Aguarde alguns minutos.' });

function sameKey(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

// Middleware de verificação de Admin
function adminAuth(req, res, next) {
  const adminKey = req.headers['x-admin-key'];

  if (!adminKey || !sameKey(adminKey, ADMIN_SECRET_KEY)) {
    // Só conta como tentativa quando a chave está errada.
    return failedAdminAttempts(req, res, () => (
      res.status(403).json({ error: 'Acesso negado ao painel administrativo.' })
    ));
  }
  next();
}

// Listar todas as Confeiteiras e suas Assinaturas
router.get('/users', adminAuth, (req, res) => {
  db.all(
    'SELECT id, nome, email, whatsapp, role, plano_tipo, status_assinatura, data_vencimento, created_at FROM users ORDER BY id DESC',
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Erro ao buscar usuárias.' });
      res.json({ users: rows });
    }
  );
});

// Atualizar Plano / Assinatura Manualmente pelo Admin
router.post('/users/:id/update-subscription', adminAuth, (req, res) => {
  const { id } = req.params;
  const { plano_tipo, status_assinatura, dias_adicionais } = req.body;

  let venceEm = null;
  if (plano_tipo === 'vitalicio') {
    const d = new Date();
    d.setFullYear(d.getFullYear() + 100);
    venceEm = d.toISOString();
  } else if (dias_adicionais) {
    const d = new Date();
    d.setDate(d.getDate() + parseInt(dias_adicionais));
    venceEm = d.toISOString();
  }

  db.run(
    'UPDATE users SET plano_tipo = ?, status_assinatura = ?, data_vencimento = COALESCE(?, data_vencimento) WHERE id = ?',
    [plano_tipo, status_assinatura, venceEm, id],
    (err) => {
      if (err) return res.status(500).json({ error: 'Erro ao atualizar dados.' });
      res.json({ message: 'Assinatura do cliente atualizada com sucesso!' });
    }
  );
});

// Historico de Pedidos
router.get('/orders', adminAuth, (req, res) => {
  db.all(
    `SELECT orders.*, users.nome as user_nome, users.email as user_email 
     FROM orders 
     JOIN users ON users.id = orders.user_id 
     ORDER BY orders.id DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Erro ao buscar histórico de pedidos.' });
      res.json({ orders: rows });
    }
  );
});

module.exports = router;
