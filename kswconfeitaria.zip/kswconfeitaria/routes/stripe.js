const express = require('express');
const Stripe = require('stripe');
const crypto = require('crypto');
const db = require('../database');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key || !key.startsWith('sk_') || /sua_chave|coloque|example/i.test(key)) {
    return null;
  }
  return new Stripe(key);
}

function dbRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({ changes: this.changes, lastID: this.lastID });
    });
  });
}

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
  });
}

function getPriceId(plan) {
  return plan === 'mensal'
    ? process.env.STRIPE_MONTHLY_PRICE_ID
    : plan === 'vitalicio'
      ? process.env.STRIPE_LIFETIME_PRICE_ID
      : null;
}

function getBaseUrl(req) {
  const configured = process.env.BASE_URL;
  if (configured && /^https:\/\/[^/]+/i.test(configured)) {
    return configured.replace(/\/$/, '');
  }
  if (process.env.NODE_ENV === 'production') return null;
  return `${req.protocol}://${req.get('host')}`;
}

router.get('/availability', (req, res) => {
  const stripe = getStripe();
  const monthly = getPriceId('mensal');
  const lifetime = getPriceId('vitalicio');
  res.json({
    available: Boolean(stripe && monthly && lifetime),
    provider: 'Stripe',
    methods: ['card'],
    message: stripe && monthly && lifetime
      ? 'Checkout da Stripe disponível.'
      : 'Configure a chave secreta e os dois IDs de preço da Stripe no .env.'
  });
});

router.post('/create-checkout', authMiddleware, async (req, res) => {
  const plan = req.body && req.body.plano_tipo;
  if (!['mensal', 'vitalicio'].includes(plan)) {
    return res.status(400).json({ error: 'Plano inválido.' });
  }

  const stripe = getStripe();
  const priceId = getPriceId(plan);
  const baseUrl = getBaseUrl(req);

  if (!stripe || !priceId || !baseUrl) {
    return res.status(503).json({
      error: 'Stripe indisponível. Confira STRIPE_SECRET_KEY, BASE_URL e os IDs de preço no .env.'
    });
  }

  const userId = Number(req.user.id);
  const amount = plan === 'mensal' ? 59.99 : 1119.00;
  const orderReference = `STRIPE-${crypto.randomUUID()}`;

  try {
    await dbRun(
      `INSERT INTO orders
       (user_id, plano_tipo, valor, status, gateway, external_reference)
       VALUES (?, ?, ?, 'pending', 'stripe', ?)`,
      [userId, plan, amount, orderReference]
    );

    const metadata = {
      userId: String(userId),
      planType: plan,
      orderReference
    };

    const session = await stripe.checkout.sessions.create({
      mode: plan === 'mensal' ? 'subscription' : 'payment',
      line_items: [{ price: priceId, quantity: 1 }],
      customer_email: req.user.email,
      client_reference_id: String(userId),
      metadata,
      ...(plan === 'mensal'
        ? { subscription_data: { metadata } }
        : { payment_intent_data: { metadata } }),
      success_url: `${baseUrl}/?stripe_payment=success&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/?stripe_payment=cancelled`
    });

    await dbRun(
      `UPDATE orders SET payment_id = ?, updated_at = CURRENT_TIMESTAMP
       WHERE external_reference = ? AND user_id = ?`,
      [session.id, orderReference, userId]
    );

    return res.status(201).json({
      checkout_url: session.url,
      session_id: session.id,
      plano_tipo: plan
    });
  } catch (error) {
    console.error('Erro ao criar Checkout Stripe:', error);
    await dbRun(
      `UPDATE orders SET status = 'failed', updated_at = CURRENT_TIMESTAMP
       WHERE external_reference = ?`,
      [orderReference]
    ).catch(() => {});
    return res.status(502).json({
      error: 'Não foi possível iniciar o pagamento pela Stripe. Tente novamente.'
    });
  }
});

async function activateUserForSession(session, stripe) {
  const metadata = session.metadata || {};
  const userId = Number(metadata.userId || session.client_reference_id);
  const plan = metadata.planType;
  if (!Number.isInteger(userId) || userId <= 0 ||
      !['mensal', 'vitalicio'].includes(plan)) {
    throw new Error('Metadados do Checkout inválidos.');
  }

  if (session.payment_status !== 'paid' && session.mode !== 'subscription') {
    return;
  }

  let subscriptionId = null;
  let expiration = null;

  if (plan === 'mensal') {
    subscriptionId = typeof session.subscription === 'string'
      ? session.subscription
      : session.subscription && session.subscription.id;

    if (!subscriptionId) throw new Error('Assinatura Stripe não encontrada.');

    const subscription = await stripe.subscriptions.retrieve(subscriptionId);
    if (subscription.status !== 'active' && subscription.status !== 'trialing') {
      throw new Error('A assinatura ainda não está ativa.');
    }
    if (subscription.current_period_end) {
      expiration = new Date(subscription.current_period_end * 1000).toISOString();
    }
  }

  await dbRun(
    `UPDATE users
     SET plano_tipo = ?, status_assinatura = 'ativa', data_vencimento = ?,
         subscription_id_gateway = ?
     WHERE id = ?`,
    [plan, expiration, subscriptionId, userId]
  );

  if (metadata.orderReference) {
    await dbRun(
      `UPDATE orders SET status = 'approved', updated_at = CURRENT_TIMESTAMP
       WHERE external_reference = ? AND user_id = ? AND gateway = 'stripe'`,
      [metadata.orderReference, userId]
    );
  } else {
    await dbRun(
      `UPDATE orders SET status = 'approved', updated_at = CURRENT_TIMESTAMP
       WHERE payment_id = ? AND user_id = ? AND gateway = 'stripe'`,
      [session.id, userId]
    );
  }
}

async function syncSubscription(subscription, statusOverride) {
  const userId = Number(subscription.metadata && subscription.metadata.userId);
  if (!Number.isInteger(userId) || userId <= 0) return;

  const active = statusOverride || subscription.status;
  const isActive = active === 'active' || active === 'trialing';
  const expiration = subscription.current_period_end
    ? new Date(subscription.current_period_end * 1000).toISOString()
    : null;

  await dbRun(
    `UPDATE users SET status_assinatura = ?, data_vencimento = ?,
       subscription_id_gateway = ? WHERE id = ? AND plano_tipo = 'mensal'`,
    [isActive ? 'ativa' : 'inativa', expiration, subscription.id, userId]
  );
}

async function webhookHandler(req, res) {
  const stripe = getStripe();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const signature = req.headers['stripe-signature'];

  if (!stripe || !webhookSecret || !Buffer.isBuffer(req.body)) {
    return res.status(503).send('Webhook Stripe não configurado.');
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, signature, webhookSecret);
  } catch (error) {
    console.error('Assinatura do webhook Stripe inválida:', error.message);
    return res.status(400).send('Assinatura inválida.');
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed':
      case 'checkout.session.async_payment_succeeded':
        await activateUserForSession(event.data.object, stripe);
        break;

      case 'invoice.paid': {
        const invoice = event.data.object;
        const subId = typeof invoice.subscription === 'string'
          ? invoice.subscription
          : invoice.parent && invoice.parent.subscription_details &&
            invoice.parent.subscription_details.subscription;
        if (subId) {
          const subscription = await stripe.subscriptions.retrieve(subId);
          await syncSubscription(subscription, 'active');
        }
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        const subId = typeof invoice.subscription === 'string'
          ? invoice.subscription
          : invoice.parent && invoice.parent.subscription_details &&
            invoice.parent.subscription_details.subscription;
        if (subId) {
          const subscription = await stripe.subscriptions.retrieve(subId);
          await syncSubscription(subscription, 'past_due');
        }
        break;
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        await syncSubscription(event.data.object);
        break;

      default:
        break;
    }

    return res.json({ received: true });
  } catch (error) {
    console.error('Erro ao processar webhook Stripe:', error);
    return res.status(500).send('Erro ao processar evento.');
  }
}

router.get('/session-status', authMiddleware, async (req, res) => {
  const sessionId = String(req.query.session_id || '');
  if (!sessionId.startsWith('cs_')) {
    return res.status(400).json({ error: 'Sessão inválida.' });
  }

  const stripe = getStripe();
  if (!stripe) return res.status(503).json({ error: 'Stripe não configurada.' });

  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    const userId = Number(session.metadata && session.metadata.userId);
    if (userId !== Number(req.user.id)) {
      return res.status(403).json({ error: 'Esta sessão não pertence à sua conta.' });
    }

    if (session.payment_status === 'paid' || session.mode === 'subscription') {
      await activateUserForSession(session, stripe);
    }

    const user = await dbGet(
      'SELECT plano_tipo, status_assinatura, data_vencimento FROM users WHERE id = ?',
      [req.user.id]
    );

    return res.json({
      payment_status: session.payment_status,
      access_active: Boolean(user && user.status_assinatura === 'ativa'),
      user
    });
  } catch (error) {
    console.error('Erro ao consultar sessão Stripe:', error);
    return res.status(502).json({ error: 'Não foi possível consultar o pagamento.' });
  }
});

module.exports = { router, webhookHandler };
