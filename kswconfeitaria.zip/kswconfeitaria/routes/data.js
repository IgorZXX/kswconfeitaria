const express = require('express');
const db = require('../database');
const { authMiddleware, checkActiveSubscription } = require('../middleware/auth');

const router = express.Router();

const MAX_OPS = 1000;            // operações por requisição
const MAX_RECORD_BYTES = 100000; // tamanho de um registro serializado
const ID_PATTERN = /^[A-Za-z0-9_.-]{1,64}$/;

const TABLES = Object.fromEntries(db.DATA_TABLES.map((t) => [t.key, t]));

function text(value, max = 200) {
  return value == null ? '' : String(value).slice(0, max);
}
function number(value) {
  const n = Number(String(value == null ? 0 : value).replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
}

// Extrai as colunas-chave de cada tipo de registro (na ordem de DATA_TABLES[].columns).
const EXTRACTORS = {
  clientes: (r) => [text(r.nome)],
  ingredientes: (r) => [text(r.nome), number(r.est), number(r.min), text(r.val, 10)],
  produtos: (r) => [text(r.nome), number(r.preco)],
  pedidos: (r) => {
    const itens = Array.isArray(r.itens) ? r.itens : [];
    const total = itens.reduce((sum, i) => sum + number(i && i.pu) * number(i && i.q), 0);
    // Valor pago = soma dos pagamentos registrados (ou o campo antigo "pg", de pedidos anteriores).
    const pago = Array.isArray(r.pagamentos)
      ? r.pagamentos.reduce((sum, x) => sum + number(x && x.v), 0)
      : number(r.pg);
    return [text(r.cli, 64), text(r.ent, 10), text(r.st, 30), total, pago];
  },
  despesas: (r) => [number(r.v), text(r.venc, 10), r.pago ? 1 : 0, text(r.cat, 60), text(r.forn, 64), text(r.dpg, 10)],
  fornecedores: (r) => [text(r.nome)],
  config: (r) => [number(r.cap_pedidos), number(r.cap_unid)],
  mov: (r) => [text(r.ing, 64), text(r.tipo, 20), number(r.qtd), text(r.data || r.criado_em, 40)]
};

function validateOps(ops) {
  if (!Array.isArray(ops)) return 'Envie a lista de operações em "ops".';
  if (ops.length > MAX_OPS) return `Limite de ${MAX_OPS} operações por requisição.`;

  for (const op of ops) {
    if (!op || typeof op !== 'object' || !TABLES[op.c]) return 'Coleção inválida.';
    if (op.op === 'put') {
      const r = op.r;
      if (!r || typeof r !== 'object' || Array.isArray(r)) return 'Registro inválido.';
      if (!ID_PATTERN.test(String(r.id))) return 'Identificador de registro inválido.';
      if (JSON.stringify(r).length > MAX_RECORD_BYTES) return 'Registro grande demais.';
    } else if (op.op === 'del') {
      if (!ID_PATTERN.test(String(op.id))) return 'Identificador de registro inválido.';
    } else {
      return 'Operação inválida.';
    }
  }
  return null;
}

function loadAll(userId) {
  const keys = Object.keys(TABLES);
  return Promise.all(keys.map((key) => new Promise((resolve, reject) => {
    db.all(`SELECT id, data FROM ${TABLES[key].table} WHERE user_id = ? ORDER BY rowid`, [userId], (err, rows) => {
      if (err) return reject(err);
      resolve(rows.map((row) => {
        try {
          return { ...JSON.parse(row.data), id: row.id };
        } catch (_) {
          return null;
        }
      }).filter(Boolean));
    });
  }))).then((lists) => Object.fromEntries(keys.map((key, i) => [key, lists[i]])));
}

// Leitura: liberada para qualquer conta autenticada, para que a confeiteira nunca
// fique sem acesso aos próprios dados (por exemplo, ao exportá-los) se a assinatura vencer.
router.get('/', authMiddleware, async (req, res) => {
  try {
    const data = await loadAll(req.user.id);
    const empty = Object.values(data).every((list) => list.length === 0);
    res.json({ data, empty });
  } catch (err) {
    console.error('Erro ao ler dados:', err);
    res.status(500).json({ error: 'Não foi possível carregar seus dados.' });
  }
});

// Exportação completa (backup em JSON feito pela própria confeiteira).
router.get('/export', authMiddleware, async (req, res) => {
  try {
    const data = await loadAll(req.user.id);
    res.set('Content-Disposition', 'attachment; filename="ksw-meus-dados.json"');
    res.json({ exportado_em: new Date().toISOString(), data });
  } catch (err) {
    console.error('Erro ao exportar dados:', err);
    res.status(500).json({ error: 'Não foi possível exportar seus dados.' });
  }
});

// Escrita: exige assinatura ativa. Cada operação é um "put" (cria ou substitui)
// ou um "del". Tudo em uma única transação: ou grava tudo, ou nada.
router.post('/sync', authMiddleware, checkActiveSubscription, async (req, res) => {
  const ops = req.body && req.body.ops;
  const problem = validateOps(ops);
  if (problem) return res.status(400).json({ error: problem });

  const userId = req.user.id;
  try {
    await db.withTransaction(async (tx) => {
      for (const op of ops) {
        const t = TABLES[op.c];
        if (op.op === 'del') {
          await tx.run(`DELETE FROM ${t.table} WHERE user_id = ? AND id = ?`, [userId, String(op.id)]);
          continue;
        }
        const record = { ...op.r, id: String(op.r.id) };
        const cols = t.columns.map((c) => c.name);
        const values = EXTRACTORS[t.key](record);
        await tx.run(
          `INSERT INTO ${t.table} (user_id, id, ${cols.join(', ')}, data, updated_at)
           VALUES (?, ?, ${cols.map(() => '?').join(', ')}, ?, CURRENT_TIMESTAMP)
           ON CONFLICT(user_id, id) DO UPDATE SET
             ${cols.map((c) => `${c} = excluded.${c}`).join(', ')},
             data = excluded.data,
             updated_at = CURRENT_TIMESTAMP`,
          [userId, record.id, ...values, JSON.stringify(record)]
        );
      }
    });
    return res.json({ ok: true, applied: ops.length });
  } catch (err) {
    console.error('Erro ao sincronizar dados:', err);
    return res.status(500).json({ error: 'Não foi possível salvar seus dados.' });
  }
});

module.exports = router;
