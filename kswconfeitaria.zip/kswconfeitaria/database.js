const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = process.env.DATABASE_PATH
  ? path.resolve(process.env.DATABASE_PATH)
  : path.resolve(__dirname, 'ksw_database.sqlite');
// Definição das tabelas de dados da confeiteira (usada também por routes/data.js).
const DATA_TABLES = [
  { key: 'clientes', table: 'clientes', columns: [
    { name: 'nome', type: 'TEXT' }
  ] },
  { key: 'ingredientes', table: 'ingredientes', columns: [
    { name: 'nome', type: 'TEXT' },
    { name: 'estoque', type: 'REAL' },
    { name: 'estoque_min', type: 'REAL' },
    { name: 'validade', type: 'TEXT' }
  ] },
  { key: 'produtos', table: 'produtos', columns: [
    { name: 'nome', type: 'TEXT' },
    { name: 'preco', type: 'REAL' }
  ] },
  { key: 'pedidos', table: 'pedidos', columns: [
    { name: 'cliente_id', type: 'TEXT', index: true },
    { name: 'data_entrega', type: 'TEXT', index: true },
    { name: 'status', type: 'TEXT', index: true },
    { name: 'total', type: 'REAL' },
    { name: 'pago', type: 'REAL' }
  ] },
  { key: 'despesas', table: 'despesas', columns: [
    { name: 'valor', type: 'REAL' },
    { name: 'vencimento', type: 'TEXT', index: true },
    { name: 'pago', type: 'INTEGER' },
    { name: 'categoria', type: 'TEXT' },
    { name: 'fornecedor_id', type: 'TEXT' },
    { name: 'data_pagamento', type: 'TEXT', index: true }
  ] },
  { key: 'fornecedores', table: 'fornecedores', columns: [
    { name: 'nome', type: 'TEXT' }
  ] },
  // Configurações da loja (um único registro, id "main"): capacidade diária de produção etc.
  { key: 'config', table: 'configuracoes', columns: [
    { name: 'cap_pedidos', type: 'REAL' },
    { name: 'cap_unid', type: 'REAL' }
  ] },
  { key: 'mov', table: 'movimentacoes_estoque', columns: [
    { name: 'ingrediente_id', type: 'TEXT', index: true },
    { name: 'tipo', type: 'TEXT' },
    { name: 'qtd', type: 'REAL' },
    { name: 'criado_em', type: 'TEXT', index: true }
  ] }
];

// Cria a tabela se não existir e, se ela veio de uma versão anterior, acrescenta as colunas
// novas (ALTER TABLE) antes de criar os índices. Assim atualizar o sistema nunca exige apagar o banco.
function ensureDataTable(t) {
  const createSql = `
    CREATE TABLE IF NOT EXISTS ${t.table} (
      user_id INTEGER NOT NULL,
      id TEXT NOT NULL,
      ${t.columns.map((c) => `${c.name} ${c.type}`).join(',\n      ')},
      data TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (user_id, id)
    )`;
  const run = (sql) => new Promise((resolve, reject) => db.run(sql, (err) => (err ? reject(err) : resolve())));
  const all = (sql) => new Promise((resolve, reject) => db.all(sql, (err, rows) => (err ? reject(err) : resolve(rows))));

  run(createSql)
    .then(() => all(`PRAGMA table_info(${t.table})`))
    .then(async (info) => {
      const have = new Set(info.map((c) => c.name));
      for (const c of t.columns.filter((col) => !have.has(col.name))) {
        await run(`ALTER TABLE ${t.table} ADD COLUMN ${c.name} ${c.type}`);
      }
      for (const c of t.columns.filter((col) => col.index)) {
        await run(`CREATE INDEX IF NOT EXISTS idx_${t.table}_${c.name} ON ${t.table} (user_id, ${c.name})`);
      }
    })
    .catch((err) => console.error(`Erro ao preparar a tabela ${t.table}:`, err.message));
}

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Erro ao conectar ao SQLite:', err.message);
  } else {
    console.log('Conectado ao banco de dados SQLite (ksw_database.sqlite).');
  }
});

db.serialize(() => {
  // WAL permite leituras durante escritas; busy_timeout evita erros SQLITE_BUSY sob concorrência.
  db.run('PRAGMA journal_mode = WAL');
  db.run('PRAGMA busy_timeout = 5000');

  // Tabela de Confeiteiras (Usuários)
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      senha TEXT NOT NULL,
      whatsapp TEXT,
      role TEXT DEFAULT 'user',
      plano_tipo TEXT DEFAULT 'free', -- 'free', 'mensal', 'vitalicio'
      status_assinatura TEXT DEFAULT 'inativa', -- 'ativa', 'vencida', 'cancelada', 'inativa'
      data_vencimento DATETIME,
      subscription_id_gateway TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Tabela de Pedidos / Transações de Pagamento
  db.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      plano_tipo TEXT NOT NULL, -- 'mensal', 'vitalicio'
      valor REAL NOT NULL,
      status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'cancelled'
      gateway TEXT NOT NULL, -- 'mercadopago', 'stripe'
      external_reference TEXT UNIQUE,
      payment_id TEXT,
      qr_code TEXT,
      qr_code_base64 TEXT,
      ticket_url TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )
  `);

  // Tabela de Recuperação de Senha
  db.run(`
    CREATE TABLE IF NOT EXISTS password_resets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token TEXT NOT NULL,
      expira_em DATETIME NOT NULL,
      usado INTEGER DEFAULT 0,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS menus (
      id TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      published INTEGER NOT NULL DEFAULT 0,
      sections_json TEXT NOT NULL DEFAULT '[]',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS menu_hubs (
      user_id INTEGER PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id)
    )
  `);
  // ------------------------------------------------------------------
  // Dados de gestão de cada confeiteira (antes ficavam só no navegador).
  // Cada registro guarda o JSON completo em `data` (flexível para novos
  // campos) e as colunas-chave abaixo para consultas, filtros e relatórios.
  // A chave primária é composta (user_id, id): um usuário nunca enxerga
  // ou sobrescreve registros de outro.
  // ------------------------------------------------------------------
  for (const t of DATA_TABLES) ensureDataTable(t);
});

// Transações em conexão dedicada, executadas uma por vez (fila).
// O driver sqlite3 usa uma única conexão por instância; sem isso, duas requisições
// simultâneas poderiam misturar comandos dentro da mesma transação.
const txDb = new sqlite3.Database(dbPath);
txDb.run('PRAGMA busy_timeout = 5000');

const tx = {
  run: (sql, params = []) => new Promise((resolve, reject) =>
    txDb.run(sql, params, function (err) { err ? reject(err) : resolve({ changes: this.changes, lastID: this.lastID }); })),
  all: (sql, params = []) => new Promise((resolve, reject) =>
    txDb.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)))),
  get: (sql, params = []) => new Promise((resolve, reject) =>
    txDb.get(sql, params, (err, row) => (err ? reject(err) : resolve(row))))
};

let txQueue = Promise.resolve();
function withTransaction(fn) {
  const job = txQueue.then(async () => {
    await tx.run('BEGIN IMMEDIATE');
    try {
      const result = await fn(tx);
      await tx.run('COMMIT');
      return result;
    } catch (err) {
      try { await tx.run('ROLLBACK'); } catch (_) { /* já revertida */ }
      throw err;
    }
  });
  txQueue = job.catch(() => {});
  return job;
}

db.DATA_TABLES = DATA_TABLES;
db.withTransaction = withTransaction;
db.dbPath = dbPath;

module.exports = db;
