// Backup consistente do banco SQLite (seguro com o servidor rodando).
// Uso: npm run backup            -> grava em ./backups/ksw-AAAA-MM-DD_HHMMSS.sqlite
//      BACKUP_DIR=/caminho npm run backup
// Mantém os 14 backups mais recentes. Agende no cron/Task Scheduler (ex.: 1x por dia)
// e copie a pasta para outro lugar (nuvem, HD externo): backup no mesmo disco não protege contra perda do disco.
const fs = require('fs');
const path = require('path');
const db = require('../database');

const KEEP = 14;
const dir = path.resolve(process.env.BACKUP_DIR || path.join(__dirname, '..', 'backups'));
fs.mkdirSync(dir, { recursive: true });

const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '_').slice(0, 15);
const target = path.join(dir, `ksw-${stamp}.sqlite`);

db.run(`VACUUM INTO '${target.replace(/'/g, "''")}'`, (err) => {
  if (err) {
    console.error('Falha ao gerar backup:', err.message);
    process.exit(1);
  }
  const files = fs.readdirSync(dir).filter((f) => /^ksw-.*\.sqlite$/.test(f)).sort();
  files.slice(0, Math.max(0, files.length - KEEP)).forEach((f) => fs.rmSync(path.join(dir, f), { force: true }));
  console.log(`Backup criado: ${target} (${(fs.statSync(target).size / 1024).toFixed(0)} KB)`);
  db.close(() => process.exit(0));
});
