// Teste de integração: sobe o servidor com um banco temporário e exercita a API.
// Uso: npm test
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const PORT = 3900 + Math.floor(Math.random() * 90);
const BASE = `http://127.0.0.1:${PORT}`;
const dbFile = path.join(os.tmpdir(), `ksw-test-${Date.now()}.sqlite`);
const ADMIN_KEY = 'chave-admin-de-teste-123';

let passed = 0;
async function check(name, fn) {
  try { await fn(); passed++; console.log('  ok  ', name); }
  catch (e) { console.error('  FAIL', name, '\n      ', e.message); process.exitCode = 1; }
}
async function api(method, url, body, token, headers = {}) {
  const res = await fetch(BASE + url, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined
  });
  let json = {};
  try { json = await res.json(); } catch (_) {}
  return { status: res.status, json };
}
const put = (c, r) => ({ c, op: 'put', r });
const del = (c, id) => ({ c, op: 'del', id });

async function main() {
  // Simula um banco criado pela versão anterior (tabela despesas sem as colunas novas)
  // para garantir que a atualização migra sem apagar nada.
  let legacyDb = false;
  try {
    const { DatabaseSync } = require('node:sqlite');
    const h = new DatabaseSync(dbFile);
    h.exec(`CREATE TABLE despesas (user_id INTEGER NOT NULL, id TEXT NOT NULL, valor REAL, vencimento TEXT, pago INTEGER,
            data TEXT NOT NULL, updated_at DATETIME DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (user_id, id))`);
    h.prepare('INSERT INTO despesas (user_id, id, valor, vencimento, pago, data) VALUES (99, ?, 10, ?, 0, ?)').run('antiga', '2026-01-01', '{"id":"antiga","v":10}');
    h.close();
    legacyDb = true;
  } catch (_) { /* Node < 22.5: etapa ignorada */ }

  const server = spawn(process.execPath, ['server.js'], {
    cwd: path.join(__dirname, '..'),
    env: { ...process.env, PORT, DATABASE_PATH: dbFile, JWT_SECRET: 'x'.repeat(48), ADMIN_SECRET_KEY: ADMIN_KEY, NODE_ENV: 'test' },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  server.stderr.on('data', (d) => process.stderr.write(d));
  for (let i = 0; i < 50; i++) {
    try { await fetch(BASE + '/api/x'); break; } catch (_) { await new Promise((r) => setTimeout(r, 100)); }
  }

  try {
    const a = (await api('POST', '/api/auth/register', { nome: 'Ana', email: 'ana@teste.com', senha: 'senha-forte-1' })).json;
    const b = (await api('POST', '/api/auth/register', { nome: 'Bia', email: 'bia@teste.com', senha: 'senha-forte-2' })).json;

    await check('cadastro rejeita senha curta e e-mail inválido', async () => {
      assert.strictEqual((await api('POST', '/api/auth/register', { nome: 'X', email: 'x@y.com', senha: '123' })).status, 400);
      assert.strictEqual((await api('POST', '/api/auth/register', { nome: 'X', email: 'invalido', senha: '12345678' })).status, 400);
      assert.strictEqual((await api('POST', '/api/auth/register', { nome: {}, email: [], senha: 1 })).status, 400);
    });

    await check('dados exigem login', async () => {
      assert.strictEqual((await api('GET', '/api/data')).status, 401);
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [] })).status, 401);
    });

    await check('leitura funciona e vem vazia para conta nova', async () => {
      const r = await api('GET', '/api/data', null, a.token);
      assert.strictEqual(r.status, 200);
      assert.strictEqual(r.json.empty, true);
      assert.deepStrictEqual(Object.keys(r.json.data).sort(), ['clientes', 'config', 'despesas', 'fornecedores', 'ingredientes', 'mov', 'pedidos', 'produtos']);
    });

    await check('escrita é bloqueada sem assinatura ativa', async () => {
      const r = await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c1', nome: 'Maria' })] }, a.token);
      assert.strictEqual(r.status, 403);
    });

    // ativa as duas contas pelo painel admin
    for (const u of [1, 2]) {
      await api('POST', `/api/admin/users/${u}/update-subscription`, { plano_tipo: 'vitalicio', status_assinatura: 'ativa' }, null, { 'x-admin-key': ADMIN_KEY });
    }

    await check('admin: chave errada é negada', async () => {
      assert.strictEqual((await api('GET', '/api/admin/users', null, null, { 'x-admin-key': 'errada' })).status, 403);
      assert.strictEqual((await api('GET', '/api/admin/users', null, null, { 'x-admin-key': ADMIN_KEY })).status, 200);
    });

    await check('grava, lê e atualiza registros', async () => {
      const ops = [
        put('clientes', { id: 'c1', nome: 'Maria', tel: '11999990000', obs: 'sem lactose' }),
        put('ingredientes', { id: 'i1', nome: 'Leite condensado', un: 'lata', preco: 7.5, est: 10, min: 3, val: '2027-01-10' }),
        put('produtos', { id: 'p1', nome: 'Brigadeiro', rend: 50, margem: 50, itens: [{ ing: 'i1', qtd: 2 }], emb: 0.5, mo: 0, out: 0, preco: 2.5 }),
        put('pedidos', { id: 'o1', cli: 'c1', ent: '2026-12-01', st: 'recebido', pg: 10, itens: [{ pid: 'p1', nome: 'Brigadeiro', q: 20, pu: 2.5, cu: 1.8 }] })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      let r = (await api('GET', '/api/data', null, a.token)).json;
      assert.strictEqual(r.empty, false);
      assert.strictEqual(r.data.clientes[0].nome, 'Maria');
      assert.strictEqual(r.data.pedidos[0].itens[0].q, 20);
      assert.strictEqual(r.data.ingredientes[0].val, '2027-01-10');

      await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c1', nome: 'Maria Souza' })] }, a.token);
      r = (await api('GET', '/api/data', null, a.token)).json;
      assert.strictEqual(r.data.clientes.length, 1, 'upsert não deve duplicar');
      assert.strictEqual(r.data.clientes[0].nome, 'Maria Souza');
    });

    await check('colunas-chave são preenchidas para relatórios', async () => {
      let DatabaseSync;
      try { ({ DatabaseSync } = require('node:sqlite')); } catch (_) { return; } // Node < 22.5: verificação ignorada
      const h = new DatabaseSync(dbFile);
      const row = h.prepare('SELECT total, pago, status, data_entrega FROM pedidos WHERE id = ?').get('o1');
      assert.strictEqual(row.total, 50);
      assert.strictEqual(row.pago, 10);
      assert.strictEqual(row.status, 'recebido');
      assert.strictEqual(row.data_entrega, '2026-12-01');
      h.close();
    });

    await check('isolamento: outra usuária não vê nem altera os dados', async () => {
      const r = (await api('GET', '/api/data', null, b.token)).json;
      assert.strictEqual(r.empty, true);
      // Bia usa o mesmo id "c1": cria o PRÓPRIO registro, sem tocar no da Ana.
      await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c1', nome: 'Cliente da Bia' })] }, b.token);
      const ana = (await api('GET', '/api/data', null, a.token)).json;
      const bia = (await api('GET', '/api/data', null, b.token)).json;
      assert.strictEqual(ana.data.clientes[0].nome, 'Maria Souza');
      assert.strictEqual(bia.data.clientes[0].nome, 'Cliente da Bia');
      // Bia tenta apagar "o1" (que só existe na Ana): não pode afetar.
      await api('POST', '/api/data/sync', { ops: [del('pedidos', 'o1')] }, b.token);
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.pedidos.length, 1);
    });

    await check('exclusão remove o registro', async () => {
      await api('POST', '/api/data/sync', { ops: [del('pedidos', 'o1')] }, a.token);
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.pedidos.length, 0);
    });

    await check('transação é atômica: uma operação inválida não grava nada', async () => {
      const r = await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c9', nome: 'Nova' }), put('clientes', { id: 'id inválido!', nome: 'X' })] }, a.token);
      assert.strictEqual(r.status, 400);
      const list = (await api('GET', '/api/data', null, a.token)).json.data.clientes;
      assert.ok(!list.some((c) => c.id === 'c9'));
    });

    await check('validação rejeita coleção, operação e excesso', async () => {
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [put('users', { id: 'x' })] }, a.token)).status, 400);
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [{ c: 'clientes', op: 'drop' }] }, a.token)).status, 400);
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: 'x' }, a.token)).status, 400);
      const many = Array.from({ length: 1001 }, (_, i) => put('clientes', { id: 'm' + i, nome: 'n' }));
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: many }, a.token)).status, 400);
    });

    await check('injeção SQL em ids/valores é tratada como texto', async () => {
      const evil = "x'); DROP TABLE clientes;--";
      await api('POST', '/api/data/sync', { ops: [put('clientes', { id: 'c2', nome: evil })] }, a.token);
      const list = (await api('GET', '/api/data', null, a.token)).json.data.clientes;
      assert.ok(list.some((c) => c.nome === evil));
    });

    await check('lote grande (migração) de 800 registros grava em uma transação', async () => {
      const ops = Array.from({ length: 800 }, (_, i) => put('ingredientes', { id: 'g' + i, nome: 'Ing ' + i, preco: i, est: 1 }));
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.ingredientes.length, 801);
    });

    await check('escritas simultâneas não corrompem nem travam', async () => {
      const results = await Promise.all(Array.from({ length: 20 }, (_, i) =>
        api('POST', '/api/data/sync', { ops: [put('despesas', { id: 'd' + i, v: i, pago: i % 2 === 0, venc: '2026-12-01' })] }, a.token)));
      assert.ok(results.every((r) => r.status === 200));
      assert.strictEqual((await api('GET', '/api/data', null, a.token)).json.data.despesas.length, 20);
    });

    await check('exportação devolve os dados em JSON', async () => {
      const r = await api('GET', '/api/data/export', null, a.token);
      assert.strictEqual(r.status, 200);
      assert.ok(r.json.exportado_em && r.json.data.clientes.length >= 1);
    });

    await check('migração: banco antigo ganha as colunas novas e mantém os dados', async () => {
      if (!legacyDb) return;
      const { DatabaseSync } = require('node:sqlite');
      const h = new DatabaseSync(dbFile);
      const cols = h.prepare('PRAGMA table_info(despesas)').all().map((c) => c.name);
      for (const c of ['categoria', 'fornecedor_id', 'data_pagamento']) assert.ok(cols.includes(c), 'falta coluna ' + c);
      assert.strictEqual(h.prepare("SELECT valor FROM despesas WHERE id = 'antiga'").get().valor, 10);
      h.close();
    });

    await check('pedido: valor pago vem da soma dos pagamentos registrados', async () => {
      const o = { id: 'o2', cli: 'c1', ent: '2026-12-05', st: 'confirmado', itens: [{ pid: 'p1', nome: 'Bolo', q: 1, pu: 100, cu: 40 }],
                  pagamentos: [{ id: 'a', v: 30, data: '2026-11-01', forma: 'Pix' }, { id: 'b', v: 20.5, data: '2026-11-10', forma: 'Dinheiro' }] };
      assert.strictEqual((await api('POST', '/api/data/sync', { ops: [put('pedidos', o)] }, a.token)).status, 200);
      let pago;
      try {
        const { DatabaseSync } = require('node:sqlite');
        const h = new DatabaseSync(dbFile);
        pago = h.prepare("SELECT pago, total FROM pedidos WHERE id = 'o2' AND user_id = 1").get();
        h.close();
      } catch (_) { return; }
      assert.strictEqual(pago.pago, 50.5);
      assert.strictEqual(pago.total, 100);
    });

    await check('fornecedores, configurações e despesas com categoria são gravados', async () => {
      const ops = [
        put('fornecedores', { id: 'f1', nome: 'Atacadão Doces', tel: '11988887777' }),
        put('config', { id: 'main', cap_pedidos: 8, cap_unid: 120 }),
        put('despesas', { id: 'dx', desc: 'Energia', v: 230.9, venc: '2026-12-10', cat: 'Energia, água e gás', forn: 'f1', pago: true, dpg: '2026-12-09' })
      ];
      assert.strictEqual((await api('POST', '/api/data/sync', { ops }, a.token)).status, 200);
      const r = (await api('GET', '/api/data', null, a.token)).json.data;
      assert.strictEqual(r.fornecedores[0].nome, 'Atacadão Doces');
      assert.strictEqual(r.config[0].cap_pedidos, 8);
      assert.strictEqual(r.despesas.find((d) => d.id === 'dx').cat, 'Energia, água e gás');
    });

    await check('login: limite de tentativas por e-mail (429 após 10)', async () => {
      let last;
      for (let i = 0; i < 12; i++) last = await api('POST', '/api/auth/login', { email: 'ana@teste.com', senha: 'errada-errada' });
      assert.strictEqual(last.status, 429);
      // outro e-mail na mesma conexão não é afetado
      assert.strictEqual((await api('POST', '/api/auth/login', { email: 'bia@teste.com', senha: 'senha-forte-2' })).status, 200);
    });

    await check('rotas públicas existentes continuam respondendo', async () => {
      assert.strictEqual((await api('GET', '/api/app-status', null, a.token)).status, 200);
    });
  } finally {
    server.kill();
    for (const ext of ['', '-wal', '-shm']) fs.rmSync(dbFile + ext, { force: true });
    console.log(`\n${passed} verificações passaram${process.exitCode ? ' (HÁ FALHAS)' : ''}.`);
  }
}
main();
