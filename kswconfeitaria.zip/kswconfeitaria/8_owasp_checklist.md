# OWASP Checklist - Confeitaria SaaS Foundation

- [x] **A01: Broken Access Control** (Isolamento rígido Multi-tenant via RLS PostgreSQL).
- [x] **A02: Cryptographic Failures** (Bcrypt para senhas, JWT forte, comunicação HTTPS estrita).
- [x] **A03: Injection** (Tratamento via driver `pg` com prepared statements e queries parametrizadas).
- [x] **A04: Insecure Design** (Rate-limiting contra brute force na rota de login).
- [x] **A07: Identification and Auth Failures** (Refresh Token seguro via HttpOnly Cookie, Access Token no cliente expira rápido em 15m).
- [x] **A09: Security Logging** (Triggers de auditoria nativos no banco para trackear todas as mudanças sensíveis via tabela `audit_logs`).
