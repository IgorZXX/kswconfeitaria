require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const authRoutes = require('./routes/auth');
const paymentRoutes = require('./routes/payment');
const adminRoutes = require('./routes/admin');
const menuRoutes = require('./routes/menus');
const stripeRoutes = require('./routes/stripe');
const dataRoutes = require('./routes/data');
const config = require('./lib/config');
const { authMiddleware, checkActiveSubscription } = require('./middleware/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// Atrás de proxy/túnel (ngrok, Nginx, Render...), defina TRUST_PROXY=1 para que o IP
// real do visitante seja usado nos limitadores de tentativas.
app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
app.disable('x-powered-by');

app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()'
  });
  if (config.isProd) res.set('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  next();
});

// O front-end é servido pela mesma origem; em produção só ela é aceita via CORS.
app.use(cors(config.isProd ? { origin: config.BASE_URL } : undefined));

// A Stripe exige o corpo bruto para validar a assinatura do webhook.
app.post('/api/payment/stripe/webhook', express.raw({ type: 'application/json' }), stripeRoutes.webhookHandler);

// Dados de gestão: limite maior para a migração inicial dos dados guardados no navegador.
app.use('/api/data', express.json({ limit: '5mb' }), dataRoutes);

app.use(express.json({ limit: '200kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/payment/stripe', stripeRoutes.router);
app.use('/api/admin', adminRoutes);
app.use('/api/menus', menuRoutes);

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Rota protegida do aplicativo principal (apenas para assinantes ativos)
app.get('/api/app-status', authMiddleware, checkActiveSubscription, (req, res) => {
  res.json({
    access: 'granted',
    user: req.user,
    message: 'Acesso liberado a todas as funcionalidades do KSW Confeitaria.'
  });
});

app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Rota da API não encontrada.' });
});

app.use((err, req, res, next) => {
  if (!req.originalUrl.startsWith('/api/')) return next(err);

  const status = Number.isInteger(err.status) && err.status >= 400 && err.status < 600
    ? err.status
    : 500;
  if (status >= 500) console.error('Erro ao processar solicitação da API:', err);

  return res.status(status).json({
    error: err.type === 'entity.parse.failed'
      ? 'O corpo da solicitação contém JSON inválido.'
      : 'Não foi possível processar a solicitação da API.'
  });
});

// Fallback index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`================================================`);
  console.log(`🍰 Servidor KSW Confeitaria Rodando na Porta ${PORT}`);
  console.log(`👉 Acesse: http://localhost:${PORT}`);
  console.log(`================================================`);
});
