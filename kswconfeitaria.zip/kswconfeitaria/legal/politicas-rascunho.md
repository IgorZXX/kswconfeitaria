# Rascunhos de políticas — KSW Confeitaria

> **USO INTERNO — NÃO PUBLICAR NEM USAR COMO ACEITE.** Este material é um ponto de partida operacional, não parecer jurídico nem garantia de conformidade. Os campos pendentes e as divergências entre a oferta e o código precisam ser resolvidos antes de coletar dados de clientes ou vender o serviço. Solicite revisão de advogado com atuação em direito do consumidor e proteção de dados no Brasil.

## Situação da operação verificada no projeto

- O cadastro solicita nome, e-mail, senha e WhatsApp opcional. A senha é armazenada com hash bcrypt.
- O backend mantém contas, pedidos e tokens de redefinição no SQLite. O token de sessão e dados de gestão da confeitaria também são guardados no `localStorage` do navegador.
- Os dados locais de gestão podem conter clientes, WhatsApp, aniversários, preferências, pedidos, ingredientes e informações financeiras inseridas pela usuária.
- O frontend carrega fontes do Google Fonts. Não foi encontrado código de analytics ou pixel de publicidade no frontend examinado; isso deve ser revalidado no ambiente publicado e em futuras integrações.
- O checkout pode usar Mercado Pago quando configurado. Sem configuração válida, o código permite criar pedido simulado e simular aprovação sem cobrança real. Stripe consta nas dependências, mas não há fluxo de pagamento Stripe implementado nas rotas examinadas.
- Embora a oferta chame o plano mensal de recorrente, o fluxo atual não cria uma assinatura com renovação automática. Não anunciar nem cobrar recorrência até implementá-la e revisar os termos.
- Não foi localizado fluxo para a titular excluir a conta nem política implementada de retenção e eliminação de dados.

## 1. Termos de uso — texto-base

**Responsável pelo serviço:** `[NOME CIVIL OU EMPRESARIAL — PENDENTE]`, identificado como `[CPF OU CNPJ — CONFIRMAR E AUTORIZAR A DIVULGAÇÃO]`, com endereço para contato em `[ENDEREÇO COMPLETO — PENDENTE]`, São Paulo/SP. Marca: KSW Confeitaria.

**Contato:** `[E-MAIL DE SUPORTE E PRIVACIDADE — PENDENTE]`.

### Objeto e elegibilidade

A KSW Confeitaria oferece ferramentas digitais de gestão para confeitaria, conforme as funcionalidades efetivamente disponibilizadas em cada versão. O serviço é destinado a pessoas maiores de 18 anos residentes no Brasil. Esta regra deve ser aplicada e informada claramente no cadastro.

### Conta e segurança

A usuária deve fornecer informações corretas, proteger suas credenciais e avisar o canal de suporte se suspeitar de acesso indevido. A senha não deve ser compartilhada. A conta é pessoal, salvo autorização expressa para uso por equipe, cujas regras ainda precisam ser definidas.

### Funcionalidades, disponibilidade e dados

As funcionalidades podem evoluir, mas mudanças relevantes de preço, escopo ou condições devem ser comunicadas de forma adequada e respeitar os direitos da consumidora. Não prometer disponibilidade ininterrupta, backups, recuperação de dados ou integrações que ainda não estejam implementados e testados. Definir suporte, manutenção, exportação de dados e recuperação antes da publicação.

### Planos, preço e cobrança

Os preços atualmente exibidos no projeto são R$ 59,99 para o plano mensal e R$ 1.119,00 para o plano chamado vitalício. Confirmar os preços e o escopo antes de qualquer publicação. O código atual não realiza cobrança recorrente automática; o ambiente sem credencial válida pode simular aprovação sem movimentar dinheiro. Portanto, esta oferta e o checkout não devem ser usados para vendas reais até que cobrança, confirmação, recibos, renovação, cancelamento e suporte estejam implementados e testados.

O significado e os limites de “vitalício”, incluindo duração, funcionalidades abrangidas, manutenção e hipóteses de encerramento, precisam ser definidos antes de usar esse nome comercial.

### Cancelamento, arrependimento e reembolso

`[DEFINIR E REVISAR COM ADVOGADO: como solicitar cancelamento; efeito sobre futuras cobranças e acesso; procedimento e prazo de reembolso; tratamento de pagamentos pendentes, duplicados ou contestados.]`

Nenhuma disposição deste texto pretende limitar direitos obrigatórios previstos na legislação brasileira, inclusive no Código de Defesa do Consumidor. Não publicar uma regra de “sem reembolso” ou renúncia geral a direitos.

### Uso aceitável e propriedade intelectual

A usuária não deve usar o serviço para fins ilícitos, tentar comprometer sua segurança ou inserir dados de terceiros sem autorização e fundamento apropriado. Definir titularidade/licenças de marca, conteúdo, modelos e dados exportados; a redação final deve distinguir conteúdo da usuária e componentes do serviço.

### Alterações e encerramento

Definir como avisos serão enviados, tratamento de contas inativas, encerramento do serviço, exportação e eliminação dos dados. Mudanças contratuais não podem retirar direitos já adquiridos nem afastar normas obrigatórias.

## 2. Aviso de privacidade e proteção de dados — texto-base

### Quem decide sobre o tratamento

`[IDENTIFICAR CONTROLADOR: nome civil ou empresarial, CPF/CNPJ conforme orientação jurídica e endereço completo.]`

Canal para assuntos de privacidade e exercício de direitos: `[E-MAIL OU CANAL OPERACIONAL — PENDENTE]`. Encarregado, se aplicável: `[NOME OU CANAL DO ENCARREGADO — AVALIAR E PREENCHER]`.

### Dados observados no código

- Cadastro e conta: nome, e-mail, senha em formato de hash e WhatsApp opcional.
- Autenticação: token de sessão guardado no navegador.
- Recuperação de senha: token e prazo de expiração registrados no banco; no modo atual de demonstração, o token é devolvido pela API em vez de enviado por um canal seguro de e-mail.
- Pedidos e pagamentos: plano, valor, estado, referência e identificadores do gateway; dados de pagamento são tratados pelo gateway quando a integração real estiver ativa.
- Dados que a usuária inclui no gestor: nomes e contatos de clientes, aniversários, preferências e observações, ingredientes, estoque, receitas, pedidos e informações financeiras. Parte disso fica no `localStorage` do dispositivo/navegador.
- Dados técnicos de acesso e registros do servidor: `[INVENTARIAR COM A HOSPEDAGEM ANTES DA PUBLICAÇÃO]`.

Não inserir dados pessoais ou informações sensíveis de clientes finais sem necessidade, aviso apropriado e base legal. A confeiteira que cadastra dados de seus próprios clientes pode ter responsabilidades próprias como agente de tratamento; definir orientação e limites do produto com assessoria jurídica.

### Finalidades e bases legais

Finalidades possíveis, a confirmar operação por operação: criar e manter a conta; autenticar; fornecer as funções contratadas; registrar e atender pedidos de pagamento; responder suporte; proteger o serviço; cumprir obrigações legais.

`[MAPEAR PARA CADA FINALIDADE A BASE LEGAL APLICÁVEL NA LGPD, NECESSIDADE, PRAZO E DADOS ENVOLVIDOS. NÃO TRATAR “CONSENTIMENTO” COMO BASE UNIVERSAL.]`

### Compartilhamento e fornecedores

O projeto referencia fontes do Google Fonts e pode enviar dados de transação ao Mercado Pago quando configurado. Identificar a hospedagem, banco, e-mail, backups, suporte, gateway efetivamente usados, contratos, suboperadores e eventuais transferências internacionais antes de publicar. Stripe não deve ser apresentado como integração ativa sem implementação.

### Armazenamento, segurança e retenção

O projeto usa SQLite no servidor e `localStorage` no navegador. Isso não comprova criptografia de transporte, controle de acesso de hospedagem, backups, segregação de contas ou política de eliminação em produção. Confirmar arquitetura, HTTPS, permissões, cópias de segurança, gestão de incidentes e controles de acesso.

`[DEFINIR PRAZOS DE RETENÇÃO POR CATEGORIA, COMO A TITULAR PEDE ELIMINAÇÃO/EXPORTAÇÃO, EXCEÇÕES DE GUARDA LEGAL, BACKUPS E DESCARTE. IMPLEMENTAR O PROCESSO ANTES DE PROMETER EXCLUSÃO.]`

### Direitos da titular

A titular pode solicitar, nos termos da LGPD e conforme aplicável, confirmação e acesso, correção, informação sobre compartilhamento, anonimização, bloqueio ou eliminação de dados tratados irregularmente, portabilidade quando regulamentada, revisão de decisões automatizadas quando cabível e demais direitos legais. Disponibilizar canal funcional e processo de verificação de identidade, resposta, registro e tratamento de exceções.

### Crianças, adolescentes e incidentes

O produto declara-se destinado a maiores de 18 anos. Definir como essa condição será comunicada e tratada caso haja cadastro de menor. Documentar procedimento de resposta a incidentes e comunicação às pessoas afetadas e à ANPD quando exigido.

## 3. Aviso de cookies e armazenamento local — texto-base

No frontend examinado, a sessão é mantida por token no `localStorage` e os dados de gestão da confeitaria podem ser mantidos na chave `ksw-db` do `localStorage`. Isso é armazenamento no dispositivo, não equivale por si só a cookie. O projeto também solicita fontes ao Google Fonts, que é um recurso de terceiro. Não foi encontrado analytics/pixel no frontend examinado.

O frontend agora exibe um aviso informativo nas páginas principal e administrativa. A confirmação de leitura fica na chave `ksw_cookie_notice_acknowledged` do `localStorage`; ela não representa consentimento para cookies opcionais. O aviso informa que fontes do Google e o checkout da Hotmart podem usar tecnologias próprias. Confirmar essa descrição e o comportamento desses serviços no ambiente publicado.

Antes de publicar, testar todos os domínios e scripts do site, identificar cookies e tecnologias de terceiros, finalidades e duração; avaliar consentimento quando necessário; disponibilizar controles apropriados; explicar como limpar dados locais e o efeito de fazê-lo. Não declarar “não usamos cookies” sem verificar todo o ambiente e a hospedagem.

## 4. Condições comerciais e pagamentos — texto-base

Os preços, periodicidade, conteúdo do plano, tributos, meios de pagamento, confirmação, emissão de comprovante, renovação, cancelamento e reembolso precisam ser mostrados antes da contratação, em linguagem clara e coerente com o gateway.

**Estado atual:** demonstração. A opção de simulação pode ativar um plano sem pagamento. O fluxo mensal não implementa renovação automática, apesar do texto comercial existente no produto. Não operar cobrança real nem anunciar recorrência até remover/desabilitar a simulação em produção e completar a integração real.

`[PREENCHER APÓS IMPLEMENTAR E TESTAR: gateway efetivo; cobrança única ou recorrente; data e frequência; valor total; como cancelar; quando o acesso termina; processo de estorno/reembolso; canal de suporte.]`

## Pendências obrigatórias antes de publicar

- [ ] Informar nome civil/empresarial do controlador e definir com advogado qual identificador deve ser divulgado. CPF recebido durante a conversa **não foi copiado para este documento** nem está autorizado para publicação.
- [ ] Fornecer endereço completo de contato e e-mail/canal efetivo de suporte e privacidade.
- [ ] Decidir a política comercial de cancelamento/reembolso em conformidade com a legislação; implementar o procedimento real.
- [ ] Corrigir a divergência entre mensalidade automática anunciada e cobrança única/simulação no código.
- [ ] Desativar a simulação de aprovação em produção e testar o fluxo real antes de aceitar pagamentos.
- [ ] Mapear hospedagem, suboperadores, transferências, logs, backups, retenção e exclusão; implementar solicitações de titulares e fluxo de eliminação de conta.
- [ ] Revisar Google Fonts e todos os cookies, scripts e integrações do ambiente de produção.
- [ ] Definir duração/escopo do plano “vitalício”, suporte, exportação, manutenção, incidentes e canal de reclamação.
- [ ] Submeter os textos finais a advogado brasileiro; publicar versões datadas, manter histórico e obter aceite demonstrável antes de concluir contratação, sem condicionar direitos que não dependem de consentimento.
