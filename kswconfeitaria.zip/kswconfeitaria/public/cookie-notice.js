(function () {
  var storageKey = 'ksw_cookie_notice_acknowledged';
  var acknowledged = false;

  try {
    acknowledged = window.localStorage.getItem(storageKey) === '1';
  } catch (error) {
    console.warn('Não foi possível ler a preferência do aviso de cookies.', error);
  }

  var notice = document.createElement('aside');
  notice.id = 'cookie-notice';
  notice.setAttribute('aria-label', 'Aviso de cookies e armazenamento local');
  notice.innerHTML =
    '<section class="cookie-notice-panel" id="cookie-notice-panel" aria-labelledby="cookie-notice-title">' +
      '<h2 id="cookie-notice-title">Cookies e armazenamento local</h2>' +
      '<p>O KSW salva sua sessão neste navegador e mantém uma cópia local dos seus dados de gestão para funcionar mesmo sem internet. Os dados ficam guardados nos servidores do KSW, ligados à sua conta. Não configuramos cookies próprios para publicidade ou analytics.</p>' +
      '<details>' +
        '<summary>Saiba o que isso significa</summary>' +
        '<p>Apagar os dados do navegador pode encerrar sua sessão e descartar alterações que ainda não foram enviadas por falta de internet; o que já foi sincronizado continua na sua conta. Fontes do Google e o checkout da Hotmart podem usar tecnologias próprias, conforme as políticas desses serviços.</p>' +
      '</details>' +
      '<div class="cookie-notice-actions"><button type="button" class="cookie-notice-acknowledge">Entendi</button></div>' +
    '</section>' +
    '<button type="button" class="cookie-notice-toggle" aria-controls="cookie-notice-panel" aria-expanded="true">Aviso de cookies</button>';

  document.body.appendChild(notice);

  var panel = notice.querySelector('.cookie-notice-panel');
  var toggle = notice.querySelector('.cookie-notice-toggle');
  var acknowledge = notice.querySelector('.cookie-notice-acknowledge');

  function setOpen(open) {
    panel.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
  }

  setOpen(!acknowledged);

  toggle.addEventListener('click', function () {
    setOpen(panel.hidden);
  });

  acknowledge.addEventListener('click', function () {
    setOpen(false);
    try {
      window.localStorage.setItem(storageKey, '1');
    } catch (error) {
      console.warn('Não foi possível salvar a preferência do aviso de cookies.', error);
    }
  });
})();
