/* KSW Confeitaria · Fase 2A
 * Encomendas (sinal e saldo), Agenda com trava de capacidade, Financeiro e Painel.
 * Usa os helpers e o visual do app principal (R, esc, num, by, D, hoje, tp, costOf, db, O...).
 * Carregado antes do script principal; só define funções, então não depende da ordem de execução. */

var FORMAS = ['Pix', 'Dinheiro', 'Cartão de crédito', 'Cartão de débito', 'Transferência', 'Outro'];
var CATS = ['Ingredientes e insumos', 'Embalagens', 'Energia, água e gás', 'Aluguel', 'Salários e pró-labore',
  'Marketing', 'Impostos e taxas', 'Equipamentos', 'Transporte e entrega', 'Outros'];

var PF = { st: 'abertos', q: '', pay: null, v: '', forma: 'Pix', data: '' };   // filtro de pedidos e painel de pagamento
var AG = { m: null, d: null };                                                   // agenda: mês e dia selecionados
var FN = { seg: 'resumo', m: null, pf: 'abertas', rf: 'todos', draft: null, sup: null };   // financeiro

/* ------------------------------------------------------------------ utilidades */
function fmtISO(x) { return new Date(x - x.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); }
function addDias(d, n) { var x = new Date(d + 'T00:00:00'); x.setDate(x.getDate() + n); return fmtISO(x); }
function addMeses(d, n) {
  var y = +d.slice(0, 4), m = +d.slice(5, 7) - 1 + n, dd = +d.slice(8, 10);
  return fmtISO(new Date(y, m, Math.min(dd, new Date(y, m + 1, 0).getDate())));
}
function diasAte(d) { return Math.round((new Date(d + 'T00:00:00') - new Date(hoje() + 'T00:00:00')) / 864e5); }
function mesAtual() { return hoje().slice(0, 7); }
function nomeMes(m) {
  var s = new Date(+m.slice(0, 4), +m.slice(5, 7) - 1, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function nomeDia(d) {
  var s = new Date(d + 'T00:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function Q(s) { return String(s == null ? '' : s).replace(/'/g, '').replace(/"/g, ''); }   // ids dentro de onclick
function opts(list, sel) {
  return list.map(function (x) { return '<option' + (x === sel ? ' selected' : '') + '>' + esc(x) + '</option>'; }).join('');
}
function kvl(a, b) { return '<div class="kv"><span>' + a + '</span><b>' + b + '</b></div>'; }
function kpi(l, v, n) {
  return '<div class="card"><div class="mut">' + l + '</div><div class="big">' + v + '</div>' + (n ? '<div class="mut">' + n + '</div>' : '') + '</div>';
}

/* ------------------------------------------------------------------ regras de pedido */
function cfg() { return by(db.config || [], 'main') || { id: 'main', cap_pedidos: 0, cap_unid: 0 }; }
function pagList(p) {
  if (Array.isArray(p.pagamentos)) return p.pagamentos;
  return num(p.pg) > 0 ? [{ id: 'legado', v: num(p.pg), data: p.pd || p.ent || '', forma: 'Outro' }] : [];   // pedidos antigos
}
function pagoDe(p) { return pagList(p).reduce(function (a, x) { return a + num(x.v); }, 0); }
function saldoDe(p) { return Math.max(0, tp(p) - pagoDe(p)); }
function custoDe(p) { return p.itens.reduce(function (a, i) { return a + (i.cu || 0) * i.q; }, 0); }
function ativo(p) { return p.st !== 'cancelado'; }
function unidades(p) { return p.itens.reduce(function (a, i) { return a + num(i.q); }, 0); }
function cliNome(p) { var c = by(db.clientes, p.cli); return c ? c.nome : 'Cliente removido'; }
function resumoItens(p) { return p.itens.map(function (i) { return i.q + '× ' + esc(i.nome); }).join(', '); }

function capCheck(d, exId, addU) {
  var c = cfg(), n = 0, u = 0;
  db.pedidos.forEach(function (p) { if (p.ent === d && ativo(p) && p.id !== exId) { n++; u += unidades(p); } });
  var m = [];
  if (c.cap_pedidos > 0 && n + 1 > c.cap_pedidos) m.push('o limite de ' + c.cap_pedidos + ' pedido(s) por dia');
  if (c.cap_unid > 0 && u + addU > c.cap_unid) m.push('o limite de ' + c.cap_unid + ' unidades por dia');
  return { n: n, u: u, msgs: m, c: c };
}
function diaLotado(d) {
  var c = cfg(), n = 0, u = 0;
  db.pedidos.forEach(function (p) { if (p.ent === d && ativo(p)) { n++; u += unidades(p); } });
  return { n: n, u: u, over: (c.cap_pedidos > 0 && n > c.cap_pedidos) || (c.cap_unid > 0 && u > c.cap_unid) };
}

/* ------------------------------------------------------------------ WhatsApp */
function waLink(tel, txt) {
  var n = String(tel || '').replace(/\D/g, '');
  if (n && n.length <= 11) n = '55' + n;
  return 'https://wa.me/' + n + (txt ? '?text=' + encodeURIComponent(txt) : '');
}
function msg(i, kind) {
  var p = by(db.pedidos, i); if (!p) return;
  var c = by(db.clientes, p.cli);
  if (!c || !String(c.tel || '').replace(/\D/g, '')) return toast('Cadastre o WhatsApp desta cliente para enviar mensagens.');
  var nome = c.nome.split(' ')[0], quando = D(p.ent) + (p.hora ? ' às ' + p.hora : ''), t = tp(p), pg = pagoDe(p), sd = Math.max(0, t - pg);
  var txt = {
    lem: 'Olá, ' + nome + '! Passando para lembrar da sua encomenda de ' + quando + ': ' + p.itens.map(function (x) { return x.q + '× ' + x.nome; }).join(', ') + '. Qualquer dúvida é só me chamar!',
    cob: 'Olá, ' + nome + '! Sua encomenda de ' + quando + ' está com saldo em aberto de ' + R(sd) + ' (total ' + R(t) + ', já pago ' + R(pg) + '). Posso te passar os dados para o pagamento?',
    conf: 'Olá, ' + nome + '! Confirmando sua encomenda para ' + quando + ': ' + p.itens.map(function (x) { return x.q + '× ' + x.nome; }).join(', ') + '. Total ' + R(t) + (pg ? ', sinal de ' + R(pg) + ' recebido' : '') + (sd ? ', saldo de ' + R(sd) + ' na entrega' : '') + '.'
  }[kind] || '';
  window.open(waLink(c.tel, txt), '_blank', 'noopener');
}

/* ------------------------------------------------------------------ PEDIDOS */
function newO(dia) {
  O = { isNew: true, cli: '', ent: dia || '', hora: '', obs: '', itens: [], sinal: 0, forma: 'Pix', st: 'recebido' };
  tab = 'pedidos'; render();
}
function editO(i) {
  var p = by(db.pedidos, i); if (!p) return;
  O = { id: p.id, isNew: false, cli: p.cli, ent: p.ent || '', hora: p.hora || '', obs: p.obs || '', st: p.st, sinal: 0, forma: 'Pix',
    itens: p.itens.map(function (x) { return { prod: x.pid, q: x.q, pu: x.pu, cu: x.cu, nome: x.nome }; }) };
  tab = 'pedidos'; render();
}
function precoItem(i) { if (i.pu != null) return i.pu; var p = by(db.produtos, i.prod); return p ? p.preco : 0; }
function totalDraft() { return O.itens.reduce(function (a, i) { return a + precoItem(i) * num(i.q); }, 0); }

function pedForm() {
  var h = '<div class="card"><b>' + (O.isNew ? 'Novo pedido' : 'Editar pedido') + '</b>';
  if (!db.clientes.length) h += '<div class="mut" style="margin-top:8px">Cadastre ao menos uma cliente para registrar pedidos. <button class="btn ghost sm" onclick="O=null;go(\'clientes\')">Cadastrar cliente</button></div>';
  h += '<label>Cliente</label><select onchange="O.cli=this.value"><option value="">Selecione…</option>' +
    db.clientes.map(function (c) { return '<option value="' + c.id + '"' + (c.id === O.cli ? ' selected' : '') + '>' + esc(c.nome) + '</option>'; }).join('') + '</select>';
  h += '<div class="cols"><div><label>Data de entrega</label><input type="date" value="' + esc(O.ent) + '" onchange="O.ent=this.value;tot()"></div>' +
    '<div><label>Horário</label><input type="time" value="' + esc(O.hora) + '" onchange="O.hora=this.value"></div></div>';
  h += '<label>Itens</label>' + O.itens.map(function (i, k) {
    var lista = db.produtos.slice();
    var orfao = i.prod && !by(db.produtos, i.prod) ? '<option value="' + esc(i.prod) + '" selected>' + esc(i.nome) + ' (' + R(i.pu) + ', removido)</option>' : '';
    return '<div class="row" style="margin-bottom:6px;flex-wrap:nowrap"><select style="flex:2;min-width:0" onchange="O.itens[' + k + '].prod=this.value;delete O.itens[' + k + '].pu;delete O.itens[' + k + '].cu;delete O.itens[' + k + '].nome;tot()">' + orfao +
      lista.map(function (x) { return '<option value="' + x.id + '"' + (x.id === i.prod ? ' selected' : '') + '>' + esc(x.nome) + ' (' + R(x.preco) + ')</option>'; }).join('') +
      '</select><input style="flex:1;min-width:64px" inputmode="numeric" value="' + esc(i.q) + '" oninput="O.itens[' + k + '].q=num(this.value);tot()" aria-label="Quantidade"><button class="btn ghost sm" type="button" onclick="O.itens.splice(' + k + ',1);render()" aria-label="Remover item">×</button></div>';
  }).join('');
  h += db.produtos.length
    ? '<button class="btn ghost sm" type="button" onclick="O.itens.push({prod:db.produtos[0].id,q:1});render()">+ Item</button>'
    : '<div class="mut">Crie um produto em Preços e receitas primeiro.</div>';
  h += '<label>Observações (tema, dedicatória, restrições, endereço de entrega…)</label><textarea rows="2" oninput="O.obs=this.value">' + esc(O.obs) + '</textarea>';
  if (O.isNew) {
    h += '<div class="cols"><div><label>Sinal recebido (R$)</label><input inputmode="decimal" value="' + (O.sinal || '') + '" placeholder="0,00" oninput="O.sinal=num(this.value);tot()"></div>' +
      '<div><label>Forma do sinal</label><select onchange="O.forma=this.value">' + opts(FORMAS, O.forma) + '</select></div></div>' +
      '<div class="mut" style="margin-top:6px">Com sinal, o pedido entra como confirmado.</div>';
  } else {
    h += '<label>Status</label><select onchange="O.st=this.value">' + opts(ST, O.st) + '</select>' +
      '<div class="mut" style="margin-top:6px">Os pagamentos deste pedido são registrados no cartão dele, em “Receber”.</div>';
  }
  h += '<div class="res" id="tot"></div><p><button class="btn" onclick="saveO()">' + (O.isNew ? 'Registrar pedido' : 'Salvar alterações') + '</button> <button class="btn ghost" onclick="O=null;render()">Cancelar</button></p></div>';
  return h;
}

function tot() {
  var e = document.getElementById('tot'); if (!e || !O) return;
  var t = totalDraft(), h = '<div style="margin-top:10px"><b>Total: ' + R(t) + '</b>';
  if (O.isNew) h += ' · Sinal: ' + R(O.sinal || 0) + ' · <b>Saldo: ' + R(Math.max(0, t - (O.sinal || 0))) + '</b>';
  else { var p = by(db.pedidos, O.id); if (p) h += ' · Já pago: ' + R(pagoDe(p)) + ' · <b>Saldo: ' + R(Math.max(0, t - pagoDe(p))) + '</b>'; }
  h += '</div>';
  if (O.ent) {
    var un = O.itens.reduce(function (a, i) { return a + num(i.q); }, 0), c = capCheck(O.ent, O.id, un);
    h += '<div class="mut" style="margin-top:6px">Neste dia: ' + c.n + ' pedido(s) e ' + c.u + ' unidade(s) já agendados.</div>';
    if (c.msgs.length) h += '<div style="margin-top:6px"><span class="tag late">Este pedido ultrapassa ' + c.msgs.join(' e ') + '</span></div>';
  }
  e.innerHTML = h;
}

function saveO() {
  if (!O.cli) return toast('Escolha a cliente.');
  if (!O.ent) return toast('Informe a data de entrega.');
  if (!O.itens.length) return toast('Adicione ao menos um item.');
  if (O.itens.some(function (i) { return !(num(i.q) > 0); })) return toast('Informe a quantidade de cada item.');
  var un = O.itens.reduce(function (a, i) { return a + num(i.q); }, 0), c = capCheck(O.ent, O.id, un);
  if (c.msgs.length && !confirm('Atenção: este pedido ultrapassa ' + c.msgs.join(' e ') + ' (' + D(O.ent) + ').\n\nAceitar mesmo assim?')) return;
  var itens = O.itens.map(function (i) {
    if (i.pu != null) return { pid: i.prod, nome: i.nome, q: num(i.q), pu: i.pu, cu: i.cu };
    var p = by(db.produtos, i.prod);
    return { pid: p.id, nome: p.nome, q: num(i.q), pu: p.preco, cu: +costOf(p).toFixed(2) };
  });
  if (O.isNew) {
    var ped = { id: id(), cli: O.cli, ent: O.ent, hora: O.hora, obs: O.obs.trim(), itens: itens, st: O.sinal > 0 ? 'confirmado' : 'recebido', pagamentos: [], pg: 0, pd: '' };
    if (O.sinal > 0) { ped.pagamentos.push({ id: id(), v: O.sinal, data: hoje(), forma: O.forma }); ped.pg = O.sinal; ped.pd = hoje(); }
    db.pedidos.push(ped);
  } else {
    var orig = by(db.pedidos, O.id), i = db.pedidos.indexOf(orig);
    db.pedidos[i] = Object.assign({}, orig, { cli: O.cli, ent: O.ent, hora: O.hora, obs: O.obs.trim(), itens: itens, st: O.st });
  }
  O = null; saveLocalDB(); render(); toast('Pedido salvo.');
}

function upO(i, v) {
  var p = by(db.pedidos, i); if (!p) return;
  if (v === 'entregue' && saldoDe(p) > 0.004 && !confirm('Ainda há ' + R(saldoDe(p)) + ' em aberto neste pedido.\n\nMarcar como entregue mesmo assim?')) return render();
  if (v === 'cancelado' && !confirm('Cancelar este pedido? Ele deixa de contar no faturamento e na agenda. Pagamentos já recebidos continuam no caixa; remova-os no pedido se precisar estornar.')) return render();
  p.st = v; saveLocalDB(); render();
}
function delO(i) {
  if (!confirm('Excluir este pedido definitivamente? Os pagamentos registrados nele também serão apagados do caixa.')) return;
  db.pedidos = db.pedidos.filter(function (x) { return x.id !== i; }); saveLocalDB(); render();
}

/* pagamentos de um pedido */
function openPay(i) {
  var p = by(db.pedidos, i); if (!p) return;
  if (PF.pay === i) { PF.pay = null; return render(); }
  PF.pay = i; PF.v = saldoDe(p) ? String(+saldoDe(p).toFixed(2)).replace('.', ',') : ''; PF.forma = 'Pix'; PF.data = hoje(); render();
}
function addPay(i) {
  var p = by(db.pedidos, i), v = num(PF.v); if (!p) return;
  if (!(v > 0)) return toast('Informe o valor recebido.');
  if (!PF.data) return toast('Informe a data do pagamento.');
  if (v > saldoDe(p) + 0.004 && !confirm('O valor (' + R(v) + ') é maior que o saldo (' + R(saldoDe(p)) + '). Registrar mesmo assim?')) return;
  var lista = pagList(p).map(function (x) { return x.id === 'legado' ? Object.assign({}, x, { id: id() }) : x; });
  lista.push({ id: id(), v: v, data: PF.data, forma: PF.forma });
  p.pagamentos = lista; p.pg = +lista.reduce(function (a, x) { return a + num(x.v); }, 0).toFixed(2); p.pd = PF.data;
  PF.pay = null; saveLocalDB(); render(); toast('Pagamento registrado.');
}
function delPay(i, pid) {
  var p = by(db.pedidos, i); if (!p || !confirm('Remover este pagamento?')) return;
  p.pagamentos = pagList(p).filter(function (x) { return x.id !== pid; });
  p.pg = +p.pagamentos.reduce(function (a, x) { return a + num(x.v); }, 0).toFixed(2);
  p.pd = p.pagamentos.length ? p.pagamentos[p.pagamentos.length - 1].data : '';
  saveLocalDB(); render();
}
function payPanel(p) {
  if (PF.pay !== p.id) return '';
  var h = '<div class="card" style="background:var(--soft);margin:10px 0 0"><b>Registrar pagamento</b> <span class="mut">saldo atual ' + R(saldoDe(p)) + '</span>' +
    '<div class="cols"><div><label>Valor recebido (R$)</label><input inputmode="decimal" value="' + esc(PF.v) + '" oninput="PF.v=this.value"></div>' +
    '<div><label>Forma</label><select onchange="PF.forma=this.value">' + opts(FORMAS, PF.forma) + '</select></div></div>' +
    '<label>Data</label><input type="date" value="' + esc(PF.data) + '" onchange="PF.data=this.value">' +
    '<p><button class="btn sm" onclick="addPay(\'' + Q(p.id) + '\')">Registrar</button> <button class="btn ghost sm" onclick="PF.pay=null;render()">Fechar</button></p>';
  var l = pagList(p);
  if (l.length) h += '<div style="margin-top:6px"><b>Pagamentos já registrados</b>' + l.map(function (g) {
    return '<div class="kv"><span>' + D(g.data) + ' · ' + esc(g.forma || '') + '</span><span><b>' + R(g.v) + '</b> ' +
      (g.id === 'legado' ? '' : '<button class="btn ghost sm" onclick="delPay(\'' + Q(p.id) + '\',\'' + Q(g.id) + '\')" aria-label="Remover pagamento">×</button>') + '</span></div>';
  }).join('') + '</div>';
  return h + '</div>';
}

function pedCard(p) {
  var t = tp(p), pg = pagoDe(p), sd = Math.max(0, t - pg), aberto = p.st !== 'entregue' && p.st !== 'cancelado';
  var late = aberto && p.ent && diasAte(p.ent) < 0;
  var h = '<div class="card"><div class="row"><div><b>' + esc(cliNome(p)) + '</b> ' + (aberto ? urg(p.ent) : '') +
    '<div class="mut">Entrega ' + D(p.ent) + (p.hora ? ' às ' + esc(p.hora) : '') + '</div></div>' +
    '<select style="width:auto;min-width:140px" aria-label="Status do pedido" onchange="upO(\'' + Q(p.id) + '\',this.value)">' + opts(ST, p.st) + '</select></div>' +
    '<div class="mut" style="margin-top:6px">' + resumoItens(p) + '</div>' + (p.obs ? '<div class="mut">Obs.: ' + esc(p.obs) + '</div>' : '') +
    '<div class="row" style="margin-top:10px"><span>Total <b>' + R(t) + '</b></span><span>Pago <b>' + R(pg) + '</b></span><span>Saldo <b' + (sd > 0.004 ? ' style="color:var(--warn)"' : '') + '>' + R(sd) + '</b>' +
    (ativo(p) && sd <= 0.004 && t > 0 ? ' <span class="tag ok">Quitado</span>' : '') + (sd > 0.004 && p.st === 'entregue' ? ' <span class="tag late">Entregue com saldo</span>' : '') + (late ? ' <span class="tag late">Entrega atrasada</span>' : '') + '</span></div>' +
    '<div class="row" style="margin-top:10px;justify-content:flex-start">' +
    (ativo(p) ? '<button class="btn sm" onclick="openPay(\'' + Q(p.id) + '\')">' + (sd > 0.004 ? 'Receber' : 'Pagamentos') + '</button>' : '') +
    (sd > 0.004 && ativo(p) ? '<button class="btn ghost sm" onclick="msg(\'' + Q(p.id) + '\',\'cob\')">Cobrar saldo</button>' : '') +
    (aberto ? '<button class="btn ghost sm" onclick="msg(\'' + Q(p.id) + '\',\'lem\')">Lembrete</button>' : '') +
    '<button class="btn ghost sm" onclick="editO(\'' + Q(p.id) + '\')">Editar</button>' +
    '<button class="btn ghost sm" onclick="delO(\'' + Q(p.id) + '\')">Excluir</button></div>' + payPanel(p) + '</div>';
  return h;
}

function pedFiltrados() {
  var q = PF.q.trim().toLowerCase();
  var l = db.pedidos.filter(function (p) {
    if (q && cliNome(p).toLowerCase().indexOf(q) < 0) return false;
    if (PF.st === 'abertos') return p.st !== 'entregue' && p.st !== 'cancelado';
    if (PF.st === 'saldo') return ativo(p) && saldoDe(p) > 0.004;
    if (PF.st === 'todos') return true;
    return p.st === PF.st;
  });
  var asc = PF.st === 'abertos' || PF.st === 'saldo';
  return l.sort(function (a, b) { var r = (a.ent || '9').localeCompare(b.ent || '9') || (a.hora || '').localeCompare(b.hora || ''); return asc ? r : -r; });
}
function pedLista() {
  var l = pedFiltrados();
  return l.length ? l.map(pedCard).join('') : '<div class="card mut">' + (db.pedidos.length ? 'Nenhum pedido neste filtro.' : 'Nenhum pedido ainda. Clique em “Novo pedido” para registrar a primeira encomenda.') + '</div>';
}
function pedFiltro() {   // atualiza só a lista (não perde o foco da busca)
  var e = document.getElementById('ped-list'); if (e) e.innerHTML = pedLista();
}
function vPed() {
  var h = '<h2>Pedidos</h2>';
  if (O) return h + pedForm();
  var f = [['abertos', 'Em aberto'], ['saldo', 'Com saldo a receber'], ['todos', 'Todos']].concat(ST.map(function (s) { return [s, s.charAt(0).toUpperCase() + s.slice(1)]; }));
  return h + '<div class="card"><div class="row" style="align-items:flex-end"><button class="btn" onclick="newO()">Novo pedido</button>' +
    '<div class="row" style="flex:1;justify-content:flex-end"><div style="flex:1;min-width:150px;max-width:220px"><label style="margin-top:0">Mostrar</label><select onchange="PF.st=this.value;pedFiltro()">' +
    f.map(function (x) { return '<option value="' + x[0] + '"' + (PF.st === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div>' +
    '<div style="flex:1;min-width:150px;max-width:220px"><label style="margin-top:0">Buscar cliente</label><input value="' + esc(PF.q) + '" oninput="PF.q=this.value;pedFiltro()" placeholder="Nome…"></div></div></div></div>' +
    '<div id="ped-list">' + pedLista() + '</div>';
}

/* ------------------------------------------------------------------ AGENDA */
function agMes(delta) { AG.m = addMeses((AG.m || mesAtual()) + '-01', delta).slice(0, 7); AG.d = null; render(); }
function agDia(d) { AG.d = d; render(); }
function agHoje() { AG.m = mesAtual(); AG.d = hoje(); render(); }
function saveCap(campo, v) {
  var c = by(db.config, 'main');
  if (!c) { c = { id: 'main', cap_pedidos: 0, cap_unid: 0 }; db.config.push(c); }
  c[campo] = Math.max(0, Math.floor(num(v)));
  saveLocalDB(); render(); toast('Capacidade atualizada.');
}
function vAgenda() {
  var m = AG.m || mesAtual(); AG.m = m;
  var sel = AG.d && AG.d.slice(0, 7) === m ? AG.d : (mesAtual() === m ? hoje() : m + '-01');
  var y = +m.slice(0, 4), mo = +m.slice(5, 7) - 1, off = new Date(y, mo, 1).getDay(), nd = new Date(y, mo + 1, 0).getDate();
  var porDia = {}, venc = {};
  db.pedidos.forEach(function (p) { if (ativo(p) && p.ent && p.ent.slice(0, 7) === m) (porDia[p.ent] = porDia[p.ent] || []).push(p); });
  db.despesas.forEach(function (x) { if (!x.pago && x.venc && x.venc.slice(0, 7) === m) venc[x.venc] = (venc[x.venc] || 0) + 1; });

  var h = '<h2>Agenda</h2><div class="card"><div class="row" style="margin-bottom:12px"><b style="font-size:17px">' + nomeMes(m) + '</b>' +
    '<span><button class="btn ghost sm" onclick="agMes(-1)" aria-label="Mês anterior">‹</button> <button class="btn ghost sm" onclick="agHoje()">Hoje</button> <button class="btn ghost sm" onclick="agMes(1)" aria-label="Próximo mês">›</button></span></div>' +
    '<div class="cal-h">' + ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map(function (x) { return '<span>' + x + '</span>'; }).join('') + '</div><div class="cal">';
  for (var i = 0; i < off; i++) h += '<span class="cal-d out"></span>';
  for (var d = 1; d <= nd; d++) {
    var iso = m + '-' + (d < 10 ? '0' : '') + d, ps = porDia[iso] || [], lot = diaLotado(iso), un = ps.reduce(function (a, p) { return a + unidades(p); }, 0);
    h += '<button type="button" class="cal-d' + (iso === hoje() ? ' today' : '') + (iso === sel ? ' sel' : '') + '" onclick="agDia(\'' + iso + '\')" aria-label="' + nomeDia(iso) + ': ' + ps.length + ' pedido(s)"' + (iso === sel ? ' aria-current="date"' : '') + '>' +
      '<span class="cal-n">' + d + '</span>' + (ps.length ? '<span class="tag' + (lot.over ? ' late' : '') + '">' + ps.length + '</span><span class="cal-u">' + un + ' un.</span>' : '') +
      (venc[iso] ? '<i class="cal-dot" title="Conta a pagar vence neste dia"></i>' : '') + '</button>';
  }
  h += '</div><div class="mut" style="margin-top:10px">O número em cada dia é a quantidade de pedidos; vermelho indica que a capacidade foi ultrapassada. O ponto marca conta a pagar vencendo.</div></div>';

  // dia selecionado
  var ps = (porDia[sel] || []).slice().sort(function (a, b) { return (a.hora || '99').localeCompare(b.hora || '99'); }), lot = diaLotado(sel), c = cfg();
  h += '<div class="card"><div class="row"><div><b>' + nomeDia(sel) + '</b><div class="mut">' + lot.n + ' pedido(s) · ' + lot.u + ' unidade(s)' +
    (c.cap_pedidos > 0 ? ' · limite ' + c.cap_pedidos + ' pedido(s)' : '') + (c.cap_unid > 0 ? ' · limite ' + c.cap_unid + ' un.' : '') + '</div></div>' +
    '<button class="btn sm" onclick="newO(\'' + sel + '\')">Novo pedido neste dia</button></div>' + (lot.over ? '<div style="margin-top:8px"><span class="tag late">Capacidade do dia ultrapassada</span></div>' : '');
  h += ps.length ? ps.map(function (p) {
    var sd = saldoDe(p);
    return '<div class="kv" style="align-items:flex-start"><span><b>' + (p.hora ? esc(p.hora) + ' · ' : '') + esc(cliNome(p)) + '</b><br><span class="mut">' + resumoItens(p) + (p.obs ? ' · ' + esc(p.obs) : '') + '</span></span>' +
      '<span style="text-align:right"><span class="tag">' + p.st + '</span><br>' + (sd > 0.004 ? '<span class="mut">saldo ' + R(sd) + '</span><br>' : '') +
      '<button class="btn ghost sm" style="margin-top:6px" onclick="editO(\'' + Q(p.id) + '\')">Abrir</button></span></div>';
  }).join('') : '<div class="mut" style="margin-top:10px">Nenhum pedido para este dia.</div>';
  var cp = db.despesas.filter(function (x) { return !x.pago && x.venc === sel; });
  if (cp.length) h += '<div style="margin-top:10px"><b>Contas a pagar neste dia</b>' + cp.map(function (x) { return kvl(esc(x.desc || 'Despesa'), R(x.v)); }).join('') + '</div>';
  h += '</div>';

  h += '<div class="card"><b>Capacidade diária de produção</b><div class="mut">A trava avisa quando um novo pedido ultrapassa o que você consegue produzir em um dia. Use 0 para não limitar.</div>' +
    '<div class="cols"><div><label>Máximo de pedidos por dia</label><input inputmode="numeric" value="' + (c.cap_pedidos || 0) + '" onchange="saveCap(\'cap_pedidos\',this.value)"></div>' +
    '<div><label>Máximo de unidades por dia</label><input inputmode="numeric" value="' + (c.cap_unid || 0) + '" onchange="saveCap(\'cap_unid\',this.value)"></div></div></div>';
  return h;
}

/* ------------------------------------------------------------------ FINANCEIRO */
function movimentos() {
  var l = [];
  db.pedidos.forEach(function (p) { pagList(p).forEach(function (g) { if (g.data) l.push({ d: g.data, v: num(g.v), txt: 'Pagamento · ' + cliNome(p), sub: g.forma || '' }); }); });
  db.despesas.forEach(function (x) { if (x.pago) { var d = x.dpg || x.venc; if (d) l.push({ d: d, v: -num(x.v), txt: x.desc || 'Despesa', sub: x.cat || '' }); } });
  return l.sort(function (a, b) { return a.d.localeCompare(b.d); });
}
function finMes() { FN.m = FN.m || mesAtual(); return FN.m; }
function finSeg(s) { FN.seg = s; FN.draft = null; FN.sup = null; PF.pay = null; render(); }
function irFin(s) { FN.seg = s; FN.draft = null; FN.sup = null; PF.pay = null; go('financeiro'); }
function vFin() {
  var segs = [['resumo', 'Resumo'], ['receber', 'A receber'], ['pagar', 'A pagar'], ['caixa', 'Fluxo de caixa'], ['forn', 'Fornecedores']];
  var h = '<h2>Financeiro</h2><div class="seg">' + segs.map(function (s) {
    return '<button type="button" class="btn sm' + (FN.seg === s[0] ? '' : ' ghost') + '" onclick="finSeg(\'' + s[0] + '\')"' + (FN.seg === s[0] ? ' aria-current="page"' : '') + '>' + s[1] + '</button>';
  }).join('') + '</div>';
  return h + ({ resumo: finResumo, receber: finReceber, pagar: finPagar, caixa: finCaixa, forn: finForn }[FN.seg] || finResumo)();
}
function seletorMes() {
  return '<div class="row" style="margin-bottom:12px;justify-content:flex-start"><label style="margin:0">Mês</label><input type="month" style="width:auto" value="' + finMes() + '" onchange="FN.m=this.value||null;render()"></div>';
}
function aReceberLista() { return db.pedidos.filter(function (p) { return ativo(p) && saldoDe(p) > 0.004; }).sort(function (a, b) { return (a.ent || '9').localeCompare(b.ent || '9'); }); }
function vencidas() { return db.despesas.filter(function (x) { return !x.pago && x.venc && x.venc < hoje(); }); }
function soma(l, f) { return l.reduce(function (a, x) { return a + f(x); }, 0); }

function finResumo() {
  var m = finMes(), mv = movimentos(), ent = 0, sai = 0;
  mv.forEach(function (x) { if (x.d.slice(0, 7) === m) { if (x.v > 0) ent += x.v; else sai -= x.v; } });
  var fat = 0, cus = 0;
  db.pedidos.forEach(function (p) { if (ativo(p) && (p.ent || '').slice(0, 7) === m) { fat += tp(p); cus += custoDe(p); } });
  var dm = db.despesas.filter(function (x) { return (x.venc || '').slice(0, 7) === m; }), desp = soma(dm, function (x) { return num(x.v); });
  var porCat = {}; dm.forEach(function (x) { var c = x.cat || 'Outros'; porCat[c] = (porCat[c] || 0) + num(x.v); });
  var ar = aReceberLista(), ap = db.despesas.filter(function (x) { return !x.pago; }), vc = vencidas();
  var semQuitar = db.pedidos.filter(function (p) { return p.st === 'entregue' && saldoDe(p) > 0.004; });
  var h = seletorMes() + '<div class="grid">' + kpi('Entradas no mês', '<span class="pos">' + R(ent) + '</span>') + kpi('Saídas no mês', '<span class="neg">' + R(sai) + '</span>') + kpi('Saldo de caixa', R(ent - sai), 'entradas − saídas pagas') + '</div>';
  h += '<div class="grid">' + kpi('A receber', R(soma(ar, saldoDe)), ar.length + ' pedido(s) com saldo') + kpi('A pagar', R(soma(ap, function (x) { return num(x.v); })), ap.length + ' conta(s) em aberto') + '</div>';
  if (vc.length || semQuitar.length) {
    h += '<div class="card"><b>Atenção</b>' + (vc.length ? '<div class="kv"><span><span class="tag late">' + vc.length + ' conta(s) vencida(s)</span> ' + R(soma(vc, function (x) { return num(x.v); })) + '</span><button class="btn ghost sm" onclick="FN.pf=\'abertas\';finSeg(\'pagar\')">Ver</button></div>' : '') +
      (semQuitar.length ? '<div class="kv"><span><span class="tag late">' + semQuitar.length + ' pedido(s) entregue(s) com saldo</span> ' + R(soma(semQuitar, saldoDe)) + '</span><button class="btn ghost sm" onclick="finSeg(\'receber\')">Ver</button></div>' : '') + '</div>';
  }
  h += '<div class="cols"><div class="card"><b>Resultado do mês</b><div class="mut">Pedidos com entrega em ' + nomeMes(m).toLowerCase() + '</div>' +
    kvl('Faturamento', R(fat)) + kvl('Custo dos produtos', R(cus)) + kvl('Lucro bruto', R(fat - cus)) + kvl('Despesas com vencimento no mês', R(desp)) + kvl('Resultado líquido', '<span class="' + (fat - cus - desp >= 0 ? 'pos' : 'neg') + '">' + R(fat - cus - desp) + '</span>') + '</div>' +
    '<div class="card"><b>Despesas por categoria</b>' + (Object.keys(porCat).length ? Object.keys(porCat).sort(function (a, b) { return porCat[b] - porCat[a]; }).map(function (c) { return kvl(esc(c), R(porCat[c])); }).join('') : '<div class="mut">Nenhuma despesa com vencimento neste mês.</div>') + '</div></div>';
  return h;
}

function finReceber() {
  var l = aReceberLista(), f = FN.rf;
  if (f === 'atrasados') l = l.filter(function (p) { return p.ent && diasAte(p.ent) < 0; });
  if (f === 'proximos') l = l.filter(function (p) { return p.ent && diasAte(p.ent) >= 0; });
  var h = '<div class="card"><div class="row"><div><div class="mut">Total a receber nesta lista</div><div class="big">' + R(soma(l, saldoDe)) + '</div></div>' +
    '<div style="min-width:180px"><label style="margin-top:0">Mostrar</label><select onchange="FN.rf=this.value;render()">' + [['todos', 'Todos'], ['atrasados', 'Entrega já passou'], ['proximos', 'Entregas futuras']].map(function (x) { return '<option value="' + x[0] + '"' + (f === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div></div></div>';
  if (!l.length) return h + '<div class="card mut">Nenhum saldo a receber neste filtro. Quando um pedido tiver valor em aberto, ele aparece aqui.</div>';
  return h + l.map(function (p) {
    var dd = p.ent ? diasAte(p.ent) : null, tg = p.st === 'entregue' ? '<span class="tag late">Entregue sem quitar</span>' : dd !== null && dd < 0 ? '<span class="tag late">Entrega atrasada</span>' : dd === 0 ? '<span class="tag now">Entrega hoje</span>' : '';
    return '<div class="card"><div class="row"><div><b>' + esc(cliNome(p)) + '</b> ' + tg + '<div class="mut">Entrega ' + D(p.ent) + ' · ' + resumoItens(p) + '</div></div><div style="text-align:right"><div class="big" style="font-size:20px">' + R(saldoDe(p)) + '</div><div class="mut">de ' + R(tp(p)) + '</div></div></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start"><button class="btn sm" onclick="openPay(\'' + Q(p.id) + '\')">Receber</button><button class="btn ghost sm" onclick="msg(\'' + Q(p.id) + '\',\'cob\')">Cobrar no WhatsApp</button></div>' + payPanel(p) + '</div>';
  }).join('');
}

/* contas a pagar */
function novaConta() { FN.draft = { desc: '', v: '', venc: hoje(), cat: CATS[0], forn: '', rep: 1 }; render(); }
function editConta(i) { var x = by(db.despesas, i); if (!x) return; FN.draft = { id: x.id, desc: x.desc || '', v: String(x.v).replace('.', ','), venc: x.venc || '', cat: x.cat || CATS[0], forn: x.forn || '', rep: 1 }; render(); }
function saveConta() {
  var d = FN.draft, v = num(d.v);
  if (!d.desc.trim()) return toast('Descreva a conta.');
  if (!(v > 0)) return toast('Informe o valor.');
  if (!d.venc) return toast('Informe o vencimento.');
  if (d.id) {
    var x = by(db.despesas, d.id); Object.assign(x, { desc: d.desc.trim(), v: v, venc: d.venc, cat: d.cat, forn: d.forn });
  } else {
    var n = Math.min(24, Math.max(1, Math.floor(num(d.rep)) || 1));
    for (var k = 0; k < n; k++) db.despesas.push({ id: id(), desc: d.desc.trim() + (n > 1 ? ' (' + (k + 1) + '/' + n + ')' : ''), v: v, venc: addMeses(d.venc, k), cat: d.cat, forn: d.forn, pago: false, dpg: '' });
  }
  FN.draft = null; saveLocalDB(); render(); toast('Conta salva.');
}
function pagarConta(i, desfazer) {
  var x = by(db.despesas, i); if (!x) return;
  x.pago = !desfazer; x.dpg = desfazer ? '' : hoje(); saveLocalDB(); render();
}
function delConta(i) { if (!confirm('Excluir esta conta?')) return; db.despesas = db.despesas.filter(function (x) { return x.id !== i; }); saveLocalDB(); render(); }

function finPagar() {
  var dr = FN.draft, f = FN.pf, h = '';
  if (dr) {
    h += '<div class="card"><b>' + (dr.id ? 'Editar conta' : 'Nova conta a pagar') + '</b><label>Descrição</label><input value="' + esc(dr.desc) + '" oninput="FN.draft.desc=this.value" placeholder="Ex.: Conta de luz, Aluguel, Farinha…">' +
      '<div class="cols"><div><label>Valor (R$)</label><input inputmode="decimal" value="' + esc(dr.v) + '" oninput="FN.draft.v=this.value"></div><div><label>Vencimento</label><input type="date" value="' + esc(dr.venc) + '" onchange="FN.draft.venc=this.value"></div>' +
      '<div><label>Categoria</label><select onchange="FN.draft.cat=this.value">' + opts(CATS, dr.cat) + '</select></div>' +
      '<div><label>Fornecedor (opcional)</label><select onchange="FN.draft.forn=this.value"><option value="">—</option>' + db.fornecedores.map(function (s) { return '<option value="' + s.id + '"' + (s.id === dr.forn ? ' selected' : '') + '>' + esc(s.nome) + '</option>'; }).join('') + '</select></div></div>' +
      (dr.id ? '' : '<label>Repetir por quantos meses? (1 = só esta)</label><input inputmode="numeric" value="' + esc(dr.rep) + '" oninput="FN.draft.rep=this.value" style="max-width:140px">') +
      '<p><button class="btn" onclick="saveConta()">Salvar conta</button> <button class="btn ghost" onclick="FN.draft=null;render()">Cancelar</button></p></div>';
  }
  var todas = db.despesas, ab = todas.filter(function (x) { return !x.pago; }), vc = vencidas();
  h += '<div class="grid">' + kpi('Em aberto', R(soma(ab, function (x) { return num(x.v); })), ab.length + ' conta(s)') + kpi('Vencidas', '<span class="neg">' + R(soma(vc, function (x) { return num(x.v); })) + '</span>', vc.length + ' conta(s)') + '</div>';
  h += '<div class="row" style="margin-bottom:12px">' + (dr ? '<span></span>' : '<button class="btn" onclick="novaConta()">Nova conta a pagar</button>') +
    '<div style="min-width:170px"><select aria-label="Filtro de contas" onchange="FN.pf=this.value;render()">' + [['abertas', 'Em aberto'], ['pagas', 'Pagas'], ['todas', 'Todas']].map(function (x) { return '<option value="' + x[0] + '"' + (f === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select></div></div>';
  var l = todas.filter(function (x) { return f === 'todas' || (f === 'pagas' ? x.pago : !x.pago); }).sort(function (a, b) { var r = (a.venc || '').localeCompare(b.venc || ''); return f === 'pagas' ? -r : r; });
  if (!l.length) return h + '<div class="card mut">' + (todas.length ? 'Nenhuma conta neste filtro.' : 'Nenhuma conta cadastrada. Lance aluguel, energia, embalagens e compras para ver o fluxo de caixa.') + '</div>';
  return h + l.map(function (x) {
    var dd = x.venc ? diasAte(x.venc) : null, s = by(db.fornecedores, x.forn);
    var tg = x.pago ? '<span class="tag ok">Paga em ' + D(x.dpg || x.venc) + '</span>' : dd !== null && dd < 0 ? '<span class="tag late">Vencida há ' + (-dd) + ' d</span>' : dd === 0 ? '<span class="tag now">Vence hoje</span>' : dd !== null && dd <= 7 ? '<span class="tag">Vence em ' + dd + ' d</span>' : '';
    return '<div class="card"><div class="row"><div><b>' + esc(x.desc || 'Despesa') + '</b> ' + tg + '<div class="mut">Vencimento ' + D(x.venc) + (x.cat ? ' · ' + esc(x.cat) : '') + (s ? ' · ' + esc(s.nome) : '') + '</div></div><div class="big" style="font-size:20px">' + R(x.v) + '</div></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start">' + (x.pago ? '<button class="btn ghost sm" onclick="pagarConta(\'' + Q(x.id) + '\',true)">Desfazer pagamento</button>' : '<button class="btn sm" onclick="pagarConta(\'' + Q(x.id) + '\')">Marcar como paga</button>') +
      '<button class="btn ghost sm" onclick="editConta(\'' + Q(x.id) + '\')">Editar</button><button class="btn ghost sm" onclick="delConta(\'' + Q(x.id) + '\')">Excluir</button></div></div>';
  }).join('');
}

/* fluxo de caixa */
function finCaixa() {
  var m = finMes(), mv = movimentos(), ini = 0, ent = 0, sai = 0, doMes = [];
  mv.forEach(function (x) { if (x.d.slice(0, 7) < m) ini += x.v; else if (x.d.slice(0, 7) === m) { doMes.push(x); if (x.v > 0) ent += x.v; else sai -= x.v; } });
  var h = seletorMes() + '<div class="grid">' + kpi('Saldo anterior', R(ini)) + kpi('Entradas', '<span class="pos">' + R(ent) + '</span>') + kpi('Saídas', '<span class="neg">' + R(sai) + '</span>') + kpi('Saldo final', R(ini + ent - sai)) + '</div>';
  var acc = ini;
  h += '<div class="card"><b>Movimentações de ' + nomeMes(m).toLowerCase() + '</b>' + (doMes.length ? doMes.map(function (x) {
    acc += x.v;
    return '<div class="kv" style="align-items:flex-start"><span>' + D(x.d).slice(0, 5) + ' · ' + esc(x.txt) + (x.sub ? '<br><span class="mut">' + esc(x.sub) + '</span>' : '') + '</span><span style="text-align:right"><b class="' + (x.v >= 0 ? 'pos' : 'neg') + '">' + (x.v >= 0 ? '+' : '−') + R(Math.abs(x.v)) + '</b><br><span class="mut">saldo ' + R(acc) + '</span></span></div>';
  }).join('') : '<div class="mut" style="margin-top:6px">Nenhuma movimentação neste mês. Pagamentos de pedidos e contas pagas aparecem aqui.</div>') + '</div>';

  // previsão: próximos 30 dias
  var t0 = hoje(), faixas = [['Em atraso', null, t0], ['Próximos 7 dias', t0, addDias(t0, 7)], ['Dias 8 a 14', addDias(t0, 7), addDias(t0, 14)], ['Dias 15 a 21', addDias(t0, 14), addDias(t0, 21)], ['Dias 22 a 30', addDias(t0, 21), addDias(t0, 30)]];
  var ar = aReceberLista(), ap = db.despesas.filter(function (x) { return !x.pago && x.venc; });
  var base = 0; mv.forEach(function (x) { base += x.v; });   // saldo real acumulado em caixa
  var cum = base;
  var linhas = faixas.map(function (f) {
    var dentro = function (d) { if (!d) d = t0; return f[1] === null ? d < f[2] : (d >= f[1] && d < f[2]); };
    var r = soma(ar.filter(function (p) { return dentro(p.ent); }), saldoDe), pg = soma(ap.filter(function (x) { return dentro(x.venc); }), function (x) { return num(x.v); });
    cum += r - pg;
    return '<div class="kv"><span>' + f[0] + '</span><span style="text-align:right"><span class="pos">+' + R(r) + '</span> · <span class="neg">−' + R(pg) + '</span> · <b>' + R(cum) + '</b></span></div>';
  }).join('');
  return h + '<div class="card"><b>Previsão dos próximos 30 dias</b><div class="mut">Saldo atual em caixa: <b>' + R(base) + '</b>. Saldos a receber (por data de entrega) menos contas a pagar (por vencimento); o último valor de cada linha é o saldo projetado.</div>' + linhas + '</div>';
}

/* fornecedores */
function novoForn() { FN.sup = { nome: '', tel: '', obs: '' }; render(); }
function editForn(i) { var s = by(db.fornecedores, i); if (s) { FN.sup = { id: s.id, nome: s.nome, tel: s.tel || '', obs: s.obs || '' }; render(); } }
function saveForn() {
  var s = FN.sup; if (!s.nome.trim()) return toast('Informe o nome do fornecedor.');
  if (s.id) Object.assign(by(db.fornecedores, s.id), { nome: s.nome.trim(), tel: s.tel.trim(), obs: s.obs.trim() });
  else db.fornecedores.push({ id: id(), nome: s.nome.trim(), tel: s.tel.trim(), obs: s.obs.trim() });
  FN.sup = null; saveLocalDB(); render(); toast('Fornecedor salvo.');
}
function delForn(i) {
  if (!confirm('Excluir este fornecedor? As contas já lançadas continuam, mas ficam sem fornecedor.')) return;
  db.fornecedores = db.fornecedores.filter(function (x) { return x.id !== i; });
  db.despesas.forEach(function (x) { if (x.forn === i) x.forn = ''; });
  saveLocalDB(); render();
}
function finForn() {
  var s = FN.sup, h = '';
  if (s) h += '<div class="card"><b>' + (s.id ? 'Editar fornecedor' : 'Novo fornecedor') + '</b><div class="cols"><div><label>Nome</label><input value="' + esc(s.nome) + '" oninput="FN.sup.nome=this.value"></div><div><label>WhatsApp (com DDD)</label><input inputmode="tel" value="' + esc(s.tel) + '" oninput="FN.sup.tel=this.value"></div></div><label>Observações</label><input value="' + esc(s.obs) + '" oninput="FN.sup.obs=this.value" placeholder="Prazo, condições, produtos…"><p><button class="btn" onclick="saveForn()">Salvar fornecedor</button> <button class="btn ghost" onclick="FN.sup=null;render()">Cancelar</button></p></div>';
  else h += '<p><button class="btn" onclick="novoForn()">Novo fornecedor</button></p>';
  if (!db.fornecedores.length) return h + (s ? '' : '<div class="card mut">Cadastre onde você compra seus insumos para ligar cada conta a pagar ao fornecedor e ver quanto gasta com cada um.</div>');
  return h + db.fornecedores.map(function (f) {
    var cs = db.despesas.filter(function (x) { return x.forn === f.id; }), ab = soma(cs.filter(function (x) { return !x.pago; }), function (x) { return num(x.v); }), pg = soma(cs.filter(function (x) { return x.pago; }), function (x) { return num(x.v); });
    return '<div class="card"><div class="row"><div><b>' + esc(f.nome) + '</b><div class="mut">' + (f.tel ? esc(f.tel) : 'sem telefone') + (f.obs ? ' · ' + esc(f.obs) : '') + '</div></div><div style="text-align:right"><div class="mut">Em aberto <b>' + R(ab) + '</b></div><div class="mut">Já pago <b>' + R(pg) + '</b></div></div></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start">' + (f.tel ? '<a class="btn sm" target="_blank" rel="noopener" href="' + waLink(f.tel) + '">WhatsApp</a>' : '') + '<button class="btn ghost sm" onclick="editForn(\'' + Q(f.id) + '\')">Editar</button><button class="btn ghost sm" onclick="delForn(\'' + Q(f.id) + '\')">Excluir</button></div></div>';
  }).join('');
}

/* ------------------------------------------------------------------ PAINEL (início) */
function vEnt() {
  var m = mesAtual(), fat = 0, luc = 0, top = {}, op = [];
  db.pedidos.forEach(function (p) {
    if (!ativo(p)) return;
    if ((p.ent || '').slice(0, 7) === m) { fat += tp(p); luc += tp(p) - custoDe(p); p.itens.forEach(function (i) { top[i.nome] = (top[i.nome] || 0) + i.q; }); }
    if (p.st !== 'entregue') op.push(p);
  });
  op.sort(function (a, b) { return (a.ent || '9').localeCompare(b.ent || '9') || (a.hora || '').localeCompare(b.hora || ''); });
  var ar = aReceberLista(), mv = movimentos(), rec = 0, sai = 0;
  mv.forEach(function (x) { if (x.d.slice(0, 7) === m) { if (x.v > 0) rec += x.v; else sai -= x.v; } });
  var tops = Object.keys(top).sort(function (a, b) { return top[b] - top[a]; }).slice(0, 3);
  var low = db.ingredientes.filter(function (g) { return g.min && (g.est || 0) <= g.min; }).length;
  var vc = vencidas(), prox = db.despesas.filter(function (x) { return !x.pago && x.venc && diasAte(x.venc) >= 0 && diasAte(x.venc) <= 7; });
  var atras = op.filter(function (p) { return p.ent && diasAte(p.ent) < 0; }), semQ = db.pedidos.filter(function (p) { return p.st === 'entregue' && saldoDe(p) > 0.004; });
  var lot = diaLotado(hoje());

  var h = '<h2>Painel do mês</h2><div class="grid">' + kpi('Faturamento do mês', R(fat)) + kpi('Lucro estimado', R(luc), 'antes de despesas e encargos') + kpi('Pedidos pendentes', op.length) + kpi('A receber', R(soma(ar, saldoDe)), ar.length + ' pedido(s) com saldo') + '</div>';
  var av = [];
  if (atras.length) av.push(['<span class="tag late">' + atras.length + ' entrega(s) atrasada(s)</span>', "go('pedidos')"]);
  if (semQ.length) av.push(['<span class="tag late">' + semQ.length + ' entregue(s) com saldo em aberto · ' + R(soma(semQ, saldoDe)) + '</span>', "irFin('receber')"]);
  if (vc.length) av.push(['<span class="tag late">' + vc.length + ' conta(s) vencida(s) · ' + R(soma(vc, function (x) { return num(x.v); })) + '</span>', "FN.pf='abertas';irFin('pagar')"]);
  if (prox.length) av.push(['<span class="tag">' + prox.length + ' conta(s) vencem nos próximos 7 dias · ' + R(soma(prox, function (x) { return num(x.v); })) + '</span>', "FN.pf='abertas';irFin('pagar')"]);
  if (low) av.push(['<span class="tag late">' + low + ' ingrediente(s) com estoque baixo</span>', "go('ingredientes')"]);
  if (lot.over) av.push(['<span class="tag late">Capacidade de hoje ultrapassada</span>', "go('agenda')"]);
  if (av.length) h += '<div class="card"><b>Atenção</b>' + av.map(function (a) { return '<div class="kv"><span>' + a[0] + '</span><button class="btn ghost sm" onclick="' + a[1] + '">Ver</button></div>'; }).join('') + '</div>';
  h += '<div class="cols"><div class="card"><b>Resumo financeiro</b>' + kvl('Recebido no mês', R(rec)) + kvl('Despesas pagas', R(sai)) + kvl('Saldo do mês', '<span class="' + (rec - sai >= 0 ? 'pos' : 'neg') + '">' + R(rec - sai) + '</span>') + '</div>' +
    '<div class="card"><b>Produtos mais vendidos</b>' + (tops.map(function (n, i) { return kvl((i + 1) + '. ' + esc(n), top[n] + ' un.'); }).join('') || '<div class="mut">Sem vendas neste mês.</div>') + '</div></div><h2>Próximas entregas</h2>';
  if (!op.length) return h + '<div class="card mut">Nenhuma entrega pendente. Cadastre um pedido na aba Pedidos.' + (db.produtos.length ? '' : '<p><button class="btn ghost" onclick="demo()">Carregar dados de exemplo</button></p>') + '</div>';
  return h + op.map(function (p) {
    var sd = saldoDe(p);
    return '<div class="card"><div class="row"><div><b>' + D(p.ent) + (p.hora ? ' · ' + esc(p.hora) : '') + '</b> ' + urg(p.ent) + ' · ' + esc(cliNome(p)) + '<div class="mut">' + resumoItens(p) + '</div>' +
      (sd > 0.004 ? '<div class="mut">Saldo a receber: <b>' + R(sd) + '</b></div>' : '') + '</div><span><span class="tag">' + p.st + '</span></span></div>' +
      '<div class="row" style="margin-top:10px;justify-content:flex-start">' + (sd > 0.004 ? '<button class="btn ghost sm" onclick="msg(\'' + Q(p.id) + '\',\'cob\')">Cobrar saldo</button>' : '') +
      '<button class="btn ghost sm" onclick="msg(\'' + Q(p.id) + '\',\'lem\')">Lembrete</button><button class="btn sm" onclick="upO(\'' + Q(p.id) + '\',\'entregue\')">Marcar entregue</button></div></div>';
  }).join('');
}
